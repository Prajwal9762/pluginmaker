package com.capacitycheck;

import com.capacitycheck.Estimator.Sample;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class CapacityCheck extends JavaPlugin implements CommandExecutor, TabCompleter {

    private final List<Sample> samples = new ArrayList<>();
    private File file;
    private StressTest running;
    private String lastTest = null;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        file = new File(getDataFolder(), "samples.csv");
        load();
        int interval = Math.max(5, getConfig().getInt("sample-interval-seconds", 30)) * 20;
        Bukkit.getScheduler().runTaskTimer(this, this::sample, 100L, interval);
        Bukkit.getScheduler().runTaskTimer(this, this::save, 12000L, 12000L);
        getCommand("capacity").setExecutor(this);
        getCommand("capacity").setTabCompleter(this);
        loadTestResult();
        getLogger().info("CapacityCheck enabled. Loaded " + samples.size() + " samples.");
    }

    @Override
    public void onDisable() {
        if (running != null) running.shutdown();
        save();
    }

    // ---------- sampling ----------
    private double cpuNow() {
        var os = ManagementFactory.getOperatingSystemMXBean();
        if (os instanceof com.sun.management.OperatingSystemMXBean m) {
            double c = m.getProcessCpuLoad();
            return c < 0 ? -1 : c * 100.0;
        }
        return -1;
    }

    private double heapMb() {
        Runtime rt = Runtime.getRuntime();
        return (rt.totalMemory() - rt.freeMemory()) / 1048576.0;
    }

    private Sample current() {
        return new Sample(System.currentTimeMillis(), Bukkit.getOnlinePlayers().size(),
                Bukkit.getAverageTickTime(), Math.min(20.0, Bukkit.getTPS()[0]), heapMb(), cpuNow());
    }

    private void sample() {
        int max = getConfig().getInt("max-samples", 5000);
        synchronized (samples) {
            samples.add(current());
            while (samples.size() > max) samples.remove(0);
        }
    }

    // ---------- storage ----------
    private void load() {
        if (!file.exists()) return;
        try {
            for (String line : Files.readAllLines(file.toPath())) {
                String[] p = line.split(",");
                if (p.length != 6) continue;
                samples.add(new Sample(Long.parseLong(p[0]), Integer.parseInt(p[1]),
                        Double.parseDouble(p[2]), Double.parseDouble(p[3]),
                        Double.parseDouble(p[4]), Double.parseDouble(p[5])));
            }
        } catch (Exception e) {
            getLogger().warning("Could not read samples.csv: " + e.getMessage());
        }
    }

    private void save() {
        try {
            getDataFolder().mkdirs();
            List<String> lines = new ArrayList<>();
            synchronized (samples) {
                for (Sample s : samples)
                    lines.add(s.time() + "," + s.players() + "," + s.mspt() + "," + s.tps() + "," + s.heapMb() + "," + s.cpu());
            }
            Files.write(file.toPath(), lines);
        } catch (Exception e) {
            getLogger().warning("Could not save samples.csv: " + e.getMessage());
        }
    }

    // ---------- commands ----------
    private static String f(double d) { return String.format("%.1f", d); }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("capacitycheck.use")) {
            sender.sendMessage("§cNo permission.");
            return true;
        }
        String sub = args.length > 0 ? args[0].toLowerCase() : "";
        switch (sub) {
            case "reload" -> { reloadConfig(); sender.sendMessage("§aConfig reloaded."); }
            case "reset" -> {
                synchronized (samples) { samples.clear(); }
                save();
                sender.sendMessage("§aAll samples cleared. Collecting from scratch.");
            }
            case "live" -> live(sender);
            case "test" -> test(sender, args);
            default -> report(sender);
        }
        return true;
    }

    private void live(CommandSender sender) {
        Sample s = current();
        long maxMb = Runtime.getRuntime().maxMemory() / 1048576;
        sender.sendMessage("§8§m------§r §bLive Stats §8§m------");
        sender.sendMessage("§7Players: §f" + s.players());
        sender.sendMessage("§7TPS: §f" + f(s.tps()) + " §7| MSPT: §f" + f(s.mspt()) + " ms §7(limit 50)");
        sender.sendMessage("§7CPU (process): §f" + (s.cpu() < 0 ? "unavailable" : f(s.cpu()) + "%"));
        sender.sendMessage("§7RAM: §f" + f(s.heapMb()) + " / " + maxMb + " MB");
        sender.sendMessage("§7Samples stored: §f" + samples.size());
    }

    private void report(CommandSender sender) {
        List<Sample> copy;
        synchronized (samples) { copy = new ArrayList<>(samples); }
        double maxHeap = Runtime.getRuntime().maxMemory() / 1048576.0;
        var r = Estimator.estimate(copy,
                getConfig().getDouble("target-mspt", 42),
                getConfig().getDouble("target-cpu-percent", 85),
                maxHeap * getConfig().getDouble("target-memory-percent", 85) / 100.0,
                getConfig().getDouble("min-memory-per-player-mb", 40),
                getConfig().getDouble("safety-factor", 0.85));

        sender.sendMessage("§8§m------§r §bServer Capacity §8§m------");
        if (!r.enough) {
            if (lastTest != null) sender.sendMessage("§7Last stress test: §f" + lastTest);
            sender.sendMessage("§eNot enough live data yet (" + r.samples + " samples).");
            sender.sendMessage("§7Need at least 10 samples, 3 of them with players online.");
            sender.sendMessage("§7Leave the plugin running while players are online,");
            sender.sendMessage("§7or run §a/capacity test §7for a quick simulated result.");
            return;
        }
        sender.sendMessage("§aEstimated safe capacity: §f§l~" + Math.round(r.finalMax) + " players");
        sender.sendMessage("§7Main bottleneck: §f" + r.bottleneck);
        sender.sendMessage("§7Limit by tick time: §f" + lim(r.byMspt));
        sender.sendMessage("§7Limit by CPU: §f" + lim(r.byCpu));
        sender.sendMessage("§7Limit by RAM: §f" + lim(r.byMemory));
        if (lastTest != null) sender.sendMessage("§7Last stress test: §f" + lastTest);
        sender.sendMessage("§7Confidence: §f" + r.confidence + " §7(" + r.samples + " samples, seen "
                + r.minPlayers + "-" + r.maxPlayers + " players)");
        if (!r.confidence.equals("High"))
            sender.sendMessage("§7Tip: collect data at peak hours for a better estimate.");
    }

    private String lim(double d) {
        return Double.isInfinite(d) ? "no data" : "~" + Math.round(d) + " players";
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1)
            for (String o : List.of("live", "test", "reset", "reload"))
                if (o.startsWith(args[0].toLowerCase())) out.add(o);
        if (args.length == 2 && args[0].equalsIgnoreCase("test"))
            for (String o : List.of("confirm", "stop"))
                if (o.startsWith(args[1].toLowerCase())) out.add(o);
        return out;
    }

    // ---------- stress test ----------
    private void test(CommandSender sender, String[] args) {
        String a = args.length > 1 ? args[1].toLowerCase() : "";
        if (a.equals("stop")) {
            if (running != null && running.isRunning()) running.stop("stopped by admin");
            else sender.sendMessage("§cNo test is running.");
            return;
        }
        if (running != null && running.isRunning()) {
            sender.sendMessage("§cA test is already running. Use /capacity test stop");
            return;
        }
        int online = Bukkit.getOnlinePlayers().size();
        if (online > 0 && !a.equals("confirm")) {
            sender.sendMessage("§e" + online + " real player(s) are online. The test creates heavy load and");
            sender.sendMessage("§ewill LAG them. Run §a/capacity test confirm §eto start anyway,");
            sender.sendMessage("§eor run it when the server is empty.");
            return;
        }
        running = new StressTest(this, sender);
        if (!running.start()) running = null;
    }

    public void saveTestResult(long players, boolean atLeast) {
        lastTest = (atLeast ? "at least " : "~") + players + " players ("
                + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(new java.util.Date()) + ")";
        try {
            getDataFolder().mkdirs();
            Files.writeString(new File(getDataFolder(), "last-test.txt").toPath(), lastTest);
        } catch (Exception ignored) {
        }
    }

    private void loadTestResult() {
        try {
            File f = new File(getDataFolder(), "last-test.txt");
            if (f.exists()) lastTest = Files.readString(f.toPath()).trim();
        } catch (Exception ignored) {
        }
    }
}
