package com.capacitycheck;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.ToDoubleFunction;

public class Estimator {

    public record Sample(long time, int players, double mspt, double tps, double heapMb, double cpu) {}

    public static class Result {
        public int samples, minPlayers, maxPlayers;
        public double byMspt, byCpu, byMemory, finalMax;
        public String bottleneck = "n/a";
        public String confidence = "Low";
        public boolean enough;
    }

    /** Least-squares line y = intercept + slope * players. Returns null if not enough player-count spread. */
    private static double[] fit(List<Sample> s, ToDoubleFunction<Sample> f) {
        Set<Integer> distinct = new HashSet<>();
        for (Sample p : s) distinct.add(p.players());
        if (distinct.size() < 3) return null;
        int n = s.size();
        double sx = 0, sy = 0, sxx = 0, sxy = 0;
        for (Sample p : s) {
            double x = p.players(), y = f.applyAsDouble(p);
            sx += x; sy += y; sxx += x * x; sxy += x * y;
        }
        double d = n * sxx - sx * sx;
        if (Math.abs(d) < 1e-9) return null;
        double slope = (n * sxy - sx * sy) / d;
        double intercept = (sy - slope * sx) / n;
        return new double[]{slope, intercept};
    }

    /** Players at which `metric` reaches `target`. */
    private static double limit(List<Sample> all, ToDoubleFunction<Sample> metric, double target, double minSlope) {
        List<Sample> s = new ArrayList<>();
        for (Sample p : all) if (metric.applyAsDouble(p) >= 0) s.add(p);
        if (s.size() < 3) return Double.POSITIVE_INFINITY;

        double[] f = fit(s, metric);
        double slope, idle;
        if (f != null && f[0] > 0) {
            slope = Math.max(f[0], minSlope);
            idle = Math.max(f[1], 0);
        } else {
            // Fallback: compare current load against the quietest samples
            double minMetric = Double.MAX_VALUE;
            double sumP = 0, sumM = 0; int cnt = 0;
            for (Sample p : s) {
                double m = metric.applyAsDouble(p);
                minMetric = Math.min(minMetric, m);
                if (p.players() > 0) { sumP += p.players(); sumM += m; cnt++; }
            }
            if (cnt == 0) return Double.POSITIVE_INFINITY;
            idle = minMetric;
            slope = Math.max((sumM / cnt - idle) / (sumP / cnt), minSlope);
        }
        if (target <= idle) return 0;
        return (target - idle) / slope;
    }

    public static Result estimate(List<Sample> s, double targetMspt, double targetCpu,
                                  double targetMemMb, double minMemPerPlayerMb, double safety) {
        Result r = new Result();
        r.samples = s.size();
        r.minPlayers = Integer.MAX_VALUE;
        for (Sample p : s) {
            r.minPlayers = Math.min(r.minPlayers, p.players());
            r.maxPlayers = Math.max(r.maxPlayers, p.players());
        }
        long withPlayers = s.stream().filter(p -> p.players() > 0).count();
        r.enough = s.size() >= 10 && withPlayers >= 3;
        if (!r.enough) return r;

        r.byMspt = limit(s, Sample::mspt, targetMspt, 0.02);
        r.byCpu = limit(s, Sample::cpu, targetCpu, 0.05);
        r.byMemory = limit(s, Sample::heapMb, targetMemMb, minMemPerPlayerMb);

        double best = r.byMspt; r.bottleneck = "Tick time (CPU speed of main thread)";
        if (r.byCpu < best) { best = r.byCpu; r.bottleneck = "Total CPU usage"; }
        if (r.byMemory < best) { best = r.byMemory; r.bottleneck = "RAM (heap)"; }
        r.finalMax = Double.isInfinite(best) ? 0 : Math.min(best * safety, 5000);

        int range = r.maxPlayers - r.minPlayers;
        if (s.size() >= 100 && range >= 10) r.confidence = "High";
        else if (s.size() >= 30 && range >= 3) r.confidence = "Medium";
        return r;
    }
}
