package com.capacitycheck;

import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class StressTest {

    private final CapacityCheck plugin;
    private final CommandSender sender;
    private final Random rnd = new Random();
    private final AtomicInteger pending = new AtomicInteger();
    private final List<Entity> mobs = new ArrayList<>();
    private final List<double[]> steps = new ArrayList<>(); // {players, mspt, minHeapMb}

    private World world;
    private BukkitTask task;
    private boolean running, adding;
    private int virtual, secs, stepWait, msptCnt;
    private double msptSum, minHeap;

    private int maxVirtual, stepSize, radius, mobsPer, settle, measure, timeout;
    private double targetMspt, memStopPct, emergency, safety, maxHeapMb;
    private EntityType mobType;
    private String worldName;

    public StressTest(CapacityCheck plugin, CommandSender sender) {
        this.plugin = plugin;
        this.sender = sender;
    }

    public boolean isRunning() { return running; }

    private void say(String s) { sender.sendMessage("§8[§bCapacityTest§8] §7" + s); }

    private static String f(double d) { return String.format("%.1f", d); }

    private double heapMb() {
        Runtime rt = Runtime.getRuntime();
        return (rt.totalMemory() - rt.freeMemory()) / 1048576.0;
    }

    public boolean start() {
        FileConfiguration c = plugin.getConfig();
        worldName = c.getString("test.world-name", "capacitycheck_test");
        if (!worldName.startsWith("capacitycheck_")) {
            say("§ctest.world-name must start with 'capacitycheck_' (safety, the folder is deleted).");
            return false;
        }
        maxVirtual = Math.max(1, c.getInt("test.max-virtual-players", 150));
        stepSize = Math.max(1, c.getInt("test.step-size", 5));
        radius = Math.max(1, Math.min(12, c.getInt("test.chunk-radius", 5)));
        mobsPer = Math.max(0, c.getInt("test.mobs-per-player", 10));
        settle = Math.max(1, c.getInt("test.settle-seconds", 3));
        measure = Math.max(2, c.getInt("test.measure-seconds", 6));
        timeout = Math.max(10, c.getInt("test.step-timeout-seconds", 90));
        targetMspt = c.getDouble("test.target-mspt", 42);
        memStopPct = c.getDouble("test.memory-stop-percent", 88);
        emergency = c.getDouble("test.emergency-mspt", 120);
        safety = c.getDouble("test.safety-factor", 0.7);
        maxHeapMb = Runtime.getRuntime().maxMemory() / 1048576.0;
        try {
            mobType = EntityType.valueOf(c.getString("test.mob-type", "COW").toUpperCase());
        } catch (Exception e) {
            mobType = EntityType.COW;
        }

        if (Bukkit.getWorld(worldName) != null) {
            say("§cA world named " + worldName + " is already loaded.");
            return false;
        }
        deleteDir(new File(Bukkit.getWorldContainer(), worldName));

        say("Creating temporary world (server may freeze for a few seconds)...");
        world = new WorldCreator(worldName)
                .environment(World.Environment.NORMAL)
                .generateStructures(false)
                .createWorld();
        if (world == null) {
            say("§cCould not create the test world.");
            return false;
        }
        world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        world.setAutoSave(false);

        running = true;
        adding = false;
        resetMeasure();
        int stepCount = (int) Math.ceil(maxVirtual / (double) stepSize);
        int estSec = stepCount * (settle + measure + 4);
        say("§aTest started: up to " + maxVirtual + " virtual players, +" + stepSize
                + " per step. Max ~" + (estSec / 60 + 1) + " min. It stops earlier when limits are hit.");
        say("Measuring baseline first...");
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, 20L);
        return true;
    }

    private void resetMeasure() {
        secs = 0;
        msptSum = 0;
        msptCnt = 0;
        minHeap = Double.MAX_VALUE;
    }

    private void tick() {
        if (!running) return;
        double mspt = Bukkit.getAverageTickTime();
        if (virtual > 0 && mspt > emergency) {
            finish("server overloaded (" + f(mspt) + " ms tick)");
            return;
        }
        if (adding) {
            stepWait++;
            if (pending.get() == 0) {
                adding = false;
                resetMeasure();
            } else if (stepWait > timeout) {
                finish("chunk loading too slow, step timed out");
            }
            return;
        }
        secs++;
        if (secs > settle) {
            msptSum += mspt;
            msptCnt++;
            minHeap = Math.min(minHeap, heapMb());
        }
        if (secs >= settle + measure) endMeasure();
    }

    private void endMeasure() {
        double avg = msptSum / Math.max(1, msptCnt);
        double heap = minHeap == Double.MAX_VALUE ? heapMb() : minHeap;
        steps.add(new double[]{virtual, avg, heap});
        say("§f" + virtual + " §7virtual players -> MSPT §e" + f(avg) + " §7| RAM §f"
                + Math.round(heap) + "/" + Math.round(maxHeapMb) + " MB");

        if (avg >= targetMspt) { finish("tick-time limit reached"); return; }
        if (heap >= maxHeapMb * memStopPct / 100.0) { finish("RAM limit reached"); return; }
        if (virtual >= maxVirtual) { finish("reached max test size"); return; }
        addPlayers(stepSize);
        adding = true;
        stepWait = 0;
    }

    private void addPlayers(int k) {
        int side = (int) Math.ceil(Math.sqrt(maxVirtual));
        int spacing = 2 * radius + 2; // areas never overlap
        for (int j = 0; j < k && virtual < maxVirtual; j++) {
            int idx = virtual++;
            final int cx = (idx % side - side / 2) * spacing;
            final int cz = (idx / side - side / 2) * spacing;
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    final int x = cx + dx, z = cz + dz;
                    final boolean center = dx == 0 && dz == 0;
                    pending.incrementAndGet();
                    world.getChunkAtAsync(x, z, true).whenComplete((chunk, err) ->
                            Bukkit.getScheduler().runTask(plugin, () -> {
                                try {
                                    if (err == null && running && world != null) {
                                        world.addPluginChunkTicket(x, z, plugin);
                                        if (center) spawnMobs(x, z);
                                    }
                                } finally {
                                    pending.decrementAndGet();
                                }
                            }));
                }
            }
        }
    }

    private void spawnMobs(int chunkX, int chunkZ) {
        for (int i = 0; i < mobsPer; i++) {
            try {
                int x = chunkX * 16 + rnd.nextInt(16);
                int z = chunkZ * 16 + rnd.nextInt(16);
                int y = world.getHighestBlockYAt(x, z) + 1;
                Entity e = world.spawnEntity(new Location(world, x + 0.5, y, z + 0.5), mobType);
                e.setPersistent(false);
                mobs.add(e);
            } catch (Exception ignored) {
            }
        }
    }

    // ---- result ----
    private double limitBy(int col, double target) {
        for (int i = 0; i < steps.size(); i++) {
            double[] cur = steps.get(i);
            if (cur[col] >= target) {
                if (i == 0) return 0;
                double[] prev = steps.get(i - 1);
                double frac = (target - prev[col]) / (cur[col] - prev[col]);
                return prev[0] + frac * (cur[0] - prev[0]);
            }
        }
        return Double.POSITIVE_INFINITY;
    }

    private void finish(String reason) {
        if (!running) return;
        running = false;
        if (task != null) task.cancel();
        say("§eTest ended: " + reason);

        if (steps.size() < 2) {
            say("§cNot enough steps completed for a result.");
        } else {
            double limM = limitBy(1, targetMspt);
            double limR = limitBy(2, maxHeapMb * memStopPct / 100.0);
            double lim = Math.min(limM, limR);
            boolean atLeast = Double.isInfinite(lim);
            double raw = atLeast ? steps.get(steps.size() - 1)[0] : lim;
            long result = Math.round(raw * safety);
            say("§a§lResult: " + (atLeast ? "at least " : "~") + result + " players §7(raw simulated "
                    + Math.round(raw) + " x safety " + safety + ")");
            if (!atLeast) say("Bottleneck: §f" + (limM <= limR ? "tick time (CPU)" : "RAM"));
            else say("§7Your server passed the whole test. Raise test.max-virtual-players to find the limit.");
            plugin.saveTestResult(result, atLeast);
        }
        say("Cleaning up temporary world...");
        cleanup(false);
    }

    public void stop(String reason) { finish(reason); }

    /** Called on plugin disable: synchronous cleanup. */
    public void shutdown() {
        if (!running) return;
        running = false;
        if (task != null) task.cancel();
        cleanup(true);
    }

    private void cleanup(boolean sync) {
        for (Entity e : mobs) {
            try { e.remove(); } catch (Exception ignored) { }
        }
        mobs.clear();
        if (world == null) return;
        File dir = world.getWorldFolder();
        try { world.removePluginChunkTickets(plugin); } catch (Exception ignored) { }
        boolean ok = Bukkit.unloadWorld(world, false);
        world = null;
        if (!ok) {
            plugin.getLogger().warning("Could not unload test world; delete folder '" + dir.getName() + "' manually.");
            return;
        }
        if (sync) deleteDir(dir);
        else Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, () -> {
            deleteDir(dir);
            say("§aDone. Temporary world deleted.");
        }, 60L);
    }

    private static void deleteDir(File dir) {
        if (dir == null || !dir.exists() || !dir.getName().startsWith("capacitycheck_")) return;
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) deleteDirUnsafe(f);
                else f.delete();
            }
        }
        dir.delete();
    }

    private static void deleteDirUnsafe(File dir) {
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) deleteDirUnsafe(f);
                else f.delete();
            }
        }
        dir.delete();
    }
}
