# ChatCraft (Rust engine + Android app)

A Minecraft Java chat client. The Minecraft protocol, networking, login, chat parsing and
session logic are written in **Rust** (`rust/`). The Android UI is **Kotlin + Jetpack Compose +
Material 3** (`app/`), talking to Rust through JNI.

## Build the APK with GitHub Actions (no local setup)

1. Create a new GitHub repository and push everything in this folder to it
   (keep `.github/workflows/build-apk.yml`).
2. Open the **Actions** tab, then the run **Build ChatCraft APK** (it starts on every push;
   you can also press "Run workflow").
3. When it finishes, download the **ChatCraft-debug-apk** (or **ChatCraft-release-apk**) artifact,
   unzip it, and install the `.apk` on your phone (allow "Install unknown apps").

The workflow runs the Rust tests, cross-compiles the engine for arm64-v8a, armeabi-v7a and
x86_64 with `cargo-ndk`, then builds the APKs with Gradle. The release APK is signed with the
debug key so it installs directly; use your own keystore before distributing it.

## Build locally

```
cargo install cargo-ndk
rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android
cd rust && cargo ndk -t arm64-v8a -t armeabi-v7a -t x86_64 -o ../app/src/main/jniLibs build --release
cd .. && gradle assembleDebug        # or open the folder in Android Studio
```
Requires JDK 17, Android SDK 34 and NDK 26. Run the Rust tests with `cd rust && cargo test`.

## Layout

| Path | Purpose |
|---|---|
| `rust/src/codec.rs` | VarInt, strings, NBT skipping, packet framing, zlib compression |
| `rust/src/status.rs` | Server list ping: MOTD, players, version, latency |
| `rust/src/auth.rs` | Offline-mode UUID and username validation |
| `rust/src/session.rs` | Login, play state, keep-alive, chat, player list, movement, reconnect |
| `rust/src/chat.rs` | JSON text components to colour-coded text |
| `rust/src/ffi.rs` | JNI functions used by `Native.kt` |
| `rust/tests/mock_server.rs` | End-to-end tests against an in-process mock server |
| `app/.../AppViewModel.kt` | App state, polling the engine, navigation |
| `app/.../Screens.kt` | All 10 screens (Compose, Material 3, light/dark) |
| `app/.../Db.kt` | SQLite: saved servers and chat history |
| `app/.../ConnectionService.kt` | Foreground service that keeps a session alive in the background |

## Status (honest)

Works in tests (Rust, against a mock server written from the protocol spec):
status ping, offline-mode login, compression, keep-alive, system and player chat, player list,
position sync and movement packets, kick handling, reconnect, cancellation, online-mode refusal.

**Not verified yet:**
- The Kotlin/Compose app has not been compiled or run by me. Expect to fix small build errors
  on the first CI run; paste the error log and they are quick to correct.
- Nothing has been tested against a real Paper, Purpur or Spigot server, or on a real device.

**Not implemented:**
- Microsoft login and encryption, so online-mode servers cannot be joined.
- Protocol 763 (Minecraft 1.20.1) only. Newer servers need ViaVersion.
- Signed chat, SRV DNS records (enter the port explicitly), resource packs, world rendering.
- Storage uses Android's built-in SQLite from Kotlin instead of SQLite inside Rust.
