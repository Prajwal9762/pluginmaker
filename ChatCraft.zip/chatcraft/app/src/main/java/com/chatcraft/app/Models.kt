package com.chatcraft.app

data class Server(
    val id: Long = 0,
    val name: String,
    val host: String,
    val port: Int = 25565,
    val username: String,
    val auth: String = "offline",
    val favorite: Boolean = false,
    val lastConnected: Long = 0,
)

data class ChatLine(
    val ts: Long,
    /** "player" or "system" */
    val kind: String,
    val sender: String,
    /** Text with Minecraft section-sign formatting codes. */
    val text: String,
)

data class PlayerRow(val uuid: String, val name: String, val latency: Int)

data class StatusResult(
    val ok: Boolean,
    val error: String = "",
    val versionName: String = "",
    val protocol: Int = 0,
    val online: Int = 0,
    val max: Int = 0,
    val motd: String = "",
    val latencyMs: Long = 0,
    val exactProtocol: Boolean = false,
)

data class SessionStats(
    val bytesIn: Long = 0,
    val bytesOut: Long = 0,
    val packetsIn: Long = 0,
    val uptimeMs: Long = 0,
    val reconnects: Int = 0,
    val latencyMs: Int = -1,
    val x: Double = 0.0,
    val y: Double = 0.0,
    val z: Double = 0.0,
)

data class SessionInfo(val uuid: String, val username: String, val entityId: Int, val gameMode: Int)

sealed interface Screen {
    object Dashboard : Screen
    object Servers : Screen
    data class AddEdit(val serverId: Long?) : Screen
    data class AuthSelect(val serverId: Long) : Screen
    object Connecting : Screen
    object Chat : Screen
    object Players : Screen
    object Info : Screen
    object Settings : Screen
    object About : Screen
}
