@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class,
)

package com.chatcraft.app

import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val USERNAME_RE = Regex("^[A-Za-z0-9_]{3,16}$")

private fun authLabel(auth: String) =
    if (auth == "offline") "Offline mode (username only, not authenticated)" else "Microsoft account"

private fun formatBytes(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
    else -> String.format(Locale.US, "%.2f MB", b / (1024.0 * 1024.0))
}

private fun formatDuration(ms: Long): String {
    val s = ms / 1000
    return String.format(Locale.US, "%dh %02dm %02ds", s / 3600, (s % 3600) / 60, s % 60)
}

// ------------------------------------------------------------------------------------------------
// Root / shells
// ------------------------------------------------------------------------------------------------

@Composable
fun AppRoot(vm: AppViewModel) {
    when (val s = vm.current) {
        Screen.Dashboard, Screen.Servers, Screen.Settings -> TopLevelShell(vm, s)
        is Screen.AddEdit -> AddEditScreen(vm, s.serverId)
        is Screen.AuthSelect -> AuthSelectScreen(vm, s.serverId)
        Screen.Connecting -> ConnectingScreen(vm)
        Screen.Chat, Screen.Players, Screen.Info -> SessionShell(vm, s)
        Screen.About -> AboutScreen(vm)
    }
}

@Composable
fun Page(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
    bottomBar: @Composable () -> Unit = {},
    floating: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = actions,
            )
        },
        bottomBar = bottomBar,
        floatingActionButton = floating,
        content = content,
    )
}

@Composable
private fun TopLevelShell(vm: AppViewModel, s: Screen) {
    val title = when (s) {
        Screen.Servers -> "Servers"
        Screen.Settings -> "Settings"
        else -> "ChatCraft"
    }
    Page(
        title = title,
        actions = {
            if (s == Screen.Servers) {
                IconButton(onClick = { vm.refreshStatuses() }) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Refresh status")
                }
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = s == Screen.Dashboard,
                    onClick = { vm.resetTo(Screen.Dashboard) },
                    icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                    label = { Text("Dashboard") },
                )
                NavigationBarItem(
                    selected = s == Screen.Servers,
                    onClick = { vm.resetTo(Screen.Servers) },
                    icon = { Icon(Icons.Filled.Dns, contentDescription = null) },
                    label = { Text("Servers") },
                )
                NavigationBarItem(
                    selected = s == Screen.Settings,
                    onClick = { vm.resetTo(Screen.Settings) },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                    label = { Text("Settings") },
                )
            }
        },
        floating = {
            if (s == Screen.Servers) {
                FloatingActionButton(onClick = { vm.go(Screen.AddEdit(null)) }) {
                    Icon(Icons.Filled.Add, contentDescription = "Add server")
                }
            }
        },
    ) { padding ->
        when (s) {
            Screen.Servers -> ServersContent(vm, padding)
            Screen.Settings -> SettingsContent(vm, padding)
            else -> DashboardContent(vm, padding)
        }
    }
}

@Composable
private fun SessionShell(vm: AppViewModel, s: Screen) {
    Page(
        title = vm.activeServer?.name ?: "Session",
        onBack = { vm.back() },
        actions = {
            IconButton(onClick = { vm.disconnectAndLeave() }) {
                Icon(Icons.Filled.Close, contentDescription = "Disconnect")
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = s == Screen.Chat,
                    onClick = { vm.replaceTop(Screen.Chat) },
                    icon = { Icon(Icons.Filled.Chat, contentDescription = null) },
                    label = { Text("Chat") },
                )
                NavigationBarItem(
                    selected = s == Screen.Players,
                    onClick = { vm.replaceTop(Screen.Players) },
                    icon = { Icon(Icons.Filled.People, contentDescription = null) },
                    label = { Text("Players") },
                )
                NavigationBarItem(
                    selected = s == Screen.Info,
                    onClick = { vm.replaceTop(Screen.Info) },
                    icon = { Icon(Icons.Filled.Info, contentDescription = null) },
                    label = { Text("Info") },
                )
            }
        },
    ) { padding ->
        when (s) {
            Screen.Players -> PlayersContent(vm, padding)
            Screen.Info -> InfoContent(vm, padding)
            else -> ChatContent(vm, padding)
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Dashboard + server list
// ------------------------------------------------------------------------------------------------

@Composable
private fun DashboardContent(vm: AppViewModel, padding: PaddingValues) {
    val version = remember { Native.version() }
    val favorites = vm.servers.filter { it.favorite }
    val recent = vm.servers.filter { it.lastConnected > 0 }.sortedByDescending { it.lastConnected }.take(5)
    LazyColumn(
        modifier = Modifier.padding(padding).fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("ChatCraft", style = MaterialTheme.typography.headlineSmall)
                    Text(version, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "A Rust-powered Minecraft Java chat client. Offline-mode (online-mode=false) servers only in this build.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }
        if (vm.sessionActive) {
            item {
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Active session", style = MaterialTheme.typography.titleMedium)
                        Text("${vm.activeServer?.name ?: ""} \u2014 ${vm.connState}")
                        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                vm.go(if (vm.connState == "play") Screen.Chat else Screen.Connecting)
                            }) { Text("Open") }
                            OutlinedButton(onClick = { vm.disconnectAndLeave() }) { Text("Disconnect") }
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { vm.go(Screen.AddEdit(null)) }) { Text("Add server") }
                FilledTonalButton(onClick = { vm.resetTo(Screen.Servers) }) { Text("All servers") }
            }
        }
        if (favorites.isNotEmpty()) {
            item { Text("Favorites", style = MaterialTheme.typography.titleMedium) }
            items(favorites, key = { "f${it.id}" }) { s ->
                ServerCard(vm, s, showActions = false) { vm.go(Screen.AuthSelect(s.id)) }
            }
        }
        if (recent.isNotEmpty()) {
            item { Text("Recent connections", style = MaterialTheme.typography.titleMedium) }
            items(recent, key = { "r${it.id}" }) { s ->
                ServerCard(vm, s, showActions = false) { vm.go(Screen.AuthSelect(s.id)) }
            }
        }
        if (vm.servers.isEmpty()) {
            item { Text("No servers yet. Tap \"Add server\" to save your first one.") }
        }
    }
}

@Composable
private fun ServersContent(vm: AppViewModel, padding: PaddingValues) {
    var deleting by remember { mutableStateOf<Server?>(null) }
    LaunchedEffect(Unit) { vm.refreshStatuses() }
    if (vm.servers.isEmpty()) {
        Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No servers saved. Tap + to add one.", modifier = Modifier.padding(24.dp))
        }
    } else {
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(vm.servers, key = { it.id }) { s ->
                ServerCard(vm, s, showActions = true, onDelete = { deleting = s }) {
                    vm.go(Screen.AuthSelect(s.id))
                }
            }
        }
    }
    val d = deleting
    if (d != null) {
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete server?") },
            text = { Text("\"${d.name}\" and its saved chat history will be removed.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteServer(d.id); deleting = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun ServerCard(
    vm: AppViewModel,
    s: Server,
    showActions: Boolean,
    onDelete: () -> Unit = {},
    onClick: () -> Unit,
) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val st = vm.statuses[s.id]
    ElevatedCard(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${s.host}:${s.port}", style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = { vm.toggleFavorite(s) }) {
                    Icon(
                        if (s.favorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = if (s.favorite) "Remove favorite" else "Add favorite",
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            when {
                st == null -> Text("Checking\u2026", style = MaterialTheme.typography.bodySmall)
                st.ok -> {
                    Text(legacyToAnnotated(st.motd, dark), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${st.online}/${st.max} players \u2022 ${st.versionName} \u2022 ${st.latencyMs} ms" +
                            if (st.exactProtocol) "" else " \u2022 different protocol (may need ViaVersion)",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                else -> Text("Offline: ${st.error}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
            Text(
                "${authLabel(s.auth)} \u2022 ${s.username}",
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 4.dp),
            )
            if (showActions) {
                Row {
                    TextButton(onClick = { vm.go(Screen.AddEdit(s.id)) }) {
                        Icon(Icons.Filled.Edit, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("Edit")
                    }
                    TextButton(onClick = onDelete) {
                        Icon(Icons.Filled.Delete, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("Delete")
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Add / edit server, authentication selection, connecting
// ------------------------------------------------------------------------------------------------

@Composable
private fun AddEditScreen(vm: AppViewModel, serverId: Long?) {
    val existing = serverId?.let { vm.serverById(it) }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var host by remember { mutableStateOf(existing?.host ?: "") }
    var port by remember { mutableStateOf((existing?.port ?: 25565).toString()) }
    var username by remember { mutableStateOf(existing?.username ?: vm.defaultUsername) }
    var favorite by remember { mutableStateOf(existing?.favorite ?: false) }

    val portNum = port.toIntOrNull()
    val hostOk = host.isNotBlank() && !host.contains(' ')
    val portOk = portNum != null && portNum in 1..65535
    val userOk = USERNAME_RE.matches(username)
    val canSave = hostOk && portOk && userOk

    Page(title = if (existing == null) "Add server" else "Edit server", onBack = { vm.back() }) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it }, label = { Text("Nickname (optional)") },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = host, onValueChange = { host = it.trim() }, label = { Text("Host or IP") },
                singleLine = true, isError = host.isNotEmpty() && !hostOk, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = port, onValueChange = { port = it.filter { c -> c.isDigit() }.take(5) },
                label = { Text("Port") }, singleLine = true, isError = !portOk, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = username, onValueChange = { username = it.trim() }, label = { Text("Minecraft username") },
                singleLine = true, isError = username.isNotEmpty() && !userOk,
                supportingText = { Text("3-16 characters: letters, digits, underscore") },
                modifier = Modifier.fillMaxWidth(),
            )
            Text("Authentication mode", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = true, onClick = {}, label = { Text("Offline") })
                FilterChip(selected = false, onClick = {}, enabled = false, label = { Text("Microsoft (not in this build)") })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Favorite", Modifier.weight(1f))
                Switch(checked = favorite, onCheckedChange = { favorite = it })
            }
            Button(
                enabled = canSave,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    vm.saveServer(
                        Server(
                            id = existing?.id ?: 0,
                            name = name.ifBlank { host },
                            host = host,
                            port = portNum ?: 25565,
                            username = username,
                            auth = "offline",
                            favorite = favorite,
                            lastConnected = existing?.lastConnected ?: 0,
                        )
                    )
                    vm.back()
                },
            ) { Text("Save") }
        }
    }
}

@Composable
private fun AuthSelectScreen(vm: AppViewModel, serverId: Long) {
    val server = vm.serverById(serverId)
    if (server == null) {
        LaunchedEffect(Unit) { vm.back() }
        return
    }
    var username by remember { mutableStateOf(server.username.ifBlank { vm.defaultUsername }) }
    val userOk = USERNAME_RE.matches(username)
    Page(title = "Connect to ${server.name}", onBack = { vm.back() }) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Offline mode", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Enter any username. It is NOT verified and is not a Microsoft account. " +
                            "Works only on servers with online-mode=false.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Microsoft account", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Not implemented in this build, so online-mode servers cannot be joined yet.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            OutlinedTextField(
                value = username, onValueChange = { username = it.trim() }, label = { Text("Username") },
                singleLine = true, isError = username.isNotEmpty() && !userOk, modifier = Modifier.fillMaxWidth(),
            )
            Text("Selected: ${authLabel("offline")}", style = MaterialTheme.typography.labelLarge)
            Button(
                enabled = userOk, modifier = Modifier.fillMaxWidth(),
                onClick = { vm.startSession(server, username) },
            ) { Text("Connect to ${server.host}:${server.port}") }
        }
    }
}

@Composable
private fun ConnectingScreen(vm: AppViewModel) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val failed = vm.connState == "error" || vm.connState == "disconnected"
    Page(title = "Connecting", onBack = { vm.back() }) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (failed) {
                Text(
                    if (vm.connState == "error") "Could not connect" else "Disconnected",
                    style = MaterialTheme.typography.titleLarge,
                )
                Spacer(Modifier.height(8.dp))
                Text(legacyToAnnotated(vm.connDetail, dark))
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.reconnect() }) { Text("Retry") }
                    OutlinedButton(onClick = { vm.back() }) { Text("Back") }
                }
            } else {
                CircularProgressIndicator()
                Spacer(Modifier.height(16.dp))
                Text(
                    when (vm.connState) {
                        "login" -> "Logging in (offline mode)\u2026"
                        "reconnecting" -> "Reconnecting\u2026"
                        else -> "Connecting\u2026"
                    },
                    style = MaterialTheme.typography.titleMedium,
                )
                Text(vm.connDetail, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(16.dp))
                OutlinedButton(onClick = { vm.back() }) { Text("Cancel") }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Live session screens
// ------------------------------------------------------------------------------------------------

@Composable
private fun ChatContent(vm: AppViewModel, padding: PaddingValues) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val listState = rememberLazyListState()
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    LaunchedEffect(vm.chat.size) {
        val total = vm.chat.size
        if (total == 0) return@LaunchedEffect
        val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
        if (last < 0) listState.scrollToItem(total - 1)
        else if (last >= total - 3) listState.animateScrollToItem(total - 1)
    }

    fun send() {
        if (input.isNotBlank()) {
            vm.sendChat(input)
            input = ""
        }
    }

    Column(Modifier.padding(padding).fillMaxSize()) {
        if (vm.connState != "play") {
            Card(
                Modifier.fillMaxWidth().padding(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        when (vm.connState) {
                            "reconnecting" -> "Connection lost \u2014 reconnecting"
                            "disconnected" -> "Disconnected"
                            "error" -> "Connection error"
                            else -> vm.connState
                        },
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Text(stripCodes(vm.connDetail), style = MaterialTheme.typography.bodySmall)
                    if (vm.connState == "disconnected" || vm.connState == "error") {
                        TextButton(onClick = { vm.reconnect() }) { Text("Reconnect") }
                    }
                }
            }
        }
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            items(vm.chat.size) { idx ->
                val line = vm.chat[idx]
                val raw = if (line.kind == "player" && line.sender.isNotEmpty()) "<${line.sender}> ${line.text}" else line.text
                val body = remember(raw, dark) { legacyToAnnotated(raw, dark) }
                Row(
                    Modifier.fillMaxWidth().combinedClickable(
                        onClick = {},
                        onLongClick = {
                            clipboard.setText(AnnotatedString(stripCodes(raw)))
                            Toast.makeText(context, "Message copied", Toast.LENGTH_SHORT).show()
                        },
                    )
                ) {
                    if (vm.showTimestamps) {
                        Text(
                            timeFmt.format(Date(line.ts)),
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(end = 8.dp, top = 2.dp),
                        )
                    }
                    Text(body, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        HorizontalDivider()
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message or /command") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() }),
            )
            IconButton(onClick = { send() }, enabled = vm.connState == "play") {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
            }
        }
    }
}

@Composable
private fun PlayersContent(vm: AppViewModel, padding: PaddingValues) {
    LazyColumn(Modifier.padding(padding).fillMaxSize()) {
        item {
            val max = if (vm.maxPlayers >= 0) " / ${vm.maxPlayers}" else ""
            Text(
                "${vm.players.size}$max players online",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(16.dp),
            )
        }
        items(vm.players, key = { it.uuid }) { p ->
            ListItem(
                headlineContent = { Text(p.name) },
                supportingContent = { Text(p.uuid, style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace) },
                trailingContent = { Text(if (p.latency > 0) "${p.latency} ms" else "\u2014") },
            )
        }
        if (vm.activity.isNotEmpty()) {
            item {
                Text("Recent activity", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(16.dp))
            }
            items(vm.activity.size) { i ->
                Text(vm.activity[i], modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, Modifier.weight(0.4f), style = MaterialTheme.typography.labelLarge)
        Text(value, Modifier.weight(0.6f), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun InfoContent(vm: AppViewModel, padding: PaddingValues) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val server = vm.activeServer
    val info = vm.sessionInfo
    val st = vm.stats
    val ping = server?.let { vm.statuses[it.id] }
    Column(
        Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Server", style = MaterialTheme.typography.titleMedium)
                InfoRow("Address", "${server?.host}:${server?.port}")
                InfoRow("Authentication", authLabel(server?.auth ?: "offline"))
                InfoRow("Protocol used", "763 (Minecraft 1.20.1)")
                if (ping != null && ping.ok) {
                    InfoRow("Reported version", "${ping.versionName} (protocol ${ping.protocol})")
                    Text(legacyToAnnotated(ping.motd, dark), modifier = Modifier.padding(top = 4.dp))
                }
                InfoRow("Max players", if (vm.maxPlayers >= 0) vm.maxPlayers.toString() else "?")
            }
        }
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Session", style = MaterialTheme.typography.titleMedium)
                InfoRow("State", vm.connState)
                InfoRow("Username", info?.username ?: server?.username ?: "")
                InfoRow("UUID", info?.uuid ?: "")
                InfoRow("Latency", if (st.latencyMs > 0) "${st.latencyMs} ms" else "n/a")
                InfoRow("Uptime", formatDuration(st.uptimeMs))
                InfoRow("Received", "${formatBytes(st.bytesIn)} (${st.packetsIn} packets)")
                InfoRow("Sent", formatBytes(st.bytesOut))
                InfoRow("Reconnects", st.reconnects.toString())
                InfoRow(
                    "Position",
                    String.format(Locale.US, "%.1f, %.1f, %.1f", st.x, st.y, st.z),
                )
            }
        }
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Move (1 block)", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Sends raw position packets with no physics or collision checks. " +
                        "Servers may move you back.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { vm.move(0.0, 0.0, -1.0) }) { Text("North") }
                    FilledTonalButton(onClick = { vm.move(0.0, 0.0, 1.0) }) { Text("South") }
                    FilledTonalButton(onClick = { vm.move(-1.0, 0.0, 0.0) }) { Text("West") }
                    FilledTonalButton(onClick = { vm.move(1.0, 0.0, 0.0) }) { Text("East") }
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { vm.move(0.0, 1.0, 0.0) }) { Text("Up") }
                    FilledTonalButton(onClick = { vm.move(0.0, -1.0, 0.0) }) { Text("Down") }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Settings + about
// ------------------------------------------------------------------------------------------------

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SettingsContent(vm: AppViewModel, padding: PaddingValues) {
    Column(
        Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Theme", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((key, label) in listOf("system" to "System", "light" to "Light", "dark" to "Dark")) {
                FilterChip(selected = vm.themeMode == key, onClick = { vm.setTheme(key) }, label = { Text(label) })
            }
        }
        SwitchRow("Show chat timestamps", vm.showTimestamps) { vm.setTimestamps(it) }
        SwitchRow("Reconnect automatically after connection loss", vm.autoReconnect) { vm.setAutoReconnect(it) }
        OutlinedTextField(
            value = vm.defaultUsername,
            onValueChange = { vm.setDefaultUsername(it.trim()) },
            label = { Text("Default username") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedButton(onClick = { vm.clearHistory() }) { Text("Clear all chat history") }
        HorizontalDivider()
        TextButton(onClick = { vm.go(Screen.About) }) { Text("About ChatCraft") }
    }
}

@Composable
private fun AboutScreen(vm: AppViewModel) {
    val version = remember { Native.version() }
    Page(title = "About", onBack = { vm.back() }) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("ChatCraft 0.1.0", style = MaterialTheme.typography.headlineSmall)
            Text(version, style = MaterialTheme.typography.bodySmall)
            Text("What this build does", style = MaterialTheme.typography.titleMedium)
            Text(
                "\u2022 Talks the Minecraft Java protocol directly from Rust (no Mineflayer, no Node.js).\n" +
                    "\u2022 Server status: MOTD, player counts, version, latency.\n" +
                    "\u2022 Offline-mode login (online-mode=false), compression, keep-alive, reconnect.\n" +
                    "\u2022 Live chat with colours, commands, player list, basic movement.\n" +
                    "\u2022 Protocol 763 (Minecraft 1.20.1). Newer servers work only through ViaVersion."
            )
            Text("Not implemented yet", style = MaterialTheme.typography.titleMedium)
            Text(
                "\u2022 Microsoft login and encrypted (online-mode) servers.\n" +
                    "\u2022 Signed chat, SRV DNS lookup (enter the port explicitly), resource packs, world rendering."
            )
            Text("Testing status", style = MaterialTheme.typography.titleMedium)
            Text(
                "The Rust engine is covered by unit tests and end-to-end tests against a mock server. " +
                    "It has not yet been verified against real Paper or Purpur servers."
            )
            Text(
                "Offline-mode names are not authenticated Microsoft accounts.",
                style = MaterialTheme.typography.labelLarge,
            )
        }
    }
}
