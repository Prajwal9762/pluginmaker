//! Authentication helpers.
//!
//! Only offline-mode (`online-mode=false`) is implemented. Offline names are NOT
//! authenticated Microsoft accounts and the UI labels them as such.

use crate::error::{Error, Result};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AuthMode {
    Offline,
    /// Declared so the UI/API can name it, but not implemented in this build.
    Microsoft,
}

impl AuthMode {
    pub fn parse(s: &str) -> AuthMode {
        if s.eq_ignore_ascii_case("microsoft") {
            AuthMode::Microsoft
        } else {
            AuthMode::Offline
        }
    }
}

/// Vanilla offline UUID: name-based (v3) UUID of "OfflinePlayer:<name>".
pub fn offline_uuid(name: &str) -> [u8; 16] {
    let mut h = md5::compute(format!("OfflinePlayer:{name}")).0;
    h[6] = (h[6] & 0x0f) | 0x30;
    h[8] = (h[8] & 0x3f) | 0x80;
    h
}

pub fn uuid_to_string(u: &[u8; 16]) -> String {
    let h: String = u.iter().map(|b| format!("{b:02x}")).collect();
    format!("{}-{}-{}-{}-{}", &h[0..8], &h[8..12], &h[12..16], &h[16..20], &h[20..32])
}

pub fn validate_username(name: &str) -> Result<()> {
    let ok = (3..=16).contains(&name.len())
        && name.chars().all(|c| c.is_ascii_alphanumeric() || c == '_');
    if ok {
        Ok(())
    } else {
        Err(Error::Protocol(
            "Username must be 3-16 characters: letters, digits or underscore".into(),
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn offline_uuid_matches_vanilla() {
        // Reference values computed independently (Python hashlib) and the well-known "Notch" value.
        assert_eq!(uuid_to_string(&offline_uuid("Notch")), "b50ad385-829d-3141-a216-7e7d7539ba7f");
        assert_eq!(uuid_to_string(&offline_uuid("Steve")), "5627dd98-e6be-3c21-b8a8-e92344183641");
        assert_eq!(uuid_to_string(&offline_uuid("MrBoss")), "884ff223-4804-3467-b3d6-6734dc93a09e");
    }

    #[test]
    fn username_rules() {
        assert!(validate_username("Steve_1").is_ok());
        assert!(validate_username("ab").is_err());
        assert!(validate_username("this_name_is_way_too_long").is_err());
        assert!(validate_username("bad name").is_err());
    }
}
