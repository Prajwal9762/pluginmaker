//! Low-level Minecraft wire format: VarInt, strings, packet framing and zlib compression.

use crate::error::{Error, Result};
use flate2::read::ZlibDecoder;
use flate2::write::ZlibEncoder;
use flate2::Compression;
use std::io::{Read, Write};
use tokio::io::{AsyncRead, AsyncReadExt};

pub const MAX_PACKET: usize = 8 * 1024 * 1024;

pub fn write_varint(buf: &mut Vec<u8>, v: i32) {
    let mut u = v as u32;
    loop {
        if u & !0x7F == 0 {
            buf.push(u as u8);
            return;
        }
        buf.push((u & 0x7F) as u8 | 0x80);
        u >>= 7;
    }
}

pub fn write_string(buf: &mut Vec<u8>, s: &str) {
    write_varint(buf, s.len() as i32);
    buf.extend_from_slice(s.as_bytes());
}

pub fn write_i64(buf: &mut Vec<u8>, v: i64) {
    buf.extend_from_slice(&v.to_be_bytes());
}
pub fn write_f64(buf: &mut Vec<u8>, v: f64) {
    buf.extend_from_slice(&v.to_be_bytes());
}
pub fn write_f32(buf: &mut Vec<u8>, v: f32) {
    buf.extend_from_slice(&v.to_be_bytes());
}

/// Cursor over a packet body.
pub struct Reader<'a> {
    data: &'a [u8],
    pos: usize,
}

impl<'a> Reader<'a> {
    pub fn new(data: &'a [u8]) -> Self {
        Reader { data, pos: 0 }
    }
    pub fn remaining(&self) -> usize {
        self.data.len() - self.pos
    }
    pub fn read_bytes(&mut self, n: usize) -> Result<&'a [u8]> {
        if self.remaining() < n {
            return Err(Error::Eof);
        }
        let s = &self.data[self.pos..self.pos + n];
        self.pos += n;
        Ok(s)
    }
    pub fn skip(&mut self, n: usize) -> Result<()> {
        self.read_bytes(n).map(|_| ())
    }
    pub fn read_u8(&mut self) -> Result<u8> {
        Ok(self.read_bytes(1)?[0])
    }
    pub fn read_i8(&mut self) -> Result<i8> {
        Ok(self.read_u8()? as i8)
    }
    pub fn read_bool(&mut self) -> Result<bool> {
        Ok(self.read_u8()? != 0)
    }
    pub fn read_u16(&mut self) -> Result<u16> {
        let b = self.read_bytes(2)?;
        Ok(u16::from_be_bytes([b[0], b[1]]))
    }
    pub fn read_i32(&mut self) -> Result<i32> {
        let b = self.read_bytes(4)?;
        Ok(i32::from_be_bytes([b[0], b[1], b[2], b[3]]))
    }
    pub fn read_i64(&mut self) -> Result<i64> {
        let b = self.read_bytes(8)?;
        let mut a = [0u8; 8];
        a.copy_from_slice(b);
        Ok(i64::from_be_bytes(a))
    }
    pub fn read_f32(&mut self) -> Result<f32> {
        Ok(f32::from_bits(self.read_i32()? as u32))
    }
    pub fn read_f64(&mut self) -> Result<f64> {
        Ok(f64::from_bits(self.read_i64()? as u64))
    }
    pub fn read_varint(&mut self) -> Result<i32> {
        let mut result: u32 = 0;
        for i in 0..5 {
            let b = self.read_u8()?;
            result |= ((b & 0x7F) as u32) << (7 * i);
            if b & 0x80 == 0 {
                return Ok(result as i32);
            }
        }
        Err(Error::VarIntTooLong)
    }
    pub fn read_string(&mut self) -> Result<String> {
        let len = self.read_varint()?;
        if len < 0 || len as usize > 32767 * 4 {
            return Err(Error::TooLarge(len.max(0) as usize));
        }
        let b = self.read_bytes(len as usize)?;
        String::from_utf8(b.to_vec()).map_err(|_| Error::BadUtf8)
    }
    pub fn read_uuid(&mut self) -> Result<[u8; 16]> {
        let b = self.read_bytes(16)?;
        let mut a = [0u8; 16];
        a.copy_from_slice(b);
        Ok(a)
    }
    pub fn read_opt_string(&mut self) -> Result<Option<String>> {
        if self.read_bool()? {
            Ok(Some(self.read_string()?))
        } else {
            Ok(None)
        }
    }
}

/// Skip one NBT value (named-root format used by 1.20.1 network NBT).
pub fn skip_nbt(r: &mut Reader) -> Result<()> {
    let t = r.read_u8()?;
    if t == 0 {
        return Ok(());
    }
    let name_len = r.read_u16()? as usize;
    r.skip(name_len)?;
    skip_nbt_payload(r, t, 0)
}

fn skip_nbt_payload(r: &mut Reader, t: u8, depth: u32) -> Result<()> {
    if depth > 512 {
        return Err(Error::Protocol("NBT nested too deeply".into()));
    }
    match t {
        1 => r.skip(1),
        2 => r.skip(2),
        3 | 5 => r.skip(4),
        4 | 6 => r.skip(8),
        7 => {
            let n = r.read_i32()?.max(0) as usize;
            r.skip(n)
        }
        8 => {
            let n = r.read_u16()? as usize;
            r.skip(n)
        }
        9 => {
            let it = r.read_u8()?;
            let n = r.read_i32()?.max(0);
            for _ in 0..n {
                skip_nbt_payload(r, it, depth + 1)?;
            }
            Ok(())
        }
        10 => loop {
            let it = r.read_u8()?;
            if it == 0 {
                return Ok(());
            }
            let nl = r.read_u16()? as usize;
            r.skip(nl)?;
            skip_nbt_payload(r, it, depth + 1)?;
        },
        11 => {
            let n = r.read_i32()?.max(0) as usize;
            r.skip(n * 4)
        }
        12 => {
            let n = r.read_i32()?.max(0) as usize;
            r.skip(n * 8)
        }
        other => Err(Error::Protocol(format!("unknown NBT tag {other}"))),
    }
}

/// Build a framed packet. `payload` = packet id VarInt + fields.
/// `threshold < 0` means compression is off.
pub fn encode_packet(payload: &[u8], threshold: i32) -> Vec<u8> {
    let mut body = Vec::with_capacity(payload.len() + 8);
    if threshold < 0 {
        body.extend_from_slice(payload);
    } else if payload.len() >= threshold as usize {
        write_varint(&mut body, payload.len() as i32);
        let mut enc = ZlibEncoder::new(Vec::new(), Compression::fast());
        enc.write_all(payload).expect("write to Vec");
        body.extend_from_slice(&enc.finish().expect("finish to Vec"));
    } else {
        write_varint(&mut body, 0);
        body.extend_from_slice(payload);
    }
    let mut frame = Vec::with_capacity(body.len() + 5);
    write_varint(&mut frame, body.len() as i32);
    frame.extend_from_slice(&body);
    frame
}

async fn read_varint_async<R: AsyncRead + Unpin>(r: &mut R) -> Result<i32> {
    let mut result: u32 = 0;
    for i in 0..5 {
        let b = r.read_u8().await?;
        result |= ((b & 0x7F) as u32) << (7 * i);
        if b & 0x80 == 0 {
            return Ok(result as i32);
        }
    }
    Err(Error::VarIntTooLong)
}

/// Read one packet and return its decompressed payload (packet id + fields).
/// Returns the payload and the number of wire bytes consumed.
pub async fn read_packet<R: AsyncRead + Unpin>(r: &mut R, threshold: i32) -> Result<(Vec<u8>, usize)> {
    let len = read_varint_async(r).await?;
    if len < 0 || len as usize > MAX_PACKET {
        return Err(Error::TooLarge(len.max(0) as usize));
    }
    let mut body = vec![0u8; len as usize];
    r.read_exact(&mut body).await?;
    let wire = body.len() + 3;
    if threshold < 0 {
        return Ok((body, wire));
    }
    let mut rd = Reader::new(&body);
    let data_len = rd.read_varint()?;
    let rest = &body[body.len() - rd.remaining()..];
    if data_len == 0 {
        return Ok((rest.to_vec(), wire));
    }
    if data_len < 0 || data_len as usize > MAX_PACKET {
        return Err(Error::TooLarge(data_len.max(0) as usize));
    }
    let mut out = Vec::with_capacity(data_len as usize);
    ZlibDecoder::new(rest)
        .take(data_len as u64 + 1)
        .read_to_end(&mut out)
        .map_err(|e| Error::Protocol(format!("zlib: {e}")))?;
    if out.len() != data_len as usize {
        return Err(Error::Protocol("decompressed size mismatch".into()));
    }
    Ok((out, wire))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn varint_known_values() {
        let mut b = Vec::new();
        write_varint(&mut b, 300);
        assert_eq!(b, [0xAC, 0x02]);
        b.clear();
        write_varint(&mut b, -1);
        assert_eq!(b, [0xFF, 0xFF, 0xFF, 0xFF, 0x0F]);
        b.clear();
        write_varint(&mut b, 0);
        assert_eq!(b, [0]);
    }

    #[test]
    fn varint_roundtrip() {
        for v in [0, 1, 127, 128, 255, 25565, 2097151, i32::MAX, -1, i32::MIN] {
            let mut b = Vec::new();
            write_varint(&mut b, v);
            assert_eq!(Reader::new(&b).read_varint().unwrap(), v);
        }
    }

    #[test]
    fn string_roundtrip_unicode() {
        let mut b = Vec::new();
        write_string(&mut b, "héllo ✓ नमस्ते");
        assert_eq!(Reader::new(&b).read_string().unwrap(), "héllo ✓ नमस्ते");
    }

    #[test]
    fn truncated_reads_error() {
        assert!(Reader::new(&[0x80]).read_varint().is_err());
        assert!(Reader::new(&[5, b'a']).read_string().is_err());
    }

    #[tokio::test]
    async fn framing_roundtrip_all_modes() {
        let small = vec![0x10, 1, 2, 3];
        let big: Vec<u8> = (0..5000u32).map(|i| (i % 7) as u8).collect();
        for (payload, threshold) in [(&small, -1), (&small, 256), (&big, 256), (&big, -1)] {
            let frame = encode_packet(payload, threshold);
            let mut cur = std::io::Cursor::new(frame);
            let (got, _) = read_packet(&mut cur, threshold).await.unwrap();
            assert_eq!(&got, payload, "threshold {threshold}");
        }
    }

    #[test]
    fn nbt_skip_compound() {
        // compound "" { string "a" = "xy", list<int> "l" = [1,2] }
        let mut d = vec![10, 0, 0];
        d.extend_from_slice(&[8, 0, 1, b'a', 0, 2, b'x', b'y']);
        d.extend_from_slice(&[9, 0, 1, b'l', 3, 0, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0, 2]);
        d.push(0);
        d.push(0xAA);
        let mut r = Reader::new(&d);
        skip_nbt(&mut r).unwrap();
        assert_eq!(r.read_u8().unwrap(), 0xAA);
    }
}
