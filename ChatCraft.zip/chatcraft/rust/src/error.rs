use std::fmt;

#[derive(Debug)]
pub enum Error {
    Eof,
    VarIntTooLong,
    BadUtf8,
    TooLarge(usize),
    Io(std::io::Error),
    Protocol(String),
    /// The server ended the connection and gave a reason (already converted to §-codes).
    Disconnected(String),
    Timeout,
    /// Server asked for encryption (online-mode) but this build has no Microsoft login.
    OnlineModeRequired,
    Cancelled,
}

pub type Result<T> = std::result::Result<T, Error>;

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Error::Eof => write!(f, "unexpected end of packet"),
            Error::VarIntTooLong => write!(f, "VarInt is too long"),
            Error::BadUtf8 => write!(f, "invalid UTF-8 string"),
            Error::TooLarge(n) => write!(f, "packet or field too large ({n} bytes)"),
            Error::Io(e) => write!(f, "network error: {e}"),
            Error::Protocol(s) => write!(f, "protocol error: {s}"),
            Error::Disconnected(s) => write!(f, "{s}"),
            Error::Timeout => write!(f, "connection timed out"),
            Error::OnlineModeRequired => write!(
                f,
                "This server is in online-mode and requires a Microsoft-authenticated account. \
                 Microsoft login is not implemented in this build; use an offline-mode (online-mode=false) server."
            ),
            Error::Cancelled => write!(f, "cancelled"),
        }
    }
}

impl std::error::Error for Error {}

impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Self {
        match e.kind() {
            std::io::ErrorKind::UnexpectedEof => Error::Io(std::io::Error::new(
                std::io::ErrorKind::UnexpectedEof,
                "connection closed by server",
            )),
            _ => Error::Io(e),
        }
    }
}
