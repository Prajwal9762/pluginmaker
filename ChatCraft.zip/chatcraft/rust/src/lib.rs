//! ChatCraft core: a from-scratch Minecraft Java protocol client written in Rust.
//! Targets protocol 763 (Minecraft 1.20.1). Offline-mode login only.

pub mod auth;
pub mod chat;
pub mod codec;
pub mod error;
pub mod ffi;
pub mod session;
pub mod status;
