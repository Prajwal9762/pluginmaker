//! A live connection to a Minecraft server (protocol 763 / 1.20.1, offline-mode login).
//!
//! The Android side polls `Shared::poll_json()`; everything else happens on a Tokio runtime.

use crate::auth::{self, AuthMode};
use crate::chat;
use crate::codec::*;
use crate::error::{Error, Result};
use crate::status::{connect_tcp, handshake_payload, PROTOCOL_VERSION};
use serde::Serialize;
use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, AtomicI32, AtomicU32, AtomicU64, Ordering::Relaxed};
use std::sync::{Arc, Mutex, MutexGuard, OnceLock};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};
use tokio::io::{AsyncRead, AsyncWriteExt, BufReader};
use tokio::sync::{mpsc, Notify};

#[derive(Debug, Clone)]
pub struct ConnectParams {
    pub host: String,
    pub port: u16,
    pub username: String,
    pub auth: AuthMode,
    pub protocol: i32,
    pub auto_reconnect: bool,
    pub max_retries: u32,
}

impl ConnectParams {
    pub fn offline(host: &str, port: u16, username: &str) -> Self {
        ConnectParams {
            host: host.to_string(),
            port,
            username: username.to_string(),
            auth: AuthMode::Offline,
            protocol: PROTOCOL_VERSION,
            auto_reconnect: true,
            max_retries: 5,
        }
    }
}

#[derive(Serialize, Clone, Debug)]
pub struct PlayerJson {
    pub uuid: String,
    pub name: String,
    pub latency: i32,
}

#[derive(Serialize, Clone, Debug)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum Event {
    State { state: String, detail: String },
    /// kind: "player" | "system"
    Chat { kind: String, sender: String, text: String, ts: i64 },
    Players { players: Vec<PlayerJson>, max_players: i32 },
    Info { max_players: i32, entity_id: i32, game_mode: i32, uuid: String, username: String },
    Position { x: f64, y: f64, z: f64 },
    Presence { name: String, joined: bool },
}

fn lock<T>(m: &Mutex<T>) -> MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

pub fn now_ms() -> i64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis() as i64).unwrap_or(0)
}

const MAX_QUEUED_EVENTS: usize = 5000;

pub struct Shared {
    events: Mutex<Vec<Event>>,
    state: Mutex<(String, String)>,
    out_tx: Mutex<Option<mpsc::UnboundedSender<Vec<u8>>>>,
    threshold: AtomicI32,
    pos: Mutex<(f64, f64, f64, f32, f32)>,
    bytes_in: AtomicU64,
    bytes_out: AtomicU64,
    packets_in: AtomicU64,
    play_since_ms: Mutex<i64>,
    reconnects: AtomicU32,
    self_latency: AtomicI32,
    reached_play: AtomicBool,
    cancelled: AtomicBool,
    cancel: Notify,
}

impl Shared {
    pub fn new() -> Arc<Shared> {
        Arc::new(Shared {
            events: Mutex::new(Vec::new()),
            state: Mutex::new(("connecting".into(), String::new())),
            out_tx: Mutex::new(None),
            threshold: AtomicI32::new(-1),
            pos: Mutex::new((0.0, 0.0, 0.0, 0.0, 0.0)),
            bytes_in: AtomicU64::new(0),
            bytes_out: AtomicU64::new(0),
            packets_in: AtomicU64::new(0),
            play_since_ms: Mutex::new(0),
            reconnects: AtomicU32::new(0),
            self_latency: AtomicI32::new(-1),
            reached_play: AtomicBool::new(false),
            cancelled: AtomicBool::new(false),
            cancel: Notify::new(),
        })
    }

    fn push(&self, e: Event) {
        let mut q = lock(&self.events);
        if q.len() >= MAX_QUEUED_EVENTS {
            q.remove(0);
        }
        q.push(e);
    }

    fn set_state(&self, state: &str, detail: impl Into<String>) {
        let detail = detail.into();
        *lock(&self.state) = (state.to_string(), detail.clone());
        self.push(Event::State { state: state.to_string(), detail });
    }

    fn send_raw(&self, payload: Vec<u8>) -> bool {
        match lock(&self.out_tx).as_ref() {
            Some(tx) => tx.send(payload).is_ok(),
            None => false,
        }
    }

    pub fn disconnect(&self) {
        self.cancelled.store(true, Relaxed);
        self.cancel.notify_one();
    }

    /// Send a chat message (or a command when it starts with '/').
    pub fn send_chat(&self, text: &str) -> Result<()> {
        let text = text.trim_end();
        if text.is_empty() {
            return Ok(());
        }
        if text.chars().count() > 256 {
            return Err(Error::Protocol("message is longer than 256 characters".into()));
        }
        let ts = now_ms();
        let mut p = Vec::new();
        if let Some(cmd) = text.strip_prefix('/') {
            write_varint(&mut p, 0x04);
            write_string(&mut p, cmd);
            write_i64(&mut p, ts);
            write_i64(&mut p, 0);
            write_varint(&mut p, 0); // no argument signatures
            write_varint(&mut p, 0); // message count
            p.extend_from_slice(&[0, 0, 0]); // acknowledged bitset
        } else {
            write_varint(&mut p, 0x05);
            write_string(&mut p, text);
            write_i64(&mut p, ts);
            write_i64(&mut p, 0);
            p.push(0); // no signature (offline-mode)
            write_varint(&mut p, 0);
            p.extend_from_slice(&[0, 0, 0]);
        }
        if self.send_raw(p) {
            Ok(())
        } else {
            Err(Error::Protocol("not connected".into()))
        }
    }

    /// Move by a relative offset (no collision or physics; the server may correct it).
    pub fn move_by(&self, dx: f64, dy: f64, dz: f64) -> Result<()> {
        let (x, y, z) = {
            let mut p = lock(&self.pos);
            p.0 += dx;
            p.1 += dy;
            p.2 += dz;
            (p.0, p.1, p.2)
        };
        let mut p = Vec::new();
        write_varint(&mut p, 0x14);
        write_f64(&mut p, x);
        write_f64(&mut p, y);
        write_f64(&mut p, z);
        p.push(1);
        if self.send_raw(p) {
            self.push(Event::Position { x, y, z });
            Ok(())
        } else {
            Err(Error::Protocol("not connected".into()))
        }
    }

    /// Drain pending events and report current state and statistics as JSON.
    pub fn poll_json(&self) -> String {
        let events: Vec<Event> = std::mem::take(&mut *lock(&self.events));
        let (state, detail) = lock(&self.state).clone();
        let since = *lock(&self.play_since_ms);
        let uptime = if state == "play" && since > 0 { now_ms() - since } else { 0 };
        let pos = *lock(&self.pos);
        serde_json::json!({
            "state": state,
            "detail": detail,
            "events": events,
            "stats": {
                "bytes_in": self.bytes_in.load(Relaxed),
                "bytes_out": self.bytes_out.load(Relaxed),
                "packets_in": self.packets_in.load(Relaxed),
                "uptime_ms": uptime,
                "reconnects": self.reconnects.load(Relaxed),
                "latency_ms": self.self_latency.load(Relaxed),
                "x": pos.0, "y": pos.1, "z": pos.2,
            }
        })
        .to_string()
    }
}

struct PlayerEntry {
    name: String,
    latency: i32,
    listed: bool,
}

struct PlayState {
    players: HashMap<[u8; 16], PlayerEntry>,
    max_players: i32,
    username: String,
    uuid: [u8; 16],
    play_start: Instant,
}

impl PlayState {
    fn emit_players(&self, sh: &Shared) {
        let mut v: Vec<PlayerJson> = self
            .players
            .iter()
            .filter(|(_, p)| p.listed && !p.name.is_empty())
            .map(|(u, p)| PlayerJson { uuid: auth::uuid_to_string(u), name: p.name.clone(), latency: p.latency })
            .collect();
        v.sort_by(|a, b| a.name.to_lowercase().cmp(&b.name.to_lowercase()));
        if let Some(me) = self.players.get(&self.uuid) {
            sh.self_latency.store(me.latency, Relaxed);
        }
        sh.push(Event::Players { players: v, max_players: self.max_players });
    }
}

async fn recv<R: AsyncRead + Unpin>(rd: &mut R, sh: &Shared, to: Duration) -> Result<Vec<u8>> {
    if sh.cancelled.load(Relaxed) {
        return Err(Error::Cancelled);
    }
    let th = sh.threshold.load(Relaxed);
    tokio::select! {
        _ = sh.cancel.notified() => Err(Error::Cancelled),
        r = tokio::time::timeout(to, read_packet(rd, th)) => match r {
            Err(_) => Err(Error::Timeout),
            Ok(Err(e)) => Err(e),
            Ok(Ok((p, wire))) => {
                sh.bytes_in.fetch_add(wire as u64, Relaxed);
                sh.packets_in.fetch_add(1, Relaxed);
                Ok(p)
            }
        }
    }
}

async fn run_once(p: &ConnectParams, sh: &Arc<Shared>) -> Result<()> {
    auth::validate_username(&p.username)?;
    if p.auth == AuthMode::Microsoft {
        return Err(Error::OnlineModeRequired);
    }
    sh.reached_play.store(false, Relaxed);
    sh.threshold.store(-1, Relaxed);
    sh.self_latency.store(-1, Relaxed);
    sh.set_state("connecting", format!("{}:{}", p.host, p.port));

    let stream = connect_tcp(&p.host, p.port, Duration::from_secs(10)).await?;
    let (rd, mut wr) = stream.into_split();
    let mut rd = BufReader::new(rd);

    let uuid = auth::offline_uuid(&p.username);
    let mut login = Vec::new();
    write_varint(&mut login, 0x00);
    write_string(&mut login, &p.username);
    login.push(1);
    login.extend_from_slice(&uuid);
    let mut first = encode_packet(&handshake_payload(p.protocol, &p.host, p.port, 2), -1);
    first.extend_from_slice(&encode_packet(&login, -1));
    wr.write_all(&first).await?;
    sh.bytes_out.fetch_add(first.len() as u64, Relaxed);
    sh.set_state("login", "offline-mode login");

    let (tx, mut rx) = mpsc::unbounded_channel::<Vec<u8>>();
    *lock(&sh.out_tx) = Some(tx);
    let sh_w = sh.clone();
    let writer = tokio::spawn(async move {
        while let Some(payload) = rx.recv().await {
            let frame = encode_packet(&payload, sh_w.threshold.load(Relaxed));
            if wr.write_all(&frame).await.is_err() {
                break;
            }
            sh_w.bytes_out.fetch_add(frame.len() as u64, Relaxed);
        }
        let _ = wr.shutdown().await;
    });

    let result = login_and_play(p, sh, &mut rd, uuid).await;
    *lock(&sh.out_tx) = None;
    writer.abort();
    result
}

async fn login_and_play<R: AsyncRead + Unpin>(
    p: &ConnectParams,
    sh: &Arc<Shared>,
    rd: &mut R,
    offline_uuid: [u8; 16],
) -> Result<()> {
    let mut st = PlayState {
        players: HashMap::new(),
        max_players: -1,
        username: p.username.clone(),
        uuid: offline_uuid,
        play_start: Instant::now(),
    };
    loop {
        let pkt = recv(rd, sh, Duration::from_secs(20)).await?;
        let mut r = Reader::new(&pkt);
        match r.read_varint()? {
            0x00 => return Err(Error::Disconnected(chat::json_to_legacy(&r.read_string()?))),
            0x01 => return Err(Error::OnlineModeRequired),
            0x03 => sh.threshold.store(r.read_varint()?, Relaxed),
            0x02 => {
                st.uuid = r.read_uuid()?;
                st.username = r.read_string()?;
                break;
            }
            0x04 => {
                let id = r.read_varint()?;
                let mut resp = Vec::new();
                write_varint(&mut resp, 0x02);
                write_varint(&mut resp, id);
                resp.push(0); // not understood
                sh.send_raw(resp);
            }
            other => return Err(Error::Protocol(format!("unexpected login packet 0x{other:02x}"))),
        }
    }

    sh.reached_play.store(true, Relaxed);
    st.play_start = Instant::now();
    *lock(&sh.play_since_ms) = now_ms();
    sh.set_state("play", format!("joined as {}", st.username));
    send_client_hello(sh);

    loop {
        let pkt = recv(rd, sh, Duration::from_secs(40)).await?;
        let mut r = Reader::new(&pkt);
        let id = r.read_varint()?;
        match handle_play(id, &mut r, sh, &mut st) {
            Err(e @ Error::Disconnected(_)) => return Err(e),
            Err(_) => {} // malformed or unsupported non-critical packet: ignore
            Ok(()) => {}
        }
    }
}

fn send_client_hello(sh: &Shared) {
    let mut brand = Vec::new();
    write_varint(&mut brand, 0x0d);
    write_string(&mut brand, "minecraft:brand");
    write_string(&mut brand, "ChatCraft");
    sh.send_raw(brand);

    let mut s = Vec::new();
    write_varint(&mut s, 0x08);
    write_string(&mut s, "en_US");
    s.push(2); // view distance (chunks): keep traffic low
    write_varint(&mut s, 0); // chat: enabled
    s.push(1); // chat colours
    s.push(0x7f); // skin parts
    write_varint(&mut s, 1); // main hand: right
    s.push(0); // text filtering
    s.push(1); // allow server listing
    sh.send_raw(s);
}

fn chat_event(sh: &Shared, kind: &str, sender: String, text: String) {
    sh.push(Event::Chat { kind: kind.to_string(), sender, text, ts: now_ms() });
}

fn handle_play(id: i32, r: &mut Reader, sh: &Arc<Shared>, st: &mut PlayState) -> Result<()> {
    match id {
        0x23 => {
            let k = r.read_i64()?;
            let mut p = Vec::new();
            write_varint(&mut p, 0x12);
            write_i64(&mut p, k);
            sh.send_raw(p);
        }
        0x32 => {
            let k = r.read_i32()?;
            let mut p = Vec::new();
            write_varint(&mut p, 0x20);
            p.extend_from_slice(&k.to_be_bytes());
            sh.send_raw(p);
        }
        0x1a => {
            let reason = r.read_string()?;
            return Err(Error::Disconnected(chat::json_to_legacy(&reason)));
        }
        0x28 => {
            let entity_id = r.read_i32()?;
            let _hardcore = r.read_bool()?;
            let game_mode = r.read_u8()? as i32;
            let _prev = r.read_i8()?;
            let n = r.read_varint()?;
            for _ in 0..n.max(0) {
                r.read_string()?;
            }
            skip_nbt(r)?; // dimension codec
            let _world_type = r.read_string()?;
            let _world = r.read_string()?;
            let _seed = r.read_i64()?;
            st.max_players = r.read_varint()?;
            sh.push(Event::Info {
                max_players: st.max_players,
                entity_id,
                game_mode,
                uuid: auth::uuid_to_string(&st.uuid),
                username: st.username.clone(),
            });
        }
        0x3c => {
            let (mut x, mut y, mut z) = (r.read_f64()?, r.read_f64()?, r.read_f64()?);
            let (mut yaw, mut pitch) = (r.read_f32()?, r.read_f32()?);
            let flags = r.read_i8()?;
            let tid = r.read_varint()?;
            {
                let mut pos = lock(&sh.pos);
                if flags & 0x01 != 0 { x += pos.0; }
                if flags & 0x02 != 0 { y += pos.1; }
                if flags & 0x04 != 0 { z += pos.2; }
                if flags & 0x08 != 0 { pitch += pos.4; }
                if flags & 0x10 != 0 { yaw += pos.3; }
                *pos = (x, y, z, yaw, pitch);
            }
            let mut c = Vec::new();
            write_varint(&mut c, 0x00);
            write_varint(&mut c, tid);
            sh.send_raw(c);
            let mut pl = Vec::new();
            write_varint(&mut pl, 0x15);
            write_f64(&mut pl, x);
            write_f64(&mut pl, y);
            write_f64(&mut pl, z);
            write_f32(&mut pl, yaw);
            write_f32(&mut pl, pitch);
            pl.push(0);
            sh.send_raw(pl);
            sh.push(Event::Position { x, y, z });
        }
        0x35 => {
            let sender = r.read_uuid()?;
            let _index = r.read_varint()?;
            if r.read_bool()? {
                r.skip(256)?;
            }
            let plain = r.read_string()?;
            // Everything after the plain text is only used for nicer display; tolerate errors.
            let rest = (|| -> Result<(Option<String>, String)> {
                let _ts = r.read_i64()?;
                let _salt = r.read_i64()?;
                let n = r.read_varint()?;
                for _ in 0..n.max(0) {
                    if r.read_varint()? == 0 {
                        r.skip(256)?;
                    }
                }
                let unsigned = r.read_opt_string()?;
                let filter = r.read_varint()?;
                if filter == 2 {
                    let n = r.read_varint()?.max(0) as usize;
                    r.skip(n * 8)?;
                }
                let _ty = r.read_varint()?;
                let net_name = r.read_string()?;
                Ok((unsigned, net_name))
            })();
            let (unsigned, net_name) = match rest {
                Ok((u, n)) => (u, Some(n)),
                Err(_) => (None, None),
            };
            let name = st
                .players
                .get(&sender)
                .map(|p| p.name.clone())
                .filter(|n| !n.is_empty())
                .or_else(|| net_name.map(|n| chat::strip_codes(&chat::json_to_legacy(&n))))
                .unwrap_or_else(|| auth::uuid_to_string(&sender)[..8].to_string());
            let text = unsigned.map(|u| chat::json_to_legacy(&u)).unwrap_or(plain);
            chat_event(sh, "player", name, text);
        }
        0x1b => {
            let msg = r.read_string()?;
            let _ty = r.read_varint()?;
            let name = r.read_string()?;
            chat_event(
                sh,
                "player",
                chat::strip_codes(&chat::json_to_legacy(&name)),
                chat::json_to_legacy(&msg),
            );
        }
        0x64 => {
            let content = r.read_string()?;
            let action_bar = r.read_bool().unwrap_or(false);
            if !action_bar {
                chat_event(sh, "system", String::new(), chat::json_to_legacy(&content));
            }
        }
        0x3a => {
            let flags = r.read_u8()?;
            let n = r.read_varint()?;
            for _ in 0..n.max(0) {
                let uuid = r.read_uuid()?;
                if flags & 0x01 != 0 {
                    let name = r.read_string()?;
                    let props = r.read_varint()?;
                    for _ in 0..props.max(0) {
                        r.read_string()?;
                        r.read_string()?;
                        if r.read_bool()? {
                            r.read_string()?;
                        }
                    }
                    let is_new = !st.players.contains_key(&uuid);
                    st.players.insert(uuid, PlayerEntry { name: name.clone(), latency: 0, listed: true });
                    if is_new && st.play_start.elapsed() > Duration::from_secs(3) && uuid != st.uuid {
                        sh.push(Event::Presence { name, joined: true });
                    }
                }
                if flags & 0x02 != 0 && r.read_bool()? {
                    r.skip(16 + 8)?;
                    let l = r.read_varint()?.max(0) as usize;
                    r.skip(l)?;
                    let l2 = r.read_varint()?.max(0) as usize;
                    r.skip(l2)?;
                }
                if flags & 0x04 != 0 {
                    r.read_varint()?;
                }
                let listed = if flags & 0x08 != 0 { Some(r.read_u8()? != 0) } else { None };
                let latency = if flags & 0x10 != 0 { Some(r.read_varint()?) } else { None };
                if flags & 0x20 != 0 && r.read_bool()? {
                    r.read_string()?;
                }
                if let Some(e) = st.players.get_mut(&uuid) {
                    if let Some(l) = listed { e.listed = l; }
                    if let Some(l) = latency { e.latency = l; }
                }
            }
            st.emit_players(sh);
        }
        0x39 => {
            let n = r.read_varint()?;
            for _ in 0..n.max(0) {
                let uuid = r.read_uuid()?;
                if let Some(p) = st.players.remove(&uuid) {
                    if st.play_start.elapsed() > Duration::from_secs(3) {
                        sh.push(Event::Presence { name: p.name, joined: false });
                    }
                }
            }
            st.emit_players(sh);
        }
        0x38 => {
            let _pid = r.read_varint()?;
            let msg = r.read_string()?;
            chat_event(sh, "system", String::new(), chat::json_to_legacy(&msg));
            let mut p = Vec::new();
            write_varint(&mut p, 0x07);
            write_varint(&mut p, 0); // perform respawn
            sh.send_raw(p);
        }
        0x40 => {
            // Resource pack offer: honestly decline (this client cannot load packs).
            let mut p = Vec::new();
            write_varint(&mut p, 0x24);
            write_varint(&mut p, 1);
            sh.send_raw(p);
        }
        _ => {}
    }
    Ok(())
}

fn is_retryable(e: &Error) -> bool {
    matches!(e, Error::Io(_) | Error::Timeout | Error::Eof)
}

async fn supervise(p: ConnectParams, sh: Arc<Shared>) {
    let mut attempt: u32 = 0;
    loop {
        let res = run_once(&p, &sh).await;
        if sh.reached_play.load(Relaxed) {
            attempt = 0;
        }
        match res {
            Err(Error::Cancelled) | Ok(()) => {
                sh.set_state("disconnected", "Disconnected");
                return;
            }
            Err(e) => {
                let retry = p.auto_reconnect && is_retryable(&e) && attempt < p.max_retries && !sh.cancelled.load(Relaxed);
                if !retry {
                    let kind = if matches!(e, Error::Disconnected(_)) { "disconnected" } else { "error" };
                    sh.set_state(kind, e.to_string());
                    return;
                }
                attempt += 1;
                sh.reconnects.fetch_add(1, Relaxed);
                let delay = Duration::from_secs((2u64 << attempt.min(4)).min(30));
                sh.set_state(
                    "reconnecting",
                    format!("{e} - retry {attempt}/{} in {}s", p.max_retries, delay.as_secs()),
                );
                tokio::select! {
                    _ = sh.cancel.notified() => {}
                    _ = tokio::time::sleep(delay) => {}
                }
                if sh.cancelled.load(Relaxed) {
                    sh.set_state("disconnected", "Disconnected");
                    return;
                }
            }
        }
    }
}

static RUNTIME: OnceLock<tokio::runtime::Runtime> = OnceLock::new();

pub fn runtime() -> &'static tokio::runtime::Runtime {
    RUNTIME.get_or_init(|| {
        tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)
            .enable_all()
            .thread_name("chatcraft-net")
            .build()
            .expect("tokio runtime")
    })
}

/// Start a session on the shared runtime.
pub fn start(params: ConnectParams) -> Arc<Shared> {
    let sh = Shared::new();
    let sh2 = sh.clone();
    runtime().spawn(supervise(params, sh2));
    sh
}
