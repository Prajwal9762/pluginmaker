//! End-to-end tests: the real client engine against an in-process mock server that speaks
//! protocol 763 (status, offline login, compression, play packets).
//! NOTE: this is a mock written from the protocol spec, not a real Paper/Purpur server.

use chatcraft_core::codec::*;
use chatcraft_core::session::{self, ConnectParams};
use chatcraft_core::status;
use serde_json::Value;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use tokio::io::{AsyncWriteExt, BufReader};
use tokio::net::{TcpListener, TcpStream};

const THRESHOLD: i32 = 64;

fn uuid_n(n: u8) -> [u8; 16] {
    let mut u = [0u8; 16];
    u[15] = n;
    u
}

async fn send(w: &mut tokio::net::tcp::OwnedWriteHalf, payload: Vec<u8>, th: i32) {
    w.write_all(&encode_packet(&payload, th)).await.unwrap();
}

fn play_login_packet() -> Vec<u8> {
    let mut p = Vec::new();
    write_varint(&mut p, 0x28);
    p.extend_from_slice(&7i32.to_be_bytes()); // entity id
    p.push(0); // hardcore
    p.push(1); // gamemode
    p.push(0xFF); // previous gamemode (-1)
    write_varint(&mut p, 1);
    write_string(&mut p, "minecraft:overworld");
    p.extend_from_slice(&[10, 0, 0, 8, 0, 1, b'k', 0, 1, b'v', 0]); // NBT compound { "k": "v" }
    write_string(&mut p, "minecraft:overworld");
    write_string(&mut p, "minecraft:overworld");
    write_i64(&mut p, 12345);
    write_varint(&mut p, 20); // max players
    write_varint(&mut p, 8);
    write_varint(&mut p, 8);
    p.extend_from_slice(&[0, 1, 0, 0]); // reducedDebug, respawnScreen, isDebug, isFlat
    p.push(0); // no death location
    write_varint(&mut p, 0);
    p
}

async fn handle(stream: TcpStream, seen: Arc<Mutex<Vec<i32>>>, mode: &'static str) {
    let (rd, mut wr) = stream.into_split();
    let mut rd = BufReader::new(rd);
    let (hs, _) = read_packet(&mut rd, -1).await.unwrap();
    let mut r = Reader::new(&hs);
    assert_eq!(r.read_varint().unwrap(), 0);
    assert_eq!(r.read_varint().unwrap(), 763, "client must announce protocol 763");
    let _host = r.read_string().unwrap();
    let _port = r.read_u16().unwrap();
    let next = r.read_varint().unwrap();

    if next == 1 {
        let _req = read_packet(&mut rd, -1).await.unwrap();
        let json = r#"{"version":{"name":"Mock 1.20.1","protocol":763},"players":{"max":20,"online":1},"description":{"text":"Mock MOTD","color":"gold"}}"#;
        let mut p = Vec::new();
        write_varint(&mut p, 0);
        write_string(&mut p, json);
        send(&mut wr, p, -1).await;
        let (ping, _) = read_packet(&mut rd, -1).await.unwrap();
        send(&mut wr, ping, -1).await;
        return;
    }

    let (ls, _) = read_packet(&mut rd, -1).await.unwrap();
    let mut r = Reader::new(&ls);
    assert_eq!(r.read_varint().unwrap(), 0);
    let name = r.read_string().unwrap();

    if mode == "online" {
        let mut p = Vec::new();
        write_varint(&mut p, 0x01);
        write_string(&mut p, "");
        write_varint(&mut p, 4);
        p.extend_from_slice(&[1, 2, 3, 4]);
        write_varint(&mut p, 4);
        p.extend_from_slice(&[5, 6, 7, 8]);
        send(&mut wr, p, -1).await;
        tokio::time::sleep(Duration::from_millis(500)).await;
        return;
    }

    let mut p = Vec::new();
    write_varint(&mut p, 0x03);
    write_varint(&mut p, THRESHOLD);
    send(&mut wr, p, -1).await;
    let mut p = Vec::new();
    write_varint(&mut p, 0x02);
    p.extend_from_slice(&uuid_n(1));
    write_string(&mut p, &name);
    write_varint(&mut p, 0);
    send(&mut wr, p, THRESHOLD).await;

    send(&mut wr, play_login_packet(), THRESHOLD).await;

    // position sync
    let mut p = Vec::new();
    write_varint(&mut p, 0x3c);
    write_f64(&mut p, 10.0);
    write_f64(&mut p, 64.0);
    write_f64(&mut p, -5.5);
    write_f32(&mut p, 90.0);
    write_f32(&mut p, 0.0);
    p.push(0);
    write_varint(&mut p, 42);
    send(&mut wr, p, THRESHOLD).await;

    // player info: add + listed + latency for the bot (1) and Alice (2)
    let mut p = Vec::new();
    write_varint(&mut p, 0x3a);
    p.push(0x01 | 0x08 | 0x10);
    write_varint(&mut p, 2);
    for (n, nm, lat) in [(1u8, name.as_str(), 5), (2u8, "Alice", 12)] {
        p.extend_from_slice(&uuid_n(n));
        write_string(&mut p, nm);
        write_varint(&mut p, 0);
        p.push(1);
        write_varint(&mut p, lat);
    }
    send(&mut wr, p, THRESHOLD).await;

    // system chat with colours + a long line to exercise compression
    let mut p = Vec::new();
    write_varint(&mut p, 0x64);
    let long = "x".repeat(300);
    write_string(&mut p, &format!(r#"{{"text":"Welcome {long}","color":"green"}}"#));
    p.push(0);
    send(&mut wr, p, THRESHOLD).await;

    // signed-style player chat from Alice (no signature present)
    let mut p = Vec::new();
    write_varint(&mut p, 0x35);
    p.extend_from_slice(&uuid_n(2));
    write_varint(&mut p, 0);
    p.push(0); // no signature
    write_string(&mut p, "hello from Alice ✓");
    write_i64(&mut p, 1);
    write_i64(&mut p, 2);
    write_varint(&mut p, 0); // previous messages
    p.push(0); // no unsigned content
    write_varint(&mut p, 0); // filter type
    write_varint(&mut p, 0); // chat type
    write_string(&mut p, r#"{"text":"Alice"}"#);
    p.push(0);
    send(&mut wr, p, THRESHOLD).await;

    // keep alive
    let mut p = Vec::new();
    write_varint(&mut p, 0x23);
    write_i64(&mut p, 777);
    send(&mut wr, p, THRESHOLD).await;

    loop {
        let (pkt, _) = match read_packet(&mut rd, THRESHOLD).await {
            Ok(x) => x,
            Err(_) => return,
        };
        let mut r = Reader::new(&pkt);
        let id = r.read_varint().unwrap();
        seen.lock().unwrap().push(id);
        if id == 0x05 {
            let msg = r.read_string().unwrap();
            if msg == "bye" {
                let mut p = Vec::new();
                write_varint(&mut p, 0x1a);
                write_string(&mut p, r#"{"text":"Kicked: test over","color":"red"}"#);
                send(&mut wr, p, THRESHOLD).await;
                return;
            }
            let mut p = Vec::new();
            write_varint(&mut p, 0x64);
            write_string(&mut p, &format!(r#"{{"text":"echo:{msg}"}}"#));
            p.push(0);
            send(&mut wr, p, THRESHOLD).await;
        }
    }
}

async fn spawn_server(mode: &'static str) -> (u16, Arc<Mutex<Vec<i32>>>) {
    let l = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = l.local_addr().unwrap().port();
    let seen = Arc::new(Mutex::new(Vec::new()));
    let s2 = seen.clone();
    tokio::spawn(async move {
        loop {
            let (s, _) = l.accept().await.unwrap();
            let s3 = s2.clone();
            tokio::spawn(handle(s, s3, mode));
        }
    });
    (port, seen)
}

fn poll(sh: &Arc<session::Shared>) -> Value {
    serde_json::from_str(&sh.poll_json()).unwrap()
}

async fn collect_until(sh: &Arc<session::Shared>, secs: u64, done: impl Fn(&[Value], &Value) -> bool) -> (Vec<Value>, Value) {
    let end = Instant::now() + Duration::from_secs(secs);
    let mut all = Vec::new();
    loop {
        let v = poll(sh);
        all.extend(v["events"].as_array().unwrap().iter().cloned());
        if done(&all, &v) {
            return (all, v);
        }
        assert!(Instant::now() < end, "timed out; events so far: {all:#?}");
        tokio::time::sleep(Duration::from_millis(50)).await;
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn status_ping_reports_version_motd_latency() {
    let (port, _) = spawn_server("offline").await;
    let info = status::ping("127.0.0.1", port, Duration::from_secs(5)).await.unwrap();
    assert_eq!(info.version_name, "Mock 1.20.1");
    assert!(info.exact_protocol_match);
    assert_eq!(info.players_online, 1);
    assert_eq!(info.motd, "§r§6Mock MOTD");
}

#[test]
fn full_offline_session_chat_players_position_kick() {
    let rt = tokio::runtime::Runtime::new().unwrap();
    let (port, seen) = rt.block_on(spawn_server("offline"));
    let mut p = ConnectParams::offline("127.0.0.1", port, "MrBoss");
    p.auto_reconnect = false;
    let sh = session::start(p);

    let ok = |ev: &[Value]| {
        ev.iter().any(|e| e["type"] == "chat" && e["text"].as_str().unwrap_or("").contains("echo:hi there"))
    };
    // wait until the join burst has arrived
    rt.block_on(async {
        let (ev, _) = collect_until(&sh, 10, |ev, _| {
            ev.iter().any(|e| e["type"] == "chat" && e["kind"] == "player")
                && ev.iter().any(|e| e["type"] == "position")
        })
        .await;
        let st: Vec<_> = ev.iter().filter(|e| e["type"] == "state").map(|e| e["state"].as_str().unwrap()).collect();
        assert_eq!(st, ["connecting", "login", "play"]);
        let info = ev.iter().find(|e| e["type"] == "info").unwrap();
        assert_eq!(info["max_players"], 20);
        assert_eq!(info["username"], "MrBoss");
        assert_eq!(info["uuid"], "00000000-0000-0000-0000-000000000001");
        let players = ev.iter().rev().find(|e| e["type"] == "players").unwrap();
        let names: Vec<_> = players["players"].as_array().unwrap().iter().map(|p| p["name"].as_str().unwrap()).collect();
        assert_eq!(names, ["Alice", "MrBoss"]);
        assert_eq!(players["players"][0]["latency"], 12);
        let sys = ev.iter().find(|e| e["type"] == "chat" && e["kind"] == "system").unwrap();
        assert!(sys["text"].as_str().unwrap().starts_with("§r§aWelcome xxx"));
        let pc = ev.iter().find(|e| e["type"] == "chat" && e["kind"] == "player").unwrap();
        assert_eq!(pc["sender"], "Alice");
        assert_eq!(pc["text"], "hello from Alice ✓");
        let pos = ev.iter().find(|e| e["type"] == "position").unwrap();
        assert_eq!(pos["x"], 10.0);
        assert_eq!(pos["z"], -5.5);
    });

    sh.send_chat("hi there").unwrap();
    sh.send_chat("/list").unwrap();
    sh.move_by(1.0, 0.0, 0.0).unwrap();
    rt.block_on(async {
        let (_, v) = collect_until(&sh, 10, |ev, _| ok(ev)).await;
        assert!(v["stats"]["bytes_in"].as_u64().unwrap() > 300);
        assert!(v["stats"]["packets_in"].as_u64().unwrap() >= 6);
    });
    {
        let want_ids = [0x08, 0x0d, 0x00, 0x15, 0x12, 0x05, 0x04, 0x14];
        let end = Instant::now() + Duration::from_secs(5);
        loop {
            let ids = seen.lock().unwrap().clone();
            let missing: Vec<_> = want_ids.iter().filter(|w| !ids.contains(w)).collect();
            if missing.is_empty() {
                break;
            }
            assert!(Instant::now() < end, "server never received packets {missing:x?}; got {ids:x?}");
            std::thread::sleep(Duration::from_millis(50));
        }
    }

    sh.send_chat("bye").unwrap();
    rt.block_on(async {
        let (ev, v) = collect_until(&sh, 10, |_, v| v["state"] == "disconnected").await;
        let _ = ev;
        assert!(v["detail"].as_str().unwrap().contains("Kicked: test over"));
    });
}

#[test]
fn online_mode_server_is_refused_honestly() {
    let rt = tokio::runtime::Runtime::new().unwrap();
    let (port, _) = rt.block_on(spawn_server("online"));
    let mut p = ConnectParams::offline("127.0.0.1", port, "Tester");
    p.auto_reconnect = false;
    let sh = session::start(p);
    rt.block_on(async {
        let (_, v) = collect_until(&sh, 10, |_, v| v["state"] == "error").await;
        assert!(v["detail"].as_str().unwrap().contains("online-mode"));
    });
}

#[test]
fn reconnects_after_connection_loss_and_can_be_cancelled() {
    let rt = tokio::runtime::Runtime::new().unwrap();
    // Nothing listens on this port: expect "reconnecting", then clean cancel.
    let l = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
    let port = l.local_addr().unwrap().port();
    drop(l);
    let mut p = ConnectParams::offline("127.0.0.1", port, "Tester");
    p.max_retries = 3;
    let sh = session::start(p);
    rt.block_on(async {
        collect_until(&sh, 10, |ev, _| ev.iter().any(|e| e["state"] == "reconnecting")).await;
    });
    sh.disconnect();
    rt.block_on(async {
        collect_until(&sh, 10, |_, v| v["state"] == "disconnected").await;
    });
}

#[test]
fn invalid_username_is_rejected_before_connecting() {
    let mut p = ConnectParams::offline("127.0.0.1", 1, "no spaces!");
    p.auto_reconnect = false;
    let sh = session::start(p);
    let end = Instant::now() + Duration::from_secs(5);
    loop {
        let v = poll(&sh);
        if v["state"] == "error" {
            assert!(v["detail"].as_str().unwrap().contains("Username"));
            return;
        }
        assert!(Instant::now() < end);
        std::thread::sleep(Duration::from_millis(50));
    }
}
