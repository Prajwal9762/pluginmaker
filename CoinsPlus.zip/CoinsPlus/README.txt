CoinsPlus - Coins currency, key shop, exchange, shop, pets
==========================================================

BUILD (needs JDK + Maven):
  mvn clean package
  -> target/CoinsPlus.jar  -> put in your server's /plugins folder

!! IMPORTANT - set these in pom.xml before building for Minecraft 26.1.2 !!
  <java.version>   -> the Java version your server runs (Paper 26.x may need 25)
  <paper.version>  -> the paper-api version matching your server
                      (see https://docs.papermc.io for the exact 26.1.2 coordinates)
  plugin.yml api-version -> change "1.21" to "26.1" if the server complains.

REQUIREMENTS: Paper, Vault + an economy plugin (for /exchange).
OPTIONAL: CoreCrates (keys), LuckPerms (ranks)

COMMANDS
  /coins (alias /shards)      main hub GUI (balance, top players, menus)
  /coins <player>             see someone's balance
  /keys                       buy keys (daily 10, rare 33, money 40) - shift-click = x5
  /coinshop (/shardshops)     shop: Combat, Totems & Utility, Ranks, Pets
  /exchange (/convert)        coins <-> Vault money GUI
  /pets                       summon / put away your pets
  /coinsadmin add|remove|set|reset|check <player> [amount]
  /coinsadmin givepet <player> <petid>
  /coinsadmin reload
  Admin permission: coins.admin

EARNING (config.yml -> earn)
  +1 coin every 60 s online, +1 per block placed, +1 per block broken.

CONFIG YOU MUST CHECK
  key-command           the console command that gives a CoreCrates key
  shop.ranks.*.commands the console commands that give VIP/MVP (LuckPerms example)
  exchange rates        coins-to-money / money-to-coins
Prices, items, enchants and pets are all editable in config.yml.
