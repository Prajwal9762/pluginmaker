CoinsPlus 1.1.0 - Coins currency, keys, ranks, pets, shop, exchange
====================================================================

BUILD (JDK + Maven, or your GitHub Actions workflow):
  mvn clean package   ->   target/CoinsPlus.jar   ->  server /plugins

!! Before building for Minecraft 26.1.2 set in pom.xml:
  <java.version>   Java version your server runs (Paper 26.x may need 25)
  <paper.version>  paper-api version matching your server (docs.papermc.io)
  (or pass -Dpaper.version=... -Djava.version=... to Maven)
  plugin.yml api-version: change "1.21" to "26.1" if the server complains.

REQUIRES: Paper. Vault + an economy plugin for /exchange.
OPTIONAL: CoreCrates (keys), LuckPerms (ranks)

GUIs (everything is clickable)
  /coins (/shards)     hub: daily reward, keys, ranks, shop, pets, exchange, top
  /keys                key shop  (left x1, shift x5, right = type any amount)
  /ranks               rank shop (VIP 10,000 / MVP 20,000 / Fly Pass 5,000)
  /coinshop (/shardshops) shop: Netherite armor, weapons, combat items, tools,
                       + buttons for keys, ranks, pets, exchange
  /exchange (/convert) coins <-> Vault money; preset amounts, sell ALL, buy MAX,
                       or a custom amount typed in chat (250, 2k, 1.5m)
  /pets                summon / put away pets (pets follow you)
  /daily               daily reward with streak bonus
  /tags (/titles)      tags next to your name (buy, equip, or make your own)
  /coinstop            top 10 richest
  /coinspay <p> <amt>  send coins to a player

ADMIN (permission coins.admin)
  /coinsadmin add|remove|set|reset|check <player> [amount]
  /coinsadmin givepet|removepet <player> <petid>
  /coinsadmin tag create <id> <price> <display &colors>   (make a new tag in-game)
  /coinsadmin tag delete|give|take|list ...
  /coinsadmin reload

FEATURES
  * TAGS: 15 default titles + custom tags players type themselves; shown in chat and TAB.
    Admin-made tags are saved in tags.yml
  * Daily reward gives coins + a guaranteed Daily Key + a chance at Rare/Money keys
    (chances in config daily-reward.keys, they grow with the streak)
  * +1 coin per minute, +1 per block placed/broken (anti place/break farming)
  * Pets give a coin bonus (+% shown in lore) while summoned
  * Bundles: Full Netherite Set, Ultimate PvP Kit, Tool Kit (one click)
  * Confirmation screen for purchases >= confirm-above coins
  * Ranks can't be bought twice (owned-permission check)

KEYS NOT WORKING? (read this)
  1. key-command is preset to CoreCrates' command:  corecrates keygive {key} {player}
     (key ids daily / rare / money must match your CoreCrates key names).
  2. Test it:  /coinsadmin testkey <yourname> daily   (watch the console)
  3. If /keys opens another plugin's menu, use /coinkeys or /coinsplus:keys
     (or open it from the /coins hub). Keys are also in /coinshop.
  If the command is wrong, buyers are refunded automatically.

MUST EDIT in config.yml
  key-command            console command that gives a CoreCrates key
                         ({player} {key} {amount}); key ids (daily/rare/money)
                         must match your CoreCrates key names
  shop.ranks.*.commands  rank commands (LuckPerms examples included)
  Extra keys/ranks are shipped with enabled: false - turn on what you have.
