CoinsPlus 1.3.0 - Coins currency, keys, ranks, pets, shop, exchange
====================================================================

BUILD (JDK + Maven, or your GitHub Actions workflow):
  mvn clean package   ->   target/CoinsPlus.jar   ->  server /plugins

!! Before building for Minecraft 26.1.2 set in pom.xml:
  <java.version>   Java version your server runs (Paper 26.x may need 25)
  <paper.version>  paper-api version matching your server (docs.papermc.io)
  (or pass -Dpaper.version=... -Djava.version=... to Maven)
  plugin.yml api-version: change "1.21" to "26.1" if the server complains.

REQUIRES: Paper. Vault + an economy plugin for /exchange.
OPTIONAL: CoreCrates (keys), LuckPerms (ranks)

GUIs (everything is clickable)
  /coins (/shards)     hub: daily reward, keys, ranks, shop, pets, exchange, top
  /keys                key shop  (left x1, shift x5, right = type any amount)
  /ranks               rank shop (VIP 10,000 / MVP 20,000 / Fly Pass 5,000)
  /coinshop (/shardshops) shop: Netherite armor, weapons, combat items, tools,
                       + buttons for keys, ranks, pets, exchange
  /exchange (/convert) coins <-> Vault money; preset amounts, sell ALL, buy MAX,
                       or a custom amount typed in chat (250, 2k, 1.5m)
  /pets                summon / put away pets (pets follow you)
  /daily               daily reward with streak bonus
  /missions (/quests)  3 random daily missions (break/place/kill/playtime) + bonus for all
  /spin (/lucky)       Lucky Spin wheel: free daily spin or pay coins; win coins, keys, boosters
  /boosters            buy timed earn multipliers (x2, x3, x5)
  /coinswithdraw <amt> turn coins into a tradeable voucher item (right-click to redeem)
  /coinstop            top 10 richest
  /coinspay <p> <amt>  send coins to a player

ADMIN (permission coins.admin)
  /coinsadmin add|remove|set|reset|check <player> [amount]
  /coinsadmin givepet|removepet <player> <petid>
  /coinsadmin booster <player> <mult> <minutes>
  /coinsadmin globalbooster <mult> <minutes>   (0 = stop; announces to everyone)
  /coinsadmin reload

FEATURES
  * Multipliers: rank multipliers (config multipliers:), pet bonus and boosters all stack
  * Mobs give coins (config earn.mob-kill), new players get a starting balance
  * Daily missions, Lucky Spin, boosters, vouchers (see config sections of the same names)
  * Daily reward gives coins + a guaranteed Daily Key + a chance at Rare/Money keys
    (chances in config daily-reward.keys, they grow with the streak)
  * +1 coin per minute, +1 per block placed/broken (anti place/break farming)
  * Pets give a coin bonus (+% shown in lore) while summoned
  * Bundles: Full Netherite Set, Ultimate PvP Kit, Tool Kit (one click)
  * Confirmation screen for purchases >= confirm-above coins
  * Ranks can't be bought twice (owned-permission check)

PLACEHOLDERAPI (optional, e.g. for TAB scoreboards)
  %coinsplus_balance%  %coinsplus_balance_formatted%  %coinsplus_streak%
  %coinsplus_pet_bonus%  %coinsplus_currency%  %coinsplus_multiplier%

UPDATING THE PLUGIN? Old config.yml files are kept by Bukkit. 1.1.2+ auto-adds new sections and
  fixes an empty/old key-command on start (check the console). Or just delete
  plugins/CoinsPlus/config.yml and restart to get the newest one (data.yml keeps balances).
  Data is saved to plugins/CoinsPlus/data.yml every 30s, on purchases, on quit and on stop.

KEYS NOT WORKING? (read this)
  1. key-command is preset to CoreCrates' command:  corecrates keygive {key} {player}
     (key ids daily / rare / money must match your CoreCrates key names).
  2. Test it:  /coinsadmin testkey <yourname> daily   (watch the console)
  3. If /keys opens another plugin's menu, use /coinkeys or /coinsplus:keys
     (or open it from the /coins hub). Keys are also in /coinshop.
  If the command is wrong, buyers are refunded automatically.

MUST EDIT in config.yml
  key-command            console command that gives a CoreCrates key
                         ({player} {key} {amount}); key ids (daily/rare/money)
                         must match your CoreCrates key names
  shop.ranks.*.commands  rank commands (LuckPerms examples included)
  Extra keys/ranks are shipped with enabled: false - turn on what you have.


NOTE: the tags/titles system was removed in 1.2.0 (old tag data in data.yml is simply ignored).
