package com.coins;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

/** PlaceholderAPI expansion: %coinsplus_...% (works in TAB, chat plugins, scoreboards...). */
public class CoinsExpansion extends PlaceholderExpansion {
    private final CoinsPlugin plugin;

    public CoinsExpansion(CoinsPlugin plugin) { this.plugin = plugin; }

    @Override public String getIdentifier() { return "coinsplus"; }
    @Override public String getAuthor() { return "CoinsPlus"; }
    @Override public String getVersion() { return "1.3.0"; }
    @Override public boolean persist() { return true; }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        return plugin.placeholder(player, params);
    }
}
