package com.coins;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
import java.util.*;
import java.util.function.Consumer;

public class CoinsPlugin extends JavaPlugin implements Listener, TabExecutor {

    private Economy eco;
    private File dataFile;
    private YamlConfiguration data;

    private final Map<UUID, Long> coins = new HashMap<>();
    private final Map<UUID, Set<String>> ownedPets = new HashMap<>();
    private final Map<UUID, String> activePetId = new HashMap<>();
    private final Map<UUID, Long> lastDaily = new HashMap<>();
    private final Map<UUID, Integer> streak = new HashMap<>();
    private final Map<UUID, Double> remainder = new HashMap<>();

    private final Map<UUID, Entity> activePets = new HashMap<>();
    private final Set<UUID> petEntityIds = new HashSet<>();
    private final Map<UUID, Consumer<String>> prompts = new HashMap<>();
    private final Map<String, Long> placedBlocks = new HashMap<>();

    // boosters
    private final Map<UUID, Double> boostMult = new HashMap<>();
    private final Map<UUID, Long> boostUntil = new HashMap<>();
    private double globalMult = 1;
    private long globalUntil = 0;
    // lucky spin
    private final Map<UUID, Long> lastSpin = new HashMap<>();
    private final Set<UUID> spinning = new HashSet<>();
    // missions
    private final Map<UUID, String> missionDay = new HashMap<>();
    private final Map<UUID, Map<String, Integer>> missionProg = new HashMap<>();
    private final Map<UUID, Set<String>> missionDone = new HashMap<>();
    private final Map<UUID, List<Mission>> missionCache = new HashMap<>();
    // vouchers
    private NamespacedKey voucherKey, voucherIdKey;
    private final Set<String> redeemed = new LinkedHashSet<>();

    private record Mission(String id, String type, int amount, long reward, String name, Material icon) {}
    private record Prize(String type, long amount, String key, double mult, int minutes, int weight, Material icon, String name) {}

    // ============================================================ lifecycle
    @Override
    public void onEnable() {
        saveDefaultConfig();
        migrateConfig();
        voucherKey = new NamespacedKey(this, "voucher");
        voucherIdKey = new NamespacedKey(this, "voucher_id");
        loadData();
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) eco = rsp.getProvider();
        else getLogger().warning("Vault economy not found - /exchange is disabled.");

        String kc = getConfig().getString("key-command", "");
        if (kc.isBlank()) getLogger().warning("key-command is EMPTY in plugins/CoinsPlus/config.yml - keys cannot be delivered!");
        else getLogger().info("Keys will be delivered with console command: " + kc);

        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new CoinsExpansion(this).register();
            getLogger().info("PlaceholderAPI found: %coinsplus_balance%, %coinsplus_balance_formatted%, %coinsplus_streak%, %coinsplus_pet_bonus% registered.");
        }
        getServer().getPluginManager().registerEvents(this, this);
        for (String cmd : List.of("coins", "keys", "coinshop", "exchange", "pets", "ranks", "daily",
                "coinspay", "coinstop", "missions", "spin", "boosters", "coinswithdraw", "coinsadmin")) {
            PluginCommand pc = getCommand(cmd);
            if (pc != null) { pc.setExecutor(this); pc.setTabCompleter(this); }
        }

        long interval = Math.max(1, getConfig().getLong("earn.interval-seconds", 60)) * 20L;
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            long amt = getConfig().getLong("earn.timed-amount", 1);
            for (Player p : Bukkit.getOnlinePlayers()) earn(p, amt);
        }, interval, interval);
        Bukkit.getScheduler().runTaskTimer(this, this::followTick, 10L, 10L);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) progress(p.getUniqueId(), "PLAYTIME", 1);
        }, 1200L, 1200L);
        Bukkit.getScheduler().runTaskTimer(this, () -> { saveData(); cleanPlaced(); }, 600L, 600L);
    }

    @Override
    public void onDisable() {
        for (Entity e : new ArrayList<>(activePets.values())) e.remove();
        activePets.clear();
        saveData();
    }

    // ============================================================ data
    private void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        redeemed.addAll(data.getStringList("redeemed"));
        globalMult = data.getDouble("global.mult", 1);
        globalUntil = data.getLong("global.until", 0);
        ConfigurationSection pl = data.getConfigurationSection("players");
        if (pl == null) return;
        for (String k : pl.getKeys(false)) {
            try {
                UUID id = UUID.fromString(k);
                coins.put(id, pl.getLong(k + ".coins"));
                ownedPets.put(id, new HashSet<>(pl.getStringList(k + ".pets")));
                String ap = pl.getString(k + ".active");
                if (ap != null && !ap.isEmpty()) activePetId.put(id, ap);
                lastDaily.put(id, pl.getLong(k + ".daily-last"));
                streak.put(id, pl.getInt(k + ".streak"));
                if (pl.contains(k + ".boost-until")) {
                    boostUntil.put(id, pl.getLong(k + ".boost-until"));
                    boostMult.put(id, pl.getDouble(k + ".boost-mult", 1));
                }
                lastSpin.put(id, pl.getLong(k + ".last-spin"));
                String md = pl.getString(k + ".mission-day", "");
                if (!md.isEmpty()) {
                    missionDay.put(id, md);
                    Map<String, Integer> mp = new HashMap<>();
                    ConfigurationSection ms = pl.getConfigurationSection(k + ".missions");
                    if (ms != null) for (String mk : ms.getKeys(false)) mp.put(mk, ms.getInt(mk));
                    missionProg.put(id, mp);
                    missionDone.put(id, new HashSet<>(pl.getStringList(k + ".missions-done")));
                }
            } catch (IllegalArgumentException ignored) {}
        }
    }

    private void saveData() {
        data.set("players", null);
        for (Map.Entry<UUID, Long> en : coins.entrySet()) {
            UUID id = en.getKey();
            String b = "players." + id;
            data.set(b + ".coins", en.getValue());
            data.set(b + ".pets", new ArrayList<>(ownedPets.getOrDefault(id, Set.of())));
            data.set(b + ".active", activePetId.getOrDefault(id, ""));
            data.set(b + ".daily-last", lastDaily.getOrDefault(id, 0L));
            data.set(b + ".streak", streak.getOrDefault(id, 0));
            if (boostUntil.getOrDefault(id, 0L) > System.currentTimeMillis()) {
                data.set(b + ".boost-until", boostUntil.get(id));
                data.set(b + ".boost-mult", boostMult.getOrDefault(id, 1.0));
            }
            data.set(b + ".last-spin", lastSpin.getOrDefault(id, 0L));
            if (missionDay.containsKey(id)) {
                data.set(b + ".mission-day", missionDay.get(id));
                for (Map.Entry<String, Integer> me : missionProg.getOrDefault(id, Map.of()).entrySet())
                    data.set(b + ".missions." + me.getKey(), me.getValue());
                data.set(b + ".missions-done", new ArrayList<>(missionDone.getOrDefault(id, Set.of())));
            }
        }
        while (redeemed.size() > 20000) { Iterator<String> ri = redeemed.iterator(); ri.next(); ri.remove(); }
        data.set("redeemed", new ArrayList<>(redeemed));
        data.set("global.mult", globalMult);
        data.set("global.until", globalUntil);
        try { data.save(dataFile); } catch (IOException ex) { getLogger().severe("Could not save data: " + ex); }
    }

    // ---- save shortly after something important changed (coalesced)
    private boolean savePending;
    private void saveSoon() {
        if (savePending) return;
        savePending = true;
        Bukkit.getScheduler().runTaskLater(this, () -> { savePending = false; saveData(); }, 20L);
    }

    /** Old config.yml files are never overwritten by saveDefaultConfig(); fill in the new sections and fix the key command. */
    private void migrateConfig() {
        try (InputStreamReader r = new InputStreamReader(getResource("config.yml"), StandardCharsets.UTF_8)) {
            YamlConfiguration def = YamlConfiguration.loadConfiguration(r);
            org.bukkit.configuration.file.FileConfiguration c = getConfig();
            boolean changed = false;
            List<String> roots = List.of("daily-reward", "confirm-above", "earn", "exchange", "currency-name", "currency-symbol", "prefix",
                    "starting-balance", "multipliers", "boosters", "missions", "spin", "voucher");
            for (String k : def.getKeys(true)) {
                if (def.isConfigurationSection(k)) continue;
                String root = k.contains(".") ? k.substring(0, k.indexOf('.')) : k;
                if (!roots.contains(root)) continue;
                if (c.contains(k, true)) continue;
                // do not resurrect entries the owner deleted on purpose
                boolean skip = false;
                for (String x : List.of("daily-reward.keys", "boosters", "missions.pool", "multipliers", "earn.mob-kill.per-type"))
                    if (k.startsWith(x + ".") && c.contains(x, true)) { skip = true; break; }
                if (skip) continue;
                c.set(k, def.get(k));
                changed = true;
            }
            String kc = c.getString("key-command", "");
            if (kc.isBlank() || kc.equals("crate key give {player} {key} {amount}")) {
                c.set("key-command", def.getString("key-command", ""));
                changed = true;
                getLogger().info("Updated key-command in config.yml to: " + def.getString("key-command"));
            }
            if (changed) saveConfig();
        } catch (Exception ex) {
            getLogger().warning("Config migration failed: " + ex);
        }
    }

    /** Used by the PlaceholderAPI expansion. Returns legacy-colored text (section signs). */
    String placeholder(OfflinePlayer op, String params) {
        if (op == null) return "";
        UUID id = op.getUniqueId();
        String key = params.toLowerCase();
        switch (key) {
            case "multiplier": {
                Player pl = op.getPlayer();
                return pl == null ? "1.00" : String.format("%.2f", totalMult(pl));
            }
            case "balance": return String.valueOf(bal(id));
            case "balance_formatted": return Util.fmt(bal(id));
            case "streak": return String.valueOf(streak.getOrDefault(id, 0));
            case "pet_bonus": return String.valueOf((int) petBonus(id));
            case "currency": return cur();
            default: return null;
        }
    }

    private void cleanPlaced() {
        long limit = System.currentTimeMillis() - getConfig().getLong("earn.anti-abuse-seconds", 30) * 1000L;
        placedBlocks.values().removeIf(t -> t < limit);
    }

    // ============================================================ economy
    public long bal(UUID id) { return coins.getOrDefault(id, 0L); }
    public void setBal(UUID id, long v) { coins.put(id, Math.max(0, v)); }
    public void add(UUID id, long v) { setBal(id, bal(id) + v); }
    public boolean take(UUID id, long v) {
        if (v < 0 || bal(id) < v) return false;
        setBal(id, bal(id) - v);
        saveSoon();
        return true;
    }

    private String cur() { return getConfig().getString("currency-name", "Coins"); }
    private String sym() { return getConfig().getString("currency-symbol", "⛃"); }
    private void msg(CommandSender s, String m) { s.sendMessage(Util.c(getConfig().getString("prefix", "") + m)); }

    private double petBonus(UUID id) {
        if (!activePets.containsKey(id)) return 0;
        String pid = activePetId.get(id);
        return pid == null ? 0 : getConfig().getDouble("pets." + pid + ".bonus", 0);
    }

    private void earn(Player p, long base) {
        if (base <= 0) return;
        if (getConfig().getStringList("earn.disabled-worlds").contains(p.getWorld().getName())) return;
        UUID id = p.getUniqueId();
        double raw = base * totalMult(p) + remainder.getOrDefault(id, 0.0);
        long give = (long) raw;
        remainder.put(id, raw - give);
        if (give <= 0) return;
        add(id, give);
        if (getConfig().getBoolean("earn.actionbar", true))
            p.sendActionBar(Util.c("&6+" + give + " " + cur() + " &7(" + Util.fmt(bal(id)) + ")"));
    }

    private List<Map.Entry<UUID, Long>> top() {
        List<Map.Entry<UUID, Long>> l = new ArrayList<>(coins.entrySet());
        l.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
        return l;
    }

    // ============================================================ events
    private String key(org.bukkit.block.Block b) {
        return b.getWorld().getName() + ":" + b.getX() + "," + b.getY() + "," + b.getZ();
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (getConfig().getBoolean("earn.anti-abuse", true)) {
            if (placedBlocks.size() > 30000) placedBlocks.clear();
            placedBlocks.put(key(e.getBlock()), System.currentTimeMillis());
        }
        progress(e.getPlayer().getUniqueId(), "PLACE", 1);
        earn(e.getPlayer(), getConfig().getLong("earn.per-block-place", 1));
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (getConfig().getBoolean("earn.anti-abuse", true)) {
            Long t = placedBlocks.remove(key(e.getBlock()));
            long win = getConfig().getLong("earn.anti-abuse-seconds", 30) * 1000L;
            if (t != null && System.currentTimeMillis() - t < win) return; // place+break farming
        }
        progress(e.getPlayer().getUniqueId(), "BREAK", 1);
        earn(e.getPlayer(), getConfig().getLong("earn.per-block-break", 1));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!coins.containsKey(p.getUniqueId())) {
            long start = getConfig().getLong("starting-balance", 0);
            coins.put(p.getUniqueId(), Math.max(0, start));
            if (start > 0) msg(p, "&aWelcome! You got &6" + Util.fmt(start) + " " + cur() + " &ato get started. Try &f/coins&a!");
            saveSoon();
        }
        String ap = activePetId.get(p.getUniqueId());
        if (ap != null && ownedPets.getOrDefault(p.getUniqueId(), Set.of()).contains(ap))
            Bukkit.getScheduler().runTaskLater(this, () -> { if (p.isOnline()) summon(p, ap); }, 40L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        prompts.remove(e.getPlayer().getUniqueId());
        despawn(e.getPlayer().getUniqueId());
        saveData();
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Gui g) {
            e.setCancelled(true);
            if (e.getClickedInventory() == e.getView().getTopInventory()) g.click(e);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Gui) e.setCancelled(true);
    }

    @EventHandler public void onPetDamage(EntityDamageEvent e) {
        if (petEntityIds.contains(e.getEntity().getUniqueId())) e.setCancelled(true);
    }
    @EventHandler public void onPetInteract(PlayerInteractEntityEvent e) {
        if (petEntityIds.contains(e.getRightClicked().getUniqueId())) e.setCancelled(true);
    }
    @EventHandler public void onPetTarget(EntityTargetEvent e) {
        if (petEntityIds.contains(e.getEntity().getUniqueId())) e.setCancelled(true);
    }
    @EventHandler public void onTeleport(PlayerTeleportEvent e) {
        Entity pet = activePets.get(e.getPlayer().getUniqueId());
        if (pet != null && pet.isValid())
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (pet.isValid() && e.getPlayer().isOnline()) pet.teleport(e.getPlayer().getLocation());
            }, 5L);
    }

    // ============================================================ chat prompts
    private void promptText(Player p, String question, Consumer<String> cb) {
        p.closeInventory();
        prompts.put(p.getUniqueId(), cb);
        msg(p, "&e" + question);
        msg(p, "&7Type it in chat. Type &ccancel &7to abort.");
    }

    private void prompt(Player p, String question, Consumer<Long> cb) {
        p.closeInventory();
        prompts.put(p.getUniqueId(), text -> {
            long n = parseAmount(text);
            if (n <= 0 || n > 100_000_000L) { msg(p, "&cThat is not a valid amount."); return; }
            cb.accept(n);
        });
        msg(p, "&e" + question);
        msg(p, "&7Type a number in chat (examples: &f250&7, &f2k&7, &f1.5m&7). Type &ccancel &7to abort.");
    }

    private long parseAmount(String t) {
        try {
            t = t.trim().toLowerCase().replace(",", "");
            double mult = 1;
            if (t.endsWith("k")) { mult = 1_000; t = t.substring(0, t.length() - 1); }
            else if (t.endsWith("m")) { mult = 1_000_000; t = t.substring(0, t.length() - 1); }
            return (long) (Double.parseDouble(t) * mult);
        } catch (NumberFormatException ex) { return -1; }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        Consumer<String> cb = prompts.remove(e.getPlayer().getUniqueId());
        if (cb == null) return;
        e.setCancelled(true);
        String text = PlainTextComponentSerializer.plainText().serialize(e.message());
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(this, () -> {
            if (text.equalsIgnoreCase("cancel")) { msg(p, "&cCancelled."); return; }
            cb.accept(text);
        });
    }

    // ============================================================ MULTIPLIERS & BOOSTERS
    private double rankMult(Player p) {
        ConfigurationSection m = getConfig().getConfigurationSection("multipliers");
        double best = 1;
        if (m != null) for (String id : m.getKeys(false)) {
            ConfigurationSection x = m.getConfigurationSection(id);
            if (x == null) continue;
            String perm = x.getString("permission", "");
            if (!perm.isEmpty() && p.hasPermission(perm)) best = Math.max(best, x.getDouble("value", 1));
        }
        return best;
    }

    private double boostFactor(UUID id) {
        long now = System.currentTimeMillis();
        double f = 1;
        if (boostUntil.getOrDefault(id, 0L) > now) f *= boostMult.getOrDefault(id, 1.0);
        if (globalUntil > now) f *= globalMult;
        return f;
    }

    private double multiplier(Player p) { return rankMult(p) * boostFactor(p.getUniqueId()); }
    private double totalMult(Player p) { return (1 + petBonus(p.getUniqueId()) / 100.0) * multiplier(p); }

    private String timeLeft(long ms) {
        long m = Math.max(0, ms) / 60000L;
        return (m / 60) + "h " + (m % 60) + "m";
    }

    private void applyBooster(UUID id, double mult, int minutes) {
        long now = System.currentTimeMillis();
        long until = boostUntil.getOrDefault(id, 0L);
        boolean active = until > now;
        double cur = active ? boostMult.getOrDefault(id, 1.0) : 0;
        long add = minutes * 60_000L;
        if (!active) { boostMult.put(id, mult); boostUntil.put(id, now + add); }
        else if (mult >= cur) { boostMult.put(id, mult); boostUntil.put(id, until + add); }
        else boostUntil.put(id, until + add);
        saveSoon();
    }

    private void openBoosters(Player p) {
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        boolean active = boostUntil.getOrDefault(id, 0L) > now;
        double curMult = active ? boostMult.getOrDefault(id, 1.0) : 1;
        Gui g = new Gui("&e&lBoosters", 4);
        g.frame(Material.YELLOW_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        ConfigurationSection bs = getConfig().getConfigurationSection("boosters");
        int[] slots = {10, 11, 12, 13, 14, 15, 16};
        int i = 0;
        if (bs != null) for (String bid : bs.getKeys(false)) {
            ConfigurationSection s = bs.getConfigurationSection(bid);
            if (s == null || !s.getBoolean("enabled", true) || i >= slots.length) continue;
            long price = s.getLong("price");
            double mult = s.getDouble("multiplier", 2);
            int min = s.getInt("minutes", 30);
            Material ic = Material.matchMaterial(s.getString("icon", "BLAZE_POWDER"));
            ItemStack it = Util.item(ic == null ? Material.BLAZE_POWDER : ic, s.getString("name", bid),
                    List.of("&7Multiplier: &ax" + mult, "&7Duration: &f" + min + " minutes", "&7Stacks with your rank & pet bonus", "",
                            "&7Price: &6" + Util.fmt(price) + " " + cur(), "&eClick to buy"));
            g.set(slots[i++], it, e -> {
                if (active && curMult > mult) { msg(p, "&cYou already have a stronger booster running (x" + curMult + ")."); return; }
                confirmOrRun(p, it, price, () -> {
                    if (!take(id, price)) { msg(p, "&cNot enough " + cur() + "!"); openBoosters(p); return; }
                    applyBooster(id, mult, min);
                    msg(p, "&aBooster active: &ex" + mult + " " + cur() + " &afor &f" + min + " &aminutes (stacks time if already running)");
                    p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.5f);
                    openBoosters(p);
                }, () -> openBoosters(p));
            });
        }
        List<String> st = new ArrayList<>();
        st.add("&7Rank multiplier: &ax" + String.format("%.2f", rankMult(p)));
        st.add("&7Pet bonus: &a+" + (int) petBonus(id) + "%");
        st.add(active ? "&7Your booster: &ax" + curMult + " &7(" + timeLeft(boostUntil.get(id) - now) + " left)" : "&7Your booster: &cnone");
        st.add(globalUntil > now ? "&7Server booster: &ax" + globalMult + " &7(" + timeLeft(globalUntil - now) + " left)" : "&7Server booster: &cnone");
        st.add("");
        st.add("&6Total: &ex" + String.format("%.2f", totalMult(p)));
        g.set(22, Util.item(Material.CLOCK, "&e&lYour multipliers", st), null);
        g.set(31, back(), e -> openHub(p));
        g.open(p);
    }

    // ============================================================ MOB KILLS
    @EventHandler
    public void onKill(EntityDeathEvent e) {
        Player k = e.getEntity().getKiller();
        if (k == null || e.getEntity() instanceof Player || petEntityIds.contains(e.getEntity().getUniqueId())) return;
        progress(k.getUniqueId(), "KILL", 1);
        if (!getConfig().getBoolean("earn.mob-kill.enabled", true)) return;
        long amt = getConfig().getLong("earn.mob-kill.per-type." + e.getEntity().getType().name(),
                getConfig().getLong("earn.mob-kill.default", 1));
        earn(k, amt);
    }

    // ============================================================ VOUCHERS (coins as an item)
    private ItemStack makeVoucher(long amt) {
        ItemStack it = Util.item(Material.PAPER, "&6&lCoin Voucher &7(" + Util.fmt(amt) + " " + cur() + ")",
                List.of("&7Right-click to redeem", "&8Value: &e" + Util.fmt(amt) + " " + cur()));
        ItemMeta m = it.getItemMeta();
        m.getPersistentDataContainer().set(voucherKey, PersistentDataType.LONG, amt);
        m.getPersistentDataContainer().set(voucherIdKey, PersistentDataType.STRING, UUID.randomUUID().toString());
        m.setEnchantmentGlintOverride(true);
        it.setItemMeta(m);
        return it;
    }

    @EventHandler
    public void onVoucher(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack it = e.getItem();
        if (it == null || !it.hasItemMeta()) return;
        var pdc = it.getItemMeta().getPersistentDataContainer();
        Long amt = pdc.get(voucherKey, PersistentDataType.LONG);
        if (amt == null) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        String vid = pdc.get(voucherIdKey, PersistentDataType.STRING);
        if (vid != null && redeemed.contains(vid)) { msg(p, "&cThis voucher was already redeemed."); p.getInventory().setItemInMainHand(null); return; }
        if (vid != null) redeemed.add(vid);
        ItemStack hand = p.getInventory().getItemInMainHand();
        hand.setAmount(hand.getAmount() - 1);
        p.getInventory().setItemInMainHand(hand.getAmount() <= 0 ? null : hand);
        add(p.getUniqueId(), amt);
        saveSoon();
        msg(p, "&aRedeemed voucher: &6+" + Util.fmt(amt) + " " + cur());
        p.playSound(p, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1, 1.2f);
    }

    // ============================================================ DAILY MISSIONS
    private Map<String, Mission> missionPool() {
        Map<String, Mission> m = new LinkedHashMap<>();
        ConfigurationSection sec = getConfig().getConfigurationSection("missions.pool");
        if (sec == null) return m;
        for (String id : sec.getKeys(false)) {
            ConfigurationSection x = sec.getConfigurationSection(id);
            if (x == null || !x.getBoolean("enabled", true)) continue;
            Material ic = Material.matchMaterial(x.getString("icon", "PAPER"));
            m.put(id, new Mission(id, x.getString("type", "BREAK").toUpperCase(), Math.max(1, x.getInt("amount", 100)),
                    x.getLong("reward", 20), x.getString("name", id), ic == null ? Material.PAPER : ic));
        }
        return m;
    }

    private void ensureMissionDay(UUID id) {
        String today = java.time.LocalDate.now().toString();
        if (!today.equals(missionDay.get(id))) {
            missionDay.put(id, today);
            missionProg.put(id, new HashMap<>());
            missionDone.put(id, new HashSet<>());
            missionCache.remove(id);
        }
    }

    private List<Mission> todaysMissions(UUID id) {
        return missionCache.computeIfAbsent(id, k -> {
            Map<String, Mission> pool = missionPool();
            List<String> ids = new ArrayList<>(pool.keySet());
            Collections.sort(ids);
            Collections.shuffle(ids, new Random(k.hashCode() * 31L + java.time.LocalDate.now().toString().hashCode()));
            List<Mission> out = new ArrayList<>();
            int n = Math.min(ids.size(), getConfig().getInt("missions.per-day", 3));
            for (int i = 0; i < n; i++) out.add(pool.get(ids.get(i)));
            return out;
        });
    }

    private void progress(UUID id, String type, int n) {
        if (!getConfig().getBoolean("missions.enabled", true)) return;
        ensureMissionDay(id);
        Map<String, Integer> pr = missionProg.get(id);
        Player p = Bukkit.getPlayer(id);
        for (Mission m : todaysMissions(id)) {
            if (!m.type().equals(type)) continue;
            int before = pr.getOrDefault(m.id(), 0);
            if (before >= m.amount()) continue;
            int after = Math.min(m.amount(), before + n);
            pr.put(m.id(), after);
            if (after >= m.amount() && p != null) {
                msg(p, "&aMission complete! &7Claim your reward in &f/missions");
                p.playSound(p, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1, 1);
            }
        }
    }

    private String bar(int cur, int max) {
        int f = (int) Math.round(10.0 * Math.min(cur, max) / Math.max(1, max));
        return "&a" + "█".repeat(f) + "&7" + "█".repeat(10 - f);
    }

    private void openMissions(Player p) {
        UUID id = p.getUniqueId();
        if (!getConfig().getBoolean("missions.enabled", true)) { msg(p, "&cMissions are disabled."); return; }
        ensureMissionDay(id);
        List<Mission> ms = todaysMissions(id);
        Map<String, Integer> pr = missionProg.get(id);
        Set<String> done = missionDone.get(id);
        Gui g = new Gui("&a&lDaily Missions", 4);
        g.frame(Material.LIME_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        int[] slots = ms.size() <= 3 ? new int[]{11, 13, 15} : new int[]{10, 11, 12, 13, 14, 15, 16};
        for (int i = 0; i < Math.min(ms.size(), slots.length); i++) {
            Mission m = ms.get(i);
            int cur = pr.getOrDefault(m.id(), 0);
            boolean claimed = done.contains(m.id());
            boolean ready = cur >= m.amount() && !claimed;
            List<String> lore = new ArrayList<>();
            lore.add(bar(cur, m.amount()));
            lore.add("&7Progress: &f" + cur + "&7/&f" + m.amount());
            lore.add("&7Reward: &6" + Util.fmt(m.reward()) + " " + cur());
            lore.add("");
            lore.add(claimed ? "&a✔ Claimed" : ready ? "&aDone! &eClick to claim" : "&7Keep going...");
            ItemStack it = Util.item(m.icon(), m.name(), lore);
            if (ready) { ItemMeta im = it.getItemMeta(); im.setEnchantmentGlintOverride(true); it.setItemMeta(im); }
            g.set(slots[i], it, e -> {
                if (!ready) { msg(p, claimed ? "&cAlready claimed." : "&cThis mission is not finished yet."); return; }
                done.add(m.id());
                add(id, m.reward());
                msg(p, "&aMission reward: &6+" + Util.fmt(m.reward()) + " " + cur());
                p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.5f);
                long bonus = getConfig().getLong("missions.bonus-all", 0);
                if (bonus > 0 && ms.stream().allMatch(x -> done.contains(x.id())) && !done.contains("__bonus")) {
                    done.add("__bonus");
                    add(id, bonus);
                    msg(p, "&6&lAll missions done! &aBonus: &6+" + Util.fmt(bonus) + " " + cur());
                }
                saveSoon();
                openMissions(p);
            });
        }
        if (ms.isEmpty()) g.set(22, Util.item(Material.BARRIER, "&cNo missions configured", List.of()), null);
        g.set(22, Util.item(Material.CLOCK, "&e&lResets at midnight",
                List.of("&7Server time", "&7Bonus for finishing all: &6" + Util.fmt(getConfig().getLong("missions.bonus-all", 0)) + " " + cur())), null);
        g.set(31, back(), e -> openHub(p));
        g.open(p);
    }

    // ============================================================ LUCKY SPIN
    private String mstr(Map<?, ?> m, String k, String d) { Object o = m.get(k); return o == null ? d : String.valueOf(o); }

    private List<Prize> prizes() {
        List<Prize> l = new ArrayList<>();
        for (Map<?, ?> m : getConfig().getMapList("spin.prizes")) {
            try {
                String type = mstr(m, "type", "COINS").toUpperCase();
                long amount = (long) Double.parseDouble(mstr(m, "amount", "1"));
                String key = mstr(m, "key", "daily");
                double mult = Double.parseDouble(mstr(m, "multiplier", "2"));
                int minutes = (int) Double.parseDouble(mstr(m, "minutes", "15"));
                int weight = Math.max(1, (int) Double.parseDouble(mstr(m, "weight", "1")));
                String dn = switch (type) {
                    case "KEY" -> getConfig().getString("keys." + key + ".name", key) + " &fx" + amount;
                    case "BOOSTER" -> "&d&lx" + mult + " Booster &7(" + minutes + " min)";
                    default -> "&e" + Util.fmt(amount) + " " + cur();
                };
                String defIcon = type.equals("KEY") ? "TRIPWIRE_HOOK" : type.equals("BOOSTER") ? "BLAZE_POWDER" : "GOLD_NUGGET";
                Material ic = Material.matchMaterial(mstr(m, "icon", defIcon));
                l.add(new Prize(type, amount, key, mult, minutes, weight, ic == null ? Material.PAPER : ic, mstr(m, "name", dn)));
            } catch (Exception ex) { getLogger().warning("Bad spin prize entry: " + m); }
        }
        return l;
    }

    private Prize pick(List<Prize> pr) {
        int total = 0;
        for (Prize x : pr) total += x.weight();
        int r = new Random().nextInt(Math.max(1, total));
        for (Prize x : pr) { r -= x.weight(); if (r < 0) return x; }
        return pr.get(0);
    }

    private ItemStack prizeItem(Prize x, List<Prize> all) {
        int total = 0;
        for (Prize y : all) total += y.weight();
        return Util.item(x.icon(), x.name(), List.of("&7Chance: &f" + String.format("%.1f", 100.0 * x.weight() / Math.max(1, total)) + "%"));
    }

    private void openSpin(Player p) {
        if (!getConfig().getBoolean("spin.enabled", true)) { msg(p, "&cLucky Spin is disabled."); return; }
        List<Prize> pr = prizes();
        if (pr.isEmpty()) { msg(p, "&cNo spin prizes configured."); return; }
        UUID id = p.getUniqueId();
        long price = getConfig().getLong("spin.price", 50);
        Gui g = new Gui("&6&lLucky Spin", 3);
        g.frame(Material.ORANGE_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        Random rnd = new Random();
        for (int i = 0; i < 9; i++) g.set(9 + i, prizeItem(pr.get(rnd.nextInt(pr.size())), pr), null);
        g.set(4, Util.item(Material.HOPPER, "&e&l▼ WINNER ▼", List.of()), null);

        long left = lastSpin.getOrDefault(id, 0L) + 24L * 3600_000L - System.currentTimeMillis();
        boolean freeReady = getConfig().getBoolean("spin.free-daily", true) && left <= 0;
        if (getConfig().getBoolean("spin.free-daily", true))
            g.set(20, Util.item(freeReady ? Material.LIME_CONCRETE : Material.GRAY_CONCRETE, "&a&lFREE daily spin",
                    List.of(freeReady ? "&aReady! &eClick to spin" : "&cNext free spin in &f" + timeLeft(left))), e -> startSpin(p, g, true));
        g.set(24, Util.item(Material.GOLD_BLOCK, "&6&lSpin for " + Util.fmt(price) + " " + cur(),
                List.of("&7Win coins, keys or boosters!", "", "&eClick to spin")), e -> startSpin(p, g, false));
        List<String> info = new ArrayList<>();
        int total = 0;
        for (Prize x : pr) total += x.weight();
        for (Prize x : pr) info.add("&8 • &r" + x.name() + " &7(" + String.format("%.1f", 100.0 * x.weight() / total) + "%)");
        g.set(22, Util.item(Material.BOOK, "&e&lPrizes", info), null);
        g.set(26, back(), e -> openHub(p));
        g.open(p);
    }

    private void startSpin(Player p, Gui g, boolean free) {
        UUID id = p.getUniqueId();
        if (spinning.contains(id)) return;
        List<Prize> pr = prizes();
        if (pr.isEmpty()) return;
        if (free) {
            long left = lastSpin.getOrDefault(id, 0L) + 24L * 3600_000L - System.currentTimeMillis();
            if (left > 0) { msg(p, "&cYour free spin is not ready (" + timeLeft(left) + ")."); return; }
            lastSpin.put(id, System.currentTimeMillis());
        } else {
            long price = getConfig().getLong("spin.price", 50);
            if (!take(id, price)) { msg(p, "&cNot enough " + cur() + "! A spin costs &6" + Util.fmt(price)); return; }
        }
        spinning.add(id);
        Prize result = pick(pr);
        int total = 26;
        List<Prize> seq = new ArrayList<>();
        for (int i = 0; i < total + 9; i++) seq.add(pick(pr));
        seq.set(total + 4, result);
        saveSoon();
        animateSpin(p, g, pr, seq, 0, total, result);
    }

    private void animateSpin(Player p, Gui g, List<Prize> all, List<Prize> seq, int step, int total, Prize result) {
        for (int i = 0; i < 9; i++) g.set(9 + i, prizeItem(seq.get(step + i), all), null);
        p.playSound(p, Sound.UI_BUTTON_CLICK, 0.6f, 0.8f + step * 0.03f);
        if (step >= total) {
            spinning.remove(p.getUniqueId());
            givePrize(p, result);
            return;
        }
        Bukkit.getScheduler().runTaskLater(this, () -> animateSpin(p, g, all, seq, step + 1, total, result), 2 + step / 5);
    }

    private void givePrize(Player p, Prize x) {
        UUID id = p.getUniqueId();
        switch (x.type()) {
            case "KEY" -> {
                ConfigurationSection ks = getConfig().getConfigurationSection("keys." + x.key());
                if (ks == null || !giveKeyCommand(p.getName(), x.key(), ks, x.amount())) {
                    long value = ks == null ? 0 : ks.getLong("price") * x.amount();
                    add(id, value);
                    getLogger().warning("Spin key prize '" + x.key() + "' could not be delivered - gave " + value + " coins instead. Check key-command.");
                    msg(p, "&cKey delivery failed, you got &6" + Util.fmt(value) + " " + cur() + " &cinstead.");
                    saveSoon();
                    return;
                }
            }
            case "BOOSTER" -> applyBooster(id, x.mult(), x.minutes());
            default -> add(id, x.amount());
        }
        msg(p, "&6&lYou won: &r" + x.name());
        p.playSound(p, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1, 1);
        saveSoon();
    }

    // ============================================================ pets
    private void summon(Player p, String id) {
        despawn(p.getUniqueId());
        ConfigurationSection s = getConfig().getConfigurationSection("pets." + id);
        if (s == null) return;
        EntityType type;
        try { type = EntityType.valueOf(s.getString("entity", "WOLF").toUpperCase()); }
        catch (IllegalArgumentException ex) { return; }
        Entity ent = p.getWorld().spawnEntity(p.getLocation(), type);
        ent.setInvulnerable(true);
        ent.setPersistent(false);
        ent.customName(Util.c(s.getString("name", id) + " &7(" + p.getName() + ")"));
        ent.setCustomNameVisible(true);
        if (ent instanceof Ageable a && s.getBoolean("baby", false)) { a.setBaby(); a.setAgeLock(true); }
        if (ent instanceof Tameable t) { t.setTamed(true); t.setOwner(p); }
        if (ent instanceof Sittable si) si.setSitting(false);
        if (ent instanceof Mob m) m.setRemoveWhenFarAway(false);
        activePets.put(p.getUniqueId(), ent);
        petEntityIds.add(ent.getUniqueId());
        activePetId.put(p.getUniqueId(), id);
        saveSoon();
    }

    private void despawn(UUID owner) {
        Entity e = activePets.remove(owner);
        if (e != null) { petEntityIds.remove(e.getUniqueId()); e.remove(); }
    }

    private void followTick() {
        Iterator<Map.Entry<UUID, Entity>> it = activePets.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Entity> en = it.next();
            Player p = Bukkit.getPlayer(en.getKey());
            Entity pet = en.getValue();
            if (p == null || !p.isOnline()) { petEntityIds.remove(pet.getUniqueId()); pet.remove(); it.remove(); continue; }
            if (!pet.isValid()) {
                it.remove(); petEntityIds.remove(pet.getUniqueId());
                String id = activePetId.get(en.getKey());
                if (id != null) Bukkit.getScheduler().runTask(this, () -> summon(p, id));
                break;
            }
            if (!pet.getWorld().equals(p.getWorld()) || pet.getLocation().distanceSquared(p.getLocation()) > 400) {
                pet.teleport(p.getLocation());
            } else if (pet.getLocation().distanceSquared(p.getLocation()) > 12 && pet instanceof Mob m) {
                m.getPathfinder().moveTo(p.getLocation(), 1.3);
            }
        }
    }

    // ============================================================ item helpers
    private ItemStack buildItem(ConfigurationSection s) {
        Material m = Material.matchMaterial(s.getString("material", "STONE"));
        if (m == null) m = Material.BARRIER;
        ItemStack it = new ItemStack(m, Math.max(1, s.getInt("amount", 1)));
        ItemMeta meta = it.getItemMeta();
        if (s.contains("name")) meta.displayName(Util.c(s.getString("name")));
        for (String e : s.getStringList("enchants")) {
            String[] a = e.split(":");
            Enchantment en = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(a[0].toLowerCase()));
            if (en != null) meta.addEnchant(en, a.length > 1 ? Integer.parseInt(a[1]) : 1, true);
            else getLogger().warning("Unknown enchantment: " + a[0]);
        }
        it.setItemMeta(meta);
        return it;
    }

    private ConfigurationSection resolve(String ref) {
        return getConfig().getConfigurationSection("shop." + ref.replace(".", ".items."));
    }

    private boolean owns(Player p, ConfigurationSection s) {
        String own = s.getString("owned-permission", "");
        return !own.isEmpty() && p.hasPermission(own);
    }

    private ItemStack displayItem(Player p, ConfigurationSection s, long price, String... extra) {
        ItemStack it = buildItem(s);
        ItemMeta meta = it.getItemMeta();
        List<Component> lore = new ArrayList<>();
        for (String l : s.getStringList("lore")) lore.add(Util.c(l));
        List<String> bundle = s.getStringList("bundle");
        if (!bundle.isEmpty()) {
            lore.add(Util.c("&7Includes:"));
            for (String ref : bundle) {
                ConfigurationSection r = resolve(ref);
                if (r != null) lore.add(Util.c("&8 • &r" + r.getString("name", ref)));
            }
        }
        lore.add(Util.c(""));
        lore.add(Util.c("&7Price: &6" + Util.fmt(price) + " " + cur()));
        if (owns(p, s)) lore.add(Util.c("&a✔ You already own this"));
        else for (String x : extra) lore.add(Util.c(x));
        meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack balanceHead(Player p) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta sm = (SkullMeta) head.getItemMeta();
        sm.setOwningPlayer(p);
        sm.displayName(Util.c("&e&l" + p.getName()));
        double tm = totalMult(p);
        List<Component> lore = new ArrayList<>();
        lore.add(Util.c("&7Balance: &6" + Util.fmt(bal(p.getUniqueId())) + " " + cur() + " " + sym()));
        if (tm > 1.0001) lore.add(Util.c("&7Multiplier: &ax" + String.format("%.2f", tm)));
        sm.lore(lore);
        head.setItemMeta(sm);
        return head;
    }

    private ItemStack back() { return Util.item(Material.ARROW, "&7« Back", List.of()); }

    // ============================================================ confirm
    private void confirmOrRun(Player p, ItemStack preview, long price, Runnable action, Runnable cancel) {
        if (price < getConfig().getLong("confirm-above", 1000)) { action.run(); return; }
        Gui g = new Gui("&8Confirm purchase", 3);
        g.frame(Material.GRAY_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        ItemStack pv = preview.clone();
        ItemMeta m = pv.getItemMeta();
        m.lore(List.of(Util.c("&7Total: &6" + Util.fmt(price) + " " + cur()),
                Util.c("&7You have: &e" + Util.fmt(bal(p.getUniqueId())) + " " + cur())));
        pv.setItemMeta(m);
        g.set(13, pv, null);
        g.set(11, Util.item(Material.LIME_CONCRETE, "&a&lCONFIRM", List.of("&7Pay &6" + Util.fmt(price) + " " + cur())), e -> action.run());
        g.set(15, Util.item(Material.RED_CONCRETE, "&c&lCANCEL", List.of("&7Go back")), e -> cancel.run());
        g.open(p);
    }

    // ============================================================ HUB
    private void openHub(Player p) {
        Gui g = new Gui("&6&l" + cur() + " &8» &7Hub", 5);
        g.frame(Material.ORANGE_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);

        UUID id = p.getUniqueId();
        long dailyMs = 24L * 3600_000L;
        long left = lastDaily.getOrDefault(id, 0L) + dailyMs - System.currentTimeMillis();
        boolean ready = left <= 0;
        g.set(19, Util.item(ready ? Material.CHEST_MINECART : Material.MINECART, "&e&lDaily Reward",
                dailyLore(id, ready, left)), e -> claimDaily(p));
        g.set(20, Util.item(Material.TRIPWIRE_HOOK, "&d&lCrate Keys", List.of("&7Daily, Rare, Money & more", "", "&eClick to open")), e -> openKeys(p));
        g.set(21, Util.item(Material.NETHER_STAR, "&6&lRanks", List.of("&7VIP, MVP & more", "", "&eClick to open")), e -> openCategory(p, "ranks", () -> openHub(p)));
        g.set(22, Util.item(Material.CHEST, "&c&l" + cur() + " Shop", List.of("&7Maxed gear, totems & tools", "", "&eClick to open")), e -> openShopMain(p));
        g.set(23, Util.item(Material.BONE, "&b&lPets", List.of("&7Buy & summon companions", "", "&eClick to open")), e -> openPetShop(p));
        g.set(24, Util.item(Material.EMERALD, "&a&lExchange", List.of("&7Coins <-> money, any amount", "", "&eClick to open")), e -> openExchange(p));
        g.set(25, Util.item(Material.PLAYER_HEAD, "&e&lTop " + cur(), List.of("&7Richest players", "", "&eClick to open")), e -> openTop(p));
        g.set(31, Util.item(Material.LEAD, "&b&lMy Pets", List.of("&7Summon / put away", "", "&eClick to open")), e -> openPets(p));
        g.set(29, Util.item(Material.WRITABLE_BOOK, "&a&lDaily Missions", List.of("&7Complete tasks for coins", "", "&eClick to open")), e -> openMissions(p));
        g.set(30, Util.item(Material.ENDER_CHEST, "&6&lLucky Spin", List.of("&7Win coins, keys & boosters", "", "&eClick to open")), e -> openSpin(p));
        g.set(32, Util.item(Material.BLAZE_POWDER, "&e&lBoosters", List.of("&7Earn more " + cur() + " for a while", "", "&eClick to open")), e -> openBoosters(p));
        g.open(p);
    }

    private List<String> dailyLore(UUID id, boolean ready, long left) {
        List<String> l = new ArrayList<>();
        l.add("&7Streak: &f" + streak.getOrDefault(id, 0) + " days");
        l.add("&7Rewards: &6" + cur() + " &7+ keys:");
        ConfigurationSection ks = getConfig().getConfigurationSection("daily-reward.keys");
        if (ks != null) for (String k : ks.getKeys(false)) {
            ConfigurationSection kc = ks.getConfigurationSection(k);
            if (kc == null) continue;
            String nm = getConfig().getString("keys." + k + ".name", k);
            double ch = kc.getDouble("chance", 100);
            l.add("&8 • &r" + nm + " &7x" + kc.getInt("amount", 1) + (ch >= 100 ? " &a(guaranteed)" : " &e(" + (int) ch + "% chance)"));
        }
        l.add("");
        l.add(ready ? "&aReady! &eClick to claim" : "&cNext in &f" + (left / 3600_000L) + "h " + ((left / 60_000L) % 60) + "m");
        return l;
    }

    private void claimDaily(Player p) {
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis(), last = lastDaily.getOrDefault(id, 0L);
        if (now - last < 24L * 3600_000L) { msg(p, "&cYou already claimed your daily reward."); p.playSound(p, Sound.ENTITY_VILLAGER_NO, 1, 1); return; }
        int st = (now - last < 48L * 3600_000L && last != 0) ? streak.getOrDefault(id, 0) + 1 : 1;
        long reward = Math.min(getConfig().getLong("daily-reward.max", 100),
                getConfig().getLong("daily-reward.amount", 25) + (st - 1) * getConfig().getLong("daily-reward.streak-step", 5));
        streak.put(id, st);
        lastDaily.put(id, now);
        add(id, reward);
        saveSoon();
        msg(p, "&aDaily reward: &6+" + Util.fmt(reward) + " " + cur() + " &7(streak " + st + ")");

        // keys: guaranteed (chance 100) or random, chance grows with the streak
        ConfigurationSection ks = getConfig().getConfigurationSection("daily-reward.keys");
        if (ks != null) {
            Random rnd = new Random();
            double bonus = (st - 1) * getConfig().getDouble("daily-reward.streak-chance-bonus", 1);
            double cap = getConfig().getDouble("daily-reward.max-chance", 50);
            for (String k : ks.getKeys(false)) {
                ConfigurationSection kc = ks.getConfigurationSection(k);
                ConfigurationSection def = getConfig().getConfigurationSection("keys." + k);
                if (kc == null || def == null) { getLogger().warning("daily-reward.keys." + k + " has no matching entry under keys:"); continue; }
                double chance = kc.getDouble("chance", 100);
                if (chance < 100) chance = Math.min(cap, chance + bonus);
                if (rnd.nextDouble() * 100.0 >= chance) continue;
                int amt = Math.max(1, kc.getInt("amount", 1));
                if (giveKeyCommand(p.getName(), k, def, amt)) {
                    msg(p, "&dBonus key! &fYou got &r" + def.getString("name", k) + " &fx" + amt);
                    if (chance < 100) p.playSound(p, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1, 1);
                } else getLogger().warning("Could not give daily key '" + k + "' to " + p.getName() + " - check key-command!");
            }
        }
        p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.2f);
        openHub(p);
    }

    private void openTop(Player p) {
        Gui g = new Gui("&e&lTop " + cur(), 5);
        g.frame(Material.YELLOW_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        int[] slots = {11, 12, 13, 14, 15, 20, 21, 22, 23, 24};
        List<Map.Entry<UUID, Long>> t = top();
        for (int i = 0; i < Math.min(slots.length, t.size()); i++) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(t.get(i).getKey());
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(op);
            sm.displayName(Util.c("&6#" + (i + 1) + " &f" + (op.getName() == null ? "Unknown" : op.getName())));
            sm.lore(List.of(Util.c("&7" + Util.fmt(t.get(i).getValue()) + " " + cur())));
            head.setItemMeta(sm);
            g.set(slots[i], head, null);
        }
        g.set(40, back(), e -> openHub(p));
        g.open(p);
    }

    // ============================================================ KEYS
    private void openKeys(Player p) {
        Gui g = new Gui("&d&lKey Shop", 5);
        g.frame(Material.PURPLE_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        ConfigurationSection keys = getConfig().getConfigurationSection("keys");
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
        int i = 0;
        if (keys != null) for (String id : keys.getKeys(false)) {
            ConfigurationSection s = keys.getConfigurationSection(id);
            if (s == null || !s.getBoolean("enabled", true)) continue;
            if (i >= slots.length) break;
            long price = s.getLong("price");
            ItemStack it = displayItem(p, s, price, "", "&eLeft-click: &fbuy x1", "&eShift-click: &fbuy x5", "&eRight-click: &fchoose amount");
            g.set(slots[i++], it, e -> {
                if (e.isRightClick() && !e.isShiftClick())
                    prompt(p, "How many " + s.getString("name", id) + "&e keys do you want? (" + price + " each)", n -> buyKey(p, id, s, n));
                else buyKey(p, id, s, e.isShiftClick() ? 5 : 1);
            });
        }
        g.set(31, Util.item(Material.PAPER, "&6&lYour balance", List.of("&f" + Util.fmt(bal(p.getUniqueId())) + " " + cur())), null);
        g.set(40, back(), e -> openHub(p));
        g.open(p);
    }

    /** Runs the configured console command(s) that give a key. Returns false if nothing is configured or a command was not accepted. */
    private boolean hasKeyCommand(ConfigurationSection s) {
        return !s.getStringList("commands").isEmpty() || !getConfig().getString("key-command", "").isBlank();
    }

    private String lastKeyCmd = "";

    private boolean giveKeyCommand(String playerName, String id, ConfigurationSection s, long amt) {
        List<String> cmds = new ArrayList<>(s.getStringList("commands"));
        if (cmds.isEmpty()) {
            String g = getConfig().getString("key-command", "");
            if (!g.isBlank()) cmds.add(g);
        }
        if (cmds.isEmpty()) return false;
        boolean ok = true;
        for (String c : cmds) {
            // if the command has no {amount}, run it once per key bought
            int times = c.contains("{amount}") ? 1 : (int) Math.max(1, Math.min(amt, 500));
            String cmd = c.replace("{player}", playerName).replace("{key}", id).replace("{amount}", String.valueOf(amt));
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            lastKeyCmd = cmd;
            for (int i = 0; i < times; i++) {
                boolean r = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
                if (i == 0) getLogger().info("Key command '" + cmd + "' x" + times + " -> " + (r ? "accepted" : "REJECTED (unknown command / wrong usage)"));
                if (!r) { ok = false; break; }
            }
        }
        return ok;
    }

    private void buyKey(Player p, String id, ConfigurationSection s, long amt) {
        if (!hasKeyCommand(s)) {
            msg(p, "&cKeys are not set up yet. Ask an admin to set &fkey-command &cin the config.");
            return;
        }
        long total = s.getLong("price") * amt;
        confirmOrRun(p, buildItem(s), total, () -> {
            if (amt <= 0 || !take(p.getUniqueId(), total)) {
                msg(p, "&cNot enough " + cur() + "! You need &6" + Util.fmt(total));
                p.playSound(p, Sound.ENTITY_VILLAGER_NO, 1, 1);
                openKeys(p);
                return;
            }
            if (!giveKeyCommand(p.getName(), id, s, amt)) {
                add(p.getUniqueId(), total); // refund - the key command failed
                msg(p, "&cCould not deliver the key, you were refunded. Tell an admin (see console).");
                if (p.hasPermission("coins.admin")) msg(p, "&7[admin] command that was rejected: &f/" + lastKeyCmd);
                p.playSound(p, Sound.ENTITY_VILLAGER_NO, 1, 1);
                openKeys(p);
                return;
            }
            msg(p, "&aBought &f" + Util.fmt(amt) + "x &r" + s.getString("name", id) + " &afor &6" + Util.fmt(total) + " " + cur());
            p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.5f);
            openKeys(p);
        }, () -> openKeys(p));
    }

    // ============================================================ EXCHANGE
    private void openExchange(Player p) {
        Gui g = new Gui("&a&lExchange", 5);
        g.frame(Material.LIME_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        if (eco == null) {
            g.set(22, Util.item(Material.BARRIER, "&cVault economy not found", List.of("&7Ask an admin to install Vault + an economy plugin")), null);
            g.set(40, back(), e -> openHub(p));
            g.open(p); return;
        }
        double sell = getConfig().getDouble("exchange.coins-to-money", 100);
        double buy = getConfig().getDouble("exchange.money-to-coins", 150);
        List<Integer> amts = getConfig().getIntegerList("exchange.amounts");
        int[] topSlots = {19, 20, 21, 22}, botSlots = {28, 29, 30, 31};

        g.set(10, Util.item(Material.GOLD_INGOT, "&6&l" + cur() + " &f→ &a&lMoney",
                List.of("&71 " + cur() + " = &a$" + sell, "&7Your money: &a$" + String.format("%,.2f", eco.getBalance(p)))), null);
        g.set(37, Util.item(Material.EMERALD, "&a&lMoney &f→ &6&l" + cur(), List.of("&71 " + cur() + " costs &a$" + buy)), null);

        for (int i = 0; i < Math.min(amts.size(), 4); i++) {
            long n = amts.get(i);
            g.set(topSlots[i], Util.item(Material.GOLD_NUGGET, "&6Sell &f" + Util.fmt(n) + " " + cur(),
                    List.of("&7You get: &a$" + String.format("%,.2f", n * sell))), e -> sellCoins(p, n));
            g.set(botSlots[i], Util.item(Material.EMERALD, "&aBuy &f" + Util.fmt(n) + " " + cur(),
                    List.of("&7Costs: &a$" + String.format("%,.2f", n * buy))), e -> buyCoins(p, n));
        }
        g.set(23, Util.item(Material.GOLD_BLOCK, "&6&lSell ALL", List.of("&7Sell every " + cur() + " you own")), e -> sellCoins(p, bal(p.getUniqueId())));
        g.set(24, Util.item(Material.NAME_TAG, "&6&lSell custom amount",
                List.of("&7Choose exactly how many", "", "&eClick, then type in chat")),
                e -> prompt(p, "How many " + cur() + " do you want to SELL for money?", n -> sellCoins(p, n)));
        g.set(32, Util.item(Material.EMERALD_BLOCK, "&a&lBuy MAX", List.of("&7Buy as many as your money allows")),
                e -> buyCoins(p, (long) Math.floor(eco.getBalance(p) / buy)));
        g.set(33, Util.item(Material.NAME_TAG, "&a&lBuy custom amount",
                List.of("&7Choose exactly how many", "", "&eClick, then type in chat")),
                e -> prompt(p, "How many " + cur() + " do you want to BUY with money?", n -> buyCoins(p, n)));
        g.set(40, back(), e -> openHub(p));
        g.open(p);
    }

    private void sellCoins(Player p, long n) {
        if (n <= 0 || !take(p.getUniqueId(), n)) { msg(p, "&cNot enough " + cur() + "!"); return; }
        double money = n * getConfig().getDouble("exchange.coins-to-money", 100);
        eco.depositPlayer(p, money);
        msg(p, "&aSold &6" + Util.fmt(n) + " " + cur() + " &afor &f$" + String.format("%,.2f", money));
        p.playSound(p, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1, 1);
        openExchange(p);
    }

    private void buyCoins(Player p, long n) {
        double cost = n * getConfig().getDouble("exchange.money-to-coins", 150);
        if (n <= 0 || !eco.has(p, cost)) { msg(p, "&cNot enough money!"); return; }
        eco.withdrawPlayer(p, cost);
        add(p.getUniqueId(), n);
        saveSoon();
        msg(p, "&aBought &6" + Util.fmt(n) + " " + cur() + " &afor &f$" + String.format("%,.2f", cost));
        p.playSound(p, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1, 1.4f);
        openExchange(p);
    }

    // ============================================================ SHOP
    private void openShopMain(Player p) {
        Gui g = new Gui("&c&l" + cur() + " Shop", 5);
        g.frame(Material.RED_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        ConfigurationSection cats = getConfig().getConfigurationSection("shop");
        int[] slots = {10, 12, 14, 16};
        int i = 0;
        if (cats != null) for (String id : cats.getKeys(false)) {
            if (id.equals("ranks")) continue; // ranks have their own button
            ConfigurationSection c = cats.getConfigurationSection(id);
            if (c == null || !c.getBoolean("enabled", true)) continue;
            if (i >= slots.length) break;
            Material icon = Material.matchMaterial(c.getString("icon", "CHEST"));
            g.set(slots[i++], Util.item(icon == null ? Material.CHEST : icon, c.getString("title", id),
                    List.of("&7Browse items", "", "&eClick to open")), e -> openCategory(p, id, () -> openShopMain(p)));
        }
        g.set(22, Util.item(Material.EMERALD, "&a&lExchange", List.of("&7Coins <-> money, any amount", "", "&eClick to open")), e -> openExchange(p));
        g.set(29, Util.item(Material.TRIPWIRE_HOOK, "&d&lCrate Keys", List.of("&7Daily, Rare, Money & more", "", "&eClick to open")), e -> openKeys(p));
        g.set(31, Util.item(Material.NETHER_STAR, "&6&lRanks", List.of("&7VIP, MVP & more", "", "&eClick to open")), e -> openCategory(p, "ranks", () -> openShopMain(p)));
        g.set(33, Util.item(Material.BONE, "&b&lPets", List.of("&7Companions that follow you", "&7and boost your " + cur(), "", "&eClick to open")), e -> openPetShop(p));
        g.set(24, Util.item(Material.BLAZE_POWDER, "&e&lBoosters", List.of("&7Earn more " + cur() + " for a while", "", "&eClick to open")), e -> openBoosters(p));
        g.set(40, back(), e -> openHub(p));
        g.open(p);
    }

    private void openCategory(Player p, String cat, Runnable backAction) {
        ConfigurationSection c = getConfig().getConfigurationSection("shop." + cat);
        if (c == null) return;
        Gui g = new Gui(c.getString("title", cat), 6);
        g.frame(Material.GRAY_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        ConfigurationSection items = c.getConfigurationSection("items");
        List<Integer> slots = new ArrayList<>();
        for (int r = 1; r <= 4; r++) for (int col = 1; col <= 7; col++) slots.add(r * 9 + col);
        int i = 0;
        if (items != null) for (String id : items.getKeys(false)) {
            ConfigurationSection s = items.getConfigurationSection(id);
            if (s == null || !s.getBoolean("enabled", true)) continue;
            if (i >= slots.size()) break;
            long price = s.getLong("price");
            g.set(slots.get(i++), displayItem(p, s, price, "", "&eClick to purchase"), e -> purchase(p, s, price, cat, backAction));
        }
        g.set(49, back(), e -> backAction.run());
        g.open(p);
    }

    private void purchase(Player p, ConfigurationSection s, long price, String cat, Runnable backAction) {
        if (owns(p, s)) { msg(p, "&cYou already own this!"); return; }
        List<ItemStack> give = new ArrayList<>();
        if (s.getBoolean("give-item", true)) {
            List<String> bundle = s.getStringList("bundle");
            if (bundle.isEmpty()) give.add(buildItem(s));
            else for (String ref : bundle) {
                ConfigurationSection r = resolve(ref);
                if (r != null) give.add(buildItem(r));
            }
        }
        int free = 0;
        for (ItemStack st : p.getInventory().getStorageContents()) if (st == null) free++;
        if (free < give.size()) { msg(p, "&cYou need &f" + give.size() + " &cfree inventory slots!"); return; }

        confirmOrRun(p, buildItem(s), price, () -> {
            if (!take(p.getUniqueId(), price)) {
                msg(p, "&cNot enough " + cur() + "! Need &6" + Util.fmt(price));
                p.playSound(p, Sound.ENTITY_VILLAGER_NO, 1, 1);
                openCategory(p, cat, backAction);
                return;
            }
            for (ItemStack st : give) p.getInventory().addItem(st);
            for (String cmd : s.getStringList("commands"))
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("{player}", p.getName()));
            msg(p, "&aPurchased &r" + s.getString("name", "item") + " &afor &6" + Util.fmt(price) + " " + cur());
            p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.5f);
            openCategory(p, cat, backAction);
        }, () -> openCategory(p, cat, backAction));
    }

    // ============================================================ PETS
    private void openPetShop(Player p) {
        Gui g = new Gui("&b&lPet Shop", 5);
        g.frame(Material.CYAN_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        ConfigurationSection pets = getConfig().getConfigurationSection("pets");
        List<Integer> slots = new ArrayList<>();
        for (int r = 1; r <= 3; r++) for (int col = 1; col <= 7; col++) slots.add(r * 9 + col);
        int i = 0;
        Set<String> owned = ownedPets.computeIfAbsent(p.getUniqueId(), k -> new HashSet<>());
        if (pets != null) for (String id : pets.getKeys(false)) {
            if (i >= slots.size()) break;
            ConfigurationSection s = pets.getConfigurationSection(id);
            Material icon = Material.matchMaterial(s.getString("icon", "BONE"));
            long price = s.getLong("price");
            boolean has = owned.contains(id);
            List<String> lore = new ArrayList<>(List.of("&7Follows you around!"));
            if (s.getDouble("bonus", 0) > 0) lore.add("&7Bonus: &a+" + (int) s.getDouble("bonus") + "% " + cur());
            lore.add("");
            lore.add(has ? "&a✔ Owned &7- use /pets to summon" : "&7Price: &6" + Util.fmt(price) + " " + cur());
            if (!has) lore.add("&eClick to purchase");
            ItemStack it = Util.item(icon == null ? Material.BONE : icon, s.getString("name", id), lore);
            g.set(slots.get(i++), it, e -> {
                if (owned.contains(id)) { msg(p, "&cYou already own this pet."); return; }
                confirmOrRun(p, it, price, () -> {
                    if (!take(p.getUniqueId(), price)) { msg(p, "&cNot enough " + cur() + "!"); openPetShop(p); return; }
                    owned.add(id);
                    saveSoon();
                    msg(p, "&aYou got " + s.getString("name", id) + "&a! Open &f/pets &ato summon it.");
                    p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.5f);
                    openPetShop(p);
                }, () -> openPetShop(p));
            });
        }
        g.set(40, back(), e -> openShopMain(p));
        g.open(p);
    }

    private void openPets(Player p) {
        Gui g = new Gui("&b&lMy Pets", 5);
        g.frame(Material.CYAN_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        Set<String> owned = ownedPets.getOrDefault(p.getUniqueId(), Set.of());
        List<Integer> slots = new ArrayList<>();
        for (int r = 1; r <= 3; r++) for (int col = 1; col <= 7; col++) slots.add(r * 9 + col);
        int i = 0;
        String active = activePetId.get(p.getUniqueId());
        boolean out = activePets.containsKey(p.getUniqueId());
        for (String id : owned) {
            if (i >= slots.size()) break;
            ConfigurationSection s = getConfig().getConfigurationSection("pets." + id);
            if (s == null) continue;
            Material icon = Material.matchMaterial(s.getString("icon", "BONE"));
            boolean isOut = out && id.equals(active);
            List<String> lore = new ArrayList<>();
            lore.add(isOut ? "&aCurrently following you" : "&7Stored");
            if (s.getDouble("bonus", 0) > 0) lore.add("&7Bonus: &a+" + (int) s.getDouble("bonus") + "% " + cur() + " while out");
            lore.add("");
            lore.add(isOut ? "&eClick to put away" : "&eClick to summon");
            g.set(slots.get(i++), Util.item(icon == null ? Material.BONE : icon, s.getString("name", id), lore), e -> {
                if (isOut) { despawn(p.getUniqueId()); activePetId.remove(p.getUniqueId()); saveSoon(); }
                else summon(p, id);
                openPets(p);
            });
        }
        if (owned.isEmpty())
            g.set(22, Util.item(Material.BARRIER, "&cNo pets yet", List.of("&7Buy some in the Pet Shop")),
                    e -> openPetShop(p));
        g.set(40, back(), e -> openHub(p));
        g.open(p);
    }

    // ============================================================ commands
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase();
        if (name.equals("coinsadmin")) return admin(sender, args);

        if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        switch (name) {
            case "coins" -> {
                if (args.length > 0) {
                    OfflinePlayer t = Bukkit.getOfflinePlayer(args[0]);
                    msg(p, "&f" + args[0] + "&7 has &6" + Util.fmt(bal(t.getUniqueId())) + " " + cur());
                } else openHub(p);
            }
            case "keys" -> openKeys(p);
            case "coinshop" -> openShopMain(p);
            case "exchange" -> openExchange(p);
            case "pets" -> openPets(p);
            case "ranks" -> openCategory(p, "ranks", () -> openHub(p));
            case "daily" -> claimDaily(p);
            case "coinstop" -> openTop(p);
            case "missions" -> openMissions(p);
            case "spin" -> openSpin(p);
            case "boosters" -> openBoosters(p);
            case "coinswithdraw" -> {
                if (args.length < 1) { msg(p, "&cUsage: /coinswithdraw <amount>  (turns coins into a tradeable voucher)"); return true; }
                long n = parseAmount(args[0]);
                long min = getConfig().getLong("voucher.min", 100);
                if (n < min) { msg(p, "&cMinimum voucher is &6" + Util.fmt(min) + " " + cur()); return true; }
                if (p.getInventory().firstEmpty() == -1) { msg(p, "&cYour inventory is full!"); return true; }
                if (!take(p.getUniqueId(), n)) { msg(p, "&cNot enough " + cur() + "!"); return true; }
                p.getInventory().addItem(makeVoucher(n));
                msg(p, "&aCreated a voucher worth &6" + Util.fmt(n) + " " + cur() + "&a. Right-click it to redeem.");
            }
            case "coinspay" -> {
                if (args.length < 2) { msg(p, "&cUsage: /coinspay <player> <amount>"); return true; }
                OfflinePlayer t = Bukkit.getOfflinePlayer(args[0]);
                long n = parseAmount(args[1]);
                if (!t.hasPlayedBefore() && !t.isOnline()) { msg(p, "&cUnknown player."); return true; }
                if (t.getUniqueId().equals(p.getUniqueId())) { msg(p, "&cYou can't pay yourself."); return true; }
                if (n <= 0 || !take(p.getUniqueId(), n)) { msg(p, "&cInvalid amount or not enough " + cur() + "."); return true; }
                add(t.getUniqueId(), n);
                msg(p, "&aSent &6" + Util.fmt(n) + " " + cur() + " &ato &f" + args[0]);
                if (t.isOnline()) msg(t.getPlayer(), "&aYou received &6" + Util.fmt(n) + " " + cur() + " &afrom &f" + p.getName());
            }
        }
        return true;
    }

    private boolean admin(CommandSender s, String[] a) {
        if (!s.hasPermission("coins.admin")) { msg(s, "&cNo permission."); return true; }
        saveSoon();
        if (a.length == 0) {
            msg(s, "&e/coinsadmin <add|remove|set|reset|check|givepet|removepet|testkey|reload> <player> [amount|pet|key]");
            return true;
        }
        if (a[0].equalsIgnoreCase("reload")) { reloadConfig(); missionCache.clear(); msg(s, "&aReloaded config."); return true; }
        if (a[0].equalsIgnoreCase("globalbooster")) {
            if (a.length < 3) { msg(s, "&cUsage: /coinsadmin globalbooster <multiplier> <minutes>   (0 minutes = stop)"); return true; }
            try {
                double m = Double.parseDouble(a[1]);
                int min = Integer.parseInt(a[2]);
                if (min <= 0) { globalUntil = 0; msg(s, "&aGlobal booster stopped."); }
                else {
                    globalMult = m;
                    globalUntil = System.currentTimeMillis() + min * 60_000L;
                    Bukkit.broadcast(Util.c(getConfig().getString("prefix", "") + "&6&lGLOBAL BOOSTER! &eEveryone earns &ax" + m + " " + cur() + " &efor &f" + min + " minutes&e!"));
                }
                saveSoon();
            } catch (NumberFormatException ex) { msg(s, "&cInvalid number."); }
            return true;
        }
        if (a[0].equalsIgnoreCase("booster")) {
            if (a.length < 4) { msg(s, "&cUsage: /coinsadmin booster <player> <multiplier> <minutes>"); return true; }
            try {
                OfflinePlayer bt = Bukkit.getOfflinePlayer(a[1]);
                applyBooster(bt.getUniqueId(), Double.parseDouble(a[2]), Integer.parseInt(a[3]));
                msg(s, "&aGave " + a[1] + " a x" + a[2] + " booster for " + a[3] + " min.");
                if (bt.isOnline()) msg(bt.getPlayer(), "&aYou received a &ex" + a[2] + " booster &afor &f" + a[3] + " &aminutes!");
            } catch (NumberFormatException ex) { msg(s, "&cInvalid number."); }
            return true;
        }
        if (a.length < 2) { msg(s, "&cUsage: /coinsadmin " + a[0] + " <player> [amount]"); return true; }
        OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]);
        UUID id = t.getUniqueId();
        long amt = 0;
        if (a.length >= 3 && !a[0].equalsIgnoreCase("givepet") && !a[0].equalsIgnoreCase("removepet") && !a[0].equalsIgnoreCase("testkey")) {
            amt = parseAmount(a[2]);
            if (amt < 0) { msg(s, "&cInvalid number."); return true; }
        }
        switch (a[0].toLowerCase()) {
            case "add" -> { add(id, amt); msg(s, "&aAdded &6" + Util.fmt(amt) + "&a to " + a[1] + ". Now: " + Util.fmt(bal(id))); }
            case "remove" -> { setBal(id, bal(id) - amt); msg(s, "&aRemoved &6" + Util.fmt(amt) + "&a from " + a[1] + ". Now: " + Util.fmt(bal(id))); }
            case "set" -> { setBal(id, amt); msg(s, "&aSet " + a[1] + " to &6" + Util.fmt(amt)); }
            case "reset" -> { setBal(id, 0); msg(s, "&aReset " + a[1] + "."); }
            case "check" -> msg(s, "&f" + a[1] + " &7has &6" + Util.fmt(bal(id)) + " " + cur());
            case "givepet" -> {
                if (a.length < 3 || getConfig().getConfigurationSection("pets." + a[2]) == null) { msg(s, "&cUnknown pet id."); return true; }
                ownedPets.computeIfAbsent(id, k -> new HashSet<>()).add(a[2]);
                coins.putIfAbsent(id, 0L);
                msg(s, "&aGave pet &f" + a[2] + "&a to " + a[1]);
            }
            case "testkey" -> {
                ConfigurationSection ks = a.length >= 3 ? getConfig().getConfigurationSection("keys." + a[2]) : null;
                if (ks == null) { msg(s, "&cUsage: /coinsadmin testkey <player> <keyid>  (keyid from config keys:)"); return true; }
                if (!hasKeyCommand(ks)) { msg(s, "&ckey-command is empty in config.yml."); return true; }
                boolean ok = giveKeyCommand(a[1], a[2], ks, 1);
                msg(s, ok ? "&aCommand accepted - check that " + a[1] + " really got the key. See console for the exact command."
                          : "&cCommand was REJECTED. Fix key-command in config.yml (see console for the exact command), then /coinsadmin reload.");
            }
            case "removepet" -> {
                if (a.length < 3) { msg(s, "&cUsage: /coinsadmin removepet <player> <pet>"); return true; }
                ownedPets.getOrDefault(id, new HashSet<>()).remove(a[2]);
                if (a[2].equals(activePetId.get(id))) { despawn(id); activePetId.remove(id); }
                msg(s, "&aRemoved pet &f" + a[2] + "&a from " + a[1]);
            }
            default -> msg(s, "&cUnknown sub-command.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        String n = c.getName().toLowerCase();
        if (n.equals("coinspay") && a.length == 1) return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        if (!n.equals("coinsadmin") || !s.hasPermission("coins.admin")) return List.of();
        if (a.length == 1) return List.of("add", "remove", "set", "reset", "check", "givepet", "removepet", "testkey", "booster", "globalbooster", "reload");
        if (a.length == 2) return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        if (a.length == 3 && (a[0].equalsIgnoreCase("givepet") || a[0].equalsIgnoreCase("removepet"))) {
            ConfigurationSection ps = getConfig().getConfigurationSection("pets");
            return ps == null ? List.of() : new ArrayList<>(ps.getKeys(false));
        }
        return List.of();
    }
}
