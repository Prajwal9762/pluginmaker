package com.coins;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.function.Consumer;

public class CoinsPlugin extends JavaPlugin implements Listener, TabExecutor {

    private Economy eco;
    private File dataFile;
    private YamlConfiguration data;

    private final Map<UUID, Long> coins = new HashMap<>();
    private final Map<UUID, Set<String>> ownedPets = new HashMap<>();
    private final Map<UUID, String> activePetId = new HashMap<>();
    private final Map<UUID, Long> lastDaily = new HashMap<>();
    private final Map<UUID, Integer> streak = new HashMap<>();
    private final Map<UUID, Double> remainder = new HashMap<>();

    private final Map<UUID, Entity> activePets = new HashMap<>();
    private final Set<UUID> petEntityIds = new HashSet<>();
    private final Map<UUID, Consumer<Long>> prompts = new HashMap<>();
    private final Map<String, Long> placedBlocks = new HashMap<>();

    // ============================================================ lifecycle
    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadData();
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) eco = rsp.getProvider();
        else getLogger().warning("Vault economy not found - /exchange is disabled.");

        getServer().getPluginManager().registerEvents(this, this);
        for (String cmd : List.of("coins", "keys", "coinshop", "exchange", "pets", "ranks", "daily",
                "coinspay", "coinstop", "coinsadmin")) {
            PluginCommand pc = getCommand(cmd);
            if (pc != null) { pc.setExecutor(this); pc.setTabCompleter(this); }
        }

        long interval = Math.max(1, getConfig().getLong("earn.interval-seconds", 60)) * 20L;
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            long amt = getConfig().getLong("earn.timed-amount", 1);
            for (Player p : Bukkit.getOnlinePlayers()) earn(p, amt);
        }, interval, interval);
        Bukkit.getScheduler().runTaskTimer(this, this::followTick, 10L, 10L);
        Bukkit.getScheduler().runTaskTimer(this, () -> { saveData(); cleanPlaced(); }, 6000L, 6000L);
    }

    @Override
    public void onDisable() {
        for (Entity e : new ArrayList<>(activePets.values())) e.remove();
        activePets.clear();
        saveData();
    }

    // ============================================================ data
    private void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection pl = data.getConfigurationSection("players");
        if (pl == null) return;
        for (String k : pl.getKeys(false)) {
            try {
                UUID id = UUID.fromString(k);
                coins.put(id, pl.getLong(k + ".coins"));
                ownedPets.put(id, new HashSet<>(pl.getStringList(k + ".pets")));
                String ap = pl.getString(k + ".active");
                if (ap != null && !ap.isEmpty()) activePetId.put(id, ap);
                lastDaily.put(id, pl.getLong(k + ".daily-last"));
                streak.put(id, pl.getInt(k + ".streak"));
            } catch (IllegalArgumentException ignored) {}
        }
    }

    private void saveData() {
        data.set("players", null);
        for (Map.Entry<UUID, Long> en : coins.entrySet()) {
            UUID id = en.getKey();
            String b = "players." + id;
            data.set(b + ".coins", en.getValue());
            data.set(b + ".pets", new ArrayList<>(ownedPets.getOrDefault(id, Set.of())));
            data.set(b + ".active", activePetId.getOrDefault(id, ""));
            data.set(b + ".daily-last", lastDaily.getOrDefault(id, 0L));
            data.set(b + ".streak", streak.getOrDefault(id, 0));
        }
        try { data.save(dataFile); } catch (IOException ex) { getLogger().severe("Could not save data: " + ex); }
    }

    private void cleanPlaced() {
        long limit = System.currentTimeMillis() - getConfig().getLong("earn.anti-abuse-seconds", 30) * 1000L;
        placedBlocks.values().removeIf(t -> t < limit);
    }

    // ============================================================ economy
    public long bal(UUID id) { return coins.getOrDefault(id, 0L); }
    public void setBal(UUID id, long v) { coins.put(id, Math.max(0, v)); }
    public void add(UUID id, long v) { setBal(id, bal(id) + v); }
    public boolean take(UUID id, long v) {
        if (v < 0 || bal(id) < v) return false;
        setBal(id, bal(id) - v);
        return true;
    }

    private String cur() { return getConfig().getString("currency-name", "Coins"); }
    private String sym() { return getConfig().getString("currency-symbol", "⛃"); }
    private void msg(CommandSender s, String m) { s.sendMessage(Util.c(getConfig().getString("prefix", "") + m)); }

    private double petBonus(UUID id) {
        if (!activePets.containsKey(id)) return 0;
        String pid = activePetId.get(id);
        return pid == null ? 0 : getConfig().getDouble("pets." + pid + ".bonus", 0);
    }

    private void earn(Player p, long base) {
        if (base <= 0) return;
        if (getConfig().getStringList("earn.disabled-worlds").contains(p.getWorld().getName())) return;
        UUID id = p.getUniqueId();
        double raw = base * (1 + petBonus(id) / 100.0) + remainder.getOrDefault(id, 0.0);
        long give = (long) raw;
        remainder.put(id, raw - give);
        if (give <= 0) return;
        add(id, give);
        if (getConfig().getBoolean("earn.actionbar", true))
            p.sendActionBar(Util.c("&6+" + give + " " + cur() + " &7(" + Util.fmt(bal(id)) + ")"));
    }

    private List<Map.Entry<UUID, Long>> top() {
        List<Map.Entry<UUID, Long>> l = new ArrayList<>(coins.entrySet());
        l.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
        return l;
    }

    // ============================================================ events
    private String key(org.bukkit.block.Block b) {
        return b.getWorld().getName() + ":" + b.getX() + "," + b.getY() + "," + b.getZ();
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (getConfig().getBoolean("earn.anti-abuse", true)) {
            if (placedBlocks.size() > 30000) placedBlocks.clear();
            placedBlocks.put(key(e.getBlock()), System.currentTimeMillis());
        }
        earn(e.getPlayer(), getConfig().getLong("earn.per-block-place", 1));
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (getConfig().getBoolean("earn.anti-abuse", true)) {
            Long t = placedBlocks.remove(key(e.getBlock()));
            long win = getConfig().getLong("earn.anti-abuse-seconds", 30) * 1000L;
            if (t != null && System.currentTimeMillis() - t < win) return; // place+break farming
        }
        earn(e.getPlayer(), getConfig().getLong("earn.per-block-break", 1));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        coins.putIfAbsent(p.getUniqueId(), 0L);
        String ap = activePetId.get(p.getUniqueId());
        if (ap != null && ownedPets.getOrDefault(p.getUniqueId(), Set.of()).contains(ap))
            Bukkit.getScheduler().runTaskLater(this, () -> { if (p.isOnline()) summon(p, ap); }, 40L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        prompts.remove(e.getPlayer().getUniqueId());
        despawn(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Gui g) {
            e.setCancelled(true);
            if (e.getClickedInventory() == e.getView().getTopInventory()) g.click(e);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Gui) e.setCancelled(true);
    }

    @EventHandler public void onPetDamage(EntityDamageEvent e) {
        if (petEntityIds.contains(e.getEntity().getUniqueId())) e.setCancelled(true);
    }
    @EventHandler public void onPetInteract(PlayerInteractEntityEvent e) {
        if (petEntityIds.contains(e.getRightClicked().getUniqueId())) e.setCancelled(true);
    }
    @EventHandler public void onPetTarget(EntityTargetEvent e) {
        if (petEntityIds.contains(e.getEntity().getUniqueId())) e.setCancelled(true);
    }
    @EventHandler public void onTeleport(PlayerTeleportEvent e) {
        Entity pet = activePets.get(e.getPlayer().getUniqueId());
        if (pet != null && pet.isValid())
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (pet.isValid() && e.getPlayer().isOnline()) pet.teleport(e.getPlayer().getLocation());
            }, 5L);
    }

    // ============================================================ chat prompt (custom amounts)
    private void prompt(Player p, String question, Consumer<Long> cb) {
        p.closeInventory();
        prompts.put(p.getUniqueId(), cb);
        msg(p, "&e" + question);
        msg(p, "&7Type a number in chat (examples: &f250&7, &f2k&7, &f1.5m&7). Type &ccancel &7to abort.");
    }

    private long parseAmount(String t) {
        try {
            t = t.trim().toLowerCase().replace(",", "");
            double mult = 1;
            if (t.endsWith("k")) { mult = 1_000; t = t.substring(0, t.length() - 1); }
            else if (t.endsWith("m")) { mult = 1_000_000; t = t.substring(0, t.length() - 1); }
            return (long) (Double.parseDouble(t) * mult);
        } catch (NumberFormatException ex) { return -1; }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        Consumer<Long> cb = prompts.remove(e.getPlayer().getUniqueId());
        if (cb == null) return;
        e.setCancelled(true);
        String text = PlainTextComponentSerializer.plainText().serialize(e.message());
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(this, () -> {
            if (text.equalsIgnoreCase("cancel")) { msg(p, "&cCancelled."); return; }
            long n = parseAmount(text);
            if (n <= 0 || n > 100_000_000L) { msg(p, "&cThat is not a valid amount."); return; }
            cb.accept(n);
        });
    }

    // ============================================================ pets
    private void summon(Player p, String id) {
        despawn(p.getUniqueId());
        ConfigurationSection s = getConfig().getConfigurationSection("pets." + id);
        if (s == null) return;
        EntityType type;
        try { type = EntityType.valueOf(s.getString("entity", "WOLF").toUpperCase()); }
        catch (IllegalArgumentException ex) { return; }
        Entity ent = p.getWorld().spawnEntity(p.getLocation(), type);
        ent.setInvulnerable(true);
        ent.setPersistent(false);
        ent.customName(Util.c(s.getString("name", id) + " &7(" + p.getName() + ")"));
        ent.setCustomNameVisible(true);
        if (ent instanceof Ageable a && s.getBoolean("baby", false)) { a.setBaby(); a.setAgeLock(true); }
        if (ent instanceof Tameable t) { t.setTamed(true); t.setOwner(p); }
        if (ent instanceof Sittable si) si.setSitting(false);
        if (ent instanceof Mob m) m.setRemoveWhenFarAway(false);
        activePets.put(p.getUniqueId(), ent);
        petEntityIds.add(ent.getUniqueId());
        activePetId.put(p.getUniqueId(), id);
    }

    private void despawn(UUID owner) {
        Entity e = activePets.remove(owner);
        if (e != null) { petEntityIds.remove(e.getUniqueId()); e.remove(); }
    }

    private void followTick() {
        Iterator<Map.Entry<UUID, Entity>> it = activePets.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Entity> en = it.next();
            Player p = Bukkit.getPlayer(en.getKey());
            Entity pet = en.getValue();
            if (p == null || !p.isOnline()) { petEntityIds.remove(pet.getUniqueId()); pet.remove(); it.remove(); continue; }
            if (!pet.isValid()) {
                it.remove(); petEntityIds.remove(pet.getUniqueId());
                String id = activePetId.get(en.getKey());
                if (id != null) Bukkit.getScheduler().runTask(this, () -> summon(p, id));
                break;
            }
            if (!pet.getWorld().equals(p.getWorld()) || pet.getLocation().distanceSquared(p.getLocation()) > 400) {
                pet.teleport(p.getLocation());
            } else if (pet.getLocation().distanceSquared(p.getLocation()) > 12 && pet instanceof Mob m) {
                m.getPathfinder().moveTo(p.getLocation(), 1.3);
            }
        }
    }

    // ============================================================ item helpers
    private ItemStack buildItem(ConfigurationSection s) {
        Material m = Material.matchMaterial(s.getString("material", "STONE"));
        if (m == null) m = Material.BARRIER;
        ItemStack it = new ItemStack(m, Math.max(1, s.getInt("amount", 1)));
        ItemMeta meta = it.getItemMeta();
        if (s.contains("name")) meta.displayName(Util.c(s.getString("name")));
        for (String e : s.getStringList("enchants")) {
            String[] a = e.split(":");
            Enchantment en = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(a[0].toLowerCase()));
            if (en != null) meta.addEnchant(en, a.length > 1 ? Integer.parseInt(a[1]) : 1, true);
            else getLogger().warning("Unknown enchantment: " + a[0]);
        }
        it.setItemMeta(meta);
        return it;
    }

    private ConfigurationSection resolve(String ref) {
        return getConfig().getConfigurationSection("shop." + ref.replace(".", ".items."));
    }

    private boolean owns(Player p, ConfigurationSection s) {
        String own = s.getString("owned-permission", "");
        return !own.isEmpty() && p.hasPermission(own);
    }

    private ItemStack displayItem(Player p, ConfigurationSection s, long price, String... extra) {
        ItemStack it = buildItem(s);
        ItemMeta meta = it.getItemMeta();
        List<Component> lore = new ArrayList<>();
        for (String l : s.getStringList("lore")) lore.add(Util.c(l));
        List<String> bundle = s.getStringList("bundle");
        if (!bundle.isEmpty()) {
            lore.add(Util.c("&7Includes:"));
            for (String ref : bundle) {
                ConfigurationSection r = resolve(ref);
                if (r != null) lore.add(Util.c("&8 • &r" + r.getString("name", ref)));
            }
        }
        lore.add(Util.c(""));
        lore.add(Util.c("&7Price: &6" + Util.fmt(price) + " " + cur()));
        if (owns(p, s)) lore.add(Util.c("&a✔ You already own this"));
        else for (String x : extra) lore.add(Util.c(x));
        meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack balanceHead(Player p) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta sm = (SkullMeta) head.getItemMeta();
        sm.setOwningPlayer(p);
        sm.displayName(Util.c("&e&l" + p.getName()));
        double b = petBonus(p.getUniqueId());
        List<Component> lore = new ArrayList<>();
        lore.add(Util.c("&7Balance: &6" + Util.fmt(bal(p.getUniqueId())) + " " + cur() + " " + sym()));
        if (b > 0) lore.add(Util.c("&7Pet bonus: &a+" + (int) b + "% " + cur()));
        sm.lore(lore);
        head.setItemMeta(sm);
        return head;
    }

    private ItemStack back() { return Util.item(Material.ARROW, "&7« Back", List.of()); }

    // ============================================================ confirm
    private void confirmOrRun(Player p, ItemStack preview, long price, Runnable action, Runnable cancel) {
        if (price < getConfig().getLong("confirm-above", 1000)) { action.run(); return; }
        Gui g = new Gui("&8Confirm purchase", 3);
        g.frame(Material.GRAY_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        ItemStack pv = preview.clone();
        ItemMeta m = pv.getItemMeta();
        m.lore(List.of(Util.c("&7Total: &6" + Util.fmt(price) + " " + cur()),
                Util.c("&7You have: &e" + Util.fmt(bal(p.getUniqueId())) + " " + cur())));
        pv.setItemMeta(m);
        g.set(13, pv, null);
        g.set(11, Util.item(Material.LIME_CONCRETE, "&a&lCONFIRM", List.of("&7Pay &6" + Util.fmt(price) + " " + cur())), e -> action.run());
        g.set(15, Util.item(Material.RED_CONCRETE, "&c&lCANCEL", List.of("&7Go back")), e -> cancel.run());
        g.open(p);
    }

    // ============================================================ HUB
    private void openHub(Player p) {
        Gui g = new Gui("&6&l" + cur() + " &8» &7Hub", 5);
        g.frame(Material.ORANGE_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);

        UUID id = p.getUniqueId();
        long dailyMs = 24L * 3600_000L;
        long left = lastDaily.getOrDefault(id, 0L) + dailyMs - System.currentTimeMillis();
        boolean ready = left <= 0;
        g.set(19, Util.item(ready ? Material.CHEST_MINECART : Material.MINECART, "&e&lDaily Reward",
                List.of("&7Streak: &f" + streak.getOrDefault(id, 0) + " days", "",
                        ready ? "&aReady! &eClick to claim" : "&cNext in &f" + (left / 3600_000L) + "h " + ((left / 60_000L) % 60) + "m")),
                e -> claimDaily(p));
        g.set(20, Util.item(Material.TRIPWIRE_HOOK, "&d&lCrate Keys", List.of("&7Daily, Rare, Money & more", "", "&eClick to open")), e -> openKeys(p));
        g.set(21, Util.item(Material.NETHER_STAR, "&6&lRanks", List.of("&7VIP, MVP & more", "", "&eClick to open")), e -> openCategory(p, "ranks", () -> openHub(p)));
        g.set(22, Util.item(Material.CHEST, "&c&l" + cur() + " Shop", List.of("&7Maxed gear, totems & tools", "", "&eClick to open")), e -> openShopMain(p));
        g.set(23, Util.item(Material.BONE, "&b&lPets", List.of("&7Buy & summon companions", "", "&eClick to open")), e -> openPetShop(p));
        g.set(24, Util.item(Material.EMERALD, "&a&lExchange", List.of("&7Coins <-> money, any amount", "", "&eClick to open")), e -> openExchange(p));
        g.set(25, Util.item(Material.PLAYER_HEAD, "&e&lTop " + cur(), List.of("&7Richest players", "", "&eClick to open")), e -> openTop(p));
        g.set(31, Util.item(Material.LEAD, "&b&lMy Pets", List.of("&7Summon / put away", "", "&eClick to open")), e -> openPets(p));
        g.open(p);
    }

    private void claimDaily(Player p) {
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis(), last = lastDaily.getOrDefault(id, 0L);
        if (now - last < 24L * 3600_000L) { msg(p, "&cYou already claimed your daily reward."); p.playSound(p, Sound.ENTITY_VILLAGER_NO, 1, 1); return; }
        int st = (now - last < 48L * 3600_000L && last != 0) ? streak.getOrDefault(id, 0) + 1 : 1;
        long reward = Math.min(getConfig().getLong("daily-reward.max", 100),
                getConfig().getLong("daily-reward.amount", 25) + (st - 1) * getConfig().getLong("daily-reward.streak-step", 5));
        streak.put(id, st);
        lastDaily.put(id, now);
        add(id, reward);
        msg(p, "&aDaily reward: &6+" + Util.fmt(reward) + " " + cur() + " &7(streak " + st + ")");
        p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.2f);
        openHub(p);
    }

    private void openTop(Player p) {
        Gui g = new Gui("&e&lTop " + cur(), 5);
        g.frame(Material.YELLOW_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        int[] slots = {11, 12, 13, 14, 15, 20, 21, 22, 23, 24};
        List<Map.Entry<UUID, Long>> t = top();
        for (int i = 0; i < Math.min(slots.length, t.size()); i++) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(t.get(i).getKey());
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(op);
            sm.displayName(Util.c("&6#" + (i + 1) + " &f" + (op.getName() == null ? "Unknown" : op.getName())));
            sm.lore(List.of(Util.c("&7" + Util.fmt(t.get(i).getValue()) + " " + cur())));
            head.setItemMeta(sm);
            g.set(slots[i], head, null);
        }
        g.set(40, back(), e -> openHub(p));
        g.open(p);
    }

    // ============================================================ KEYS
    private void openKeys(Player p) {
        Gui g = new Gui("&d&lKey Shop", 5);
        g.frame(Material.PURPLE_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        ConfigurationSection keys = getConfig().getConfigurationSection("keys");
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
        int i = 0;
        if (keys != null) for (String id : keys.getKeys(false)) {
            ConfigurationSection s = keys.getConfigurationSection(id);
            if (s == null || !s.getBoolean("enabled", true)) continue;
            if (i >= slots.length) break;
            long price = s.getLong("price");
            ItemStack it = displayItem(p, s, price, "", "&eLeft-click: &fbuy x1", "&eShift-click: &fbuy x5", "&eRight-click: &fchoose amount");
            g.set(slots[i++], it, e -> {
                if (e.isRightClick() && !e.isShiftClick())
                    prompt(p, "How many " + s.getString("name", id) + "&e keys do you want? (" + price + " each)", n -> buyKey(p, id, s, n));
                else buyKey(p, id, s, e.isShiftClick() ? 5 : 1);
            });
        }
        g.set(31, Util.item(Material.PAPER, "&6&lYour balance", List.of("&f" + Util.fmt(bal(p.getUniqueId())) + " " + cur())), null);
        g.set(40, back(), e -> openHub(p));
        g.open(p);
    }

    private void buyKey(Player p, String id, ConfigurationSection s, long amt) {
        long total = s.getLong("price") * amt;
        confirmOrRun(p, buildItem(s), total, () -> {
            if (amt <= 0 || !take(p.getUniqueId(), total)) {
                msg(p, "&cNot enough " + cur() + "! You need &6" + Util.fmt(total));
                p.playSound(p, Sound.ENTITY_VILLAGER_NO, 1, 1);
                openKeys(p);
                return;
            }
            String cmd = getConfig().getString("key-command", "")
                    .replace("{player}", p.getName()).replace("{key}", id).replace("{amount}", String.valueOf(amt));
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            msg(p, "&aBought &f" + Util.fmt(amt) + "x &r" + s.getString("name", id) + " &afor &6" + Util.fmt(total) + " " + cur());
            p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.5f);
            openKeys(p);
        }, () -> openKeys(p));
    }

    // ============================================================ EXCHANGE
    private void openExchange(Player p) {
        Gui g = new Gui("&a&lExchange", 5);
        g.frame(Material.LIME_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        if (eco == null) {
            g.set(22, Util.item(Material.BARRIER, "&cVault economy not found", List.of("&7Ask an admin to install Vault + an economy plugin")), null);
            g.set(40, back(), e -> openHub(p));
            g.open(p); return;
        }
        double sell = getConfig().getDouble("exchange.coins-to-money", 100);
        double buy = getConfig().getDouble("exchange.money-to-coins", 150);
        List<Integer> amts = getConfig().getIntegerList("exchange.amounts");
        int[] topSlots = {19, 20, 21, 22}, botSlots = {28, 29, 30, 31};

        g.set(10, Util.item(Material.GOLD_INGOT, "&6&l" + cur() + " &f→ &a&lMoney",
                List.of("&71 " + cur() + " = &a$" + sell, "&7Your money: &a$" + String.format("%,.2f", eco.getBalance(p)))), null);
        g.set(37, Util.item(Material.EMERALD, "&a&lMoney &f→ &6&l" + cur(), List.of("&71 " + cur() + " costs &a$" + buy)), null);

        for (int i = 0; i < Math.min(amts.size(), 4); i++) {
            long n = amts.get(i);
            g.set(topSlots[i], Util.item(Material.GOLD_NUGGET, "&6Sell &f" + Util.fmt(n) + " " + cur(),
                    List.of("&7You get: &a$" + String.format("%,.2f", n * sell))), e -> sellCoins(p, n));
            g.set(botSlots[i], Util.item(Material.EMERALD, "&aBuy &f" + Util.fmt(n) + " " + cur(),
                    List.of("&7Costs: &a$" + String.format("%,.2f", n * buy))), e -> buyCoins(p, n));
        }
        g.set(23, Util.item(Material.GOLD_BLOCK, "&6&lSell ALL", List.of("&7Sell every " + cur() + " you own")), e -> sellCoins(p, bal(p.getUniqueId())));
        g.set(24, Util.item(Material.NAME_TAG, "&6&lSell custom amount",
                List.of("&7Choose exactly how many", "", "&eClick, then type in chat")),
                e -> prompt(p, "How many " + cur() + " do you want to SELL for money?", n -> sellCoins(p, n)));
        g.set(32, Util.item(Material.EMERALD_BLOCK, "&a&lBuy MAX", List.of("&7Buy as many as your money allows")),
                e -> buyCoins(p, (long) Math.floor(eco.getBalance(p) / buy)));
        g.set(33, Util.item(Material.NAME_TAG, "&a&lBuy custom amount",
                List.of("&7Choose exactly how many", "", "&eClick, then type in chat")),
                e -> prompt(p, "How many " + cur() + " do you want to BUY with money?", n -> buyCoins(p, n)));
        g.set(40, back(), e -> openHub(p));
        g.open(p);
    }

    private void sellCoins(Player p, long n) {
        if (n <= 0 || !take(p.getUniqueId(), n)) { msg(p, "&cNot enough " + cur() + "!"); return; }
        double money = n * getConfig().getDouble("exchange.coins-to-money", 100);
        eco.depositPlayer(p, money);
        msg(p, "&aSold &6" + Util.fmt(n) + " " + cur() + " &afor &f$" + String.format("%,.2f", money));
        p.playSound(p, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1, 1);
        openExchange(p);
    }

    private void buyCoins(Player p, long n) {
        double cost = n * getConfig().getDouble("exchange.money-to-coins", 150);
        if (n <= 0 || !eco.has(p, cost)) { msg(p, "&cNot enough money!"); return; }
        eco.withdrawPlayer(p, cost);
        add(p.getUniqueId(), n);
        msg(p, "&aBought &6" + Util.fmt(n) + " " + cur() + " &afor &f$" + String.format("%,.2f", cost));
        p.playSound(p, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1, 1.4f);
        openExchange(p);
    }

    // ============================================================ SHOP
    private void openShopMain(Player p) {
        Gui g = new Gui("&c&l" + cur() + " Shop", 5);
        g.frame(Material.RED_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        ConfigurationSection cats = getConfig().getConfigurationSection("shop");
        int[] slots = {10, 12, 14, 16};
        int i = 0;
        if (cats != null) for (String id : cats.getKeys(false)) {
            if (id.equals("ranks")) continue; // ranks have their own button
            ConfigurationSection c = cats.getConfigurationSection(id);
            if (c == null || !c.getBoolean("enabled", true)) continue;
            if (i >= slots.length) break;
            Material icon = Material.matchMaterial(c.getString("icon", "CHEST"));
            g.set(slots[i++], Util.item(icon == null ? Material.CHEST : icon, c.getString("title", id),
                    List.of("&7Browse items", "", "&eClick to open")), e -> openCategory(p, id, () -> openShopMain(p)));
        }
        g.set(22, Util.item(Material.EMERALD, "&a&lExchange", List.of("&7Coins <-> money, any amount", "", "&eClick to open")), e -> openExchange(p));
        g.set(29, Util.item(Material.TRIPWIRE_HOOK, "&d&lCrate Keys", List.of("&7Daily, Rare, Money & more", "", "&eClick to open")), e -> openKeys(p));
        g.set(31, Util.item(Material.NETHER_STAR, "&6&lRanks", List.of("&7VIP, MVP & more", "", "&eClick to open")), e -> openCategory(p, "ranks", () -> openShopMain(p)));
        g.set(33, Util.item(Material.BONE, "&b&lPets", List.of("&7Companions that follow you", "&7and boost your " + cur(), "", "&eClick to open")), e -> openPetShop(p));
        g.set(40, back(), e -> openHub(p));
        g.open(p);
    }

    private void openCategory(Player p, String cat, Runnable backAction) {
        ConfigurationSection c = getConfig().getConfigurationSection("shop." + cat);
        if (c == null) return;
        Gui g = new Gui(c.getString("title", cat), 6);
        g.frame(Material.GRAY_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        ConfigurationSection items = c.getConfigurationSection("items");
        List<Integer> slots = new ArrayList<>();
        for (int r = 1; r <= 4; r++) for (int col = 1; col <= 7; col++) slots.add(r * 9 + col);
        int i = 0;
        if (items != null) for (String id : items.getKeys(false)) {
            ConfigurationSection s = items.getConfigurationSection(id);
            if (s == null || !s.getBoolean("enabled", true)) continue;
            if (i >= slots.size()) break;
            long price = s.getLong("price");
            g.set(slots.get(i++), displayItem(p, s, price, "", "&eClick to purchase"), e -> purchase(p, s, price, cat, backAction));
        }
        g.set(49, back(), e -> backAction.run());
        g.open(p);
    }

    private void purchase(Player p, ConfigurationSection s, long price, String cat, Runnable backAction) {
        if (owns(p, s)) { msg(p, "&cYou already own this!"); return; }
        List<ItemStack> give = new ArrayList<>();
        if (s.getBoolean("give-item", true)) {
            List<String> bundle = s.getStringList("bundle");
            if (bundle.isEmpty()) give.add(buildItem(s));
            else for (String ref : bundle) {
                ConfigurationSection r = resolve(ref);
                if (r != null) give.add(buildItem(r));
            }
        }
        int free = 0;
        for (ItemStack st : p.getInventory().getStorageContents()) if (st == null) free++;
        if (free < give.size()) { msg(p, "&cYou need &f" + give.size() + " &cfree inventory slots!"); return; }

        confirmOrRun(p, buildItem(s), price, () -> {
            if (!take(p.getUniqueId(), price)) {
                msg(p, "&cNot enough " + cur() + "! Need &6" + Util.fmt(price));
                p.playSound(p, Sound.ENTITY_VILLAGER_NO, 1, 1);
                openCategory(p, cat, backAction);
                return;
            }
            for (ItemStack st : give) p.getInventory().addItem(st);
            for (String cmd : s.getStringList("commands"))
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("{player}", p.getName()));
            msg(p, "&aPurchased &r" + s.getString("name", "item") + " &afor &6" + Util.fmt(price) + " " + cur());
            p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.5f);
            openCategory(p, cat, backAction);
        }, () -> openCategory(p, cat, backAction));
    }

    // ============================================================ PETS
    private void openPetShop(Player p) {
        Gui g = new Gui("&b&lPet Shop", 5);
        g.frame(Material.CYAN_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        ConfigurationSection pets = getConfig().getConfigurationSection("pets");
        List<Integer> slots = new ArrayList<>();
        for (int r = 1; r <= 3; r++) for (int col = 1; col <= 7; col++) slots.add(r * 9 + col);
        int i = 0;
        Set<String> owned = ownedPets.computeIfAbsent(p.getUniqueId(), k -> new HashSet<>());
        if (pets != null) for (String id : pets.getKeys(false)) {
            if (i >= slots.size()) break;
            ConfigurationSection s = pets.getConfigurationSection(id);
            Material icon = Material.matchMaterial(s.getString("icon", "BONE"));
            long price = s.getLong("price");
            boolean has = owned.contains(id);
            List<String> lore = new ArrayList<>(List.of("&7Follows you around!"));
            if (s.getDouble("bonus", 0) > 0) lore.add("&7Bonus: &a+" + (int) s.getDouble("bonus") + "% " + cur());
            lore.add("");
            lore.add(has ? "&a✔ Owned &7- use /pets to summon" : "&7Price: &6" + Util.fmt(price) + " " + cur());
            if (!has) lore.add("&eClick to purchase");
            ItemStack it = Util.item(icon == null ? Material.BONE : icon, s.getString("name", id), lore);
            g.set(slots.get(i++), it, e -> {
                if (owned.contains(id)) { msg(p, "&cYou already own this pet."); return; }
                confirmOrRun(p, it, price, () -> {
                    if (!take(p.getUniqueId(), price)) { msg(p, "&cNot enough " + cur() + "!"); openPetShop(p); return; }
                    owned.add(id);
                    msg(p, "&aYou got " + s.getString("name", id) + "&a! Open &f/pets &ato summon it.");
                    p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.5f);
                    openPetShop(p);
                }, () -> openPetShop(p));
            });
        }
        g.set(40, back(), e -> openShopMain(p));
        g.open(p);
    }

    private void openPets(Player p) {
        Gui g = new Gui("&b&lMy Pets", 5);
        g.frame(Material.CYAN_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        Set<String> owned = ownedPets.getOrDefault(p.getUniqueId(), Set.of());
        List<Integer> slots = new ArrayList<>();
        for (int r = 1; r <= 3; r++) for (int col = 1; col <= 7; col++) slots.add(r * 9 + col);
        int i = 0;
        String active = activePetId.get(p.getUniqueId());
        boolean out = activePets.containsKey(p.getUniqueId());
        for (String id : owned) {
            if (i >= slots.size()) break;
            ConfigurationSection s = getConfig().getConfigurationSection("pets." + id);
            if (s == null) continue;
            Material icon = Material.matchMaterial(s.getString("icon", "BONE"));
            boolean isOut = out && id.equals(active);
            List<String> lore = new ArrayList<>();
            lore.add(isOut ? "&aCurrently following you" : "&7Stored");
            if (s.getDouble("bonus", 0) > 0) lore.add("&7Bonus: &a+" + (int) s.getDouble("bonus") + "% " + cur() + " while out");
            lore.add("");
            lore.add(isOut ? "&eClick to put away" : "&eClick to summon");
            g.set(slots.get(i++), Util.item(icon == null ? Material.BONE : icon, s.getString("name", id), lore), e -> {
                if (isOut) { despawn(p.getUniqueId()); activePetId.remove(p.getUniqueId()); }
                else summon(p, id);
                openPets(p);
            });
        }
        if (owned.isEmpty())
            g.set(22, Util.item(Material.BARRIER, "&cNo pets yet", List.of("&7Buy some in the Pet Shop")),
                    e -> openPetShop(p));
        g.set(40, back(), e -> openHub(p));
        g.open(p);
    }

    // ============================================================ commands
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase();
        if (name.equals("coinsadmin")) return admin(sender, args);

        if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        switch (name) {
            case "coins" -> {
                if (args.length > 0) {
                    OfflinePlayer t = Bukkit.getOfflinePlayer(args[0]);
                    msg(p, "&f" + args[0] + "&7 has &6" + Util.fmt(bal(t.getUniqueId())) + " " + cur());
                } else openHub(p);
            }
            case "keys" -> openKeys(p);
            case "coinshop" -> openShopMain(p);
            case "exchange" -> openExchange(p);
            case "pets" -> openPets(p);
            case "ranks" -> openCategory(p, "ranks", () -> openHub(p));
            case "daily" -> claimDaily(p);
            case "coinstop" -> openTop(p);
            case "coinspay" -> {
                if (args.length < 2) { msg(p, "&cUsage: /coinspay <player> <amount>"); return true; }
                OfflinePlayer t = Bukkit.getOfflinePlayer(args[0]);
                long n = parseAmount(args[1]);
                if (!t.hasPlayedBefore() && !t.isOnline()) { msg(p, "&cUnknown player."); return true; }
                if (t.getUniqueId().equals(p.getUniqueId())) { msg(p, "&cYou can't pay yourself."); return true; }
                if (n <= 0 || !take(p.getUniqueId(), n)) { msg(p, "&cInvalid amount or not enough " + cur() + "."); return true; }
                add(t.getUniqueId(), n);
                msg(p, "&aSent &6" + Util.fmt(n) + " " + cur() + " &ato &f" + args[0]);
                if (t.isOnline()) msg(t.getPlayer(), "&aYou received &6" + Util.fmt(n) + " " + cur() + " &afrom &f" + p.getName());
            }
        }
        return true;
    }

    private boolean admin(CommandSender s, String[] a) {
        if (!s.hasPermission("coins.admin")) { msg(s, "&cNo permission."); return true; }
        if (a.length == 0) {
            msg(s, "&e/coinsadmin <add|remove|set|reset|check|givepet|removepet|reload> <player> [amount|pet]");
            return true;
        }
        if (a[0].equalsIgnoreCase("reload")) { reloadConfig(); msg(s, "&aReloaded config."); return true; }
        if (a.length < 2) { msg(s, "&cUsage: /coinsadmin " + a[0] + " <player> [amount]"); return true; }
        OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]);
        UUID id = t.getUniqueId();
        long amt = 0;
        if (a.length >= 3 && !a[0].equalsIgnoreCase("givepet") && !a[0].equalsIgnoreCase("removepet")) {
            amt = parseAmount(a[2]);
            if (amt < 0) { msg(s, "&cInvalid number."); return true; }
        }
        switch (a[0].toLowerCase()) {
            case "add" -> { add(id, amt); msg(s, "&aAdded &6" + Util.fmt(amt) + "&a to " + a[1] + ". Now: " + Util.fmt(bal(id))); }
            case "remove" -> { setBal(id, bal(id) - amt); msg(s, "&aRemoved &6" + Util.fmt(amt) + "&a from " + a[1] + ". Now: " + Util.fmt(bal(id))); }
            case "set" -> { setBal(id, amt); msg(s, "&aSet " + a[1] + " to &6" + Util.fmt(amt)); }
            case "reset" -> { setBal(id, 0); msg(s, "&aReset " + a[1] + "."); }
            case "check" -> msg(s, "&f" + a[1] + " &7has &6" + Util.fmt(bal(id)) + " " + cur());
            case "givepet" -> {
                if (a.length < 3 || getConfig().getConfigurationSection("pets." + a[2]) == null) { msg(s, "&cUnknown pet id."); return true; }
                ownedPets.computeIfAbsent(id, k -> new HashSet<>()).add(a[2]);
                coins.putIfAbsent(id, 0L);
                msg(s, "&aGave pet &f" + a[2] + "&a to " + a[1]);
            }
            case "removepet" -> {
                if (a.length < 3) { msg(s, "&cUsage: /coinsadmin removepet <player> <pet>"); return true; }
                ownedPets.getOrDefault(id, new HashSet<>()).remove(a[2]);
                if (a[2].equals(activePetId.get(id))) { despawn(id); activePetId.remove(id); }
                msg(s, "&aRemoved pet &f" + a[2] + "&a from " + a[1]);
            }
            default -> msg(s, "&cUnknown sub-command.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        String n = c.getName().toLowerCase();
        if (n.equals("coinspay") && a.length == 1) return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        if (!n.equals("coinsadmin") || !s.hasPermission("coins.admin")) return List.of();
        if (a.length == 1) return List.of("add", "remove", "set", "reset", "check", "givepet", "removepet", "reload");
        if (a.length == 2) return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        if (a.length == 3 && (a[0].equalsIgnoreCase("givepet") || a[0].equalsIgnoreCase("removepet"))) {
            ConfigurationSection ps = getConfig().getConfigurationSection("pets");
            return ps == null ? List.of() : new ArrayList<>(ps.getKeys(false));
        }
        return List.of();
    }
}
