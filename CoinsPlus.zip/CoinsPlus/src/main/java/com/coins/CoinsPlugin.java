package com.coins;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class CoinsPlugin extends JavaPlugin implements Listener, TabExecutor {

    private Economy eco;
    private File dataFile;
    private YamlConfiguration data;
    private final Map<UUID, Long> coins = new HashMap<>();
    private final Map<UUID, Set<String>> ownedPets = new HashMap<>();
    private final Map<UUID, String> activePetId = new HashMap<>();
    private final Map<UUID, Entity> activePets = new HashMap<>();
    private final Set<UUID> petEntityIds = new HashSet<>();

    // ------------------------------------------------------------ lifecycle
    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadData();
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) eco = rsp.getProvider();
        else getLogger().warning("Vault economy not found - exchange is disabled.");

        getServer().getPluginManager().registerEvents(this, this);
        for (String cmd : List.of("coins", "keys", "coinshop", "exchange", "pets", "coinsadmin")) {
            PluginCommand pc = getCommand(cmd);
            if (pc != null) { pc.setExecutor(this); pc.setTabCompleter(this); }
        }

        long interval = Math.max(1, getConfig().getLong("earn.interval-seconds", 60)) * 20L;
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            long amt = getConfig().getLong("earn.timed-amount", 1);
            for (Player p : Bukkit.getOnlinePlayers()) earn(p, amt);
        }, interval, interval);

        Bukkit.getScheduler().runTaskTimer(this, this::followTick, 10L, 10L);
        Bukkit.getScheduler().runTaskTimer(this, this::saveData, 6000L, 6000L);
    }

    @Override
    public void onDisable() {
        for (Entity e : new ArrayList<>(activePets.values())) e.remove();
        activePets.clear();
        saveData();
    }

    // ------------------------------------------------------------ data
    private void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        coins.clear(); ownedPets.clear(); activePetId.clear();
        ConfigurationSection pl = data.getConfigurationSection("players");
        if (pl == null) return;
        for (String k : pl.getKeys(false)) {
            try {
                UUID id = UUID.fromString(k);
                coins.put(id, pl.getLong(k + ".coins"));
                ownedPets.put(id, new HashSet<>(pl.getStringList(k + ".pets")));
                String ap = pl.getString(k + ".active");
                if (ap != null && !ap.isEmpty()) activePetId.put(id, ap);
            } catch (IllegalArgumentException ignored) {}
        }
    }

    private void saveData() {
        data.set("players", null);
        for (Map.Entry<UUID, Long> en : coins.entrySet()) {
            String b = "players." + en.getKey();
            data.set(b + ".coins", en.getValue());
            data.set(b + ".pets", new ArrayList<>(ownedPets.getOrDefault(en.getKey(), Set.of())));
            data.set(b + ".active", activePetId.getOrDefault(en.getKey(), ""));
        }
        try { data.save(dataFile); } catch (IOException ex) { getLogger().severe("Could not save data: " + ex); }
    }

    // ------------------------------------------------------------ economy
    public long bal(UUID id) { return coins.getOrDefault(id, 0L); }
    public void setBal(UUID id, long v) { coins.put(id, Math.max(0, v)); }
    public void add(UUID id, long v) { setBal(id, bal(id) + v); }
    public boolean take(UUID id, long v) {
        if (bal(id) < v) return false;
        setBal(id, bal(id) - v);
        return true;
    }

    private void earn(Player p, long amt) {
        if (amt <= 0) return;
        if (getConfig().getStringList("earn.disabled-worlds").contains(p.getWorld().getName())) return;
        add(p.getUniqueId(), amt);
        if (getConfig().getBoolean("earn.actionbar", true))
            p.sendActionBar(Util.c("&6+" + amt + " " + cur() + " &7(" + Util.fmt(bal(p.getUniqueId())) + ")"));
    }

    private String cur() { return getConfig().getString("currency-name", "Coins"); }
    private String sym() { return getConfig().getString("currency-symbol", "⛃"); }
    private void msg(CommandSender s, String m) { s.sendMessage(Util.c(getConfig().getString("prefix", "") + m)); }

    // ------------------------------------------------------------ earning events
    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) { earn(e.getPlayer(), getConfig().getLong("earn.per-block-place", 1)); }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) { earn(e.getPlayer(), getConfig().getLong("earn.per-block-break", 1)); }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        coins.putIfAbsent(p.getUniqueId(), 0L);
        String ap = activePetId.get(p.getUniqueId());
        if (ap != null && ownedPets.getOrDefault(p.getUniqueId(), Set.of()).contains(ap))
            Bukkit.getScheduler().runTaskLater(this, () -> { if (p.isOnline()) summon(p, ap); }, 40L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        despawn(e.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------ GUI events
    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Gui g) {
            e.setCancelled(true);
            if (e.getClickedInventory() == e.getView().getTopInventory()) g.click(e);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Gui) e.setCancelled(true);
    }

    // ------------------------------------------------------------ pet protection
    @EventHandler public void onPetDamage(EntityDamageEvent e) {
        if (petEntityIds.contains(e.getEntity().getUniqueId())) e.setCancelled(true);
    }
    @EventHandler public void onPetInteract(PlayerInteractEntityEvent e) {
        if (petEntityIds.contains(e.getRightClicked().getUniqueId())) e.setCancelled(true);
    }
    @EventHandler public void onPetTarget(EntityTargetEvent e) {
        if (petEntityIds.contains(e.getEntity().getUniqueId())) e.setCancelled(true);
    }
    @EventHandler public void onTeleport(PlayerTeleportEvent e) {
        Entity pet = activePets.get(e.getPlayer().getUniqueId());
        if (pet != null && pet.isValid())
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (pet.isValid() && e.getPlayer().isOnline()) pet.teleport(e.getPlayer().getLocation());
            }, 5L);
    }

    // ------------------------------------------------------------ pets
    private void summon(Player p, String id) {
        despawn(p.getUniqueId());
        ConfigurationSection s = getConfig().getConfigurationSection("pets." + id);
        if (s == null) return;
        EntityType type;
        try { type = EntityType.valueOf(s.getString("entity", "WOLF").toUpperCase()); }
        catch (IllegalArgumentException ex) { return; }
        Entity ent = p.getWorld().spawnEntity(p.getLocation(), type);
        ent.setInvulnerable(true);
        ent.setPersistent(false);
        ent.customName(Util.c(s.getString("name", id) + " &7(" + p.getName() + ")"));
        ent.setCustomNameVisible(true);
        if (ent instanceof Ageable a && s.getBoolean("baby", false)) { a.setBaby(); a.setAgeLock(true); }
        if (ent instanceof Tameable t) { t.setTamed(true); t.setOwner(p); }
        if (ent instanceof Sittable si) si.setSitting(false);
        if (ent instanceof Mob m) m.setRemoveWhenFarAway(false);
        activePets.put(p.getUniqueId(), ent);
        petEntityIds.add(ent.getUniqueId());
        activePetId.put(p.getUniqueId(), id);
    }

    private void despawn(UUID owner) {
        Entity e = activePets.remove(owner);
        if (e != null) { petEntityIds.remove(e.getUniqueId()); e.remove(); }
    }

    private void followTick() {
        Iterator<Map.Entry<UUID, Entity>> it = activePets.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Entity> en = it.next();
            Player p = Bukkit.getPlayer(en.getKey());
            Entity pet = en.getValue();
            if (p == null || !p.isOnline()) { petEntityIds.remove(pet.getUniqueId()); pet.remove(); it.remove(); continue; }
            if (!pet.isValid()) {
                // died/unloaded -> respawn next to owner
                it.remove(); petEntityIds.remove(pet.getUniqueId());
                String id = activePetId.get(en.getKey());
                if (id != null) Bukkit.getScheduler().runTask(this, () -> summon(p, id));
                break;
            }
            if (!pet.getWorld().equals(p.getWorld()) || pet.getLocation().distanceSquared(p.getLocation()) > 400) {
                pet.teleport(p.getLocation());
            } else if (pet.getLocation().distanceSquared(p.getLocation()) > 12 && pet instanceof Mob m) {
                m.getPathfinder().moveTo(p.getLocation(), 1.3);
            }
        }
    }

    // ------------------------------------------------------------ item building
    private ItemStack buildItem(ConfigurationSection s) {
        Material m = Material.matchMaterial(s.getString("material", "STONE"));
        if (m == null) m = Material.BARRIER;
        ItemStack it = new ItemStack(m, Math.max(1, s.getInt("amount", 1)));
        ItemMeta meta = it.getItemMeta();
        if (s.contains("name")) meta.displayName(Util.c(s.getString("name")));
        for (String e : s.getStringList("enchants")) {
            String[] a = e.split(":");
            Enchantment en = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(a[0].toLowerCase()));
            if (en != null) meta.addEnchant(en, a.length > 1 ? Integer.parseInt(a[1]) : 1, true);
            else getLogger().warning("Unknown enchantment: " + a[0]);
        }
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack displayItem(ConfigurationSection s, long price, String... extra) {
        ItemStack it = buildItem(s);
        ItemMeta meta = it.getItemMeta();
        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        for (String l : s.getStringList("lore")) lore.add(Util.c(l));
        lore.add(Util.c(""));
        lore.add(Util.c("&7Price: &6" + Util.fmt(price) + " " + cur()));
        for (String x : extra) lore.add(Util.c(x));
        meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }

    // ------------------------------------------------------------ GUIs
    private ItemStack balanceHead(Player p) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta sm = (SkullMeta) head.getItemMeta();
        sm.setOwningPlayer(p);
        sm.displayName(Util.c("&e&l" + p.getName()));
        sm.lore(List.of(Util.c("&7Balance: &6" + Util.fmt(bal(p.getUniqueId())) + " " + cur() + " " + sym())));
        head.setItemMeta(sm);
        return head;
    }

    private void openHub(Player p) {
        Gui g = new Gui("&6&l" + cur() + " &8» &7Hub", 5);
        g.frame(Material.ORANGE_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        g.set(20, Util.item(Material.TRIPWIRE_HOOK, "&d&lKey Shop",
                List.of("&7Buy crate keys with " + cur(), "", "&eClick to open")), e -> openKeys(p));
        g.set(22, Util.item(Material.CHEST, "&c&l" + cur() + " Shop",
                List.of("&7Maxed gear, totems, ranks & pets", "", "&eClick to open")), e -> openShopMain(p));
        g.set(24, Util.item(Material.EMERALD, "&a&lExchange",
                List.of("&7Convert " + cur() + " &8<-> &7money", "", "&eClick to open")), e -> openExchange(p));
        g.set(30, Util.item(Material.BONE, "&b&lMy Pets",
                List.of("&7Summon your companions", "", "&eClick to open")), e -> openPets(p));
        List<String> top = new ArrayList<>(List.of("&7Richest players:", ""));
        List<Map.Entry<UUID, Long>> sorted = new ArrayList<>(coins.entrySet());
        sorted.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
        for (int i = 0; i < Math.min(5, sorted.size()); i++) {
            String n = Bukkit.getOfflinePlayer(sorted.get(i).getKey()).getName();
            top.add("&6#" + (i + 1) + " &f" + (n == null ? "?" : n) + " &8- &e" + Util.fmt(sorted.get(i).getValue()));
        }
        g.set(32, Util.item(Material.NETHER_STAR, "&e&lTop " + cur(), top), null);
        g.open(p);
    }

    private void openKeys(Player p) {
        Gui g = new Gui("&d&lKey Shop", 4);
        g.frame(Material.PURPLE_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        ConfigurationSection keys = getConfig().getConfigurationSection("keys");
        int[] slots = {11, 13, 15, 20, 22, 24};
        int i = 0;
        if (keys != null) for (String id : keys.getKeys(false)) {
            if (i >= slots.length) break;
            ConfigurationSection s = keys.getConfigurationSection(id);
            long price = s.getLong("price");
            ItemStack it = displayItem(s, price, "", "&eLeft-click: buy x1", "&eShift-click: buy x5");
            g.set(slots[i++], it, e -> {
                int amt = e.isShiftClick() ? 5 : 1;
                if (!take(p.getUniqueId(), price * amt)) { msg(p, "&cNot enough " + cur() + "!"); p.playSound(p, Sound.ENTITY_VILLAGER_NO, 1, 1); return; }
                String cmd = getConfig().getString("key-command", "")
                        .replace("{player}", p.getName()).replace("{key}", id).replace("{amount}", String.valueOf(amt));
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
                msg(p, "&aBought &f" + amt + "x &r" + s.getString("name", id) + " &afor &6" + Util.fmt(price * amt) + " " + cur());
                p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.5f);
                openKeys(p);
            });
        }
        g.set(31, Util.item(Material.ARROW, "&7« Back", List.of()), e -> openHub(p));
        g.open(p);
    }

    private void openExchange(Player p) {
        Gui g = new Gui("&a&lExchange", 5);
        g.frame(Material.LIME_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        if (eco == null) {
            g.set(22, Util.item(Material.BARRIER, "&cVault economy not found", List.of("&7Ask an admin to install Vault + an economy plugin")), null);
            g.set(40, Util.item(Material.ARROW, "&7« Back", List.of()), e -> openHub(p));
            g.open(p); return;
        }
        double sell = getConfig().getDouble("exchange.coins-to-money", 100);
        double buy = getConfig().getDouble("exchange.money-to-coins", 150);
        List<Integer> amts = getConfig().getIntegerList("exchange.amounts");
        int[] topSlots = {19, 20, 21, 22}, botSlots = {28, 29, 30, 31};

        g.set(10, Util.item(Material.GOLD_INGOT, "&6&l" + cur() + " &f→ &a&lMoney",
                List.of("&71 " + cur() + " = &a$" + sell, "&7Your money: &a$" + String.format("%,.2f", eco.getBalance(p)))), null);
        g.set(37, Util.item(Material.EMERALD, "&a&lMoney &f→ &6&l" + cur(),
                List.of("&71 " + cur() + " costs &a$" + buy)), null);

        for (int i = 0; i < Math.min(amts.size(), 4); i++) {
            long n = amts.get(i);
            g.set(topSlots[i], Util.item(Material.GOLD_NUGGET, "&6Sell &f" + Util.fmt(n) + " " + cur(),
                    List.of("&7You get: &a$" + String.format("%,.2f", n * sell))), e -> sellCoins(p, n));
            g.set(botSlots[i], Util.item(Material.EMERALD, "&aBuy &f" + Util.fmt(n) + " " + cur(),
                    List.of("&7Costs: &a$" + String.format("%,.2f", n * buy))), e -> buyCoins(p, n));
        }
        g.set(23, Util.item(Material.GOLD_BLOCK, "&6&lSell ALL",
                List.of("&7Sell every " + cur() + " you own")), e -> sellCoins(p, bal(p.getUniqueId())));
        g.set(32, Util.item(Material.EMERALD_BLOCK, "&a&lBuy MAX",
                List.of("&7Buy as many as your money allows")), e -> buyCoins(p, (long) Math.floor(eco.getBalance(p) / buy)));
        g.set(40, Util.item(Material.ARROW, "&7« Back", List.of()), e -> openHub(p));
        g.open(p);
    }

    private void sellCoins(Player p, long n) {
        if (n <= 0 || !take(p.getUniqueId(), n)) { msg(p, "&cNot enough " + cur() + "!"); return; }
        double money = n * getConfig().getDouble("exchange.coins-to-money", 100);
        eco.depositPlayer(p, money);
        msg(p, "&aSold &6" + Util.fmt(n) + " " + cur() + " &afor &f$" + String.format("%,.2f", money));
        p.playSound(p, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1, 1);
        openExchange(p);
    }

    private void buyCoins(Player p, long n) {
        double cost = n * getConfig().getDouble("exchange.money-to-coins", 150);
        if (n <= 0 || !eco.has(p, cost)) { msg(p, "&cNot enough money!"); return; }
        eco.withdrawPlayer(p, cost);
        add(p.getUniqueId(), n);
        msg(p, "&aBought &6" + Util.fmt(n) + " " + cur() + " &afor &f$" + String.format("%,.2f", cost));
        p.playSound(p, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1, 1.4f);
        openExchange(p);
    }

    private void openShopMain(Player p) {
        Gui g = new Gui("&c&l" + cur() + " Shop", 4);
        g.frame(Material.RED_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        ConfigurationSection cats = getConfig().getConfigurationSection("shop");
        int[] slots = {11, 13, 15, 22};
        int i = 0;
        if (cats != null) for (String id : cats.getKeys(false)) {
            if (i >= 3) break;
            ConfigurationSection c = cats.getConfigurationSection(id);
            Material icon = Material.matchMaterial(c.getString("icon", "CHEST"));
            g.set(slots[i++], Util.item(icon == null ? Material.CHEST : icon, c.getString("title", id),
                    List.of("&7Browse items", "", "&eClick to open")), e -> openCategory(p, id));
        }
        g.set(22, Util.item(Material.BONE, "&b&lPets", List.of("&7Companions that follow you", "", "&eClick to open")), e -> openPetShop(p));
        g.set(31, Util.item(Material.ARROW, "&7« Back", List.of()), e -> openHub(p));
        g.open(p);
    }

    private void openCategory(Player p, String cat) {
        ConfigurationSection c = getConfig().getConfigurationSection("shop." + cat);
        if (c == null) return;
        Gui g = new Gui(c.getString("title", cat), 6);
        g.frame(Material.GRAY_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        ConfigurationSection items = c.getConfigurationSection("items");
        List<Integer> slots = new ArrayList<>();
        for (int r = 1; r <= 4; r++) for (int col = 1; col <= 7; col++) slots.add(r * 9 + col);
        int i = 0;
        if (items != null) for (String id : items.getKeys(false)) {
            if (i >= slots.size()) break;
            ConfigurationSection s = items.getConfigurationSection(id);
            long price = s.getLong("price");
            g.set(slots.get(i++), displayItem(s, price, "", "&eClick to purchase"), e -> purchase(p, s, price, cat));
        }
        g.set(49, Util.item(Material.ARROW, "&7« Back", List.of()), e -> openShopMain(p));
        g.open(p);
    }

    private void purchase(Player p, ConfigurationSection s, long price, String cat) {
        boolean giveItem = s.getBoolean("give-item", true);
        if (giveItem && p.getInventory().firstEmpty() == -1) { msg(p, "&cYour inventory is full!"); return; }
        if (!take(p.getUniqueId(), price)) { msg(p, "&cNot enough " + cur() + "! Need &6" + Util.fmt(price)); p.playSound(p, Sound.ENTITY_VILLAGER_NO, 1, 1); return; }
        if (giveItem) p.getInventory().addItem(buildItem(s));
        for (String cmd : s.getStringList("commands"))
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("{player}", p.getName()));
        msg(p, "&aPurchased &r" + s.getString("name", "item") + " &afor &6" + Util.fmt(price) + " " + cur());
        p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.5f);
        openCategory(p, cat);
    }

    private void openPetShop(Player p) {
        Gui g = new Gui("&b&lPet Shop", 5);
        g.frame(Material.CYAN_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        g.set(4, balanceHead(p), null);
        ConfigurationSection pets = getConfig().getConfigurationSection("pets");
        List<Integer> slots = new ArrayList<>();
        for (int r = 1; r <= 3; r++) for (int col = 1; col <= 7; col++) slots.add(r * 9 + col);
        int i = 0;
        Set<String> owned = ownedPets.computeIfAbsent(p.getUniqueId(), k -> new HashSet<>());
        if (pets != null) for (String id : pets.getKeys(false)) {
            if (i >= slots.size()) break;
            ConfigurationSection s = pets.getConfigurationSection(id);
            Material icon = Material.matchMaterial(s.getString("icon", "BONE"));
            long price = s.getLong("price");
            boolean has = owned.contains(id);
            ItemStack it = Util.item(icon == null ? Material.BONE : icon, s.getString("name", id),
                    List.of("&7Follows you around!", "", has ? "&aOwned" : "&7Price: &6" + Util.fmt(price) + " " + cur(),
                            has ? "&7Use /pets to summon" : "&eClick to purchase"));
            g.set(slots.get(i++), it, e -> {
                if (owned.contains(id)) { msg(p, "&cYou already own this pet."); return; }
                if (!take(p.getUniqueId(), price)) { msg(p, "&cNot enough " + cur() + "!"); return; }
                owned.add(id);
                msg(p, "&aYou got " + s.getString("name", id) + "&a! Use &f/pets &ato summon it.");
                p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.5f);
                openPetShop(p);
            });
        }
        g.set(40, Util.item(Material.ARROW, "&7« Back", List.of()), e -> openShopMain(p));
        g.open(p);
    }

    private void openPets(Player p) {
        Gui g = new Gui("&b&lMy Pets", 4);
        g.frame(Material.CYAN_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE);
        Set<String> owned = ownedPets.getOrDefault(p.getUniqueId(), Set.of());
        List<Integer> slots = new ArrayList<>();
        for (int r = 1; r <= 2; r++) for (int col = 1; col <= 7; col++) slots.add(r * 9 + col);
        int i = 0;
        String active = activePetId.get(p.getUniqueId());
        boolean out = activePets.containsKey(p.getUniqueId());
        for (String id : owned) {
            if (i >= slots.size()) break;
            ConfigurationSection s = getConfig().getConfigurationSection("pets." + id);
            if (s == null) continue;
            Material icon = Material.matchMaterial(s.getString("icon", "BONE"));
            boolean isOut = out && id.equals(active);
            g.set(slots.get(i++), Util.item(icon == null ? Material.BONE : icon, s.getString("name", id),
                    List.of(isOut ? "&aCurrently following you" : "&7Stored", "", isOut ? "&eClick to put away" : "&eClick to summon")), e -> {
                if (isOut) { despawn(p.getUniqueId()); activePetId.remove(p.getUniqueId()); }
                else summon(p, id);
                openPets(p);
            });
        }
        if (owned.isEmpty())
            g.set(13, Util.item(Material.BARRIER, "&cNo pets yet", List.of("&7Buy some in /coinshop")), null);
        g.set(31, Util.item(Material.ARROW, "&7« Back", List.of()), e -> openHub(p));
        g.open(p);
    }

    // ------------------------------------------------------------ commands
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase();
        if (name.equals("coinsadmin")) return admin(sender, args);

        if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        switch (name) {
            case "coins" -> {
                if (args.length > 0) {
                    OfflinePlayer t = Bukkit.getOfflinePlayer(args[0]);
                    msg(p, "&f" + args[0] + "&7 has &6" + Util.fmt(bal(t.getUniqueId())) + " " + cur());
                } else openHub(p);
            }
            case "keys" -> openKeys(p);
            case "coinshop" -> openShopMain(p);
            case "exchange" -> openExchange(p);
            case "pets" -> openPets(p);
        }
        return true;
    }

    private boolean admin(CommandSender s, String[] a) {
        if (!s.hasPermission("coins.admin")) { msg(s, "&cNo permission."); return true; }
        if (a.length == 0) {
            msg(s, "&e/coinsadmin <add|remove|set|reset|check|givepet|reload> <player> [amount|pet]");
            return true;
        }
        if (a[0].equalsIgnoreCase("reload")) { reloadConfig(); msg(s, "&aReloaded config."); return true; }
        if (a.length < 2) { msg(s, "&cUsage: /coinsadmin " + a[0] + " <player> [amount]"); return true; }
        OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]);
        UUID id = t.getUniqueId();
        long amt = 0;
        if (a.length >= 3 && !a[0].equalsIgnoreCase("givepet")) {
            try { amt = Long.parseLong(a[2]); } catch (NumberFormatException ex) { msg(s, "&cInvalid number."); return true; }
        }
        switch (a[0].toLowerCase()) {
            case "add" -> { add(id, amt); msg(s, "&aAdded &6" + Util.fmt(amt) + "&a to " + a[1] + ". Now: " + Util.fmt(bal(id))); }
            case "remove" -> { setBal(id, bal(id) - amt); msg(s, "&aRemoved &6" + Util.fmt(amt) + "&a from " + a[1] + ". Now: " + Util.fmt(bal(id))); }
            case "set" -> { setBal(id, amt); msg(s, "&aSet " + a[1] + " to &6" + Util.fmt(amt)); }
            case "reset" -> { setBal(id, 0); msg(s, "&aReset " + a[1] + "."); }
            case "check" -> msg(s, "&f" + a[1] + " &7has &6" + Util.fmt(bal(id)) + " " + cur());
            case "givepet" -> {
                if (a.length < 3 || getConfig().getConfigurationSection("pets." + a[2]) == null) { msg(s, "&cUnknown pet id."); return true; }
                ownedPets.computeIfAbsent(id, k -> new HashSet<>()).add(a[2]);
                coins.putIfAbsent(id, 0L);
                msg(s, "&aGave pet &f" + a[2] + "&a to " + a[1]);
            }
            default -> msg(s, "&cUnknown sub-command.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (!c.getName().equalsIgnoreCase("coinsadmin") || !s.hasPermission("coins.admin")) return List.of();
        if (a.length == 1) return List.of("add", "remove", "set", "reset", "check", "givepet", "reload");
        if (a.length == 2) return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        if (a.length == 3 && a[0].equalsIgnoreCase("givepet")) {
            ConfigurationSection ps = getConfig().getConfigurationSection("pets");
            return ps == null ? List.of() : new ArrayList<>(ps.getKeys(false));
        }
        return List.of();
    }
}
