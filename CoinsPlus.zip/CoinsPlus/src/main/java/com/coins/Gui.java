package com.coins;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class Gui implements InventoryHolder {
    private final Inventory inv;
    private final int size;
    private final Map<Integer, Consumer<InventoryClickEvent>> actions = new HashMap<>();

    public Gui(String title, int rows) {
        this.size = rows * 9;
        this.inv = Bukkit.createInventory(this, size, Util.c(title));
    }

    public void set(int slot, ItemStack it, Consumer<InventoryClickEvent> action) {
        inv.setItem(slot, it);
        if (action != null) actions.put(slot, action);
    }

    /** Decorative frame (colored) + black filler. */
    public void frame(Material border, Material filler) {
        ItemStack f = Util.item(filler, " ", List.of());
        ItemStack b = Util.item(border, " ", List.of());
        for (int i = 0; i < size; i++) {
            boolean edge = i < 9 || i >= size - 9 || i % 9 == 0 || i % 9 == 8;
            inv.setItem(i, edge ? b : f);
        }
    }

    public void click(InventoryClickEvent e) {
        Consumer<InventoryClickEvent> a = actions.get(e.getRawSlot());
        if (a != null) a.accept(e);
    }

    public void open(Player p) { p.openInventory(inv); }

    @Override
    public Inventory getInventory() { return inv; }
}
