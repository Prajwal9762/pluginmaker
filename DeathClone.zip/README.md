# DeathClone 2.0

Paper plugin for **Minecraft Paper 1.21.9+** (real skins; older 1.21.x falls back to armor-stand clones). Java 21.

Players opt in with `/clone start`. Their life is recorded. When they die they respawn
normally and keep playing, and a **clone with their real skin** redoes that whole life:

- walks the same path (smooth, with head turning, sneaking, footsteps)
- **mines** the blocks they mined (with the block-crack animation) and **places** the blocks they placed
- **drops** the items they dropped
- wears the same armor and holds the same items (updates when the player swapped gear)
- every death = another clone, so you can build an army

## Commands
- `/clone start`  - start recording yourself
- `/clone stop`   - stop recording and clear it
- `/clone status` - recording state + active clones
- `/clone kill`   - remove all your clones
- `/clone reload` - reload config (permission `deathclone.admin`)

## Config highlights (`plugins/DeathClone/config.yml`)
- `enabled` - master on/off
- `after-replay` - `DESPAWN`, `STAY`, `LOOP`, or `PINGPONG` (walk back undoing the work, then repeat)
- `loops`, `stay-seconds`, `speed`, `max-clones-per-player`, `max-record-seconds`
- `appearance.*` - real skin, name tag, equipment, join/leave messages
- `actions.*` - turn each behaviour on/off: mining, mining-animation, placing, item-drops,
  block-drops, swinging, sneaking, footsteps, sounds, particles
- `actions.respect-protection` - asks WorldGuard/GriefPrevention/etc. before the clone edits a block

## Notes
- Clones only break a block if it is still the same block the player broke, and only place into empty spots.
- `item-drops` creates copies of dropped items (duplication) - turn it off if that is a problem.
- Recordings are kept in memory only (lost on restart).

## Building with GitHub
Upload the contents to a repo (keep `.github`), open **Actions -> Build DeathClone -> Run workflow**,
download the **DeathClone** artifact. Set `paper_version` if you need a different paper-api version.
