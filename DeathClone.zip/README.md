# DeathClone

A Paper plugin (Minecraft 1.21.x, Java 21).

Each player opts in with `/clone start`. While recording, their movement, sneaking, arm swings
and block breaks/places are remembered (rolling window). When they die they **respawn normally
and keep playing**, and a **clone** of them appears, redoes everything that life did (really
breaking/placing the blocks at the recorded positions), then despawns when it has caught up to
the moment of death. Every death adds another clone, so you can build an army of clones.

## Commands
- `/clone start`  - start recording yourself
- `/clone stop`   - stop recording and clear it
- `/clone status` - show recording state and how many clones are working
- `/clone kill`   - remove all your active clones

Permission: `deathclone.use` (default: everyone).

## Config (`plugins/DeathClone/config.yml`)
- `max-record-seconds` - how much of a life is remembered (default 300)
- `max-clones-per-player` - army size limit per player (default 3)
- `speed` - replay speed (default 1.0)
- `apply-block-changes` - clone really edits blocks (default true)
- `drop-items` - broken blocks drop items (default true)

## Building the jar with GitHub
1. Create a new GitHub repository and upload everything from this zip (keep the `.github` folder).
2. Open the **Actions** tab. The "Build plugin jar" workflow runs on every push
   (or press **Run workflow**).
3. When it finishes, open the run and download the **DeathClone-jar** artifact (a zip containing the jar).
4. Put the jar in your server's `plugins/` folder and restart.

Local build: `mvn package`, jar appears in `target/`.
