package dev.example.deathclone;

import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.inventory.ItemStack;

/** Things a player can do that a clone will redo. */
interface Action {

    /** Player started digging a block (used for the crack animation). */
    record Damage(World world, int x, int y, int z) implements Action {}

    /** Player broke a block. {@code data} is what was broken. */
    record Break(World world, int x, int y, int z, BlockData data) implements Action {}

    /** Player placed a block. {@code data} is what was placed. */
    record Place(World world, int x, int y, int z, BlockData data) implements Action {}

    /** Player dropped an item (Q key). */
    record Drop(ItemStack item) implements Action {}
}
