package dev.example.deathclone;

import com.destroystokyo.paper.profile.PlayerProfile;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Pose;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

/** One clone: replays a recorded life, tick by tick. */
final class CloneRun {

    private final DeathClonePlugin plugin;
    private final Settings s;
    final UUID owner;
    final String ownerName;
    private final List<Frame> frames;
    final LivingEntity body;
    private final PlayerProfile profile;

    private BukkitTask task;
    private double pos = 0;      // position in the recording (frame units, fractional)
    private int lastIdx = -1;    // last frame whose actions were fired
    private int dir = 1;         // +1 forward, -1 backwards (ping-pong)
    private int loopsDone = 0;
    private boolean staying = false;
    private int stayTicks = 0;
    private int tickCount = 0;

    private ItemStack tool = null;
    private boolean lastSneak = false;
    private Location lastStep = null;

    // keeps the chunk the clone stands in loaded, so it can't vanish when nobody is nearby
    private World tWorld = null;
    private int tx, tz;

    // mining crack animation
    private Action.Damage crack = null;
    private int crackStart = 0;
    private int crackEnd = -1;

    CloneRun(DeathClonePlugin plugin, Settings s, UUID owner, String ownerName,
             List<Frame> frames, LivingEntity body, PlayerProfile profile) {
        this.plugin = plugin;
        this.s = s;
        this.owner = owner;
        this.ownerName = ownerName;
        this.frames = frames;
        this.body = body;
        this.profile = profile;
    }

    void start() {
        Frame first = frames.get(0);
        if (first.equip() != null) equip(first.equip());
        keepLoaded(body.getLocation());
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    void stop() {
        if (task != null) task.cancel();
        clearCrack();
        releaseChunk();
        if (body != null && !body.isDead()) body.remove();
    }

    private void keepLoaded(Location loc) {
        World w = loc.getWorld();
        int cx = loc.getBlockX() >> 4, cz = loc.getBlockZ() >> 4;
        if (w == tWorld && cx == tx && cz == tz) return;
        releaseChunk();
        w.addPluginChunkTicket(cx, cz, plugin);
        tWorld = w; tx = cx; tz = cz;
    }

    private void releaseChunk() {
        if (tWorld != null) {
            tWorld.removePluginChunkTicket(tx, tz, plugin);
            tWorld = null;
        }
    }

    // ------------------------------------------------------------ main loop

    private void tick() {
        try {
            tickInner();
        } catch (Throwable t) {
            plugin.getLogger().log(Level.SEVERE, "Clone of " + ownerName + " crashed", t);
            plugin.finish(this, "error: " + t);
        }
    }

    private void tickInner() {
        if (!body.isValid()) { plugin.finish(this, "its body was removed"); return; }

        if (staying) {
            stayTicks++;
            if (s.stayTicks > 0 && stayTicks >= s.stayTicks) plugin.finish(this, "stay time over");
            return;
        }

        tickCount++;
        int n = frames.size();
        pos += dir * s.speed * 0.5; // frames are 2 ticks apart, we move every tick

        boolean passDone = false;
        if (dir > 0 && pos >= n - 1) { pos = n - 1; passDone = true; }
        if (dir < 0 && pos <= 0) { pos = 0; passDone = true; }

        int idx = (int) Math.floor(pos);

        if (dir > 0) {
            for (int k = lastIdx + 1; k <= idx; k++) fireFrame(frames.get(k), k, false);
        } else {
            for (int k = lastIdx; k > idx; k--) fireFrame(frames.get(k), k, true);
        }
        lastIdx = idx;

        // movement
        Frame a = frames.get(idx);
        Frame b = frames.get(Math.min(n - 1, idx + 1));
        double t = pos - idx;
        Location loc;
        if (a.world() == b.world()) {
            loc = new Location(a.world(),
                    a.x() + (b.x() - a.x()) * t,
                    a.y() + (b.y() - a.y()) * t,
                    a.z() + (b.z() - a.z()) * t,
                    lerpAngle(a.yaw(), b.yaw(), t),
                    (float) (a.pitch() + (b.pitch() - a.pitch()) * t));
        } else {
            loc = new Location(b.world(), b.x(), b.y(), b.z(), b.yaw(), b.pitch());
        }
        keepLoaded(loc);
        body.teleport(loc);
        body.setRotation(loc.getYaw(), loc.getPitch());

        setSneak(a.sneak());
        footstep(loc, a);
        updateCrack();

        if (passDone) onPassDone();
    }

    private void onPassDone() {
        clearCrack();
        if (dir < 0) fireFrame(frames.get(0), 0, true); // undo frame 0 as well

        switch (s.after) {
            case DESPAWN -> plugin.finish(this, "replay completed");
            case STAY -> staying = true;
            case LOOP -> {
                loopsDone++;
                if (s.loops != 0 && loopsDone >= s.loops) { afterLoops(); return; }
                pos = 0;
                lastIdx = -1;
            }
            case PINGPONG -> {
                if (dir > 0) {
                    dir = -1;                 // walk back, undoing the work
                    lastIdx = frames.size() - 1;
                } else {
                    loopsDone++;
                    if (s.loops != 0 && loopsDone >= s.loops) { afterLoops(); return; }
                    dir = 1;                  // and do it all again
                    pos = 0;
                    lastIdx = -1;
                }
            }
        }
    }

    private void afterLoops() {
        plugin.finish(this, "all loops completed");
    }

    // ------------------------------------------------------------ per-frame actions

    private void fireFrame(Frame f, int k, boolean inverse) {
        if (!inverse && f.equip() != null && s.showEquipment) equip(f.equip());
        if (f.swing() && s.swinging) body.swingMainHand();

        for (Action act : f.actions()) {
            if (act instanceof Action.Damage d) {
                if (!inverse && s.mining && s.miningAnim) startCrack(d, k);
            } else if (act instanceof Action.Break br) {
                if (inverse) restoreBlock(br); else doBreak(br);
            } else if (act instanceof Action.Place pl) {
                if (inverse) undoPlace(pl); else doPlace(pl);
            } else if (act instanceof Action.Drop dr) {
                if (!inverse) doDrop(dr);
            }
        }
    }

    private void equip(ItemStack[] e) {
        EntityEquipment eq = body.getEquipment();
        if (eq == null) return;
        eq.setItemInMainHand(e[0]);
        eq.setItemInOffHand(e[1]);
        ItemStack head = e[2];
        if (body instanceof ArmorStand && (head == null || head.getType().isAir()))
            head = Spawner.skull(profile); // fallback body keeps the player's head
        eq.setHelmet(head);
        eq.setChestplate(e[3]);
        eq.setLeggings(e[4]);
        eq.setBoots(e[5]);
        tool = e[0];
    }

    private void setSneak(boolean sneak) {
        if (!s.sneaking || sneak == lastSneak || body instanceof ArmorStand) return;
        lastSneak = sneak;
        try {
            body.setPose(sneak ? Pose.SNEAKING : Pose.STANDING);
        } catch (Throwable ignored) {
        }
    }

    private void footstep(Location loc, Frame f) {
        if (!s.footsteps || !s.sounds || !f.onGround() || f.sneak() || tickCount % 6 != 0) return;
        if (lastStep != null && lastStep.getWorld() == loc.getWorld()
                && lastStep.distanceSquared(loc) < 0.04) return; // standing still
        lastStep = loc.clone();
        Block below = loc.clone().subtract(0, 0.2, 0).getBlock();
        if (below.getType().isAir()) return;
        loc.getWorld().playSound(loc, below.getBlockData().getSoundGroup().getStepSound(), 0.25f, 1f);
    }

    // ------------------------------------------------------------ mining

    private void startCrack(Action.Damage d, int k) {
        clearCrack();
        crack = d;
        crackStart = k;
        crackEnd = -1;
        int limit = Math.min(frames.size(), k + 600);
        search:
        for (int i = k; i < limit; i++) {
            for (Action a : frames.get(i).actions()) {
                if (a instanceof Action.Break b && b.x() == d.x() && b.y() == d.y() && b.z() == d.z()) {
                    crackEnd = i;
                    break search;
                }
            }
        }
    }

    private void updateCrack() {
        if (crack == null) return;
        double prog = crackEnd > crackStart
                ? (pos - crackStart) / (double) (crackEnd - crackStart)
                : Math.min(0.9, (pos - crackStart) / 30.0);
        prog = Math.max(0.0, Math.min(0.99, prog));
        sendCrack(crack, (float) prog);

        if (s.sounds && tickCount % 4 == 0) {
            Block bl = crack.world().getBlockAt(crack.x(), crack.y(), crack.z());
            if (!bl.getType().isAir())
                crack.world().playSound(bl.getLocation().add(0.5, 0.5, 0.5),
                        bl.getBlockData().getSoundGroup().getHitSound(), 0.5f, 0.75f);
        }
    }

    private void clearCrack() {
        if (crack != null) sendCrack(crack, 0f);
        crack = null;
    }

    private void sendCrack(Action.Damage d, float progress) {
        Location l = new Location(d.world(), d.x(), d.y(), d.z());
        for (Player pl : d.world().getPlayers())
            if (pl.getLocation().distanceSquared(l) < 48 * 48) pl.sendBlockDamage(l, progress);
    }

    // ------------------------------------------------------------ block work

    private void doBreak(Action.Break b) {
        if (!s.mining) return;
        if (crack != null && crack.x() == b.x() && crack.y() == b.y() && crack.z() == b.z()) clearCrack();

        World w = b.world();
        if (!w.isChunkLoaded(b.x() >> 4, b.z() >> 4)) return;
        Block bl = w.getBlockAt(b.x(), b.y(), b.z());

        // only break what the player really broke (never something that was built there since)
        if (bl.getType() != b.data().getMaterial()) return;
        if (bl.getType().getHardness() < 0) return;
        if (!allowBreak(bl)) return;

        Location c = bl.getLocation().add(0.5, 0.5, 0.5);
        BlockData cur = bl.getBlockData();
        if (s.particles) w.spawnParticle(Particle.BLOCK, c, 25, 0.25, 0.25, 0.25, cur);
        if (s.sounds) w.playSound(c, cur.getSoundGroup().getBreakSound(), 1f, 0.8f);

        if (s.blockDrops) bl.breakNaturally(tool == null ? new ItemStack(Material.AIR) : tool);
        else bl.setType(Material.AIR);
    }

    private void doPlace(Action.Place p) {
        if (!s.placing) return;
        placeBlock(p.world(), p.x(), p.y(), p.z(), p.data());
    }

    /** Reverse pass: put back what the player broke. */
    private void restoreBlock(Action.Break b) {
        if (!s.mining || !s.placing) return;
        placeBlock(b.world(), b.x(), b.y(), b.z(), b.data());
    }

    /** Reverse pass: remove what the player placed. */
    private void undoPlace(Action.Place p) {
        if (!s.placing) return;
        World w = p.world();
        if (!w.isChunkLoaded(p.x() >> 4, p.z() >> 4)) return;
        Block bl = w.getBlockAt(p.x(), p.y(), p.z());
        if (bl.getType() != p.data().getMaterial()) return;
        if (!allowBreak(bl)) return;
        Location c = bl.getLocation().add(0.5, 0.5, 0.5);
        if (s.particles) w.spawnParticle(Particle.BLOCK, c, 20, 0.25, 0.25, 0.25, bl.getBlockData());
        if (s.sounds) w.playSound(c, bl.getBlockData().getSoundGroup().getBreakSound(), 1f, 0.8f);
        bl.setType(Material.AIR);
    }

    private void placeBlock(World w, int x, int y, int z, BlockData data) {
        if (!w.isChunkLoaded(x >> 4, z >> 4)) return;
        Block bl = w.getBlockAt(x, y, z);
        if (!(bl.getType().isAir() || bl.isReplaceable())) return; // spot is taken

        BlockState old = bl.getState();
        bl.setBlockData(data, false);

        if (s.protection) {
            boolean ok = false;
            Player o = Bukkit.getPlayer(owner);
            if (o != null) {
                Material mat = data.getPlacementMaterial();
                if (mat.isAir() || !mat.isItem()) mat = Material.STONE;
                plugin.internal = true;
                try {
                    BlockPlaceEvent ev = new BlockPlaceEvent(bl, old, bl.getRelative(BlockFace.DOWN),
                            new ItemStack(mat), o, true, EquipmentSlot.HAND);
                    Bukkit.getPluginManager().callEvent(ev);
                    ok = !ev.isCancelled() && ev.canBuild();
                } finally {
                    plugin.internal = false;
                }
            }
            if (!ok) { old.update(true, false); return; }
        }

        Location c = bl.getLocation().add(0.5, 0.5, 0.5);
        if (s.particles) w.spawnParticle(Particle.BLOCK, c, 8, 0.2, 0.2, 0.2, data);
        if (s.sounds) w.playSound(c, data.getSoundGroup().getPlaceSound(), 1f, 0.9f);
    }

    /** Land-claim / protection plugins get to veto, as if the owner broke it. */
    private boolean allowBreak(Block bl) {
        if (!s.protection) return true;
        Player o = Bukkit.getPlayer(owner);
        if (o == null) return false; // owner offline: don't touch the world
        plugin.internal = true;
        try {
            BlockBreakEvent ev = new BlockBreakEvent(bl, o);
            Bukkit.getPluginManager().callEvent(ev);
            return !ev.isCancelled();
        } finally {
            plugin.internal = false;
        }
    }

    private void doDrop(Action.Drop d) {
        if (!s.itemDrops) return;
        Location eye = body.getEyeLocation();
        Item it = eye.getWorld().dropItem(eye, d.item().clone());
        it.setVelocity(eye.getDirection().multiply(0.3));
        it.setPickupDelay(40);
    }

    // ------------------------------------------------------------ helpers

    private static float lerpAngle(float a, float b, double t) {
        float d = ((b - a + 540f) % 360f) - 180f;
        return (float) (a + d * t);
    }
}
