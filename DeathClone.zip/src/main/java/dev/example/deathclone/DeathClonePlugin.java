package dev.example.deathclone;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * DeathClone: when a player who ran /clone start dies, they respawn normally and a clone
 * of them redoes everything that life did (movement, swings, block breaking/placing),
 * then despawns. Every death adds another clone, so you can build an army.
 */
public final class DeathClonePlugin extends JavaPlugin implements Listener {

    /** One recorded sample (taken every 2 ticks). */
    private record Frame(World world, double x, double y, double z, float yaw, float pitch,
                         boolean swing, boolean sneak,
                         BlockData block, boolean placed, int bx, int by, int bz) {}

    private record Gear(ItemStack head, ItemStack chest, ItemStack legs, ItemStack feet, ItemStack hand) {}

    private static final class CloneRun {
        ArmorStand stand;
        BukkitTask task;
    }

    private final Map<UUID, ArrayDeque<Frame>> recordings = new HashMap<>();
    private final Set<UUID> pendingSwing = new HashSet<>();
    private final Map<UUID, Frame> pendingBlock = new HashMap<>();
    private final Map<UUID, List<CloneRun>> runs = new HashMap<>();
    /** Players who ran /clone start. */
    private final Set<UUID> enabled = new HashSet<>();

    private int maxFrames;
    private int maxClones;
    private double speed;
    private boolean applyBlocks;
    private boolean dropItems;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        maxFrames = getConfig().getInt("max-record-seconds", 300) * 10; // 10 samples / second
        maxClones = getConfig().getInt("max-clones-per-player", 3);
        speed = Math.max(0.1, getConfig().getDouble("speed", 1.0));
        applyBlocks = getConfig().getBoolean("apply-block-changes", true);
        dropItems = getConfig().getBoolean("drop-items", true);

        getServer().getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::sample, 0L, 2L);
    }

    @Override
    public void onDisable() {
        for (List<CloneRun> list : runs.values())
            for (CloneRun r : list) {
                if (r.task != null) r.task.cancel();
                if (r.stand != null && !r.stand.isDead()) r.stand.remove();
            }
        runs.clear();
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Only players can use /clone.");
            return true;
        }
        UUID id = p.getUniqueId();
        String sub = args.length == 0 ? "help" : args[0].toLowerCase();

        switch (sub) {
            case "start" -> {
                if (enabled.add(id)) {
                    recordings.remove(id);
                    p.sendMessage(Component.text("Clone recording started. When you die, you respawn and a clone redoes your work.", NamedTextColor.GREEN));
                } else {
                    p.sendMessage(Component.text("You are already recording.", NamedTextColor.YELLOW));
                }
            }
            case "stop" -> {
                if (enabled.remove(id)) {
                    recordings.remove(id);
                    pendingSwing.remove(id);
                    pendingBlock.remove(id);
                    p.sendMessage(Component.text("Clone recording stopped and cleared.", NamedTextColor.RED));
                } else {
                    p.sendMessage(Component.text("You are not recording.", NamedTextColor.YELLOW));
                }
            }
            case "kill" -> {
                int n = killClones(id);
                p.sendMessage(Component.text("Removed " + n + " clone(s).", NamedTextColor.GOLD));
            }
            case "status" -> {
                int active = runs.getOrDefault(id, List.of()).size();
                if (!enabled.contains(id)) {
                    p.sendMessage(Component.text("Clone: OFF. Use /clone start. Active clones: " + active, NamedTextColor.GRAY));
                } else {
                    int n = recordings.getOrDefault(id, new ArrayDeque<>()).size();
                    p.sendMessage(Component.text("Clone: ON, recorded " + (n / 10) + "s this life. Active clones: "
                            + active + "/" + maxClones, NamedTextColor.AQUA));
                }
            }
            default -> p.sendMessage(Component.text("Usage: /clone <start|stop|status|kill>", NamedTextColor.GOLD));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> out = new ArrayList<>();
            for (String o : List.of("start", "stop", "status", "kill"))
                if (o.startsWith(args[0].toLowerCase())) out.add(o);
            return out;
        }
        return List.of();
    }

    private int killClones(UUID owner) {
        List<CloneRun> list = runs.remove(owner);
        if (list == null) return 0;
        for (CloneRun r : list) {
            if (r.task != null) r.task.cancel();
            if (r.stand != null && !r.stand.isDead()) r.stand.remove();
        }
        return list.size();
    }

    // ---------------------------------------------------------------- recording

    private void sample() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            if (!enabled.contains(id)) continue;
            if (p.isDead() || p.getGameMode() == GameMode.SPECTATOR) continue;

            Location l = p.getLocation();
            boolean swing = pendingSwing.remove(id);
            Frame b = pendingBlock.remove(id);

            Frame f = new Frame(l.getWorld(), l.getX(), l.getY(), l.getZ(), l.getYaw(), l.getPitch(),
                    swing, p.isSneaking(),
                    b == null ? null : b.block, b != null && b.placed,
                    b == null ? 0 : b.bx, b == null ? 0 : b.by, b == null ? 0 : b.bz);

            ArrayDeque<Frame> q = recordings.computeIfAbsent(id, k -> new ArrayDeque<>());
            q.addLast(f);
            while (q.size() > maxFrames) q.removeFirst();
        }
    }

    @EventHandler
    public void onSwing(PlayerAnimationEvent e) {
        if (enabled.contains(e.getPlayer().getUniqueId()))
            pendingSwing.add(e.getPlayer().getUniqueId());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (!enabled.contains(id)) return;
        Block b = e.getBlock();
        pendingBlock.put(id, new Frame(b.getWorld(), 0, 0, 0, 0, 0, false, false,
                b.getBlockData(), false, b.getX(), b.getY(), b.getZ()));
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (!enabled.contains(id)) return;
        Block b = e.getBlockPlaced();
        pendingBlock.put(id, new Frame(b.getWorld(), 0, 0, 0, 0, 0, false, false,
                b.getBlockData(), true, b.getX(), b.getY(), b.getZ()));
    }

    // ---------------------------------------------------------------- death -> clone

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        UUID id = p.getUniqueId();

        ArrayDeque<Frame> q = recordings.remove(id); // new life starts with an empty recording
        pendingSwing.remove(id);
        pendingBlock.remove(id);

        if (!enabled.contains(id) || q == null || q.size() < 2) return;

        if (runs.getOrDefault(id, List.of()).size() >= maxClones) {
            p.sendMessage(Component.text("Clone limit reached (" + maxClones + "), no new clone this time.", NamedTextColor.YELLOW));
            return;
        }

        var inv = p.getInventory();
        Gear g = new Gear(copy(inv.getHelmet()), copy(inv.getChestplate()),
                copy(inv.getLeggings()), copy(inv.getBoots()), copy(inv.getItemInMainHand()));
        List<Frame> frames = new ArrayList<>(q);

        // The player respawns immediately as normal; the clone starts right away.
        Bukkit.getScheduler().runTask(this, () -> startClone(p.getUniqueId(), p.getName(), p, frames, g));
    }

    private void startClone(UUID owner, String ownerName, Player skinSource, List<Frame> frames, Gear g) {
        Frame first = frames.get(0);
        Location start = new Location(first.world, first.x, first.y, first.z, first.yaw, first.pitch);
        if (!start.getWorld().isChunkLoaded(start.getBlockX() >> 4, start.getBlockZ() >> 4))
            start.getWorld().getChunkAt(start);

        CloneRun run = new CloneRun();
        run.stand = start.getWorld().spawn(start, ArmorStand.class, a -> {
            a.setArms(true);
            a.setBasePlate(false);
            a.setGravity(false);
            a.setInvulnerable(true);
            a.setPersistent(false);
            a.customName(Component.text(ownerName + "'s clone"));
            a.setCustomNameVisible(true);

            ItemStack head = g.head;
            if (head == null || head.getType().isAir()) {
                head = new ItemStack(Material.PLAYER_HEAD);
                SkullMeta m = (SkullMeta) head.getItemMeta();
                m.setOwningPlayer(skinSource);
                head.setItemMeta(m);
            }
            a.getEquipment().setHelmet(head);
            a.getEquipment().setChestplate(g.chest);
            a.getEquipment().setLeggings(g.legs);
            a.getEquipment().setBoots(g.feet);
            a.getEquipment().setItemInMainHand(g.hand);
        });
        runs.computeIfAbsent(owner, k -> new ArrayList<>()).add(run);

        run.task = Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
            double pos = 0;
            int lastFired = -1;

            @Override
            public void run() {
                if (run.stand == null || run.stand.isDead()) { finish(owner, run); return; }

                pos = Math.min(frames.size() - 1, pos + speed);
                int i = (int) pos;
                int j = Math.min(frames.size() - 1, i + 1);
                double t = pos - i;
                Frame a = frames.get(i), b = frames.get(j);

                if (a.world == b.world) {
                    run.stand.teleport(new Location(a.world,
                            a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t,
                            a.yaw, a.pitch));
                } else {
                    run.stand.teleport(new Location(b.world, b.x, b.y, b.z, b.yaw, b.pitch));
                }
                run.stand.setSneaking(a.sneak);

                for (int k = lastFired + 1; k <= i; k++) {
                    Frame f = frames.get(k);
                    if (f.swing) run.stand.swingMainHand();
                    if (f.block != null) doBlockAction(f, g);
                }
                lastFired = i;

                if (pos >= frames.size() - 1) finish(owner, run); // caught up to where the life ended
            }
        }, 0L, 2L);
    }

    private void finish(UUID owner, CloneRun run) {
        if (run.task != null) run.task.cancel();
        if (run.stand != null && !run.stand.isDead()) run.stand.remove();
        List<CloneRun> list = runs.get(owner);
        if (list != null) {
            list.remove(run);
            if (list.isEmpty()) runs.remove(owner);
        }
    }

    /** Really breaks/places the block at its recorded position (if it differs from the recorded result). */
    private void doBlockAction(Frame f, Gear g) {
        World w = f.world;
        if (!w.isChunkLoaded(f.bx >> 4, f.bz >> 4)) return;
        Block bl = w.getBlockAt(f.bx, f.by, f.bz);
        Location l = bl.getLocation().add(0.5, 0.5, 0.5);

        if (f.placed) {
            if (applyBlocks && (bl.getType().isAir() || bl.isLiquid())) bl.setBlockData(f.block);
            w.playSound(l, f.block.getSoundGroup().getPlaceSound(), 0.6f, 1f);
        } else {
            if (applyBlocks && !bl.getType().isAir() && bl.getType().getHardness() >= 0) {
                w.spawnParticle(Particle.BLOCK, l, 15, 0.25, 0.25, 0.25, bl.getBlockData());
                w.playSound(l, bl.getBlockData().getSoundGroup().getBreakSound(), 0.6f, 1f);
                if (dropItems) bl.breakNaturally(g.hand != null ? g.hand : new ItemStack(Material.AIR));
                else bl.setType(Material.AIR);
            } else {
                w.spawnParticle(Particle.BLOCK, l, 15, 0.25, 0.25, 0.25, f.block);
                w.playSound(l, f.block.getSoundGroup().getBreakSound(), 0.6f, 1f);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        recordings.remove(id);
        enabled.remove(id);
        pendingSwing.remove(id);
        pendingBlock.remove(id);
        // clones already running keep going until they finish
    }

    private static ItemStack copy(ItemStack i) {
        return i == null ? null : i.clone();
    }
}
