package dev.example.deathclone;

import com.destroystokyo.paper.profile.PlayerProfile;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

/**
 * DeathClone 2.0
 *
 * Players opt in with /clone start. Their life is recorded (movement, mining, placing, drops, gear...).
 * When they die they respawn normally and a clone with their real skin redoes that life.
 */
public final class DeathClonePlugin extends JavaPlugin implements Listener {

    Settings settings;
    /** true while the plugin fires its own events, so we don't record them. */
    boolean internal = false;

    private final Map<UUID, ArrayDeque<Frame>> recordings = new HashMap<>();
    private final Map<UUID, List<Action>> pendingActions = new HashMap<>();
    private final Set<UUID> pendingSwing = new HashSet<>();
    private final Map<UUID, ItemStack[]> lastEquip = new HashMap<>();
    private final Map<UUID, List<CloneRun>> runs = new HashMap<>();
    private final Set<UUID> enabled = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        settings = Settings.load(getConfig());
        getServer().getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::sample, 0L, 2L);

        if (Spawner.MANNEQUIN_AVAILABLE)
            getLogger().info("Mannequin support found: clones will use the player's real skin.");
        else
            getLogger().warning("This server has no Mannequin entity (needs Paper 1.21.9+). Clones will be armor stands.");
    }

    @Override
    public void onDisable() {
        for (List<CloneRun> list : runs.values())
            for (CloneRun r : new ArrayList<>(list)) r.stop();
        runs.clear();
    }

    // ================================================================ commands

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "help" : args[0].toLowerCase();

        if (sub.equals("reload")) {
            if (!sender.hasPermission("deathclone.admin")) {
                sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
                return true;
            }
            reloadConfig();
            settings = Settings.load(getConfig());
            sender.sendMessage(Component.text("DeathClone config reloaded.", NamedTextColor.GREEN));
            return true;
        }

        if (!(sender instanceof Player p)) {
            sender.sendMessage("Only players can use /clone.");
            return true;
        }
        UUID id = p.getUniqueId();

        switch (sub) {
            case "start" -> {
                if (!settings.enabled) {
                    p.sendMessage(Component.text("Clones are currently disabled on this server.", NamedTextColor.RED));
                } else if (enabled.add(id)) {
                    recordings.remove(id);
                    lastEquip.remove(id);
                    p.sendMessage(Component.text("Clone recording started. When you die you respawn and a clone redoes your work.", NamedTextColor.GREEN));
                } else {
                    p.sendMessage(Component.text("You are already recording.", NamedTextColor.YELLOW));
                }
            }
            case "stop" -> {
                if (enabled.remove(id)) {
                    clearRecording(id);
                    p.sendMessage(Component.text("Clone recording stopped and cleared.", NamedTextColor.RED));
                } else {
                    p.sendMessage(Component.text("You are not recording.", NamedTextColor.YELLOW));
                }
            }
            case "kill" -> {
                int n = killClones(id);
                p.sendMessage(Component.text("Removed " + n + " clone(s).", NamedTextColor.GOLD));
            }
            case "status" -> {
                int active = runs.getOrDefault(id, List.of()).size();
                if (!enabled.contains(id)) {
                    p.sendMessage(Component.text("Clone: OFF (use /clone start). Active clones: " + active, NamedTextColor.GRAY));
                } else {
                    int n = recordings.getOrDefault(id, new ArrayDeque<>()).size();
                    p.sendMessage(Component.text("Clone: ON, recorded " + (n / 10) + "s this life. Active clones: "
                            + active + "/" + settings.maxClones, NamedTextColor.AQUA));
                }
            }
            default -> p.sendMessage(Component.text("Usage: /clone <start|stop|status|kill>", NamedTextColor.GOLD));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) return List.of();
        List<String> options = new ArrayList<>(List.of("start", "stop", "status", "kill"));
        if (sender.hasPermission("deathclone.admin")) options.add("reload");
        List<String> out = new ArrayList<>();
        for (String o : options) if (o.startsWith(args[0].toLowerCase())) out.add(o);
        return out;
    }

    private void clearRecording(UUID id) {
        recordings.remove(id);
        pendingActions.remove(id);
        pendingSwing.remove(id);
        lastEquip.remove(id);
    }

    private int killClones(UUID owner) {
        List<CloneRun> list = runs.remove(owner);
        if (list == null) return 0;
        for (CloneRun r : list) {
            r.stop();
            announceLeave(r);
        }
        return list.size();
    }

    // ================================================================ recording

    private void sample() {
        if (!settings.enabled) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            if (!enabled.contains(id)) continue;
            if (p.isDead() || p.getGameMode() == GameMode.SPECTATOR) continue;

            Location l = p.getLocation();
            boolean swing = pendingSwing.remove(id);
            List<Action> acts = pendingActions.remove(id);

            // gear: only stored when it changed
            ItemStack[] now = snapshotEquipment(p);
            ItemStack[] last = lastEquip.get(id);
            ItemStack[] changed = null;
            if (last == null || !sameEquipment(last, now)) {
                changed = now;
                lastEquip.put(id, now);
            }

            Frame f = new Frame(l.getWorld(), l.getX(), l.getY(), l.getZ(), l.getYaw(), l.getPitch(),
                    p.isSneaking(), swing, p.isOnGround(),
                    changed, acts == null ? List.of() : acts);

            ArrayDeque<Frame> q = recordings.computeIfAbsent(id, k -> new ArrayDeque<>());
            q.addLast(f);
            while (q.size() > settings.maxFrames) q.removeFirst();
        }
    }

    private static ItemStack[] snapshotEquipment(Player p) {
        PlayerInventory inv = p.getInventory();
        return new ItemStack[]{
                copy(inv.getItemInMainHand()), copy(inv.getItemInOffHand()),
                copy(inv.getHelmet()), copy(inv.getChestplate()),
                copy(inv.getLeggings()), copy(inv.getBoots())
        };
    }

    private static boolean sameEquipment(ItemStack[] a, ItemStack[] b) {
        for (int i = 0; i < a.length; i++) {
            ItemStack x = a[i], y = b[i];
            boolean xe = x == null || x.getType().isAir();
            boolean ye = y == null || y.getType().isAir();
            if (xe != ye) return false;
            if (!xe && !x.isSimilar(y)) return false;
        }
        return true;
    }

    private static ItemStack copy(ItemStack i) {
        return i == null ? null : i.clone();
    }

    private void addAction(UUID id, Action a) {
        pendingActions.computeIfAbsent(id, k -> new ArrayList<>()).add(a);
    }

    @EventHandler
    public void onSwing(PlayerAnimationEvent e) {
        if (internal) return;
        if (enabled.contains(e.getPlayer().getUniqueId())) pendingSwing.add(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamageBlock(BlockDamageEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (internal || !enabled.contains(id) || e.getInstaBreak()) return;
        Block b = e.getBlock();
        addAction(id, new Action.Damage(b.getWorld(), b.getX(), b.getY(), b.getZ()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (internal || !enabled.contains(id)) return;
        Block b = e.getBlock();
        addAction(id, new Action.Break(b.getWorld(), b.getX(), b.getY(), b.getZ(), b.getBlockData()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (internal || !enabled.contains(id)) return;
        Block b = e.getBlockPlaced();
        addAction(id, new Action.Place(b.getWorld(), b.getX(), b.getY(), b.getZ(), b.getBlockData()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (internal || !enabled.contains(id)) return;
        addAction(id, new Action.Drop(e.getItemDrop().getItemStack().clone()));
    }

    // ================================================================ death -> clone

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        UUID id = p.getUniqueId();

        ArrayDeque<Frame> q = recordings.remove(id); // the next life starts with a fresh recording
        pendingActions.remove(id);
        pendingSwing.remove(id);
        lastEquip.remove(id);

        if (!settings.enabled || !enabled.contains(id) || q == null || q.size() < 2) return;

        if (runs.getOrDefault(id, List.of()).size() >= settings.maxClones) {
            p.sendMessage(Component.text("Clone limit reached (" + settings.maxClones + "), no new clone this time.", NamedTextColor.YELLOW));
            return;
        }

        List<Frame> frames = new ArrayList<>(q);
        PlayerProfile profile = p.getPlayerProfile(); // contains the real skin
        String name = p.getName();

        // The player respawns as normal; the clone starts right away.
        Bukkit.getScheduler().runTask(this, () -> startClone(id, name, profile, frames));
    }

    private void startClone(UUID owner, String name, PlayerProfile profile, List<Frame> frames) {
        Frame first = frames.get(0);
        Location start = new Location(first.world(), first.x(), first.y(), first.z(), first.yaw(), first.pitch());
        start.getChunk(); // make sure it is loaded

        Component display = Component.text(settings.nameFormat.replace("%player%", name));
        LivingEntity body = Spawner.spawn(this, start, profile, display, settings);
        if (body == null) return;

        CloneRun run = new CloneRun(this, settings, owner, name, frames, body, profile);
        runs.computeIfAbsent(owner, k -> new ArrayList<>()).add(run);

        if (settings.joinMessages)
            Bukkit.broadcast(Component.text(settings.nameFormat.replace("%player%", name) + " joined the game", NamedTextColor.YELLOW));

        run.start();
    }

    /** Called by a clone when it is done (or its body vanished). */
    void finish(CloneRun run) {
        run.stop();
        List<CloneRun> list = runs.get(run.owner);
        if (list != null) {
            list.remove(run);
            if (list.isEmpty()) runs.remove(run.owner);
        }
        announceLeave(run);
    }

    private void announceLeave(CloneRun run) {
        if (settings.joinMessages)
            Bukkit.broadcast(Component.text(settings.nameFormat.replace("%player%", run.ownerName) + " left the game", NamedTextColor.YELLOW));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        enabled.remove(id);
        clearRecording(id);
        // clones that are already running keep going
    }
}
