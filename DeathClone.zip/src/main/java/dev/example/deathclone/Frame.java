package dev.example.deathclone;

import org.bukkit.World;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * One recorded sample of a player (taken every 2 ticks).
 *
 * @param equip   [mainHand, offHand, head, chest, legs, feet] - only set when something changed (null = unchanged)
 * @param actions things the player did during this sample (never null)
 */
record Frame(World world, double x, double y, double z, float yaw, float pitch,
             boolean sneak, boolean swing, boolean onGround,
             ItemStack[] equip, List<Action> actions) {
}
