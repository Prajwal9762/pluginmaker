package dev.example.deathclone;

import com.destroystokyo.paper.profile.PlayerProfile;
import io.papermc.paper.datacomponent.item.ResolvableProfile;
import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mannequin;

/** Only loaded when the server has the Mannequin entity (Paper 1.21.9+). */
final class MannequinSpawner {

    private MannequinSpawner() {}

    static LivingEntity spawn(Location loc, PlayerProfile profile, Component name, boolean showName) {
        return loc.getWorld().spawn(loc, Mannequin.class, m -> {
            m.setProfile(ResolvableProfile.resolvableProfile(profile)); // the player's real skin
            m.setImmovable(true);
            m.setGravity(false);
            m.setInvulnerable(true);
            m.setPersistent(false);
            m.setCollidable(false);
            m.setDescription(null); // removes the default "NPC" text under the name
            m.customName(name);
            m.setCustomNameVisible(showName);
        });
    }
}
