package dev.example.deathclone;

import org.bukkit.configuration.file.FileConfiguration;

/** All config values in one place. */
final class Settings {

    enum After { DESPAWN, STAY, LOOP, PINGPONG }

    boolean enabled;
    int maxFrames;
    int maxClones;
    double speed;
    After after;
    int loops;
    int stayTicks;

    boolean realSkin;
    boolean showName;
    String nameFormat;
    boolean showEquipment;
    boolean joinMessages;

    boolean mining;
    boolean miningAnim;
    boolean placing;
    boolean itemDrops;
    boolean blockDrops;
    boolean swinging;
    boolean sneaking;
    boolean footsteps;
    boolean sounds;
    boolean particles;
    boolean protection;

    static Settings load(FileConfiguration c) {
        Settings s = new Settings();
        s.enabled = c.getBoolean("enabled", true);
        s.maxFrames = Math.max(20, c.getInt("max-record-seconds", 300) * 10); // 10 samples / second
        s.maxClones = Math.max(1, c.getInt("max-clones-per-player", 3));
        s.speed = Math.max(0.1, c.getDouble("speed", 1.0));
        try {
            s.after = After.valueOf(c.getString("after-replay", "DESPAWN").toUpperCase());
        } catch (IllegalArgumentException ex) {
            s.after = After.DESPAWN;
        }
        s.loops = Math.max(0, c.getInt("loops", 1));
        s.stayTicks = Math.max(0, c.getInt("stay-seconds", 0)) * 20;

        s.realSkin = c.getBoolean("appearance.real-skin", true);
        s.showName = c.getBoolean("appearance.show-name", true);
        s.nameFormat = c.getString("appearance.name-format", "%player%'s clone");
        s.showEquipment = c.getBoolean("appearance.show-equipment", true);
        s.joinMessages = c.getBoolean("appearance.join-messages", false);

        s.mining = c.getBoolean("actions.mining", true);
        s.miningAnim = c.getBoolean("actions.mining-animation", true);
        s.placing = c.getBoolean("actions.placing", true);
        s.itemDrops = c.getBoolean("actions.item-drops", true);
        s.blockDrops = c.getBoolean("actions.block-drops", true);
        s.swinging = c.getBoolean("actions.swinging", true);
        s.sneaking = c.getBoolean("actions.sneaking", true);
        s.footsteps = c.getBoolean("actions.footsteps", true);
        s.sounds = c.getBoolean("actions.sounds", true);
        s.particles = c.getBoolean("actions.particles", true);
        s.protection = c.getBoolean("actions.respect-protection", true);
        return s;
    }
}
