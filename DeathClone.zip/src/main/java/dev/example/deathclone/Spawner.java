package dev.example.deathclone;

import com.destroystokyo.paper.profile.PlayerProfile;
import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.logging.Level;

/**
 * Creates the clone's body.
 * - Paper 1.21.9+ : a Mannequin wearing the player's real skin.
 * - older Paper   : an armor stand wearing the player's head (fallback).
 */
final class Spawner {

    static final boolean MANNEQUIN_AVAILABLE;

    static {
        boolean ok = false;
        try {
            Class.forName("org.bukkit.entity.Mannequin");
            Class.forName("io.papermc.paper.datacomponent.item.ResolvableProfile");
            ok = true;
        } catch (Throwable ignored) {
        }
        MANNEQUIN_AVAILABLE = ok;
    }

    private Spawner() {}

    static LivingEntity spawn(DeathClonePlugin plugin, Location loc, PlayerProfile profile,
                              Component name, Settings s) {
        if (s.realSkin && MANNEQUIN_AVAILABLE) {
            try {
                // Kept in a separate class so older servers never try to load Mannequin.
                LivingEntity m = MannequinSpawner.spawn(loc, profile, name, s.showName);
                if (m != null && m.isValid()) return m;
                plugin.getLogger().warning("Mannequin spawn was refused (cancelled by another plugin, or the chunk "
                        + "was not ready). Using an armor stand instead.");
                if (m != null) m.remove();
            } catch (Throwable t) {
                plugin.getLogger().log(Level.WARNING, "Mannequin spawn failed, using armor stand instead", t);
            }
        }
        return loc.getWorld().spawn(loc, ArmorStand.class, a -> {
            a.setArms(true);
            a.setBasePlate(false);
            a.setGravity(false);
            a.setInvulnerable(true);
            a.setPersistent(false);
            a.customName(name);
            a.setCustomNameVisible(s.showName);
            a.getEquipment().setHelmet(skull(profile));
        });
    }

    static ItemStack skull(PlayerProfile profile) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta m = (SkullMeta) head.getItemMeta();
        m.setPlayerProfile(profile);
        head.setItemMeta(m);
        return head;
    }
}
