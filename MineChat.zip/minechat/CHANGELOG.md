# Changelog

## 1.5.0
- Smart auto-eat: once hunger is low it keeps eating until the food bar is full, picks the food that wastes
  least, and also uses food from the main inventory (swapped into your selected slot, then put back).
  Optional golden-apple healing. Stops cleanly if there is no food and tells you.
- New Automation screen (Settings > Automation, alerts and chat tools): panic command at low health, vibrate on
  damage, auto-reply to whispers, keyword rules, scheduled commands, join greetings, friends (highlight and
  join alerts), ignore list and hidden words, junk list, keep screen on.
- Death point saved automatically as a waypoint.
- Info tab: server TPS estimate, ping graph, bandwidth meter, compass facing, look and sneak/sprint controls,
  per-server notes.
- Map: nearby mob and player counts with distance, waypoint compass bearing.
- Items tab: find-item highlight, item totals, drop-junk button.
- Players tab: tap a player for message, teleport request, copy name, friend and ignore.

## 1.4.0
- Everything is now named MineChat: app id `com.minechat.app`, library `minechat_core`, all code and files.
  This is a new app on your phone, separate from older ChatCraft builds (uninstall those; saved servers
  do not carry over, use Settings > Copy backup in the old app first if you want to move them).
- Heart and hunger bars with half-units, XP level and bar, game clock and weather.
- Notices when health or hunger drops ("Health -3 hearts (now 7)"), low-health and hungry alerts that also
  notify you in the background.
- Optional auto-eat (food in the hotbar) and anti-AFK (tiny move every 45 s), both off by default.

## 1.3.0
- Auto-login: save a password (encrypted with the Android Keystore) and commands to run after joining,
  for example `/login {password}`.
- Use item (right-click, for compass menus), swing arm, and right-click a block (chests, buttons).
- Mention and whisper notifications while the app is in the background.
- Titles, action bar, boss bars and the sidebar scoreboard are shown in chat.
- Radar on the world map: players, hostile mobs, friendly mobs and dropped items.
- Server domain (SRV) lookup: servers reachable by a plain domain work without typing the port.
- Quick commands can be chained with `;`. Backup and restore of saved servers through the clipboard.

## 1.2.0
- Item textures: download the official textures from Mojang to your own device, or import a resource pack
  or the game's .jar (Settings > Item textures). MineChat itself ships no Minecraft textures.
- Map tab: top-down world map around you (decoded from the server's chunks, depth-tinted water,
  relief shading) and in-game map items (the picture on a held map).
- Waypoints: save your position with a name, see distance, show them on the map, copy coordinates.
- Chat search; tap a player in the Players tab to start a /msg.
- Map view distance setting (2 to 10 chunks).

## 1.1.0
- Tab button in chat: lists the commands the server lets you use and tab-completes names and arguments.
- Quick-command buttons in chat (default /help, /spawn, /home, /shop; editable in Settings).
- Server menus (/shop, /warp and similar) open automatically as an interactive screen; items now show
  their custom names, lore and an enchanted outline.
- Server list: server icons, latency bars, search, quick connect on the Dashboard.
- Export chat through the share sheet.
- Smoother screen transitions and animations; faster chat updates.
- "Coming soon" cards for Microsoft account and Account ID login.
- Ownership notice, LICENSE and third-party notices added. App renamed to MineChat.

## 0.2.0
- Rename to MineChat, inventory with click, shift-click and drop.

## 0.1.0
- First version: status ping, offline-mode login, chat, player list, movement.
