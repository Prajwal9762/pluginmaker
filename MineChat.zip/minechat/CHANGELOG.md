# Changelog

## 1.2.0
- Item textures: download the official textures from Mojang to your own device, or import a resource pack
  or the game's .jar (Settings > Item textures). MineChat itself ships no Minecraft textures.
- Map tab: top-down world map around you (decoded from the server's chunks, depth-tinted water,
  relief shading) and in-game map items (the picture on a held map).
- Waypoints: save your position with a name, see distance, show them on the map, copy coordinates.
- Chat search; tap a player in the Players tab to start a /msg.
- Map view distance setting (2 to 10 chunks).

## 1.1.0
- Tab button in chat: lists the commands the server lets you use and tab-completes names and arguments.
- Quick-command buttons in chat (default /help, /spawn, /home, /shop; editable in Settings).
- Server menus (/shop, /warp and similar) open automatically as an interactive screen; items now show
  their custom names, lore and an enchanted outline.
- Server list: server icons, latency bars, search, quick connect on the Dashboard.
- Export chat through the share sheet.
- Smoother screen transitions and animations; faster chat updates.
- "Coming soon" cards for Microsoft account and Account ID login.
- Ownership notice, LICENSE and third-party notices added. App renamed to MineChat.

## 0.2.0
- Rename to MineChat, inventory with click, shift-click and drop.

## 0.1.0
- First version: status ping, offline-mode login, chat, player list, movement.
