# MineChat 1.2.0

Created by **SAROJGMG (Prajwal)**. Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See `LICENSE`.

A Minecraft Java client for Android. The Minecraft protocol, networking, login, chat and
inventory logic are written in **Rust** (`rust/`). The UI is **Kotlin + Jetpack Compose +
Material 3** (`app/`), connected to Rust through JNI.

## Build the APK with GitHub Actions (works from a phone)

1. Create a GitHub repository. Upload `MineChat.zip` to the repository root (do not unzip it).
2. Add `.github/workflows/build.yml` (the file that came with this zip's download).
3. Open **Actions**; the build starts on every push. When it is green:
   - open **Releases** and tap **MineChat-v1.2.0.apk** under *Assets*, or
   - open the run page and tap the APK under *Artifacts*.
4. Install the APK (allow "Install unknown apps" for your browser).

## Features

- Server list with icons, MOTD, player counts, latency bars, search, favorites, quick connect.
- Offline-mode login (`online-mode=false`), compression, keep-alive, auto-reconnect.
- Live chat with colours, commands, quick-command buttons, Tab button (command list and completions).
- Inventory and server menus (/shop style): click, right-click, shift-click, drop, hotbar select,
  custom item names and lore.
- Player list, basic movement, background connection, chat export.
- Item textures from your own Minecraft files (downloaded from Mojang or imported), no textures bundled.
- Map tab: world map around you, in-game map items, waypoints. Chat search, tap a player to /msg them.
- Light and dark themes.

## Coming soon

- Microsoft account login and online-mode servers; Account ID login.
- 3D world view.

## Honest status

- The Rust engine passes 33 tests (unit tests plus end-to-end tests against a mock server written
  from the protocol spec).
- The Kotlin app is compiled only by your GitHub build; small fixes may be needed.
- Nothing has been verified against real Paper, Purpur or Spigot servers yet.
- Protocol 763 (Minecraft 1.20.1) only; newer servers need ViaVersion.
- Offline-mode names are not authenticated Microsoft accounts.

## Build locally

```
cargo install cargo-ndk
rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android
cd rust && cargo ndk -t arm64-v8a -t armeabi-v7a -t x86_64 -o ../app/src/main/jniLibs build --release
cd .. && gradle assembleDebug
```
Requires JDK 17, Android SDK 34, NDK 26. Run the Rust tests with `cd rust && cargo test`.

## Licence

Proprietary. See `LICENSE` and `THIRD_PARTY_NOTICES.md`. MineChat is not affiliated with Mojang
Studios or Microsoft. Minecraft is a trademark of Mojang Synergies AB.
