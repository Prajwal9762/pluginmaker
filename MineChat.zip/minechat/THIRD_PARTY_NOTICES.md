# Third-party notices

MineChat is Copyright (c) 2026 SAROJGMG (Prajwal). The components below are used under
their own licences, which remain with their respective authors.

| Component | Licence |
|---|---|
| tokio | MIT |
| serde, serde_json | MIT or Apache-2.0 |
| flate2 (miniz_oxide backend) | MIT or Apache-2.0 |
| md5 | MIT or Apache-2.0 |
| jni (Rust crate) | MIT or Apache-2.0 |
| AndroidX, Jetpack Compose, Material 3, Kotlin standard library | Apache-2.0 |
| Item names for Minecraft 1.20.1 (`rust/src/items.rs`, `rust/src/blocks.rs` and `rust/src/entities.rs`), derived from PrismarineJS/minecraft-data | MIT |

The MIT licence for minecraft-data requires this notice: Copyright (c) PrismarineJS contributors.
Permission is granted, free of charge, to use, copy, modify, merge, publish, distribute,
sublicense and/or sell copies of that data, provided the copyright and permission notice are
included in copies or substantial portions of it. The data is provided "as is" without warranty.

"Minecraft" is a trademark of Mojang Synergies AB. MineChat contains no Minecraft game code,
textures or sounds.
