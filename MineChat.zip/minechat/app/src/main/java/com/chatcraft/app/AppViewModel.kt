// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
package com.chatcraft.app

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val db = Db(app)
    private val sp = app.getSharedPreferences("chatcraft", Context.MODE_PRIVATE)

    // ---- navigation -------------------------------------------------------------------------
    val stack = mutableStateListOf<Screen>(Screen.Dashboard)
    val current: Screen get() = stack.last()

    fun go(s: Screen) { stack.add(s) }
    fun replaceTop(s: Screen) { stack[stack.size - 1] = s }
    fun resetTo(s: Screen) { stack.clear(); stack.add(s) }

    fun back() {
        when (current) {
            Screen.Connecting -> { stopSession(); }
            else -> {}
        }
        if (stack.size > 1) stack.removeAt(stack.size - 1)
    }

    // ---- settings ---------------------------------------------------------------------------
    var themeMode by mutableStateOf(sp.getString("theme", "system") ?: "system"); private set
    var showTimestamps by mutableStateOf(sp.getBoolean("timestamps", true)); private set
    var autoReconnect by mutableStateOf(sp.getBoolean("autoreconnect", true)); private set
    var defaultUsername by mutableStateOf(sp.getString("username", "") ?: ""); private set

    fun setTheme(v: String) { themeMode = v; sp.edit().putString("theme", v).apply() }
    fun setTimestamps(v: Boolean) { showTimestamps = v; sp.edit().putBoolean("timestamps", v).apply() }
    fun updateAutoReconnect(v: Boolean) { autoReconnect = v; sp.edit().putBoolean("autoreconnect", v).apply() }
    fun updateDefaultUsername(v: String) { defaultUsername = v; sp.edit().putString("username", v).apply() }

    fun clearHistory() {
        viewModelScope.launch(Dispatchers.IO) { db.clearHistory() }
        chat.clear()
    }

    // ---- servers ----------------------------------------------------------------------------
    var servers by mutableStateOf(db.servers()); private set
    val statuses = mutableStateMapOf<Long, StatusResult>()
    var refreshing by mutableStateOf(false); private set

    fun serverById(id: Long): Server? = servers.firstOrNull { it.id == id }

    fun saveServer(s: Server) {
        val id = db.save(s)
        servers = db.servers()
        refreshStatus(serverById(id))
    }

    fun deleteServer(id: Long) {
        db.delete(id)
        statuses.remove(id)
        servers = db.servers()
    }

    fun toggleFavorite(s: Server) {
        db.save(s.copy(favorite = !s.favorite))
        servers = db.servers()
    }

    fun refreshStatuses() {
        viewModelScope.launch {
            refreshing = true
            val jobs = servers.map { s -> async { s.id to pingServer(s) } }
            for ((id, r) in jobs.awaitAll()) statuses[id] = r
            refreshing = false
        }
    }

    private fun refreshStatus(s: Server?) {
        if (s == null) return
        viewModelScope.launch { statuses[s.id] = pingServer(s) }
    }

    private suspend fun pingServer(s: Server): StatusResult = withContext(Dispatchers.IO) {
        try {
            val o = JSONObject(Native.ping(s.host, s.port, 5000))
            if (o.optBoolean("ok")) {
                val i = o.getJSONObject("info")
                StatusResult(
                    ok = true,
                    versionName = i.optString("version_name"),
                    protocol = i.optInt("protocol"),
                    online = i.optInt("players_online"),
                    max = i.optInt("players_max"),
                    motd = i.optString("motd"),
                    latencyMs = i.optLong("latency_ms"),
                    exactProtocol = i.optBoolean("exact_protocol_match"),
                    favicon = if (i.isNull("favicon")) "" else i.optString("favicon"),
                )
            } else {
                StatusResult(ok = false, error = o.optString("error", "unknown error"))
            }
        } catch (e: Throwable) {
            StatusResult(ok = false, error = e.message ?: "ping failed")
        }
    }

    // ---- live session -----------------------------------------------------------------------
    var sessionId by mutableStateOf(-1L); private set
    var activeServer by mutableStateOf<Server?>(null); private set
    var connState by mutableStateOf("idle"); private set
    var connDetail by mutableStateOf(""); private set
    var maxPlayers by mutableStateOf(-1); private set
    var sessionInfo by mutableStateOf<SessionInfo?>(null); private set
    var stats by mutableStateOf(SessionStats()); private set
    var inventory by mutableStateOf<InventoryUi?>(null); private set
    val chat = mutableStateListOf<ChatLine>()
    val players = mutableStateListOf<PlayerRow>()
    val activity = mutableStateListOf<String>()
    private var pollJob: Job? = null

    val sessionActive: Boolean get() = sessionId > 0

    fun startSession(server: Server, username: String) {
        stopSession()
        val s = server.copy(username = username, auth = "offline")
        db.save(s)
        db.touch(s.id)
        servers = db.servers()
        updateDefaultUsername(username)
        activeServer = s
        chat.clear(); players.clear(); activity.clear(); dismissCompletions()
        inventory = null
        maxPlayers = -1; sessionInfo = null; stats = SessionStats()
        val old = db.history(s.id, 200)
        if (old.isNotEmpty()) {
            chat.addAll(old)
            chat.add(ChatLine(System.currentTimeMillis(), "system", "", "\u00A78\u2014 new session \u2014"))
        }
        connState = "connecting"; connDetail = "${s.host}:${s.port}"
        val id = Native.connect(s.host, s.port, username, "offline", autoReconnect)
        sessionId = id
        if (stack.lastOrNull() != Screen.Connecting) {
            // keep Dashboard at the bottom of the stack so Back always has somewhere to go
            resetTo(Screen.Dashboard)
            go(Screen.Connecting)
        }
        val app = getApplication<Application>()
        val svc = Intent(app, ConnectionService::class.java)
            .putExtra(ConnectionService.EXTRA_TEXT, "Connected to ${s.name}")
        try { ContextCompat.startForegroundService(app, svc) } catch (e: Exception) { /* background start not allowed */ }
        startPolling(id, s.id)
    }

    fun reconnect() {
        val s = activeServer ?: return
        startSession(s, s.username)
    }

    fun stopSession() {
        pollJob?.cancel()
        pollJob = null
        if (sessionId > 0) Native.disconnect(sessionId)
        sessionId = -1
        connState = "idle"
        val app = getApplication<Application>()
        app.stopService(Intent(app, ConnectionService::class.java))
    }

    fun disconnectAndLeave() {
        stopSession()
        resetTo(Screen.Dashboard)
    }

    private fun startPolling(id: Long, serverId: Long) {
        pollJob = viewModelScope.launch {
            while (isActive) {
                val json = withContext(Dispatchers.IO) { Native.poll(id) }
                val terminal = applyPoll(json, serverId)
                if (terminal) break
                delay(120)
            }
        }
    }

    /** Applies one poll result; returns true when the session reached a terminal state. */
    private fun applyPoll(json: String, serverId: Long): Boolean {
        val o = try { JSONObject(json) } catch (e: Exception) { return true }
        if (o.has("ok") && !o.optBoolean("ok", true)) {
            connState = "error"; connDetail = o.optString("error")
            return true
        }
        val newLines = ArrayList<ChatLine>()
        val evs = o.optJSONArray("events")
        if (evs != null) {
            for (i in 0 until evs.length()) {
                val e = evs.getJSONObject(i)
                when (e.optString("type")) {
                    "chat" -> {
                        val line = ChatLine(e.optLong("ts"), e.optString("kind"), e.optString("sender"), e.optString("text"))
                        chat.add(line)
                        newLines.add(line)
                        while (chat.size > 3000) chat.removeAt(0)
                    }
                    "players" -> {
                        players.clear()
                        val arr = e.getJSONArray("players")
                        for (k in 0 until arr.length()) {
                            val p = arr.getJSONObject(k)
                            players.add(PlayerRow(p.optString("uuid"), p.optString("name"), p.optInt("latency")))
                        }
                        maxPlayers = e.optInt("max_players", -1)
                    }
                    "completions" -> {
                        if (e.optInt("tx") == pendingTx) {
                            val arr = e.getJSONArray("matches")
                            val list = ArrayList<String>(arr.length())
                            for (k in 0 until arr.length()) list.add(arr.getString(k))
                            completions = CompletionsUi(pendingTx, e.optInt("start"), e.optInt("length"), list)
                            completionsLoading = false
                        }
                    }
                    "info" -> sessionInfo = SessionInfo(
                        e.optString("uuid"), e.optString("username"), e.optInt("entity_id"), e.optInt("game_mode")
                    )
                    "presence" -> {
                        val verb = if (e.optBoolean("joined")) "joined" else "left"
                        activity.add(0, "${e.optString("name")} $verb")
                        while (activity.size > 50) activity.removeAt(activity.size - 1)
                    }
                }
            }
        }
        val st = o.optString("state")
        connState = st
        connDetail = o.optString("detail")
        val s = o.optJSONObject("stats")
        if (s != null) {
            stats = SessionStats(
                bytesIn = s.optLong("bytes_in"), bytesOut = s.optLong("bytes_out"),
                packetsIn = s.optLong("packets_in"), uptimeMs = s.optLong("uptime_ms"),
                reconnects = s.optInt("reconnects"), latencyMs = s.optInt("latency_ms", -1),
                x = s.optDouble("x"), y = s.optDouble("y"), z = s.optDouble("z"),
            )
        }
        val invJson = o.optJSONObject("inventory")
        if (invJson != null) {
            val arr = invJson.getJSONArray("slots")
            val slots = ArrayList<ItemStackUi?>(arr.length())
            for (k in 0 until arr.length()) {
                slots.add(if (arr.isNull(k)) null else parseItem(arr.getJSONObject(k)))
            }
            val newWindow = invJson.optInt("window_id")
            val guiOpened = newWindow != 0 && (inventory?.windowId ?: 0) == 0
            inventory = InventoryUi(
                windowId = invJson.optInt("window_id"),
                title = invJson.optString("title"),
                kind = invJson.optInt("kind"),
                slots = slots,
                cursor = parseItem(invJson.optJSONObject("cursor")),
                held = invJson.optInt("held"),
            )
            if (guiOpened && (current == Screen.Chat || current == Screen.Players || current == Screen.Info)) {
                replaceTop(Screen.Inventory)
            }
        }
        if (newLines.isNotEmpty()) {
            viewModelScope.launch(Dispatchers.IO) { db.addChats(serverId, newLines) }
        }
        if (st == "play" && current == Screen.Connecting) replaceTop(Screen.Chat)
        if (st == "error" || st == "disconnected") {
            val app = getApplication<Application>()
            app.stopService(Intent(app, ConnectionService::class.java))
            return true
        }
        return false
    }

    fun sendChat(text: String) {
        val id = sessionId
        if (id <= 0 || text.isBlank()) return
        sentHistory.remove(text)
        sentHistory.add(0, text)
        while (sentHistory.size > 30) sentHistory.removeAt(sentHistory.size - 1)
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) { Native.sendChat(id, text) }
            if (err.isNotEmpty()) {
                chat.add(ChatLine(System.currentTimeMillis(), "system", "", "\u00A7c$err"))
            }
        }
    }

    private fun parseItem(o: JSONObject?): ItemStackUi? =
        if (o == null) null else {
            val lore = ArrayList<String>()
            val arr = o.optJSONArray("lore")
            if (arr != null) for (k in 0 until arr.length()) lore.add(arr.optString(k))
            ItemStackUi(
                id = o.optInt("id"),
                name = o.optString("name"),
                count = o.optInt("count"),
                customName = if (o.isNull("custom_name")) null else o.optString("custom_name"),
                lore = lore,
                enchanted = o.optBoolean("enchanted"),
            )
        }

    private fun reportError(err: String) {
        if (err.isNotEmpty()) chat.add(ChatLine(System.currentTimeMillis(), "system", "", "\u00A7c$err"))
    }

    /** mode: 0 click, 1 shift-click, 4 drop. Slot -999 with mode 0 drops the held item. */
    fun clickSlot(slot: Int, button: Int, mode: Int) {
        val id = sessionId
        val inv = inventory ?: return
        if (id <= 0) return
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) { Native.click(id, inv.windowId, slot, button, mode) }
            reportError(err)
        }
    }

    fun closeContainer() {
        val id = sessionId
        val inv = inventory ?: return
        if (id <= 0) return
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) { Native.closeWindow(id, inv.windowId) }
            reportError(err)
        }
    }

    fun holdSlot(hotbarIndex: Int) {
        val id = sessionId
        if (id <= 0) return
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) { Native.hold(id, hotbarIndex) }
            reportError(err)
        }
    }

    fun move(dx: Double, dy: Double, dz: Double) {
        val id = sessionId
        if (id <= 0) return
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) { Native.move(id, dx, dy, dz) }
            if (err.isNotEmpty()) {
                chat.add(ChatLine(System.currentTimeMillis(), "system", "", "\u00A7c$err"))
            }
        }
    }

    // ---- tab completion / command list -------------------------------------------------------
    var completions by mutableStateOf<CompletionsUi?>(null); private set
    var completionsLoading by mutableStateOf(false); private set
    private var pendingTx = -1
    val sentHistory = mutableStateListOf<String>()

    /** Asks the server for completions of [text] (use "/" to list the commands you may run). */
    fun requestCompletions(text: String) {
        val id = sessionId
        if (id <= 0) return
        completions = null
        completionsLoading = true
        viewModelScope.launch {
            val res = withContext(Dispatchers.IO) { Native.complete(id, text) }
            try {
                val o = JSONObject(res)
                if (o.optBoolean("ok")) {
                    pendingTx = o.optInt("tx")
                } else {
                    completionsLoading = false
                    reportError(o.optString("error"))
                }
            } catch (e: Exception) {
                completionsLoading = false
            }
        }
    }

    fun dismissCompletions() {
        completions = null
        completionsLoading = false
        pendingTx = -1
    }

    // ---- quick commands, quick connect, export ------------------------------------------------
    var quickCommands by mutableStateOf(sp.getString("quickcmds", "/help,/spawn,/home,/shop") ?: ""); private set

    fun updateQuickCommands(v: String) {
        quickCommands = v
        sp.edit().putString("quickcmds", v).apply()
    }

    val quickList: List<String>
        get() = quickCommands.split(',').map { it.trim() }.filter { it.isNotEmpty() }

    /** Connects to "host" or "host:port" using offline mode. Returns an error message or null. */
    fun quickConnect(hostPort: String, username: String): String? {
        val hp = hostPort.trim()
        if (hp.isEmpty() || hp.contains(' ')) return "Enter a server address like play.example.com or 1.2.3.4:25565"
        val idx = hp.lastIndexOf(':')
        val host = if (idx > 0) hp.substring(0, idx) else hp
        val port = if (idx > 0) hp.substring(idx + 1).toIntOrNull() else 25565
        if (port == null || port !in 1..65535) return "Port must be a number from 1 to 65535"
        if (!Regex("^[A-Za-z0-9_]{3,16}$").matches(username)) return "Username must be 3-16 letters, digits or underscore"
        val existing = servers.firstOrNull { it.host.equals(host, true) && it.port == port }
        val server = existing ?: run {
            val id = db.save(Server(name = host, host = host, port = port, username = username))
            servers = db.servers()
            serverById(id)
        }
        if (server == null) return "Could not save the server"
        startSession(server, username)
        return null
    }

    fun chatAsText(): String {
        val fmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        return chat.joinToString("\n") { l ->
            val who = if (l.kind == "player" && l.sender.isNotEmpty()) "<${l.sender}> " else ""
            "[" + fmt.format(java.util.Date(l.ts)) + "] " + who + stripCodes(l.text)
        }
    }

    override fun onCleared() {
        if (sessionId > 0) Native.disconnect(sessionId)
        super.onCleared()
    }
}
