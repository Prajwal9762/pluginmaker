// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
package com.chatcraft.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Local persistence (SQLite): saved servers and per-server chat history. */
class Db(context: Context) : SQLiteOpenHelper(context, "chatcraft.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE servers (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, host TEXT NOT NULL, port INTEGER NOT NULL, " +
                "username TEXT NOT NULL, auth TEXT NOT NULL, " +
                "favorite INTEGER NOT NULL DEFAULT 0, last_connected INTEGER NOT NULL DEFAULT 0, " +
                "join_commands TEXT NOT NULL DEFAULT '')"
        )
        db.execSQL(
            "CREATE TABLE history (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, server_id INTEGER NOT NULL, " +
                "ts INTEGER NOT NULL, kind TEXT NOT NULL, sender TEXT NOT NULL, text TEXT NOT NULL)"
        )
        db.execSQL("CREATE INDEX idx_history_server ON history(server_id, id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE servers ADD COLUMN join_commands TEXT NOT NULL DEFAULT ''")
        }
    }

    fun servers(): List<Server> {
        val out = ArrayList<Server>()
        readableDatabase.rawQuery(
            "SELECT id, name, host, port, username, auth, favorite, last_connected, join_commands " +
                "FROM servers ORDER BY favorite DESC, name COLLATE NOCASE",
            null
        ).use { c ->
            while (c.moveToNext()) {
                out.add(
                    Server(
                        id = c.getLong(0),
                        name = c.getString(1),
                        host = c.getString(2),
                        port = c.getInt(3),
                        username = c.getString(4),
                        auth = c.getString(5),
                        favorite = c.getInt(6) != 0,
                        lastConnected = c.getLong(7),
                        joinCommands = c.getString(8) ?: "",
                    )
                )
            }
        }
        return out
    }

    /** Inserts when [Server.id] is 0, otherwise updates. Returns the row id. */
    fun save(s: Server): Long {
        val cv = ContentValues().apply {
            put("name", s.name)
            put("host", s.host)
            put("port", s.port)
            put("username", s.username)
            put("auth", s.auth)
            put("favorite", if (s.favorite) 1 else 0)
            put("last_connected", s.lastConnected)
            put("join_commands", s.joinCommands)
        }
        return if (s.id == 0L) {
            writableDatabase.insert("servers", null, cv)
        } else {
            writableDatabase.update("servers", cv, "id = ?", arrayOf(s.id.toString()))
            s.id
        }
    }

    fun delete(id: Long) {
        writableDatabase.delete("servers", "id = ?", arrayOf(id.toString()))
        writableDatabase.delete("history", "server_id = ?", arrayOf(id.toString()))
    }

    fun touch(id: Long) {
        val cv = ContentValues().apply { put("last_connected", System.currentTimeMillis()) }
        writableDatabase.update("servers", cv, "id = ?", arrayOf(id.toString()))
    }

    fun addChats(serverId: Long, lines: List<ChatLine>) {
        if (lines.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (l in lines) {
                val cv = ContentValues().apply {
                    put("server_id", serverId)
                    put("ts", l.ts)
                    put("kind", l.kind)
                    put("sender", l.sender)
                    put("text", l.text)
                }
                db.insert("history", null, cv)
            }
            // Keep at most 2000 lines per server.
            db.execSQL(
                "DELETE FROM history WHERE server_id = ? AND id NOT IN " +
                    "(SELECT id FROM history WHERE server_id = ? ORDER BY id DESC LIMIT 2000)",
                arrayOf<Any>(serverId, serverId)
            )
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun history(serverId: Long, limit: Int): List<ChatLine> {
        val out = ArrayList<ChatLine>()
        readableDatabase.rawQuery(
            "SELECT ts, kind, sender, text FROM history WHERE server_id = ? ORDER BY id DESC LIMIT ?",
            arrayOf(serverId.toString(), limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out.add(ChatLine(c.getLong(0), c.getString(1), c.getString(2), c.getString(3)))
            }
        }
        out.reverse()
        return out
    }

    fun clearHistory() {
        writableDatabase.delete("history", null, null)
    }
}
