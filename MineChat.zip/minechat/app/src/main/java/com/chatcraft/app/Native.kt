// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
package com.chatcraft.app

/** JNI bridge to the Rust engine (rust/src/ffi.rs). All calls are fast except [ping], which blocks. */
object Native {
    init {
        System.loadLibrary("chatcraft_core")
    }

    external fun ping(host: String, port: Int, timeoutMs: Int): String
    external fun connect(host: String, port: Int, username: String, authMode: String, autoReconnect: Boolean): Long
    external fun poll(id: Long): String
    external fun sendChat(id: Long, text: String): String
    external fun click(id: Long, windowId: Int, slot: Int, button: Int, mode: Int): String
    external fun closeWindow(id: Long, windowId: Int): String
    external fun hold(id: Long, slot: Int): String
    external fun complete(id: Long, text: String): String
    external fun move(id: Long, dx: Double, dy: Double, dz: Double): String
    external fun disconnect(id: Long)
    external fun version(): String
}
