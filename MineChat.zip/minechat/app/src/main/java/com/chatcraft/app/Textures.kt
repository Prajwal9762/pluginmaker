// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
package com.chatcraft.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipFile

/**
 * Item textures come from a resource pack or the Minecraft client jar that the user imports or
 * downloads from Mojang onto their own device. MineChat does not contain or redistribute them.
 */
object TextureStore {
    /** Changes whenever the texture source changes, so composables refresh. */
    var version by mutableStateOf(0)
        private set

    private var file: File? = null
    private var zip: ZipFile? = null
    private val cache = HashMap<String, ImageBitmap?>()

    val available: Boolean get() = zip != null

    fun init(context: Context) {
        if (file == null) {
            file = File(context.filesDir, "textures.zip")
            reopen()
        }
    }

    private fun reopen() {
        try { zip?.close() } catch (e: Exception) { /* ignore */ }
        zip = null
        cache.clear()
        val f = file
        if (f != null && f.exists()) {
            zip = try { ZipFile(f) } catch (e: Exception) { null }
        }
        version++
    }

    /** Copies [input] to the texture file and checks that it really contains item textures. */
    fun install(input: InputStream): Boolean {
        val dest = file ?: return false
        val tmp = File(dest.parentFile, "textures.tmp")
        try {
            input.use { src -> tmp.outputStream().use { out -> src.copyTo(out) } }
            val ok = try {
                ZipFile(tmp).use { z -> z.getEntry("assets/minecraft/textures/item/apple.png") != null }
            } catch (e: Exception) {
                false
            }
            if (!ok) {
                tmp.delete()
                return false
            }
            try { zip?.close() } catch (e: Exception) { /* ignore */ }
            zip = null
            dest.delete()
            tmp.renameTo(dest)
        } catch (e: Exception) {
            tmp.delete()
            return false
        }
        reopen()
        return true
    }

    fun remove() {
        file?.delete()
        reopen()
    }

    private fun candidates(name: String): List<String> {
        val b = "assets/minecraft/textures/"
        return listOf(
            "${b}item/$name.png",
            "${b}block/$name.png",
            "${b}item/${name}_00.png",
            "${b}block/${name}_side.png",
            "${b}block/${name}_front.png",
            "${b}block/${name}_top.png",
            "${b}block/${name}_0.png",
        )
    }

    /** Returns the texture for an item name such as "diamond_sword", or null when unavailable. */
    fun forItem(name: String): ImageBitmap? {
        val z = zip ?: return null
        if (cache.containsKey(name)) return cache[name]
        var result: ImageBitmap? = null
        for (path in candidates(name)) {
            val entry = z.getEntry(path) ?: continue
            try {
                val bmp = z.getInputStream(entry).use { BitmapFactory.decodeStream(it) } ?: continue
                // animated textures are vertical strips of square frames: keep the first frame
                val square = if (bmp.height > bmp.width) Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.width) else bmp
                result = square.asImageBitmap()
                break
            } catch (e: Exception) {
                // try the next candidate
            }
        }
        cache[name] = result
        return result
    }
}

object TextureDownloader {
    private fun fetchText(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Downloads the official client jar for [version] from Mojang's servers into [dest]. */
    fun download(dest: File, version: String, onProgress: (String) -> Unit) {
        onProgress("Contacting Mojang\u2026")
        val manifest = JSONObject(fetchText("https://launchermeta.mojang.com/mc/game/version_manifest_v2.json"))
        val versions = manifest.getJSONArray("versions")
        var versionUrl: String? = null
        for (i in 0 until versions.length()) {
            val v = versions.getJSONObject(i)
            if (v.optString("id") == version) {
                versionUrl = v.optString("url")
                break
            }
        }
        if (versionUrl == null) throw IllegalStateException("Version $version not found")
        val client = JSONObject(fetchText(versionUrl)).getJSONObject("downloads").getJSONObject("client")
        val jarUrl = client.getString("url")
        val total = client.optLong("size", 0)
        val c = URL(jarUrl).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        var done = 0L
        var lastPct = -1
        c.inputStream.use { input ->
            dest.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    val pct = if (total > 0) (done * 100 / total).toInt() else 0
                    if (pct != lastPct) {
                        lastPct = pct
                        onProgress("Downloading\u2026 $pct%")
                    }
                }
            }
        }
    }
}
