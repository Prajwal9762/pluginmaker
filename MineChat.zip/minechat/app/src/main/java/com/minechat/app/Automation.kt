// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
package com.minechat.app

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Text typed into the inventory "Find item" box; slots that match are outlined. */
object InvSearch {
    var query by mutableStateOf("")
}

private val EIGHT_POINTS = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")

/** Compass direction for a Minecraft yaw (0 = south, 90 = west, 180 = north, 270 = east). */
fun compassName(yaw: Float): String {
    val compass = (((yaw + 180f) % 360f) + 360f) % 360f
    return EIGHT_POINTS[(((compass + 22.5f) % 360f) / 45f).toInt().coerceIn(0, 7)]
}

/** Compass direction from the player towards an offset (north is negative Z). */
fun bearingName(dx: Double, dz: Double): String {
    val deg = Math.toDegrees(Math.atan2(dx, -dz))
    val compass = ((deg % 360.0) + 360.0) % 360.0
    return EIGHT_POINTS[(((compass + 22.5) % 360.0) / 45.0).toInt().coerceIn(0, 7)]
}

fun matchesSearch(item: ItemStackUi, query: String): Boolean {
    val q = query.trim()
    if (q.isEmpty()) return false
    if (item.name.contains(q.replace(' ', '_'), ignoreCase = true)) return true
    val custom = item.customName
    return custom != null && stripCodes(custom).contains(q, ignoreCase = true)
}

/**
 * Optional helpers that run on top of the connection: smart auto-eat, safety commands, chat rules,
 * scheduled commands, friends and ignore lists. Everything is off unless the user turns it on.
 */
class Automation(
    private val vm: AppViewModel,
    private val sp: SharedPreferences,
    private val scope: CoroutineScope,
) {
    private val defaults = mapOf(
        "eatstart" to "14",
        "gapple" to "0",
        "gapplebelow" to "12",
        "panic" to "0",
        "panichp" to "6",
        "paniccmd" to "/home",
        "vibrate" to "1",
        "reply" to "0",
        "replytext" to "I am away right now, I will answer soon.",
        "triggers" to "",
        "schedule" to "",
        "greet" to "0",
        "greettext" to "Welcome, {name}!",
        "friends" to "",
        "ignored" to "",
        "words" to "",
        "junk" to "rotten_flesh,spider_eye,poisonous_potato",
        "keepon" to "0",
    )
    private val values = mutableStateMapOf<String, String>()

    init {
        for ((k, d) in defaults) values[k] = sp.getString("auto_$k", d) ?: d
    }

    fun text(key: String): String = values[key] ?: defaults[key] ?: ""
    fun flag(key: String): Boolean = text(key) == "1"
    fun num(key: String): Int = text(key).toIntOrNull() ?: (defaults[key]?.toIntOrNull() ?: 0)

    fun setText(key: String, value: String) {
        values[key] = value
        sp.edit().putString("auto_$key", value).apply()
    }

    fun setFlag(key: String, value: Boolean) = setText(key, if (value) "1" else "0")

    fun list(key: String): List<String> = text(key).split(',').map { it.trim() }.filter { it.isNotEmpty() }

    fun inList(key: String, name: String): Boolean = list(key).any { it.equals(name, ignoreCase = true) }

    fun addToList(key: String, name: String) {
        if (!inList(key, name)) setText(key, (list(key) + name).joinToString(","))
    }

    fun removeFromList(key: String, name: String) {
        setText(key, list(key).filter { !it.equals(name, ignoreCase = true) }.joinToString(","))
    }

    private val lastFired = HashMap<String, Long>()

    private fun cooldown(key: String, ms: Long): Boolean {
        val now = System.currentTimeMillis()
        if (now - (lastFired[key] ?: 0L) < ms) return false
        lastFired[key] = now
        return true
    }

    // ---- chat rules ---------------------------------------------------------------------------------

    private fun me(): String? = vm.sessionInfo?.username ?: vm.activeServer?.username

    /** True when the line should be hidden (ignored player or filtered word). */
    fun isIgnored(line: ChatLine): Boolean {
        val ignored = list("ignored")
        val words = list("words")
        if (ignored.isEmpty() && words.isEmpty()) return false
        val plain = stripCodes(line.text)
        for (n in ignored) {
            if (line.sender.equals(n, ignoreCase = true)) return true
            if (plain.startsWith("<$n>", ignoreCase = true)) return true
            if (plain.contains("$n whispers", ignoreCase = true)) return true
        }
        for (w in words) if (plain.contains(w, ignoreCase = true)) return true
        return false
    }

    /** True when the line mentions you or a friend (shown with a highlight). */
    fun isMention(line: ChatLine): Boolean {
        val name = me() ?: return false
        if (line.sender.equals(name, ignoreCase = true)) return false
        val plain = stripCodes(line.text)
        if (plain.contains(name, ignoreCase = true)) return true
        for (f in list("friends")) if (line.sender.equals(f, ignoreCase = true)) return true
        return false
    }

    private val whisperPattern = Regex("""^\W*(\w{3,16})\s*(?:whispers to you|whispers:|->\s*me|\u2192\s*me)""", RegexOption.IGNORE_CASE)

    fun onChat(line: ChatLine) {
        val name = me() ?: return
        if (line.sender.equals(name, ignoreCase = true)) return
        val plain = stripCodes(line.text)
        if (flag("reply")) {
            val m = whisperPattern.find(plain)
            if (m != null) {
                val who = m.groupValues[1]
                if (!who.equals(name, ignoreCase = true) && cooldown("reply:$who", 30_000)) {
                    vm.sendChat("/msg " + who + " " + text("replytext"), remember = false)
                }
            }
        }
        for (rule in text("triggers").lines()) {
            val parts = rule.split("=>")
            if (parts.size != 2) continue
            val key = parts[0].trim()
            val response = parts[1].trim()
            if (key.isEmpty() || response.isEmpty()) continue
            if (plain.contains(key, ignoreCase = true) && cooldown("trigger:$key", 10_000)) {
                vm.sendChat(response, remember = false)
            }
        }
    }

    fun onPresence(name: String, joined: Boolean) {
        if (!joined) return
        if (flag("greet") && cooldown("greet:$name", 60_000)) {
            vm.sendChat(text("greettext").replace("{name}", name), remember = false)
        }
        if (inList("friends", name)) {
            vm.showNotice("Friend online: $name", "info")
            vm.postAlert("Friend online", "$name joined the server")
        }
    }

    // ---- scheduled commands ------------------------------------------------------------------------

    private val scheduleJobs = ArrayList<Job>()

    /** Lines look like "10 | /daily": run the command every 10 minutes while connected. */
    fun startSchedules() {
        stopSchedules()
        val id = vm.sessionId
        if (id <= 0) return
        for (line in text("schedule").lines()) {
            val parts = line.split("|")
            val minutes = parts.getOrNull(0)?.trim()?.toIntOrNull() ?: continue
            val command = parts.getOrNull(1)?.trim() ?: ""
            if (minutes < 1 || command.isEmpty()) continue
            scheduleJobs.add(
                scope.launch {
                    while (isActive && vm.sessionId == id) {
                        delay(minutes * 60_000L)
                        if (vm.connState == "play") vm.sendChat(command, remember = false)
                    }
                }
            )
        }
    }

    fun stopSchedules() {
        for (j in scheduleJobs) j.cancel()
        scheduleJobs.clear()
    }

    // ---- health: safety and extras -----------------------------------------------------------------

    fun onVitalsExtras(old: VitalsUi, v: VitalsUi) {
        if (old.health < 0f) return
        if (v.health < old.health && flag("vibrate")) vm.vibrate(if (v.health <= 6f) 250L else 80L)
        val limit = num("panichp").toFloat()
        if (flag("panic") && v.health > 0f && v.health <= limit && old.health > limit && cooldown("panic", 60_000)) {
            vm.sendChat(text("paniccmd"), remember = false)
            vm.showNotice("Low health: sent " + text("paniccmd"), "health")
        }
        if (v.health <= 0f && old.health > 0f) {
            val stamp = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            vm.addWaypoint("Death $stamp")
            vm.showNotice("Death point saved in your waypoints", "health")
        }
    }

    // ---- smart auto-eat ----------------------------------------------------------------------------

    private val foodValue = mapOf(
        "rabbit_stew" to 10, "cooked_beef" to 8, "cooked_porkchop" to 8, "pumpkin_pie" to 8,
        "cooked_mutton" to 6, "cooked_chicken" to 6, "cooked_salmon" to 6, "golden_carrot" to 6,
        "mushroom_stew" to 6, "beetroot_soup" to 6, "cooked_rabbit" to 5, "cooked_cod" to 5,
        "bread" to 5, "baked_potato" to 5, "apple" to 4, "carrot" to 3, "beef" to 3, "porkchop" to 3,
        "melon_slice" to 2, "sweet_berries" to 2, "glow_berries" to 2, "cookie" to 2, "mutton" to 2,
        "cod" to 2, "salmon" to 2, "dried_kelp" to 1, "beetroot" to 1,
    )

    private var eating = false
    private var eatJob: Job? = null
    private var noFoodUntil = 0L

    /** Picks the inventory slot to eat from: least waste for the missing hunger, hotbar first. */
    private fun pickFood(inv: InventoryUi, deficit: Int, goldenOnly: Boolean): Int? {
        var best: Int? = null
        var bestScore = Int.MAX_VALUE
        val order = (36..44).toList() + (9..35).toList()
        for (slot in order) {
            val stack = inv.slots.getOrNull(slot) ?: continue
            val raw: Int
            if (goldenOnly) {
                raw = when (stack.name) {
                    "golden_apple" -> 1
                    "enchanted_golden_apple" -> 2
                    else -> continue
                }
            } else {
                val value = foodValue[stack.name] ?: continue
                raw = if (value >= deficit) value - deficit else 100 + (deficit - value)
            }
            val score = raw * 2 + (if (slot >= 36) 0 else 1)
            if (score < bestScore) {
                bestScore = score
                best = slot
            }
        }
        return best
    }

    fun onVitals(v: VitalsUi) {
        if (!vm.autoEat || eating || v.food < 0) return
        if (System.currentTimeMillis() < noFoodUntil) return
        val hungry = v.food < 20 && (v.food <= num("eatstart") || v.health < 20f)
        val heal = flag("gapple") && v.health > 0f && v.health <= num("gapplebelow").toFloat()
        if (hungry || heal) startEating()
    }

    /** Eats repeatedly until food is full (and, with golden apples enabled, until health is restored). */
    private fun startEating() {
        if (eating) return
        eating = true
        val id = vm.sessionId
        eatJob = scope.launch {
            var eaten = 0
            var swapped: Pair<Int, Int>? = null
            var fails = 0
            var foundAny = false
            try {
                while (isActive && vm.sessionId == id && vm.connState == "play") {
                    val v = vm.vitals
                    val inv = vm.inventory
                    if (inv == null || inv.windowId != 0 || v.food < 0) break
                    val wantFood = v.food < 20
                    val wantGolden = !wantFood && flag("gapple") && v.health > 0f &&
                        v.health <= num("gapplebelow").toFloat()
                    if (!wantFood && !wantGolden) break
                    val slot = pickFood(inv, 20 - v.food, !wantFood)
                    if (slot == null) break
                    foundAny = true
                    if (slot in 9..35) {
                        // food is in the main inventory: swap it into the selected hotbar slot
                        val hotbar = inv.held.coerceIn(0, 8)
                        withContext(Dispatchers.IO) { Native.click(id, 0, slot, hotbar, 2) }
                        if (swapped == null) swapped = Pair(slot, hotbar)
                        delay(600)
                        continue
                    }
                    withContext(Dispatchers.IO) { Native.hold(id, slot - 36) }
                    delay(250)
                    val foodBefore = vm.vitals.food
                    val healthBefore = vm.vitals.health
                    withContext(Dispatchers.IO) { Native.useItem(id, 0) }
                    delay(2000)
                    eaten++
                    var waited = 0
                    while (waited < 1500 && vm.vitals.food == foodBefore && vm.vitals.health == healthBefore) {
                        delay(100)
                        waited += 100
                    }
                    if (vm.vitals.food <= foodBefore && vm.vitals.health <= healthBefore) {
                        fails++
                        if (fails >= 2) break
                    } else {
                        fails = 0
                    }
                }
            } finally {
                val back = swapped
                if (back != null) {
                    withContext(NonCancellable + Dispatchers.IO) { Native.click(id, 0, back.first, back.second, 2) }
                }
                eating = false
                if (eaten > 0) vm.showNotice("Auto-eat finished: ate $eaten item(s)", "info")
                if (!foundAny) {
                    noFoodUntil = System.currentTimeMillis() + 30_000
                    vm.showNotice("Auto-eat: no suitable food in your inventory", "hunger")
                }
            }
        }
    }

    // ---- inventory helpers ---------------------------------------------------------------------------

    fun dropJunk() {
        val inv = vm.inventory
        val id = vm.sessionId
        if (inv == null || id <= 0) return
        if (inv.windowId != 0) {
            vm.showNotice("Close the open menu first", "info")
            return
        }
        val junk = list("junk").map { it.lowercase() }.toSet()
        if (junk.isEmpty()) {
            vm.showNotice("Your junk list is empty (Settings > Automation)", "info")
            return
        }
        scope.launch {
            var n = 0
            for (slot in 9..44) {
                val stack = inv.slots.getOrNull(slot) ?: continue
                if (stack.name.lowercase() in junk) {
                    withContext(Dispatchers.IO) { Native.click(id, 0, slot, 1, 4) }
                    n++
                    delay(180)
                }
            }
            vm.showNotice(if (n > 0) "Dropped $n stack(s) of junk" else "No junk found", "info")
        }
    }

    fun reset() {
        eatJob?.cancel()
        eatJob = null
        eating = false
        stopSchedules()
        lastFired.clear()
    }
}
