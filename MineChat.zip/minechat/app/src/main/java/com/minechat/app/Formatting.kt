// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
package com.minechat.app

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle

private val MC_COLORS: Map<Char, Int> = mapOf(
    '0' to 0x000000, '1' to 0x0000AA, '2' to 0x00AA00, '3' to 0x00AAAA,
    '4' to 0xAA0000, '5' to 0xAA00AA, '6' to 0xFFAA00, '7' to 0xAAAAAA,
    '8' to 0x555555, '9' to 0x5555FF, 'a' to 0x55FF55, 'b' to 0x55FFFF,
    'c' to 0xFF5555, 'd' to 0xFF55FF, 'e' to 0xFFFF55, 'f' to 0xFFFFFF,
)

/** Keep Minecraft colours legible on both light and dark backgrounds. */
private fun readable(c: Color, darkTheme: Boolean): Color {
    val l = c.luminance()
    return when {
        darkTheme && l < 0.25f -> lerp(c, Color.White, 0.6f)
        !darkTheme && l > 0.7f -> lerp(c, Color.Black, 0.55f)
        else -> c
    }
}

/** Removes all section-sign formatting codes. */
fun stripCodes(s: String): String {
    val sb = StringBuilder()
    var i = 0
    while (i < s.length) {
        if (s[i] == '\u00A7' && i + 1 < s.length) {
            i += 2
        } else {
            sb.append(s[i])
            i++
        }
    }
    return sb.toString()
}

/** Converts a string with Minecraft section-sign codes (colours, bold, italic, ...) to styled text. */
fun legacyToAnnotated(s: String, darkTheme: Boolean): AnnotatedString {
    val sb = AnnotatedString.Builder()
    var color: Color? = null
    var bold = false
    var italic = false
    var underline = false
    var strike = false
    val buf = StringBuilder()

    fun flush() {
        if (buf.isEmpty()) return
        val deco = ArrayList<TextDecoration>()
        if (underline) deco.add(TextDecoration.Underline)
        if (strike) deco.add(TextDecoration.LineThrough)
        val style = SpanStyle(
            color = color ?: Color.Unspecified,
            fontWeight = if (bold) FontWeight.Bold else null,
            fontStyle = if (italic) FontStyle.Italic else null,
            textDecoration = if (deco.isEmpty()) null else TextDecoration.combine(deco),
        )
        sb.withStyle(style) { append(buf.toString()) }
        buf.setLength(0)
    }

    var i = 0
    while (i < s.length) {
        val ch = s[i]
        if (ch == '\u00A7' && i + 1 < s.length) {
            val code = s[i + 1].lowercaseChar()
            flush()
            when {
                MC_COLORS.containsKey(code) -> {
                    color = readable(Color(0xFF000000.toInt() or MC_COLORS.getValue(code)), darkTheme)
                    bold = false; italic = false; underline = false; strike = false
                }
                code == 'x' -> {
                    val hex = StringBuilder()
                    var j = i + 2
                    var n = 0
                    while (n < 6 && j + 1 < s.length && s[j] == '\u00A7') {
                        hex.append(s[j + 1])
                        j += 2
                        n++
                    }
                    if (hex.length == 6) {
                        try {
                            color = readable(Color(android.graphics.Color.parseColor("#$hex")), darkTheme)
                        } catch (e: IllegalArgumentException) {
                            // ignore malformed colour
                        }
                        bold = false; italic = false; underline = false; strike = false
                        i = j
                        continue
                    }
                }
                code == 'l' -> bold = true
                code == 'm' -> strike = true
                code == 'n' -> underline = true
                code == 'o' -> italic = true
                code == 'r' -> {
                    color = null; bold = false; italic = false; underline = false; strike = false
                }
                // 'k' (obfuscated) and unknown codes are ignored
            }
            i += 2
        } else {
            buf.append(ch)
            i++
        }
    }
    flush()
    return sb.toAnnotatedString()
}
