// Copyright (c) 2026 ZORVI Studios. All rights reserved. See LICENSE.
package com.minechat.app

import android.net.Uri
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

/** The ZORVI Studios opening video. Plays once when the app starts; tap to skip. */
@Composable
fun IntroScreen(onFinished: () -> Unit) {
    var done by remember { mutableStateOf(false) }
    val finish = {
        if (!done) {
            done = true
            onFinished()
        }
    }
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                VideoView(ctx).apply {
                    setVideoURI(Uri.parse("android.resource://" + ctx.packageName + "/" + R.raw.zorvi_intro))
                    setOnPreparedListener { mp ->
                        mp.isLooping = false
                        mp.start()
                    }
                    setOnCompletionListener { finish() }
                    setOnErrorListener { _, _, _ ->
                        finish()
                        true
                    }
                }
            },
        )
        // transparent layer on top so a tap anywhere skips the video
        Box(Modifier.fillMaxSize().clickable { finish() })
        Text(
            "Tap to skip",
            color = Color.White.copy(alpha = 0.45f),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp),
        )
    }
}
