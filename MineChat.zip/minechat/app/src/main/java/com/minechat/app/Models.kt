// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
package com.minechat.app

data class Server(
    val id: Long = 0,
    val name: String,
    val host: String,
    val port: Int = 25565,
    val username: String,
    val auth: String = "offline",
    val favorite: Boolean = false,
    val lastConnected: Long = 0,
    /** Commands run automatically after joining, one per line. {password} is replaced. */
    val joinCommands: String = "",
)

data class ChatLine(
    val ts: Long,
    /** "player" or "system" */
    val kind: String,
    val sender: String,
    /** Text with Minecraft section-sign formatting codes. */
    val text: String,
)

data class PlayerRow(val uuid: String, val name: String, val latency: Int)

data class StatusResult(
    val ok: Boolean,
    val error: String = "",
    val versionName: String = "",
    val protocol: Int = 0,
    val online: Int = 0,
    val max: Int = 0,
    val motd: String = "",
    val latencyMs: Long = 0,
    val exactProtocol: Boolean = false,
    /** data:image/png;base64,... server icon, or empty. */
    val favicon: String = "",
)

data class SessionStats(
    val bytesIn: Long = 0,
    val bytesOut: Long = 0,
    val packetsIn: Long = 0,
    val uptimeMs: Long = 0,
    val reconnects: Int = 0,
    val latencyMs: Int = -1,
    val x: Double = 0.0,
    val y: Double = 0.0,
    val z: Double = 0.0,
    val xpLevel: Int = 0,
    val xpBar: Float = 0f,
    /** Minecraft day time in ticks (24000 per day). */
    val time: Long = 0,
    val rain: Boolean = false,
    val age: Long = 0,
    val yaw: Float = 0f,
    val pitch: Float = 0f,
)

/** Health and food are in half units: 20 = ten hearts / ten drumsticks. -1 = unknown. */
data class VitalsUi(val health: Float = -1f, val food: Int = -1, val saturation: Float = 0f)

data class NoticeUi(val text: String, val kind: String)

data class ItemStackUi(
    val id: Int,
    val name: String,
    val count: Int,
    /** Custom name with section-sign codes (shop and menu items), or null. */
    val customName: String? = null,
    val lore: List<String> = emptyList(),
    val enchanted: Boolean = false,
)

data class BossBarUi(val id: String, val title: String, val health: Float, val color: Int)

data class SidebarUi(val title: String, val lines: List<String>)

data class RadarEntity(val kind: Int, val name: String, val x: Double, val z: Double, val uuid: String)

data class Waypoint(val name: String, val x: Double, val y: Double, val z: Double)

data class MapItemUi(val id: Int, val scale: Int, val locked: Boolean)

data class CompletionsUi(val tx: Int, val start: Int, val length: Int, val matches: List<String>)

data class InventoryUi(
    val windowId: Int,
    val title: String,
    val kind: Int,
    val slots: List<ItemStackUi?>,
    val cursor: ItemStackUi?,
    /** Selected hotbar slot, 0-8. */
    val held: Int,
)

data class SessionInfo(val uuid: String, val username: String, val entityId: Int, val gameMode: Int)

sealed interface Screen {
    object Dashboard : Screen
    object Servers : Screen
    data class AddEdit(val serverId: Long?) : Screen
    data class AuthSelect(val serverId: Long) : Screen
    object Connecting : Screen
    object Chat : Screen
    object Players : Screen
    object Inventory : Screen
    object Info : Screen
    object Automation : Screen
    object Map : Screen
    object Settings : Screen
    object About : Screen
}
