// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
package com.minechat.app

/** JNI bridge to the Rust engine (rust/src/ffi.rs). All calls are fast except [ping], which blocks. */
object Native {
    init {
        System.loadLibrary("minechat_core")
    }

    external fun ping(host: String, port: Int, timeoutMs: Int): String
    external fun connect(
        host: String, port: Int, username: String, authMode: String, autoReconnect: Boolean, viewDistance: Int,
    ): Long
    external fun poll(id: Long): String
    external fun sendChat(id: Long, text: String): String
    external fun click(id: Long, windowId: Int, slot: Int, button: Int, mode: Int): String
    external fun closeWindow(id: Long, windowId: Int): String
    external fun hold(id: Long, slot: Int): String
    external fun complete(id: Long, text: String): String
    external fun useItem(id: Long, hand: Int): String
    external fun swing(id: Long): String
    external fun look(id: Long, yaw: Float, pitch: Float): String
    external fun entityAction(id: Long, entityId: Int, action: Int): String
    external fun interact(id: Long, x: Int, y: Int, z: Int, face: Int): String
    external fun entities(id: Long): String
    external fun minimap(id: Long, radius: Int): IntArray
    external fun mapList(id: Long): String
    external fun mapPixels(id: Long, mapId: Int): IntArray
    external fun move(id: Long, dx: Double, dy: Double, dz: Double): String
    external fun disconnect(id: Long)
    external fun version(): String
}
