// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class,
)

package com.minechat.app

import android.widget.Toast
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalView
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.Slider
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.FilterQuality
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Surface
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.Apps
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val USERNAME_RE = Regex("^[A-Za-z0-9_]{3,16}$")

private fun decodeFavicon(data: String): ImageBitmap? {
    if (data.isBlank()) return null
    val b64 = data.substringAfter("base64,", "")
    if (b64.isEmpty()) return null
    return try {
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
    } catch (e: Exception) {
        null
    }
}

private fun signalBars(ms: Long): String = when {
    ms < 100 -> "\u2582\u2584\u2586\u2588"
    ms < 200 -> "\u2582\u2584\u2586"
    ms < 400 -> "\u2582\u2584"
    else -> "\u2582"
}

private fun shareChat(context: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(send, "Export chat"))
}

@Composable
private fun ComingSoonCard(title: String, text: String) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.tertiaryContainer) {
                    Text(
                        "COMING SOON",
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    )
                }
            }
            Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

private fun authLabel(auth: String) =
    if (auth == "offline") "Offline mode (username only, not authenticated)" else "Microsoft account"

private fun formatBytes(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
    else -> String.format(Locale.US, "%.2f MB", b / (1024.0 * 1024.0))
}

private fun formatDuration(ms: Long): String {
    val s = ms / 1000
    return String.format(Locale.US, "%dh %02dm %02ds", s / 3600, (s % 3600) / 60, s % 60)
}

// ------------------------------------------------------------------------------------------------
// Root / shells
// ------------------------------------------------------------------------------------------------

@Composable
fun AppRoot(vm: AppViewModel) {
    val view = LocalView.current
    val keepOn = vm.auto.flag("keepon") && vm.sessionActive
    DisposableEffect(keepOn) {
        view.keepScreenOn = keepOn
        onDispose { view.keepScreenOn = false }
    }
    Crossfade(targetState = vm.current, label = "screen") { s ->
    when (s) {
        Screen.Dashboard, Screen.Servers, Screen.Settings -> TopLevelShell(vm, s)
        is Screen.AddEdit -> AddEditScreen(vm, s.serverId)
        is Screen.AuthSelect -> AuthSelectScreen(vm, s.serverId)
        Screen.Connecting -> ConnectingScreen(vm)
        Screen.Chat, Screen.Players, Screen.Inventory, Screen.Map, Screen.Info -> SessionShell(vm, s)
        Screen.Automation -> AutomationScreen(vm)
        Screen.About -> AboutScreen(vm)
    }
    }
}

@Composable
fun Page(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
    bottomBar: @Composable () -> Unit = {},
    floating: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = actions,
            )
        },
        bottomBar = bottomBar,
        floatingActionButton = floating,
        content = content,
    )
}

@Composable
private fun TopLevelShell(vm: AppViewModel, s: Screen) {
    val title = when (s) {
        Screen.Servers -> "Servers"
        Screen.Settings -> "Settings"
        else -> "MineChat"
    }
    Page(
        title = title,
        actions = {
            if (s == Screen.Servers) {
                IconButton(onClick = { vm.refreshStatuses() }) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Refresh status")
                }
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = s == Screen.Dashboard,
                    onClick = { vm.resetTo(Screen.Dashboard) },
                    icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                    label = { Text("Dashboard") },
                )
                NavigationBarItem(
                    selected = s == Screen.Servers,
                    onClick = { vm.resetTo(Screen.Servers) },
                    icon = { Icon(Icons.Filled.Dns, contentDescription = null) },
                    label = { Text("Servers") },
                )
                NavigationBarItem(
                    selected = s == Screen.Settings,
                    onClick = { vm.resetTo(Screen.Settings) },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                    label = { Text("Settings") },
                )
            }
        },
        floating = {
            if (s == Screen.Servers) {
                FloatingActionButton(onClick = { vm.go(Screen.AddEdit(null)) }) {
                    Icon(Icons.Filled.Add, contentDescription = "Add server")
                }
            }
        },
    ) { padding ->
        when (s) {
            Screen.Servers -> ServersContent(vm, padding)
            Screen.Settings -> SettingsContent(vm, padding)
            else -> DashboardContent(vm, padding)
        }
    }
}

@Composable
private fun SessionShell(vm: AppViewModel, s: Screen) {
    Page(
        title = vm.activeServer?.name ?: "Session",
        onBack = { vm.back() },
        actions = {
            if (s == Screen.Chat) {
                val ctx = LocalContext.current
                IconButton(onClick = { shareChat(ctx, vm.chatAsText()) }) {
                    Icon(Icons.Filled.Share, contentDescription = "Export chat")
                }
            }
            IconButton(onClick = { vm.disconnectAndLeave() }) {
                Icon(Icons.Filled.Close, contentDescription = "Disconnect")
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = s == Screen.Chat,
                    onClick = { vm.replaceTop(Screen.Chat) },
                    icon = { Icon(Icons.Filled.Chat, contentDescription = null) },
                    label = { Text("Chat") },
                )
                NavigationBarItem(
                    selected = s == Screen.Players,
                    onClick = { vm.replaceTop(Screen.Players) },
                    icon = { Icon(Icons.Filled.People, contentDescription = null) },
                    label = { Text("Players") },
                )
                NavigationBarItem(
                    selected = s == Screen.Inventory,
                    onClick = { vm.replaceTop(Screen.Inventory) },
                    icon = { Icon(Icons.Filled.Apps, contentDescription = null) },
                    label = { Text("Items") },
                )
                NavigationBarItem(
                    selected = s == Screen.Map,
                    onClick = { vm.replaceTop(Screen.Map) },
                    icon = { Icon(Icons.Filled.Map, contentDescription = null) },
                    label = { Text("Map") },
                )
                NavigationBarItem(
                    selected = s == Screen.Info,
                    onClick = { vm.replaceTop(Screen.Info) },
                    icon = { Icon(Icons.Filled.Info, contentDescription = null) },
                    label = { Text("Info") },
                )
            }
        },
    ) { padding ->
        when (s) {
            Screen.Players -> PlayersContent(vm, padding)
            Screen.Inventory -> InventoryContent(vm, padding)
            Screen.Map -> MapContent(vm, padding)
            Screen.Info -> InfoContent(vm, padding)
            else -> ChatContent(vm, padding)
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Dashboard + server list
// ------------------------------------------------------------------------------------------------

@Composable
private fun DashboardContent(vm: AppViewModel, padding: PaddingValues) {
    val version = remember { Native.version() }
    val favorites = vm.servers.filter { it.favorite }
    val recent = vm.servers.filter { it.lastConnected > 0 }.sortedByDescending { it.lastConnected }.take(5)
    LazyColumn(
        modifier = Modifier.padding(padding).fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("MineChat", style = MaterialTheme.typography.headlineSmall)
                    Text(version, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "A Rust-powered Minecraft Java client with chat and inventory. Offline-mode (online-mode=false) servers only in this build.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }
        if (vm.sessionActive) {
            item {
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Active session", style = MaterialTheme.typography.titleMedium)
                        Text("${vm.activeServer?.name ?: ""} \u2014 ${vm.connState}")
                        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                vm.go(if (vm.connState == "play") Screen.Chat else Screen.Connecting)
                            }) { Text("Open") }
                            OutlinedButton(onClick = { vm.disconnectAndLeave() }) { Text("Disconnect") }
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { vm.go(Screen.AddEdit(null)) }) { Text("Add server") }
                FilledTonalButton(onClick = { vm.resetTo(Screen.Servers) }) { Text("All servers") }
            }
        }
        item {
            var hostPort by remember { mutableStateOf("") }
            var qUser by remember { mutableStateOf(vm.defaultUsername) }
            var qError by remember { mutableStateOf("") }
            ElevatedCard(Modifier.fillMaxWidth().animateContentSize()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Quick connect", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = hostPort, onValueChange = { hostPort = it.trim(); qError = "" },
                        label = { Text("host or host:port") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = qUser, onValueChange = { qUser = it.trim(); qError = "" },
                        label = { Text("Username (offline mode)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    if (qError.isNotEmpty()) {
                        Text(qError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                    Button(
                        onClick = { val err = vm.quickConnect(hostPort, qUser); if (err != null) qError = err },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Connect") }
                }
            }
        }
        if (favorites.isNotEmpty()) {
            item { Text("Favorites", style = MaterialTheme.typography.titleMedium) }
            items(favorites, key = { "f${it.id}" }) { s ->
                ServerCard(vm, s, showActions = false) { vm.go(Screen.AuthSelect(s.id)) }
            }
        }
        if (recent.isNotEmpty()) {
            item { Text("Recent connections", style = MaterialTheme.typography.titleMedium) }
            items(recent, key = { "r${it.id}" }) { s ->
                ServerCard(vm, s, showActions = false) { vm.go(Screen.AuthSelect(s.id)) }
            }
        }
        if (vm.servers.isEmpty()) {
            item { Text("No servers yet. Tap \"Add server\" to save your first one.") }
        }
    }
}

@Composable
private fun ServersContent(vm: AppViewModel, padding: PaddingValues) {
    var deleting by remember { mutableStateOf<Server?>(null) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { vm.refreshStatuses() }
    if (vm.servers.isEmpty()) {
        Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No servers saved. Tap + to add one.", modifier = Modifier.padding(24.dp))
        }
    } else {
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "search") {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, label = { Text("Search servers") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
            }
            items(
                vm.servers.filter { query.isBlank() || it.name.contains(query, true) || it.host.contains(query, true) },
                key = { it.id },
            ) { s ->
                ServerCard(vm, s, showActions = true, onDelete = { deleting = s }) {
                    vm.go(Screen.AuthSelect(s.id))
                }
            }
        }
    }
    val d = deleting
    if (d != null) {
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete server?") },
            text = { Text("\"${d.name}\" and its saved chat history will be removed.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteServer(d.id); deleting = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun ServerCard(
    vm: AppViewModel,
    s: Server,
    showActions: Boolean,
    onDelete: () -> Unit = {},
    onClick: () -> Unit,
) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val st = vm.statuses[s.id]
    ElevatedCard(Modifier.fillMaxWidth().animateContentSize().clickable(onClick = onClick)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val icon = remember(st?.favicon) { decodeFavicon(st?.favicon ?: "") }
                if (icon != null) {
                    Image(
                        bitmap = icon,
                        contentDescription = "Server icon",
                        modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)),
                    )
                    Spacer(Modifier.width(12.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(s.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${s.host}:${s.port}", style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = { vm.toggleFavorite(s) }) {
                    Icon(
                        if (s.favorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = if (s.favorite) "Remove favorite" else "Add favorite",
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            when {
                st == null -> Text("Checking\u2026", style = MaterialTheme.typography.bodySmall)
                st.ok -> {
                    Text(legacyToAnnotated(st.motd, dark), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${signalBars(st.latencyMs)} ${st.online}/${st.max} players \u2022 ${st.versionName} \u2022 ${st.latencyMs} ms" +
                            if (st.exactProtocol) "" else " \u2022 different protocol (may need ViaVersion)",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                else -> Text("Offline: ${st.error}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
            Text(
                "${authLabel(s.auth)} \u2022 ${s.username}",
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 4.dp),
            )
            if (showActions) {
                Row {
                    TextButton(onClick = { vm.go(Screen.AddEdit(s.id)) }) {
                        Icon(Icons.Filled.Edit, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("Edit")
                    }
                    TextButton(onClick = onDelete) {
                        Icon(Icons.Filled.Delete, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("Delete")
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Add / edit server, authentication selection, connecting
// ------------------------------------------------------------------------------------------------

@Composable
private fun AddEditScreen(vm: AppViewModel, serverId: Long?) {
    val existing = serverId?.let { vm.serverById(it) }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var host by remember { mutableStateOf(existing?.host ?: "") }
    var port by remember { mutableStateOf((existing?.port ?: 25565).toString()) }
    var username by remember { mutableStateOf(existing?.username ?: vm.defaultUsername) }
    var favorite by remember { mutableStateOf(existing?.favorite ?: false) }
    var joinCommands by remember { mutableStateOf(existing?.joinCommands ?: "") }
    var password by remember { mutableStateOf("") }
    var hasSavedPassword by remember { mutableStateOf(existing != null && vm.hasPassword(existing.id)) }

    val portNum = port.toIntOrNull()
    val hostOk = host.isNotBlank() && !host.contains(' ')
    val portOk = portNum != null && portNum in 1..65535
    val userOk = USERNAME_RE.matches(username)
    val canSave = hostOk && portOk && userOk

    Page(title = if (existing == null) "Add server" else "Edit server", onBack = { vm.back() }) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it }, label = { Text("Nickname (optional)") },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = host, onValueChange = { host = it.trim() }, label = { Text("Host or IP") },
                singleLine = true, isError = host.isNotEmpty() && !hostOk, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = port, onValueChange = { port = it.filter { c -> c.isDigit() }.take(5) },
                label = { Text("Port") }, singleLine = true, isError = !portOk, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = username, onValueChange = { username = it.trim() }, label = { Text("Minecraft username") },
                singleLine = true, isError = username.isNotEmpty() && !userOk,
                supportingText = { Text("3-16 characters: letters, digits, underscore") },
                modifier = Modifier.fillMaxWidth(),
            )
            Text("Authentication mode", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = true, onClick = {}, label = { Text("Offline") })
                FilterChip(selected = false, onClick = {}, enabled = false, label = { Text("Microsoft (coming soon)") })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Favorite", Modifier.weight(1f))
                Switch(checked = favorite, onCheckedChange = { favorite = it })
            }
            Text("Auto-login (optional)", style = MaterialTheme.typography.titleSmall)
            OutlinedTextField(
                value = password, onValueChange = { password = it },
                label = { Text(if (hasSavedPassword) "New password (one is saved)" else "Password") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = joinCommands, onValueChange = { joinCommands = it },
                label = { Text("Commands after joining") }, minLines = 2,
                supportingText = { Text("One per line. {password} is replaced by the saved password, for example /login {password}") },
                modifier = Modifier.fillMaxWidth(),
            )
            if (hasSavedPassword) {
                TextButton(onClick = { existing?.let { vm.savePassword(it.id, "") }; hasSavedPassword = false }) {
                    Text("Remove saved password")
                }
            }
            Button(
                enabled = canSave,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val savedId = vm.saveServer(
                        Server(
                            id = existing?.id ?: 0,
                            name = name.ifBlank { host },
                            host = host,
                            port = portNum ?: 25565,
                            username = username,
                            auth = "offline",
                            favorite = favorite,
                            lastConnected = existing?.lastConnected ?: 0,
                            joinCommands = joinCommands,
                        )
                    )
                    if (password.isNotEmpty()) vm.savePassword(savedId, password)
                    vm.back()
                },
            ) { Text("Save") }
        }
    }
}

@Composable
private fun AuthSelectScreen(vm: AppViewModel, serverId: Long) {
    val server = vm.serverById(serverId)
    if (server == null) {
        LaunchedEffect(Unit) { vm.back() }
        return
    }
    var username by remember { mutableStateOf(server.username.ifBlank { vm.defaultUsername }) }
    val userOk = USERNAME_RE.matches(username)
    Page(title = "Connect to ${server.name}", onBack = { vm.back() }) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Offline mode", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Enter any username. It is NOT verified and is not a Microsoft account. " +
                            "Works only on servers with online-mode=false.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            ComingSoonCard(
                "Microsoft account",
                "Sign in with your own Microsoft account to join online-mode servers.",
            )
            ComingSoonCard(
                "Account ID login",
                "Log in with a saved account ID so you do not have to sign in every time.",
            )
            OutlinedTextField(
                value = username, onValueChange = { username = it.trim() }, label = { Text("Username") },
                singleLine = true, isError = username.isNotEmpty() && !userOk, modifier = Modifier.fillMaxWidth(),
            )
            Text("Selected: ${authLabel("offline")}", style = MaterialTheme.typography.labelLarge)
            Button(
                enabled = userOk, modifier = Modifier.fillMaxWidth(),
                onClick = { vm.startSession(server, username) },
            ) { Text("Connect to ${server.host}:${server.port}") }
        }
    }
}

@Composable
private fun ConnectingScreen(vm: AppViewModel) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val failed = vm.connState == "error" || vm.connState == "disconnected"
    Page(title = "Connecting", onBack = { vm.back() }) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (failed) {
                Text(
                    if (vm.connState == "error") "Could not connect" else "Disconnected",
                    style = MaterialTheme.typography.titleLarge,
                )
                Spacer(Modifier.height(8.dp))
                Text(legacyToAnnotated(vm.connDetail, dark))
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.reconnect() }) { Text("Retry") }
                    OutlinedButton(onClick = { vm.back() }) { Text("Back") }
                }
            } else {
                CircularProgressIndicator()
                Spacer(Modifier.height(16.dp))
                Text(
                    when (vm.connState) {
                        "login" -> "Logging in (offline mode)\u2026"
                        "reconnecting" -> "Reconnecting\u2026"
                        else -> "Connecting\u2026"
                    },
                    style = MaterialTheme.typography.titleMedium,
                )
                Text(vm.connDetail, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(16.dp))
                OutlinedButton(onClick = { vm.back() }) { Text("Cancel") }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Live session screens
// ------------------------------------------------------------------------------------------------

@Composable
private fun ChatContent(vm: AppViewModel, padding: PaddingValues) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val listState = rememberLazyListState()
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var input by remember { mutableStateOf(vm.chatDraft) }
    LaunchedEffect(Unit) { vm.clearDraft() }
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    var search by remember { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }
    val lines = remember(vm.chat.size, vm.chat.lastOrNull(), search) {
        if (search.isBlank()) vm.chat.toList()
        else vm.chat.filter { stripCodes(it.text).contains(search, true) || it.sender.contains(search, true) }
    }

    LaunchedEffect(lines.size) {
        val total = lines.size
        if (total == 0) return@LaunchedEffect
        val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
        if (last < 0) listState.scrollToItem(total - 1)
        else if (last >= total - 3) listState.animateScrollToItem(total - 1)
    }

    fun send() {
        if (input.isNotBlank()) {
            vm.sendChat(input)
            input = ""
        }
    }

    var showTab by remember { mutableStateOf(false) }
    var tabFilter by remember { mutableStateOf("") }
    var tabText by remember { mutableStateOf("/") }

    fun applyCompletion(m: String) {
        val c = vm.completions
        val text = tabText
        if (c != null) {
            val st = c.start.coerceIn(0, text.length)
            val en = (c.start + c.length).coerceIn(st, text.length)
            val tail = if (text.startsWith("/") && st == 1) " " else ""
            input = text.substring(0, st) + m + tail + text.substring(en)
        }
        showTab = false
        vm.dismissCompletions()
    }

    if (showTab) {
        val comp = vm.completions
        val shown = (comp?.matches ?: emptyList()).filter { tabFilter.isBlank() || it.contains(tabFilter, ignoreCase = true) }
        AlertDialog(
            onDismissRequest = { showTab = false; vm.dismissCompletions() },
            title = { Text("Commands and completions") },
            text = {
                Column {
                    OutlinedTextField(
                        value = tabFilter, onValueChange = { tabFilter = it },
                        label = { Text("Filter") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(8.dp))
                    if (vm.completionsLoading) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Asking the server\u2026")
                        }
                    } else if (shown.isEmpty()) {
                        Text("No suggestions from the server.", style = MaterialTheme.typography.bodySmall)
                    }
                    LazyColumn(Modifier.heightIn(max = 320.dp)) {
                        items(shown) { m ->
                            Text(
                                m,
                                modifier = Modifier.fillMaxWidth().clickable { applyCompletion(m) }.padding(vertical = 10.dp),
                                fontFamily = FontFamily.Monospace,
                            )
                        }
                        if (vm.sentHistory.isNotEmpty()) {
                            item {
                                Text(
                                    "Recently sent",
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(top = 12.dp),
                                )
                            }
                            items(vm.sentHistory.toList()) { h ->
                                Text(
                                    h,
                                    modifier = Modifier.fillMaxWidth()
                                        .clickable { input = h; showTab = false; vm.dismissCompletions() }
                                        .padding(vertical = 8.dp),
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTab = false; vm.dismissCompletions() }) { Text("Close") } },
        )
    }

    Column(Modifier.padding(padding).fillMaxSize()) {
        AnimatedVisibility(visible = vm.connState != "play") {
            Card(
                Modifier.fillMaxWidth().padding(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        when (vm.connState) {
                            "reconnecting" -> "Connection lost \u2014 reconnecting"
                            "disconnected" -> "Disconnected"
                            "error" -> "Connection error"
                            else -> vm.connState
                        },
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Text(stripCodes(vm.connDetail), style = MaterialTheme.typography.bodySmall)
                    if (vm.connState == "disconnected" || vm.connState == "error") {
                        TextButton(onClick = { vm.reconnect() }) { Text("Reconnect") }
                    }
                }
            }
        }
        VitalsBar(vm, compact = true)
        AnimatedVisibility(visible = vm.notice != null) {
            val n = vm.notice
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (n?.kind == "health") MaterialTheme.colorScheme.errorContainer
                    else MaterialTheme.colorScheme.tertiaryContainer
                ),
            ) {
                Text(n?.text ?: "", modifier = Modifier.padding(10.dp), style = MaterialTheme.typography.labelLarge)
            }
        }
        AnimatedVisibility(visible = vm.titleText.isNotEmpty() || vm.subtitleText.isNotEmpty()) {
            Card(
                Modifier.fillMaxWidth().padding(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (vm.titleText.isNotEmpty()) {
                        Text(legacyToAnnotated(vm.titleText, dark), style = MaterialTheme.typography.titleLarge)
                    }
                    if (vm.subtitleText.isNotEmpty()) {
                        Text(legacyToAnnotated(vm.subtitleText, dark), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        for (b in vm.bossBars.values) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp)) {
                Text(
                    legacyToAnnotated(b.title, dark),
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                LinearProgressIndicator(progress = b.health.coerceIn(0f, 1f), modifier = Modifier.fillMaxWidth())
            }
        }
        val sb = vm.sidebar
        if (sb != null) {
            var sidebarOpen by remember { mutableStateOf(false) }
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)
                    .animateContentSize().clickable { sidebarOpen = !sidebarOpen },
            ) {
                Column(Modifier.padding(10.dp)) {
                    Text(
                        legacyToAnnotated(sb.title.ifEmpty { "Scoreboard" }, dark),
                        style = MaterialTheme.typography.labelLarge,
                    )
                    if (sidebarOpen) {
                        for (line in sb.lines) {
                            Text(legacyToAnnotated(line, dark), style = MaterialTheme.typography.bodySmall)
                        }
                    } else {
                        Text("Tap to expand", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        if (showSearch) {
            OutlinedTextField(
                value = search, onValueChange = { search = it }, label = { Text("Search chat") },
                singleLine = true, modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            )
        }
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            items(lines.size) { idx ->
                val line = lines[idx]
                val raw = if (line.kind == "player" && line.sender.isNotEmpty()) "<${line.sender}> ${line.text}" else line.text
                val body = remember(raw, dark) { legacyToAnnotated(raw, dark) }
                Row(
                    Modifier.fillMaxWidth()
                        .then(
                            if (vm.auto.isMention(line)) Modifier.background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))
                            else Modifier
                        )
                        .combinedClickable(
                        onClick = {},
                        onLongClick = {
                            clipboard.setText(AnnotatedString(stripCodes(raw)))
                            Toast.makeText(context, "Message copied", Toast.LENGTH_SHORT).show()
                        },
                    )
                ) {
                    if (vm.showTimestamps) {
                        Text(
                            timeFmt.format(Date(line.ts)),
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(end = 8.dp, top = 2.dp),
                        )
                    }
                    Text(body, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        if (vm.actionBar.isNotEmpty()) {
            Text(
                legacyToAnnotated(vm.actionBar, dark),
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp),
            )
        }
        HorizontalDivider()
        if (vm.quickList.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(vm.quickList) { c ->
                    AssistChip(onClick = { vm.runQuick(c) }, label = { Text(c) })
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message or /command") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() }),
            )
            IconButton(onClick = { showSearch = !showSearch; if (!showSearch) search = "" }) {
                Icon(Icons.Filled.Search, contentDescription = "Search chat")
            }
            TextButton(
                onClick = {
                    tabText = if (input.isEmpty()) "/" else input
                    tabFilter = ""
                    showTab = true
                    vm.requestCompletions(tabText)
                },
                enabled = vm.connState == "play",
            ) { Text("Tab") }
            IconButton(onClick = { send() }, enabled = vm.connState == "play") {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
            }
        }
    }
}

@Composable
private fun PlayersContent(vm: AppViewModel, padding: PaddingValues) {
    var selectedPlayer by remember { mutableStateOf<PlayerRow?>(null) }
    val sel = selectedPlayer
    if (sel != null) {
        val ctx = LocalContext.current
        val clipboard = LocalClipboardManager.current
        val isFriend = vm.auto.inList("friends", sel.name)
        val isIgnored = vm.auto.inList("ignored", sel.name)
        AlertDialog(
            onDismissRequest = { selectedPlayer = null },
            title = { Text(sel.name) },
            text = {
                Column {
                    TextButton(onClick = { vm.draftMessage("/msg ${sel.name} "); selectedPlayer = null }) { Text("Message (/msg)") }
                    TextButton(onClick = { vm.sendChat("/tpa ${sel.name}"); selectedPlayer = null }) { Text("Teleport request (/tpa)") }
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(sel.name))
                        Toast.makeText(ctx, "Name copied", Toast.LENGTH_SHORT).show()
                        selectedPlayer = null
                    }) { Text("Copy name") }
                    TextButton(onClick = {
                        if (isFriend) vm.auto.removeFromList("friends", sel.name) else vm.auto.addToList("friends", sel.name)
                        selectedPlayer = null
                    }) { Text(if (isFriend) "Remove from friends" else "Add to friends") }
                    TextButton(onClick = {
                        if (isIgnored) vm.auto.removeFromList("ignored", sel.name) else vm.auto.addToList("ignored", sel.name)
                        selectedPlayer = null
                    }) { Text(if (isIgnored) "Stop ignoring" else "Ignore (hide their chat)") }
                }
            },
            confirmButton = { TextButton(onClick = { selectedPlayer = null }) { Text("Close") } },
        )
    }
    LazyColumn(Modifier.padding(padding).fillMaxSize()) {
        item {
            val max = if (vm.maxPlayers >= 0) " / ${vm.maxPlayers}" else ""
            Text(
                "${vm.players.size}$max players online",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(16.dp),
            )
        }
        items(vm.players, key = { it.uuid }) { p ->
            ListItem(
                modifier = Modifier.clickable { selectedPlayer = p },
                headlineContent = { Text((if (vm.auto.inList("friends", p.name)) "\u2605 " else "") + p.name) },
                supportingContent = { Text(p.uuid, style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace) },
                trailingContent = { Text(if (p.latency > 0) "${p.latency} ms" else "\u2014") },
            )
        }
        if (vm.activity.isNotEmpty()) {
            item {
                Text("Recent activity", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(16.dp))
            }
            items(vm.activity.size) { i ->
                Text(vm.activity[i], modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, Modifier.weight(0.4f), style = MaterialTheme.typography.labelLarge)
        Text(value, Modifier.weight(0.6f), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun InfoContent(vm: AppViewModel, padding: PaddingValues) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val server = vm.activeServer
    val info = vm.sessionInfo
    val st = vm.stats
    val ping = server?.let { vm.statuses[it.id] }
    Column(
        Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Server", style = MaterialTheme.typography.titleMedium)
                InfoRow("Address", "${server?.host}:${server?.port}")
                InfoRow("Authentication", authLabel(server?.auth ?: "offline"))
                InfoRow("Protocol used", "763 (Minecraft 1.20.1)")
                if (ping != null && ping.ok) {
                    InfoRow("Reported version", "${ping.versionName} (protocol ${ping.protocol})")
                    Text(legacyToAnnotated(ping.motd, dark), modifier = Modifier.padding(top = 4.dp))
                }
                InfoRow("Max players", if (vm.maxPlayers >= 0) vm.maxPlayers.toString() else "?")
            }
        }
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Session", style = MaterialTheme.typography.titleMedium)
                InfoRow("State", vm.connState)
                InfoRow("Username", info?.username ?: server?.username ?: "")
                InfoRow("UUID", info?.uuid ?: "")
                InfoRow("Latency", if (st.latencyMs > 0) "${st.latencyMs} ms" else "n/a")
                InfoRow("Uptime", formatDuration(st.uptimeMs))
                InfoRow("Received", "${formatBytes(st.bytesIn)} (${st.packetsIn} packets)")
                InfoRow("Sent", formatBytes(st.bytesOut))
                InfoRow("Reconnects", st.reconnects.toString())
                InfoRow(
                    "Position",
                    String.format(Locale.US, "%.1f, %.1f, %.1f", st.x, st.y, st.z),
                )
            }
        }
        VitalsCard(vm)
        TelemetryCard(vm)
        ControlsCard(vm)
        InteractCard(vm)
        NotesCard(vm)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Move (1 block)", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Sends raw position packets with no physics or collision checks. " +
                        "Servers may move you back.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { vm.move(0.0, 0.0, -1.0) }) { Text("North") }
                    FilledTonalButton(onClick = { vm.move(0.0, 0.0, 1.0) }) { Text("South") }
                    FilledTonalButton(onClick = { vm.move(-1.0, 0.0, 0.0) }) { Text("West") }
                    FilledTonalButton(onClick = { vm.move(1.0, 0.0, 0.0) }) { Text("East") }
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { vm.move(0.0, 1.0, 0.0) }) { Text("Up") }
                    FilledTonalButton(onClick = { vm.move(0.0, -1.0, 0.0) }) { Text("Down") }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Inventory
// ------------------------------------------------------------------------------------------------

private fun displayName(name: String): String =
    name.split('_').joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercaseChar() } }

private fun abbreviation(name: String): String {
    val parts = name.split('_').filter { it.isNotEmpty() }
    return when {
        parts.isEmpty() -> "?"
        parts.size == 1 -> parts[0].take(2).replaceFirstChar { c -> c.uppercaseChar() }
        else -> parts.take(2).joinToString("") { it.take(1).uppercase() }
    }
}

private fun itemColor(name: String): Color {
    val hue = ((name.hashCode() and 0x7fffffff) % 360).toFloat()
    return Color.hsv(hue, 0.45f, 0.85f)
}

private fun describe(item: ItemStackUi?): String =
    if (item == null) "Empty" else "${stripCodes(item.customName ?: displayName(item.name))} \u00D7${item.count}"

@Composable
private fun RowScope.SlotTile(item: ItemStackUi?, selected: Boolean, onTap: () -> Unit, onLong: () -> Unit) {
    val shape = RoundedCornerShape(4.dp)
    val borderColor = when {
        selected -> MaterialTheme.colorScheme.primary
        item != null && matchesSearch(item, InvSearch.query) -> Color(0xFFFFD600)
        item?.enchanted == true -> MaterialTheme.colorScheme.tertiary
        else -> MaterialTheme.colorScheme.outlineVariant
    }
    val tex = remember(item?.name, TextureStore.version) { item?.let { TextureStore.forItem(it.name) } }
    val fill = when {
        item == null -> MaterialTheme.colorScheme.surfaceVariant
        tex != null -> Color(0xFF8B8B8B)
        else -> itemColor(item.name)
    }
    Box(
        modifier = Modifier
            .weight(1f)
            .aspectRatio(1f)
            .padding(1.dp)
            .background(fill, shape)
            .border(if (selected) 2.dp else 1.dp, borderColor, shape)
            .combinedClickable(onClick = onTap, onLongClick = onLong),
        contentAlignment = Alignment.Center,
    ) {
        if (item != null) {
            if (tex != null) {
                Image(
                    bitmap = tex,
                    contentDescription = null,
                    filterQuality = FilterQuality.None,
                    modifier = Modifier.fillMaxSize().padding(3.dp),
                )
            } else {
                Text(
                    abbreviation(item.customName?.let { stripCodes(it).trim().lowercase().replace(' ', '_') } ?: item.name),
                    fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }
            if (item.count > 1) {
                Text(
                    "${item.count}",
                    fontSize = 10.sp,
                    color = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 1.dp, bottom = 1.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(3.dp))
                        .padding(horizontal = 2.dp),
                )
            }
        }
    }
}

@Composable
private fun SlotGrid(
    inv: InventoryUi,
    slotIds: List<Int>,
    heldIndex: Int,
    onTap: (Int) -> Unit,
    onLong: (Int) -> Unit,
) {
    val columns = 9
    Column {
        for (row in slotIds.chunked(columns)) {
            Row(Modifier.fillMaxWidth()) {
                for (i in row) {
                    SlotTile(inv.slots.getOrNull(i), i == heldIndex, { onTap(i) }, { onLong(i) })
                }
                for (k in row.size until columns) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun InventoryContent(vm: AppViewModel, padding: PaddingValues) {
    val inv = vm.inventory
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    var mode by remember { mutableStateOf("normal") }
    var touched by remember { mutableStateOf<ItemStackUi?>(null) }

    if (inv == null) {
        Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Waiting for the server to send your inventory\u2026", modifier = Modifier.padding(24.dp))
        }
    } else {
        val size = inv.slots.size
        val isPlayer = inv.windowId == 0
        val hotbarStart = if (isPlayer) 36 else size - 9
        val hotbar = hotbarStart until (hotbarStart + 9)
        val heldIndex = hotbarStart + inv.held

        fun act(i: Int, long: Boolean) {
            touched = inv.slots.getOrNull(i)
            when (mode) {
                "normal" -> vm.clickSlot(i, if (long) 1 else 0, 0)
                "shift" -> vm.clickSlot(i, 0, 1)
                "drop1" -> vm.clickSlot(i, 0, 4)
                "dropall" -> vm.clickSlot(i, 1, 4)
                "hold" -> if (i in hotbar) vm.holdSlot(i - hotbarStart)
                else -> {}
            }
        }

        val modes = listOf(
            "normal" to "Click",
            "shift" to "Shift-click",
            "drop1" to "Drop 1",
            "dropall" to "Drop stack",
            "hold" to "Select hotbar",
            "info" to "Inspect",
        )
        val hint = when (mode) {
            "normal" -> "Tap = left click, long-press = right click"
            "shift" -> "Tap = shift-click (quick move)"
            "drop1" -> "Tap = drop one item from that slot"
            "dropall" -> "Tap = drop the whole stack"
            "hold" -> "Tap a hotbar slot to hold it"
            else -> "Tap to see an item's name (nothing is sent)"
        }

        Column(
            Modifier.padding(padding).padding(12.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (isPlayer) "Inventory" else inv.title,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                )
                if (!isPlayer) {
                    TextButton(onClick = { vm.closeContainer() }) { Text("Close") }
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((key, label) in modes) {
                    FilterChip(selected = mode == key, onClick = { mode = key }, label = { Text(label) })
                }
            }
            Text(hint, style = MaterialTheme.typography.bodySmall)
            InventoryTools(vm, inv)
            val t = touched
            if (t == null) {
                Text("Selected: Empty", style = MaterialTheme.typography.labelLarge)
            } else {
                Card(Modifier.fillMaxWidth().animateContentSize()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            legacyToAnnotated(t.customName ?: displayName(t.name), dark),
                            style = MaterialTheme.typography.titleSmall,
                        )
                        Text(
                            "${displayName(t.name)} \u00D7${t.count}" + if (t.enchanted) " \u2022 enchanted" else "",
                            style = MaterialTheme.typography.labelSmall,
                        )
                        for (line in t.lore) {
                            Text(legacyToAnnotated(line, dark), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            if (inv.cursor != null) {
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Holding: ${describe(inv.cursor)}", Modifier.weight(1f))
                        TextButton(onClick = { vm.clickSlot(-999, 0, 0) }) { Text("Drop all") }
                        TextButton(onClick = { vm.clickSlot(-999, 1, 0) }) { Text("Drop one") }
                    }
                }
            }

            val onTap: (Int) -> Unit = { i -> act(i, false) }
            val onLong: (Int) -> Unit = { i -> act(i, true) }
            if (isPlayer) {
                Text("Armor and off-hand", style = MaterialTheme.typography.labelMedium)
                SlotGrid(inv, listOf(5, 6, 7, 8, 45), heldIndex, onTap, onLong)
                Text("Crafting (grid, then result)", style = MaterialTheme.typography.labelMedium)
                SlotGrid(inv, listOf(1, 2, 3, 4, 0), heldIndex, onTap, onLong)
                Text("Backpack", style = MaterialTheme.typography.labelMedium)
                SlotGrid(inv, (9..35).toList(), heldIndex, onTap, onLong)
                Text("Hotbar", style = MaterialTheme.typography.labelMedium)
                SlotGrid(inv, (36..44).toList(), heldIndex, onTap, onLong)
            } else if (size >= 36) {
                Text("Container", style = MaterialTheme.typography.labelMedium)
                SlotGrid(inv, (0 until size - 36).toList(), heldIndex, onTap, onLong)
                Text("Backpack", style = MaterialTheme.typography.labelMedium)
                SlotGrid(inv, ((size - 36) until (size - 9)).toList(), heldIndex, onTap, onLong)
                Text("Hotbar", style = MaterialTheme.typography.labelMedium)
                SlotGrid(inv, ((size - 9) until size).toList(), heldIndex, onTap, onLong)
            } else {
                SlotGrid(inv, (0 until size).toList(), heldIndex, onTap, onLong)
            }
            Text(
                "Items are shown as coloured tiles with short names (no Minecraft textures). " +
                    "Containers with unusual shapes (hoppers, dispensers) are shown in rows of nine.",
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Settings + about
// ------------------------------------------------------------------------------------------------

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SettingsContent(vm: AppViewModel, padding: PaddingValues) {
    val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importTextures(uri)
    }
    Column(
        Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Theme", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((key, label) in listOf("system" to "System", "light" to "Light", "dark" to "Dark")) {
                FilterChip(selected = vm.themeMode == key, onClick = { vm.setTheme(key) }, label = { Text(label) })
            }
        }
        SwitchRow("Show chat timestamps", vm.showTimestamps) { vm.setTimestamps(it) }
        SwitchRow("Reconnect automatically after connection loss", vm.autoReconnect) { vm.updateAutoReconnect(it) }
        SwitchRow("Notify me when someone says my name or whispers", vm.mentionAlerts) { vm.updateMentionAlerts(it) }
        SwitchRow("Health and hunger notices (damage, low health, hungry)", vm.vitalAlerts) { vm.updateVitalAlerts(it) }
        SwitchRow("Auto-eat when hungry (food must be in your hotbar)", vm.autoEat) { vm.updateAutoEat(it) }
        SwitchRow("Anti-AFK: tiny move every 45 s (some servers forbid this)", vm.antiAfk) { vm.updateAntiAfk(it) }
        HorizontalDivider()
        Text("Item textures", style = MaterialTheme.typography.titleMedium)
        Text(
            if (vm.texturesAvailable) "Textures are installed." else
                "Items are shown as coloured tiles. Add textures from your own copy of Minecraft.",
            style = MaterialTheme.typography.bodySmall,
        )
        if (vm.textureStatus.isNotEmpty()) {
            Text(vm.textureStatus, style = MaterialTheme.typography.labelMedium)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.downloadTextures() }, enabled = !vm.textureBusy) { Text("Download from Mojang") }
            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !vm.textureBusy) { Text("Import pack") }
        }
        if (vm.texturesAvailable) {
            TextButton(onClick = { vm.removeTextures() }) { Text("Remove textures") }
        }
        Text(
            "Minecraft textures belong to Mojang. They are fetched to this device only and are not part of MineChat. " +
                "You can also import a resource pack (.zip) or the game's .jar file.",
            style = MaterialTheme.typography.labelSmall,
        )
        HorizontalDivider()
        Text("Map view distance: ${vm.viewDistance} chunks", style = MaterialTheme.typography.titleMedium)
        Slider(
            value = vm.viewDistance.toFloat(),
            onValueChange = { vm.updateViewDistance(it.toInt()) },
            valueRange = 2f..10f,
            steps = 7,
        )
        Text(
            "More chunks show more of the world map but use more mobile data. Applies on the next connect.",
            style = MaterialTheme.typography.labelSmall,
        )
        HorizontalDivider()
        OutlinedTextField(
            value = vm.defaultUsername,
            onValueChange = { vm.updateDefaultUsername(it.trim()) },
            label = { Text("Default username") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = vm.quickCommands,
            onValueChange = { vm.updateQuickCommands(it) },
            label = { Text("Quick commands (comma separated)") },
            supportingText = { Text("Buttons in chat. Chain commands with ; for example /spawn ; /shop") },
            modifier = Modifier.fillMaxWidth(),
        )
        Text("Saved servers", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                clipboard.setText(AnnotatedString(vm.exportServersJson()))
                Toast.makeText(ctx, "Backup copied (passwords are not included)", Toast.LENGTH_SHORT).show()
            }) { Text("Copy backup") }
            OutlinedButton(onClick = {
                val text = clipboard.getText()?.text ?: ""
                Toast.makeText(ctx, vm.importServersJson(text), Toast.LENGTH_SHORT).show()
            }) { Text("Restore from clipboard") }
        }
        OutlinedButton(onClick = { vm.clearHistory() }) { Text("Clear all chat history") }
        HorizontalDivider()
        TextButton(onClick = { vm.go(Screen.Automation) }) { Text("Automation, alerts and chat tools") }
        TextButton(onClick = { vm.go(Screen.About) }) { Text("About MineChat") }
    }
}

@Composable
private fun AboutScreen(vm: AppViewModel) {
    val version = remember { Native.version() }
    Page(title = "About", onBack = { vm.back() }) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("MineChat 1.5.0", style = MaterialTheme.typography.headlineSmall)
            Text(version, style = MaterialTheme.typography.bodySmall)
            Text("Created by SAROJGMG (Prajwal)", style = MaterialTheme.typography.titleMedium)
            Text(
                "Copyright \u00A9 2026 SAROJGMG (Prajwal). All rights reserved. " +
                    "This app and its source code may not be copied, modified or redistributed " +
                    "without written permission from the owner.",
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                "MineChat is an independent project and is not affiliated with Mojang Studios or Microsoft. " +
                    "Minecraft is a trademark of Mojang Synergies AB.",
                style = MaterialTheme.typography.bodySmall,
            )
            HorizontalDivider()
            Text("What this build does", style = MaterialTheme.typography.titleMedium)
            Text(
                "\u2022 Minecraft Java protocol written in Rust (no Mineflayer, no Node.js).\n" +
                    "\u2022 Server list with icons, MOTD, player counts, latency and search; quick connect.\n" +
                    "\u2022 Offline-mode login (online-mode=false), compression, keep-alive, auto-reconnect.\n" +
                    "\u2022 Live chat with colours, commands, quick-command buttons and a Tab button " +
                    "(server command list and completions).\n" +
                    "\u2022 Inventory and server menus (/shop style GUIs): click, shift-click, drop, " +
                    "custom item names and lore.\n" +
                    "\u2022 Item textures from your own Minecraft files, world map around you, in-game map items, " +
                    "waypoints, chat search, tap a player to message them.\n" +
                    "\u2022 Auto-login commands, mention notifications, titles, boss bars, scoreboard, " +
                    "radar, use item and right-click blocks, server domain (SRV) lookup, server backup.\n" +
                    "\u2022 Heart, hunger and XP bars with damage and hunger notices, low-health alerts, " +
                    "optional auto-eat and anti-AFK, game clock and weather.\n" +
                    "\u2022 Smart auto-eat, safety command, auto-reply, keyword rules, scheduled commands, friends, " +
                    "ignore list, TPS and ping graph, compass, look and sneak controls, server notes, item totals.\n" +
                    "\u2022 Player list, basic movement, background connection, chat export.\n" +
                    "\u2022 Protocol 763 (Minecraft 1.20.1). Newer servers work only through ViaVersion."
            )
            Text("Coming soon", style = MaterialTheme.typography.titleMedium)
            Text(
                "\u2022 Microsoft account login and online-mode servers.\n" +
                    "\u2022 Account ID login.\n" +
                    "\u2022 3D world view."
            )
            Text("Testing status", style = MaterialTheme.typography.titleMedium)
            Text(
                "The Rust engine is covered by unit tests and end-to-end tests against a mock server. " +
                    "It has not yet been verified against real Paper or Purpur servers."
            )
            Text(
                "Offline-mode names are not authenticated Microsoft accounts.",
                style = MaterialTheme.typography.labelLarge,
            )
        }
    }
}


// ------------------------------------------------------------------------------------------------
// Map tab: world map around the player and in-game map items
// ------------------------------------------------------------------------------------------------

@Composable
private fun MapContent(vm: AppViewModel, padding: PaddingValues) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.padding(padding).fillMaxSize()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("World") })
            FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Map items") })
        }
        if (tab == 0) WorldMap(vm) else ItemMaps(vm)
    }
}

@Composable
private fun WorldMap(vm: AppViewModel) {
    var radius by remember { mutableStateOf(4) }
    var image by remember { mutableStateOf<ImageBitmap?>(null) }
    var originX by remember { mutableStateOf(0) }
    var originZ by remember { mutableStateOf(0) }
    var mapW by remember { mutableStateOf(1) }
    var wpName by remember { mutableStateOf("") }
    var radar by remember { mutableStateOf(true) }
    var ents by remember { mutableStateOf<List<RadarEntity>>(emptyList()) }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val primary = MaterialTheme.colorScheme.primary

    LaunchedEffect(radius, vm.sessionId) {
        while (true) {
            val id = vm.sessionId
            if (id > 0) {
                val data = withContext(Dispatchers.IO) { Native.minimap(id, radius) }
                if (data.size > 4) {
                    val w = data[0]
                    val h = data[1]
                    if (w > 0 && h > 0 && data.size >= 4 + w * h) {
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.setPixels(data, 4, w, 0, 0, w, h)
                        image = bmp.asImageBitmap()
                        originX = data[2]
                        originZ = data[3]
                        mapW = w
                    }
                }
            }
            delay(1000)
        }
    }

    LaunchedEffect(vm.sessionId, radar) {
        while (true) {
            val id = vm.sessionId
            if (id > 0 && radar) {
                val list = withContext(Dispatchers.IO) {
                    val out = ArrayList<RadarEntity>()
                    try {
                        val arr = org.json.JSONArray(Native.entities(id))
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            out.add(RadarEntity(o.optInt("k"), o.optString("n"), o.optDouble("x"), o.optDouble("z"), o.optString("u")))
                        }
                    } catch (e: Exception) {
                        // keep what we have
                    }
                    out
                }
                ents = list
            } else if (!radar) {
                ents = emptyList()
            }
            delay(1000)
        }
    }

    val st = vm.stats
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = radar, onClick = { radar = !radar }, label = { Text("Radar") })
                for (r in listOf(2, 4, 6, 8)) {
                    FilterChip(selected = radius == r, onClick = { radius = r }, label = { Text("${r * 2 + 1}\u00D7${r * 2 + 1}") })
                }
            }
        }
        item {
            val img = image
            if (img == null) {
                Text("Waiting for chunk data from the server\u2026")
            } else {
                Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(8.dp))) {
                    Image(
                        bitmap = img,
                        contentDescription = "World map",
                        filterQuality = FilterQuality.None,
                        modifier = Modifier.fillMaxSize(),
                    )
                    Canvas(Modifier.fillMaxSize()) {
                        val w = this.size.width
                        val h = this.size.height
                        for (wp in vm.waypoints) {
                            val fx = ((wp.x - originX) / mapW).toFloat()
                            val fz = ((wp.z - originZ) / mapW).toFloat()
                            if (fx in 0f..1f && fz in 0f..1f) {
                                drawCircle(Color.Black, radius = 8f, center = Offset(fx * w, fz * h))
                                drawCircle(Color.Yellow, radius = 5f, center = Offset(fx * w, fz * h))
                            }
                        }
                        for (e in ents) {
                            if (e.kind == 5) continue
                            val ex = ((e.x - originX) / mapW).toFloat()
                            val ez = ((e.z - originZ) / mapW).toFloat()
                            if (ex in 0f..1f && ez in 0f..1f) {
                                val c = when (e.kind) {
                                    1 -> Color.Cyan
                                    2 -> Color.Red
                                    3 -> Color.Green
                                    4 -> Color.Yellow
                                    else -> Color.Gray
                                }
                                val big = e.kind != 4
                                drawCircle(Color.Black, radius = if (big) 7f else 4f, center = Offset(ex * w, ez * h))
                                drawCircle(c, radius = if (big) 5f else 2.5f, center = Offset(ex * w, ez * h))
                            }
                        }
                        val px = ((st.x - originX) / mapW).toFloat() * w
                        val pz = ((st.z - originZ) / mapW).toFloat() * h
                        drawCircle(Color.White, radius = 10f, center = Offset(px, pz))
                        drawCircle(primary, radius = 7f, center = Offset(px, pz))
                    }
                }
                Text(
                    String.format(Locale.US, "You: X %.1f  Y %.1f  Z %.1f", st.x, st.y, st.z),
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(top = 8.dp),
                )
                if (radar) {
                    val names = ents.filter { it.kind == 1 }.map { e ->
                        vm.players.firstOrNull { it.uuid == e.uuid }?.name ?: "player"
                    }
                    Text(
                        "Radar: ${ents.count { it.kind == 2 }} hostile, ${ents.count { it.kind == 3 }} friendly" +
                            (if (names.isNotEmpty()) " \u2022 players: " + names.joinToString(", ") else ""),
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
                if (radar && ents.isNotEmpty()) {
                    val groups = ents.filter { it.kind != 5 }.groupBy { it.name }
                    val rows = groups.entries.sortedByDescending { it.value.size }.take(8)
                    for ((ename, list) in rows) {
                        val nearest = list.minOf { Math.hypot(it.x - st.x, it.z - st.z) }
                        Text(
                            displayName(ename) + " \u00D7" + list.size + " \u2022 nearest " + nearest.toInt() + " m",
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                }
                Text(
                    "Colours are approximate. Chunks the server has not sent are dark. " +
                        "Raise the map view distance in Settings to see farther.",
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }
        item { Text("Waypoints", style = MaterialTheme.typography.titleMedium) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = wpName, onValueChange = { wpName = it }, label = { Text("Name") },
                    singleLine = true, modifier = Modifier.weight(1f),
                )
                Button(onClick = { vm.addWaypoint(wpName); wpName = "" }) { Text("Save here") }
            }
        }
        items(vm.waypoints.size) { i ->
            val w = vm.waypoints[i]
            val dx = w.x - st.x
            val dz = w.z - st.z
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(w.name, style = MaterialTheme.typography.titleSmall)
                    Text(
                        String.format(Locale.US, "%.0f, %.0f, %.0f \u2022 %.0f blocks to the %s", w.x, w.y, w.z, Math.sqrt(dx * dx + dz * dz), bearingName(dx, dz)),
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Row {
                        TextButton(onClick = {
                            clipboard.setText(AnnotatedString(String.format(Locale.US, "%.0f %.0f %.0f", w.x, w.y, w.z)))
                            Toast.makeText(context, "Coordinates copied", Toast.LENGTH_SHORT).show()
                        }) { Text("Copy") }
                        TextButton(onClick = { vm.removeWaypoint(i) }) { Text("Delete") }
                    }
                }
            }
        }
    }
}

@Composable
private fun ItemMaps(vm: AppViewModel) {
    var maps by remember { mutableStateOf<List<Pair<MapItemUi, ImageBitmap?>>>(emptyList()) }
    LaunchedEffect(vm.sessionId) {
        while (true) {
            val id = vm.sessionId
            if (id > 0) {
                val result = withContext(Dispatchers.IO) {
                    val list = ArrayList<Pair<MapItemUi, ImageBitmap?>>()
                    try {
                        val arr = org.json.JSONArray(Native.mapList(id))
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            val mid = o.getInt("id")
                            val px = Native.mapPixels(id, mid)
                            val bmp: ImageBitmap? = if (px.size == 128 * 128) {
                                val b = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
                                b.setPixels(px, 0, 128, 0, 0, 128, 128)
                                b.asImageBitmap()
                            } else {
                                null
                            }
                            list.add(Pair(MapItemUi(mid, o.optInt("scale"), o.optBoolean("locked")), bmp))
                        }
                    } catch (e: Exception) {
                        // keep what we have
                    }
                    list
                }
                maps = result
            }
            delay(1500)
        }
    }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (maps.isEmpty()) {
            item {
                Text(
                    "No map items received yet. Put a filled map in your hotbar and select it " +
                        "(Items tab, Hold mode) so the server sends its picture.",
                )
            }
        }
        items(maps) { (m, bmp) ->
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        "Map #${m.id} \u2022 scale ${m.scale}" + if (m.locked) " \u2022 locked" else "",
                        style = MaterialTheme.typography.titleSmall,
                    )
                    if (bmp != null) {
                        Image(
                            bitmap = bmp,
                            contentDescription = "Map ${m.id}",
                            filterQuality = FilterQuality.None,
                            modifier = Modifier.fillMaxWidth().aspectRatio(1f).padding(top = 8.dp),
                        )
                    }
                }
            }
        }
    }
}


@Composable
private fun InteractCard(vm: AppViewModel) {
    val st = vm.stats
    var blockX by remember { mutableStateOf(Math.floor(st.x).toInt().toString()) }
    var blockY by remember { mutableStateOf((Math.floor(st.y).toInt() - 1).toString()) }
    var blockZ by remember { mutableStateOf(Math.floor(st.z).toInt().toString()) }
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Interact", style = MaterialTheme.typography.titleMedium)
            Text(
                "Right-click the item in your hand (for example a menu compass), swing your arm, " +
                    "or right-click a block such as a chest or button within reach.",
                style = MaterialTheme.typography.bodySmall,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { vm.useItem() }) { Text("Use item") }
                FilledTonalButton(onClick = { vm.swing() }) { Text("Swing") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = blockX, onValueChange = { blockX = it.filter { c -> c.isDigit() || c == '-' } },
                    label = { Text("X") }, singleLine = true, modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    value = blockY, onValueChange = { blockY = it.filter { c -> c.isDigit() || c == '-' } },
                    label = { Text("Y") }, singleLine = true, modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    value = blockZ, onValueChange = { blockZ = it.filter { c -> c.isDigit() || c == '-' } },
                    label = { Text("Z") }, singleLine = true, modifier = Modifier.weight(1f),
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = {
                    val x = blockX.toIntOrNull()
                    val y = blockY.toIntOrNull()
                    val z = blockZ.toIntOrNull()
                    if (x != null && y != null && z != null) vm.interactBlock(x, y, z, 1)
                }) { Text("Right-click block") }
                TextButton(onClick = {
                    blockX = Math.floor(st.x).toInt().toString()
                    blockY = (Math.floor(st.y).toInt() - 1).toString()
                    blockZ = Math.floor(st.z).toInt().toString()
                }) { Text("Block under me") }
            }
        }
    }
}


private fun gameClock(time: Long): String {
    val t = ((time % 24000) + 24000) % 24000
    val hour = ((t / 1000 + 6) % 24).toInt()
    val minute = ((t % 1000) * 60 / 1000).toInt()
    return String.format(Locale.US, "%02d:%02d", hour, minute)
}

@Composable
private fun VitalsBar(vm: AppViewModel, compact: Boolean) {
    val v = vm.vitals
    if (v.health < 0f) return
    val size = if (compact) 12.dp else 20.dp
    val heart = Color(0xFFE53935)
    val food = Color(0xFFEF8F00)
    val empty = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
            for (i in 0 until 10) {
                val full = v.health >= 2f * (i + 1)
                val half = !full && v.health >= 2f * i + 1f
                Icon(
                    if (full || half) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = null,
                    tint = if (full) heart else if (half) heart.copy(alpha = 0.55f) else empty,
                    modifier = Modifier.size(size),
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
            for (i in 0 until 10) {
                val full = v.food >= 2 * (i + 1)
                val half = !full && v.food >= 2 * i + 1
                Icon(
                    Icons.Filled.Restaurant,
                    contentDescription = null,
                    tint = if (full) food else if (half) food.copy(alpha = 0.55f) else empty.copy(alpha = 0.3f),
                    modifier = Modifier.size(size),
                )
            }
        }
    }
}

@Composable
private fun VitalsCard(vm: AppViewModel) {
    val v = vm.vitals
    val st = vm.stats
    ElevatedCard(Modifier.fillMaxWidth().animateContentSize()) {
        Column(Modifier.padding(vertical = 12.dp)) {
            Text("Status", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 16.dp))
            if (v.health < 0f) {
                Text(
                    "Waiting for health data from the server\u2026",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
            } else {
                VitalsBar(vm, compact = false)
                Text(
                    "Health ${v.health.toInt()}/20 \u2022 Food ${v.food}/20 \u2022 Saturation " +
                        String.format(Locale.US, "%.1f", v.saturation),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
            }
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text("XP level ${st.xpLevel}", style = MaterialTheme.typography.labelLarge)
                LinearProgressIndicator(progress = st.xpBar.coerceIn(0f, 1f), modifier = Modifier.fillMaxWidth())
                Text(
                    "Day ${st.time / 24000 + 1} \u2022 ${gameClock(st.time)}" + if (st.rain) " \u2022 Raining" else "",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
    }
}


// ------------------------------------------------------------------------------------------------
// Automation screen and the extra tools
// ------------------------------------------------------------------------------------------------

@Composable
private fun AutoSwitch(vm: AppViewModel, key: String, title: String) {
    SwitchRow(title, vm.auto.flag(key)) { vm.auto.setFlag(key, it) }
}

@Composable
private fun AutoField(vm: AppViewModel, key: String, label: String, hint: String = "", lines: Int = 1) {
    OutlinedTextField(
        value = vm.auto.text(key),
        onValueChange = { vm.auto.setText(key, it) },
        label = { Text(label) },
        supportingText = { if (hint.isNotEmpty()) Text(hint) },
        minLines = lines,
        singleLine = lines == 1,
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun AutoSlider(vm: AppViewModel, key: String, title: String, from: Int, to: Int) {
    val v = vm.auto.num(key).coerceIn(from, to)
    Text("$title: $v", style = MaterialTheme.typography.labelLarge)
    Slider(
        value = v.toFloat(),
        onValueChange = { vm.auto.setText(key, it.toInt().toString()) },
        valueRange = from.toFloat()..to.toFloat(),
        steps = (to - from - 1).coerceAtLeast(0),
    )
}

@Composable
private fun AutomationScreen(vm: AppViewModel) {
    Page(title = "Automation and chat tools", onBack = { vm.back() }) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                "Everything here is off until you turn it on. Make sure the server you play on allows automation.",
                style = MaterialTheme.typography.bodySmall,
            )
            Text("Eating", style = MaterialTheme.typography.titleMedium)
            SwitchRow("Auto-eat (keeps eating until food is full)", vm.autoEat) { vm.updateAutoEat(it) }
            AutoSlider(vm, "eatstart", "Start eating when food is at or below", 2, 19)
            Text(
                "Once it starts it keeps eating until your food bar is full. Food can be in the hotbar or the main " +
                    "inventory (it is swapped into your selected slot and put back afterwards).",
                style = MaterialTheme.typography.labelSmall,
            )
            AutoSwitch(vm, "gapple", "Heal with golden apples when health is low")
            AutoSlider(vm, "gapplebelow", "Golden apple when health is at or below (half-hearts)", 2, 18)
            HorizontalDivider()
            Text("Safety", style = MaterialTheme.typography.titleMedium)
            SwitchRow("Health and hunger notices", vm.vitalAlerts) { vm.updateVitalAlerts(it) }
            AutoSwitch(vm, "vibrate", "Vibrate when you take damage")
            AutoSwitch(vm, "panic", "Run a command when health gets low")
            AutoSlider(vm, "panichp", "Low health at or below (half-hearts)", 2, 12)
            AutoField(vm, "paniccmd", "Command", "For example /home or /spawn")
            SwitchRow("Anti-AFK: tiny move every 45 s", vm.antiAfk) { vm.updateAntiAfk(it) }
            HorizontalDivider()
            Text("Chat", style = MaterialTheme.typography.titleMedium)
            AutoSwitch(vm, "reply", "Auto-reply to whispers")
            AutoField(vm, "replytext", "Reply message")
            AutoField(vm, "triggers", "Keyword rules", "One per line: keyword => what to send", 3)
            AutoSwitch(vm, "greet", "Greet players who join")
            AutoField(vm, "greettext", "Greeting", "{name} is replaced by the player's name")
            AutoField(vm, "friends", "Friends (comma separated)", "Highlighted in chat, and you get an alert when they join")
            AutoField(vm, "ignored", "Ignored players (comma separated)")
            AutoField(vm, "words", "Hidden words (comma separated)", "Chat lines containing these are hidden")
            AutoField(vm, "schedule", "Scheduled commands", "One per line: minutes | command, for example 30 | /daily", 3)
            HorizontalDivider()
            Text("Inventory and screen", style = MaterialTheme.typography.titleMedium)
            AutoField(vm, "junk", "Junk items (comma separated)", "Item names such as rotten_flesh. The Drop junk button on the Items tab drops them.")
            AutoSwitch(vm, "keepon", "Keep the screen on while connected")
        }
    }
}

@Composable
private fun InventoryTools(vm: AppViewModel, inv: InventoryUi) {
    var showTotals by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = InvSearch.query,
        onValueChange = { InvSearch.query = it },
        label = { Text("Find item (matches are outlined in yellow)") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { showTotals = !showTotals }) { Text(if (showTotals) "Hide totals" else "Item totals") }
        OutlinedButton(onClick = { vm.auto.dropJunk() }) { Text("Drop junk") }
    }
    if (showTotals) {
        val totals = HashMap<String, Int>()
        for (stack in inv.slots) {
            if (stack != null) totals[stack.name] = (totals[stack.name] ?: 0) + stack.count
        }
        for ((name, n) in totals.entries.sortedByDescending { it.value }.take(30)) {
            Text(displayName(name) + "  \u00D7" + n, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun TelemetryCard(vm: AppViewModel) {
    val st = vm.stats
    val lineColor = MaterialTheme.colorScheme.primary
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Connection", style = MaterialTheme.typography.titleMedium)
            Text(
                "Server TPS: " + (if (vm.tps < 0f) "?" else String.format(Locale.US, "%.1f", vm.tps)) +
                    " \u2022 Ping: " + (if (st.latencyMs > 0) "${st.latencyMs} ms" else "?"),
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                String.format(Locale.US, "Download %.1f KB/s \u2022 Upload %.1f KB/s", vm.rxRate / 1024.0, vm.txRate / 1024.0),
                style = MaterialTheme.typography.bodySmall,
            )
            if (vm.pingHistory.size >= 2) {
                val points = vm.pingHistory.toList()
                val maxPing = (points.maxOrNull() ?: 50).coerceAtLeast(50).toFloat()
                Canvas(Modifier.fillMaxWidth().height(60.dp)) {
                    var prev: Offset? = null
                    for (i in points.indices) {
                        val x = this.size.width * i / (points.size - 1)
                        val y = this.size.height * (1f - points[i] / maxPing)
                        val p = Offset(x, y)
                        val before = prev
                        if (before != null) drawLine(lineColor, before, p, strokeWidth = 3f)
                        prev = p
                    }
                }
                Text(
                    "Ping over the last ${points.size} s (peak ${points.maxOrNull() ?: 0} ms)",
                    style = MaterialTheme.typography.labelSmall,
                )
            }
            Text(
                "Facing ${compassName(st.yaw)} (yaw ${st.yaw.toInt()}\u00B0, pitch ${st.pitch.toInt()}\u00B0)",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun ControlsCard(vm: AppViewModel) {
    val st = vm.stats
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Look and stance", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { vm.look(180f, 0f) }) { Text("Face N") }
                FilledTonalButton(onClick = { vm.look(270f, 0f) }) { Text("E") }
                FilledTonalButton(onClick = { vm.look(0f, 0f) }) { Text("S") }
                FilledTonalButton(onClick = { vm.look(90f, 0f) }) { Text("W") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { vm.look(st.yaw - 45f, st.pitch) }) { Text("Left 45") }
                FilledTonalButton(onClick = { vm.look(st.yaw + 45f, st.pitch) }) { Text("Right 45") }
                FilledTonalButton(onClick = { vm.look(st.yaw, st.pitch - 30f) }) { Text("Up") }
                FilledTonalButton(onClick = { vm.look(st.yaw, st.pitch + 30f) }) { Text("Down") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = vm.sneaking, onClick = { vm.toggleSneak() }, label = { Text("Sneak") })
                FilterChip(selected = vm.sprinting, onClick = { vm.toggleSprint() }, label = { Text("Sprint") })
            }
        }
    }
}

@Composable
private fun NotesCard(vm: AppViewModel) {
    val sid = vm.activeServer?.id ?: return
    var note by remember(sid) { mutableStateOf(vm.noteFor(sid)) }
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Notes for this server", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = note,
                onValueChange = { note = it; vm.saveNote(sid, it) },
                minLines = 3,
                label = { Text("Warps, base coordinates, rules\u2026") },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
