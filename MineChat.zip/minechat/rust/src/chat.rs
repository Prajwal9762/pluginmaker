// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
//! Converts Minecraft JSON text components to legacy §-formatted strings
//! (which the Android UI renders with colours and styles).

use serde_json::Value;

#[derive(Clone, Default, PartialEq, Debug)]
struct Style {
    color: Option<String>,
    bold: Option<bool>,
    italic: Option<bool>,
    underlined: Option<bool>,
    strikethrough: Option<bool>,
    obfuscated: Option<bool>,
}

impl Style {
    fn merged(&self, v: &Value) -> Style {
        let mut s = self.clone();
        if let Some(c) = v.get("color").and_then(|c| c.as_str()) {
            s.color = Some(c.to_string());
        }
        let b = |k: &str| v.get(k).and_then(|x| x.as_bool());
        if let Some(x) = b("bold") { s.bold = Some(x); }
        if let Some(x) = b("italic") { s.italic = Some(x); }
        if let Some(x) = b("underlined") { s.underlined = Some(x); }
        if let Some(x) = b("strikethrough") { s.strikethrough = Some(x); }
        if let Some(x) = b("obfuscated") { s.obfuscated = Some(x); }
        s
    }
}

fn color_code(name: &str) -> Option<String> {
    let c = match name {
        "black" => '0', "dark_blue" => '1', "dark_green" => '2', "dark_aqua" => '3',
        "dark_red" => '4', "dark_purple" => '5', "gold" => '6', "gray" => '7',
        "dark_gray" => '8', "blue" => '9', "green" => 'a', "aqua" => 'b',
        "red" => 'c', "light_purple" => 'd', "yellow" => 'e', "white" => 'f',
        _ => {
            if let Some(hex) = name.strip_prefix('#') {
                if hex.len() == 6 && hex.chars().all(|c| c.is_ascii_hexdigit()) {
                    let mut s = String::from("§x");
                    for ch in hex.chars() {
                        s.push('§');
                        s.push(ch.to_ascii_lowercase());
                    }
                    return Some(s);
                }
            }
            return None;
        }
    };
    Some(format!("§{c}"))
}

const TRANSLATIONS: &[(&str, &str)] = &[
    ("chat.type.text", "<%s> %s"),
    ("chat.type.announcement", "[%s] %s"),
    ("chat.type.emote", "* %s %s"),
    ("chat.type.admin", "[%s: %s]"),
    ("chat.type.team.text", "%s <%s> %s"),
    ("chat.type.advancement.task", "%s has made the advancement %s"),
    ("chat.type.advancement.goal", "%s has reached the goal %s"),
    ("chat.type.advancement.challenge", "%s has completed the challenge %s"),
    ("multiplayer.player.joined", "%s joined the game"),
    ("multiplayer.player.left", "%s left the game"),
    ("multiplayer.player.joined.renamed", "%s (formerly known as %s) joined the game"),
    ("commands.message.display.incoming", "%s whispers to you: %s"),
    ("commands.message.display.outgoing", "You whisper to %s: %s"),
    ("death.attack.generic", "%s died"),
    ("death.attack.player", "%s was slain by %s"),
    ("death.attack.mob", "%s was slain by %s"),
    ("death.attack.explosion", "%s blew up"),
    ("death.attack.drown", "%s drowned"),
    ("death.attack.lava", "%s tried to swim in lava"),
    ("death.attack.outOfWorld", "%s fell out of the world"),
    ("death.fell.accident.generic", "%s fell from a high place"),
    ("death.attack.inFire", "%s went up in flames"),
    ("death.attack.starve", "%s starved to death"),
];

struct Writer {
    out: String,
    last: Style,
}

impl Writer {
    fn emit_style(&mut self, eff: &Style) {
        if *eff == self.last {
            return;
        }
        self.out.push_str("§r");
        if let Some(c) = eff.color.as_deref().and_then(color_code) {
            self.out.push_str(&c);
        }
        if eff.obfuscated == Some(true) { self.out.push_str("§k"); }
        if eff.bold == Some(true) { self.out.push_str("§l"); }
        if eff.strikethrough == Some(true) { self.out.push_str("§m"); }
        if eff.underlined == Some(true) { self.out.push_str("§n"); }
        if eff.italic == Some(true) { self.out.push_str("§o"); }
        self.last = eff.clone();
    }

    fn text(&mut self, s: &str, eff: &Style) {
        if s.is_empty() {
            return;
        }
        self.emit_style(eff);
        self.out.push_str(s);
    }

    fn walk(&mut self, v: &Value, parent: &Style, depth: u32) {
        if depth > 32 {
            return;
        }
        match v {
            Value::String(s) => self.text(s, parent),
            Value::Number(n) => self.text(&n.to_string(), parent),
            Value::Bool(b) => self.text(&b.to_string(), parent),
            Value::Array(a) => {
                for item in a {
                    self.walk(item, parent, depth + 1);
                }
            }
            Value::Object(_) => {
                let eff = parent.merged(v);
                if let Some(t) = v.get("text").and_then(|t| t.as_str()) {
                    self.text(t, &eff);
                } else if let Some(key) = v.get("translate").and_then(|t| t.as_str()) {
                    let args: Vec<&Value> = v
                        .get("with")
                        .and_then(|w| w.as_array())
                        .map(|a| a.iter().collect())
                        .unwrap_or_default();
                    let fmt = TRANSLATIONS
                        .iter()
                        .find(|(k, _)| *k == key)
                        .map(|(_, f)| *f)
                        .or_else(|| v.get("fallback").and_then(|f| f.as_str()));
                    match fmt {
                        Some(f) => self.format(f, &args, &eff, depth),
                        None => {
                            self.text(key, &eff);
                            for a in &args {
                                self.text(" ", &eff);
                                self.walk(a, &eff, depth + 1);
                            }
                        }
                    }
                } else if let Some(k) = v.get("keybind").and_then(|t| t.as_str()) {
                    self.text(k, &eff);
                }
                if let Some(extra) = v.get("extra").and_then(|e| e.as_array()) {
                    for e in extra {
                        self.walk(e, &eff, depth + 1);
                    }
                }
            }
            Value::Null => {}
        }
    }

    fn format(&mut self, fmt: &str, args: &[&Value], eff: &Style, depth: u32) {
        let mut lit = String::new();
        let mut next = 0usize;
        let mut chars = fmt.chars().peekable();
        while let Some(c) = chars.next() {
            if c != '%' {
                lit.push(c);
                continue;
            }
            // %s, %%, or %N$s
            let mut num = String::new();
            while let Some(d) = chars.peek() {
                if d.is_ascii_digit() { num.push(*d); chars.next(); } else { break; }
            }
            match chars.peek() {
                Some('$') if !num.is_empty() => {
                    chars.next();
                    if chars.peek() == Some(&'s') { chars.next(); }
                    let idx = num.parse::<usize>().unwrap_or(1).saturating_sub(1);
                    self.text(&std::mem::take(&mut lit), eff);
                    if let Some(a) = args.get(idx) { self.walk(a, eff, depth + 1); }
                }
                Some('s') if num.is_empty() => {
                    chars.next();
                    self.text(&std::mem::take(&mut lit), eff);
                    if let Some(a) = args.get(next) { self.walk(a, eff, depth + 1); }
                    next += 1;
                }
                Some('%') if num.is_empty() => {
                    chars.next();
                    lit.push('%');
                }
                _ => {
                    lit.push('%');
                    lit.push_str(&num);
                }
            }
        }
        self.text(&lit, eff);
    }
}

/// Convert a JSON text component (as a string) to legacy §-codes.
/// Plain (non-JSON) strings are returned unchanged.
pub fn json_to_legacy(s: &str) -> String {
    match serde_json::from_str::<Value>(s) {
        Ok(v) => value_to_legacy(&v),
        Err(_) => s.to_string(),
    }
}

pub fn value_to_legacy(v: &Value) -> String {
    let mut w = Writer { out: String::new(), last: Style::default() };
    w.walk(v, &Style::default(), 0);
    w.out
}

/// Remove all §x formatting codes.
pub fn strip_codes(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut it = s.chars();
    while let Some(c) = it.next() {
        if c == '§' {
            it.next();
        } else {
            out.push(c);
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn plain_and_extra() {
        let j = r#"{"text":"Hello ","color":"red","extra":[{"text":"World","bold":true}]}"#;
        assert_eq!(json_to_legacy(j), "§r§cHello §r§c§lWorld");
        assert_eq!(strip_codes(&json_to_legacy(j)), "Hello World");
    }

    #[test]
    fn plain_string_passthrough() {
        assert_eq!(json_to_legacy("just text"), "just text");
        assert_eq!(json_to_legacy("\"quoted\""), "quoted");
    }

    #[test]
    fn translate_join_and_chat() {
        let j = r#"{"translate":"multiplayer.player.joined","with":[{"text":"Alex"}],"color":"yellow"}"#;
        assert_eq!(strip_codes(&json_to_legacy(j)), "Alex joined the game");
        let c = r#"{"translate":"chat.type.text","with":["Bob","hi there"]}"#;
        assert_eq!(json_to_legacy(c), "<Bob> hi there");
    }

    #[test]
    fn hex_colour_and_unknown_key() {
        let j = r##"{"text":"x","color":"#FF8800"}"##;
        assert_eq!(json_to_legacy(j), "§r§x§f§f§8§8§0§0x");
        let u = r#"{"translate":"some.unknown.key","with":["A"]}"#;
        assert_eq!(json_to_legacy(u), "some.unknown.key A");
    }

    #[test]
    fn unicode_preserved() {
        assert_eq!(json_to_legacy(r#"{"text":"नमस्ते ✓"}"#), "नमस्ते ✓");
    }
}
