// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
//! JNI bridge used by `com.chatcraft.app.Native` (Kotlin). All calls are panic-safe.

use crate::auth::AuthMode;
use crate::session::{self, ConnectParams, Shared};
use crate::status;
use jni::objects::{JObject, JString};
use jni::sys::{jint, jlong, jstring};
use jni::JNIEnv;
use std::collections::HashMap;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::atomic::{AtomicI64, Ordering};
use std::sync::{Arc, Mutex, OnceLock};
use std::time::Duration;

static NEXT_ID: AtomicI64 = AtomicI64::new(1);
static SESSIONS: OnceLock<Mutex<HashMap<i64, Arc<Shared>>>> = OnceLock::new();

fn sessions() -> std::sync::MutexGuard<'static, HashMap<i64, Arc<Shared>>> {
    SESSIONS
        .get_or_init(|| Mutex::new(HashMap::new()))
        .lock()
        .unwrap_or_else(|e| e.into_inner())
}

fn get_string(env: &mut JNIEnv, s: &JString) -> String {
    env.get_string(s).map(|j| j.into()).unwrap_or_default()
}

fn ret(env: &mut JNIEnv, s: String) -> jstring {
    env.new_string(s).map(|j| j.into_raw()).unwrap_or(std::ptr::null_mut())
}

fn err_json(msg: &str) -> String {
    serde_json::json!({ "ok": false, "error": msg }).to_string()
}

/// ping(host, port, timeoutMs) -> JSON {"ok":true,"info":{...}} or {"ok":false,"error":"..."}
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_ping<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    host: JString<'l>,
    port: jint,
    timeout_ms: jint,
) -> jstring {
    let host = get_string(&mut env, &host);
    let out = catch_unwind(AssertUnwindSafe(|| {
        let to = Duration::from_millis(timeout_ms.max(500) as u64);
        match session::runtime().block_on(status::ping(&host, port as u16, to)) {
            Ok(info) => serde_json::json!({ "ok": true, "info": info }).to_string(),
            Err(e) => err_json(&e.to_string()),
        }
    }))
    .unwrap_or_else(|_| err_json("internal error"));
    ret(&mut env, out)
}

/// connect(host, port, username, authMode, autoReconnect) -> session id (>0)
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_connect<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    host: JString<'l>,
    port: jint,
    username: JString<'l>,
    auth_mode: JString<'l>,
    auto_reconnect: jni::sys::jboolean,
    view_distance: jint,
) -> jlong {
    let host = get_string(&mut env, &host);
    let username = get_string(&mut env, &username);
    let auth = AuthMode::parse(&get_string(&mut env, &auth_mode));
    catch_unwind(AssertUnwindSafe(|| {
        let mut p = ConnectParams::offline(&host, port as u16, &username);
        p.auth = auth;
        p.auto_reconnect = auto_reconnect != 0;
        p.view_distance = view_distance.clamp(2, 12) as u8;
        let sh = session::start(p);
        let id = NEXT_ID.fetch_add(1, Ordering::Relaxed);
        sessions().insert(id, sh);
        id
    }))
    .unwrap_or(-1)
}

/// poll(id) -> JSON {"state","detail","events":[...],"stats":{...}}
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_poll<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
) -> jstring {
    let out = catch_unwind(AssertUnwindSafe(|| match sessions().get(&id) {
        Some(s) => s.poll_json(),
        None => err_json("no such session"),
    }))
    .unwrap_or_else(|_| err_json("internal error"));
    ret(&mut env, out)
}

/// sendChat(id, text) -> "" on success, otherwise an error message
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_sendChat<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
    text: JString<'l>,
) -> jstring {
    let text = get_string(&mut env, &text);
    let out = catch_unwind(AssertUnwindSafe(|| {
        let s = sessions().get(&id).cloned();
        match s {
            Some(s) => s.send_chat(&text).err().map(|e| e.to_string()).unwrap_or_default(),
            None => "no such session".to_string(),
        }
    }))
    .unwrap_or_else(|_| "internal error".to_string());
    ret(&mut env, out)
}

/// move(id, dx, dy, dz) -> "" on success, otherwise an error message
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_move<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
    dx: f64,
    dy: f64,
    dz: f64,
) -> jstring {
    let out = catch_unwind(AssertUnwindSafe(|| {
        let s = sessions().get(&id).cloned();
        match s {
            Some(s) => s.move_by(dx, dy, dz).err().map(|e| e.to_string()).unwrap_or_default(),
            None => "no such session".to_string(),
        }
    }))
    .unwrap_or_else(|_| "internal error".to_string());
    ret(&mut env, out)
}

/// disconnect(id): stops the session and forgets it.
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_disconnect<'l>(
    _env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
) {
    let _ = catch_unwind(AssertUnwindSafe(|| {
        if let Some(s) = sessions().remove(&id) {
            s.disconnect();
        }
    }));
}

fn session_call(id: jlong, f: impl FnOnce(&Shared) -> crate::error::Result<()>) -> String {
    catch_unwind(AssertUnwindSafe(|| {
        let s = sessions().get(&id).cloned();
        match s {
            Some(s) => f(&s).err().map(|e| e.to_string()).unwrap_or_default(),
            None => "no such session".to_string(),
        }
    }))
    .unwrap_or_else(|_| "internal error".to_string())
}

/// click(id, windowId, slot, button, mode) -> "" on success, otherwise an error message
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_click<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
    window: jint,
    slot: jint,
    button: jint,
    mode: jint,
) -> jstring {
    let out = session_call(id, |s| s.click_slot(window as u8, slot as i16, button as i8, mode));
    ret(&mut env, out)
}

/// closeWindow(id, windowId) -> "" on success, otherwise an error message
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_closeWindow<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
    window: jint,
) -> jstring {
    let out = session_call(id, |s| s.close_window(window as u8));
    ret(&mut env, out)
}

/// hold(id, hotbarSlot 0-8) -> "" on success, otherwise an error message
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_hold<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
    slot: jint,
) -> jstring {
    let out = session_call(id, |s| s.hold_slot(slot as i16));
    ret(&mut env, out)
}

/// version() -> engine description
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_version<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
) -> jstring {
    ret(
        &mut env,
        format!("chatcraft_core {} (protocol {})", env!("CARGO_PKG_VERSION"), status::PROTOCOL_VERSION),
    )
}

/// complete(id, text) -> JSON {"ok":true,"tx":n} or {"ok":false,"error":"..."}.
/// The suggestions arrive later as a "completions" event with the same tx.
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_complete<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
    text: JString<'l>,
) -> jstring {
    let text = get_string(&mut env, &text);
    let out = catch_unwind(AssertUnwindSafe(|| {
        let s = sessions().get(&id).cloned();
        match s {
            Some(s) => match s.request_completions(&text) {
                Ok(tx) => serde_json::json!({ "ok": true, "tx": tx }).to_string(),
                Err(e) => err_json(&e.to_string()),
            },
            None => err_json("no such session"),
        }
    }))
    .unwrap_or_else(|_| err_json("internal error"));
    ret(&mut env, out)
}

fn int_array(env: &mut JNIEnv, data: &[i32]) -> jni::sys::jintArray {
    match env.new_int_array(data.len() as i32) {
        Ok(arr) => {
            let _ = env.set_int_array_region(&arr, 0, data);
            arr.into_raw()
        }
        Err(_) => std::ptr::null_mut(),
    }
}

/// minimap(id, radiusChunks) -> int[]: [width, height, originX, originZ, ARGB pixels...]
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_minimap<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
    radius: jint,
) -> jni::sys::jintArray {
    let data = catch_unwind(AssertUnwindSafe(|| {
        let s = sessions().get(&id).cloned();
        s.map(|s| s.minimap(radius)).unwrap_or_default()
    }))
    .unwrap_or_default();
    int_array(&mut env, &data)
}

/// mapList(id) -> JSON [{"id":..,"scale":..,"locked":..}]
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_mapList<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
) -> jstring {
    let out = catch_unwind(AssertUnwindSafe(|| {
        let s = sessions().get(&id).cloned();
        s.map(|s| s.map_list_json()).unwrap_or_else(|| "[]".to_string())
    }))
    .unwrap_or_else(|_| "[]".to_string());
    ret(&mut env, out)
}

/// mapPixels(id, mapId) -> int[16384] ARGB (128x128), or empty
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_mapPixels<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
    map_id: jint,
) -> jni::sys::jintArray {
    let data = catch_unwind(AssertUnwindSafe(|| {
        let s = sessions().get(&id).cloned();
        s.map(|s| s.map_pixels(map_id)).unwrap_or_default()
    }))
    .unwrap_or_default();
    int_array(&mut env, &data)
}

/// useItem(id, hand) -> "" on success, otherwise an error message
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_useItem<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
    hand: jint,
) -> jstring {
    let out = catch_unwind(AssertUnwindSafe(|| {
        let s = sessions().get(&id).cloned();
        match s {
            Some(s) => s.use_item(hand).err().map(|e| e.to_string()).unwrap_or_default(),
            None => "no such session".to_string(),
        }
    }))
    .unwrap_or_else(|_| "internal error".to_string());
    ret(&mut env, out)
}

/// swing(id) -> "" on success, otherwise an error message
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_swing<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
) -> jstring {
    let out = catch_unwind(AssertUnwindSafe(|| {
        let s = sessions().get(&id).cloned();
        match s {
            Some(s) => s.swing().err().map(|e| e.to_string()).unwrap_or_default(),
            None => "no such session".to_string(),
        }
    }))
    .unwrap_or_else(|_| "internal error".to_string());
    ret(&mut env, out)
}

/// interact(id, x, y, z, face) -> "" on success, otherwise an error message
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_interact<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
    x: jint,
    y: jint,
    z: jint,
    face: jint,
) -> jstring {
    let out = catch_unwind(AssertUnwindSafe(|| {
        let s = sessions().get(&id).cloned();
        match s {
            Some(s) => s.interact_block(x, y, z, face).err().map(|e| e.to_string()).unwrap_or_default(),
            None => "no such session".to_string(),
        }
    }))
    .unwrap_or_else(|_| "internal error".to_string());
    ret(&mut env, out)
}

/// entities(id) -> JSON list of nearby entities for the radar
#[no_mangle]
pub extern "system" fn Java_com_chatcraft_app_Native_entities<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jlong,
) -> jstring {
    let out = catch_unwind(AssertUnwindSafe(|| {
        let s = sessions().get(&id).cloned();
        s.map(|s| s.entities_json()).unwrap_or_else(|| "[]".to_string())
    }))
    .unwrap_or_else(|_| "[]".to_string());
    ret(&mut env, out)
}
