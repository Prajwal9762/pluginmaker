// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
//! Sidebar scoreboard state (objectives, scores and teams) rebuilt from server packets.

use std::collections::{HashMap, HashSet};

#[derive(Default)]
struct Team {
    prefix: String,
    suffix: String,
    players: HashSet<String>,
}

#[derive(Default)]
pub struct Scoreboard {
    objectives: HashMap<String, String>,
    scores: HashMap<String, HashMap<String, i32>>,
    teams: HashMap<String, Team>,
    sidebar: Option<String>,
}

impl Scoreboard {
    /// action: 0 create, 1 remove, 2 update display text
    pub fn objective(&mut self, name: &str, action: i8, title: Option<String>) {
        match action {
            1 => {
                self.objectives.remove(name);
                self.scores.remove(name);
                if self.sidebar.as_deref() == Some(name) {
                    self.sidebar = None;
                }
            }
            _ => {
                self.objectives.insert(name.to_string(), title.unwrap_or_default());
            }
        }
    }

    /// position 1 is the sidebar; an empty name clears that slot.
    pub fn display(&mut self, position: i8, name: &str) {
        if position == 1 {
            self.sidebar = if name.is_empty() { None } else { Some(name.to_string()) };
        }
    }

    pub fn score(&mut self, entry: &str, action: i32, objective: &str, value: i32) {
        if action == 1 {
            if objective.is_empty() {
                for s in self.scores.values_mut() {
                    s.remove(entry);
                }
            } else if let Some(s) = self.scores.get_mut(objective) {
                s.remove(entry);
            }
        } else {
            self.scores.entry(objective.to_string()).or_default().insert(entry.to_string(), value);
        }
    }

    /// mode: 0 create, 1 remove, 2 update info, 3 add players, 4 remove players
    pub fn team(&mut self, name: &str, mode: i8, info: Option<(String, String)>, players: Vec<String>) {
        match mode {
            1 => {
                self.teams.remove(name);
            }
            0 | 2 => {
                let t = self.teams.entry(name.to_string()).or_default();
                if let Some((p, s)) = info {
                    t.prefix = p;
                    t.suffix = s;
                }
                if mode == 0 {
                    t.players = players.into_iter().collect();
                }
            }
            3 => {
                self.teams.entry(name.to_string()).or_default().players.extend(players);
            }
            4 => {
                if let Some(t) = self.teams.get_mut(name) {
                    for p in players {
                        t.players.remove(&p);
                    }
                }
            }
            _ => {}
        }
    }

    /// Title and up to 15 lines (highest score first) of the sidebar, if one is shown.
    pub fn sidebar_lines(&self) -> Option<(String, Vec<(String, i32)>)> {
        let obj = self.sidebar.as_ref()?;
        let title = self.objectives.get(obj).cloned().unwrap_or_default();
        let mut rows: Vec<(String, i32)> = self
            .scores
            .get(obj)
            .map(|m| m.iter().map(|(e, v)| (self.decorate(e), *v)).collect())
            .unwrap_or_default();
        rows.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(&b.0)));
        rows.truncate(15);
        Some((title, rows))
    }

    fn decorate(&self, entry: &str) -> String {
        for t in self.teams.values() {
            if t.players.contains(entry) {
                return format!("{}{}{}", t.prefix, entry, t.suffix);
            }
        }
        entry.to_string()
    }

    pub fn clear(&mut self) {
        *self = Scoreboard::default();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sidebar_with_team_prefix_and_ordering() {
        let mut sb = Scoreboard::default();
        assert!(sb.sidebar_lines().is_none());
        sb.objective("side", 0, Some("Title".into()));
        sb.display(1, "side");
        sb.score("a", 0, "side", 1);
        sb.score("b", 0, "side", 5);
        sb.team("t1", 0, Some(("[P] ".into(), "!".into())), vec!["a".into()]);
        let (title, rows) = sb.sidebar_lines().unwrap();
        assert_eq!(title, "Title");
        assert_eq!(rows, vec![("b".to_string(), 5), ("[P] a!".to_string(), 1)]);
        sb.score("b", 1, "side", 0);
        assert_eq!(sb.sidebar_lines().unwrap().1.len(), 1);
        sb.team("t1", 4, None, vec!["a".into()]);
        assert_eq!(sb.sidebar_lines().unwrap().1[0].0, "a");
        sb.display(1, "");
        assert!(sb.sidebar_lines().is_none());
    }

    #[test]
    fn removing_objective_clears_sidebar() {
        let mut sb = Scoreboard::default();
        sb.objective("o", 0, Some("T".into()));
        sb.display(1, "o");
        sb.score("x", 0, "o", 3);
        sb.objective("o", 1, None);
        assert!(sb.sidebar_lines().is_none());
    }
}
