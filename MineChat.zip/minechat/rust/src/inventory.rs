// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
//! Player inventory and container windows (protocol 763).
//!
//! The server is authoritative: clicks are sent without a client-side prediction and the
//! server answers with the real slot contents, which this module mirrors.

use crate::chat;
use crate::codec::{read_nbt_json, Reader};
use crate::error::Result;
use crate::items::item_name;
use serde_json::{json, Value};

#[derive(Clone, Debug, PartialEq)]
pub struct ItemStack {
    pub id: i32,
    pub count: i32,
    /// Custom display name (section-sign coded), e.g. shop/menu buttons.
    pub custom_name: Option<String>,
    /// Lore lines (section-sign coded).
    pub lore: Vec<String>,
    pub enchanted: bool,
}

impl ItemStack {
    pub fn new(id: i32, count: i32) -> ItemStack {
        ItemStack { id, count, custom_name: None, lore: Vec::new(), enchanted: false }
    }

    fn to_json(&self) -> Value {
        json!({
            "id": self.id,
            "name": item_name(self.id),
            "count": self.count,
            "custom_name": self.custom_name,
            "lore": self.lore,
            "enchanted": self.enchanted,
        })
    }
}

fn apply_nbt(s: &mut ItemStack, root: &Value) {
    if let Some(d) = root.get("display") {
        if let Some(n) = d.get("Name").and_then(|v| v.as_str()) {
            s.custom_name = Some(chat::json_to_legacy(n));
        }
        if let Some(l) = d.get("Lore").and_then(|v| v.as_array()) {
            s.lore = l.iter().filter_map(|x| x.as_str()).take(24).map(chat::json_to_legacy).collect();
        }
    }
    let has = |k: &str| root.get(k).and_then(|v| v.as_array()).map(|a| !a.is_empty()).unwrap_or(false);
    s.enchanted = has("Enchantments") || has("StoredEnchantments");
}

/// Reads a 1.20.1 item slot, extracting the custom name, lore and enchanted flag from NBT.
pub fn read_slot(r: &mut Reader) -> Result<Option<ItemStack>> {
    if !r.read_bool()? {
        return Ok(None);
    }
    let id = r.read_varint()?;
    let count = r.read_i8()? as i32;
    let mut stack = ItemStack::new(id, count);
    if let Some(root) = read_nbt_json(r)? {
        apply_nbt(&mut stack, &root);
    }
    Ok(Some(stack))
}

#[derive(Clone, Debug)]
pub struct Window {
    pub id: u8,
    pub title: String,
    pub kind: i32,
    pub state_id: i32,
    pub slots: Vec<Option<ItemStack>>,
}

impl Window {
    fn player() -> Window {
        Window { id: 0, title: "Inventory".into(), kind: -1, state_id: 0, slots: vec![None; 46] }
    }

    fn set(&mut self, slot: i16, item: Option<ItemStack>) {
        if slot < 0 || slot as usize > 512 {
            return;
        }
        let s = slot as usize;
        if s >= self.slots.len() {
            self.slots.resize(s + 1, None);
        }
        self.slots[s] = item;
    }
}

pub struct InvState {
    pub player: Window,
    pub open: Option<Window>,
    pub cursor: Option<ItemStack>,
    pub held: i32,
    pub version: u64,
    pub loaded: bool,
}

impl InvState {
    pub fn new() -> InvState {
        InvState { player: Window::player(), open: None, cursor: None, held: 0, version: 0, loaded: false }
    }

    fn bump(&mut self) {
        self.version += 1;
    }

    pub fn window_by_id(&self, id: u8) -> Option<&Window> {
        if id == 0 {
            Some(&self.player)
        } else {
            self.open.as_ref().filter(|w| w.id == id)
        }
    }

    pub fn current(&self) -> &Window {
        self.open.as_ref().unwrap_or(&self.player)
    }

    fn window_mut(&mut self, id: u8) -> &mut Window {
        if id == 0 {
            return &mut self.player;
        }
        let missing = self.open.as_ref().map(|w| w.id != id).unwrap_or(true);
        if missing {
            self.open = Some(Window { id, title: "Container".into(), kind: -1, state_id: 0, slots: vec![] });
        }
        self.open.as_mut().expect("just set")
    }

    pub fn apply_items(&mut self, window_id: u8, state_id: i32, items: Vec<Option<ItemStack>>, carried: Option<ItemStack>) {
        let w = self.window_mut(window_id);
        w.state_id = state_id;
        w.slots = items;
        self.cursor = carried;
        self.loaded = true;
        self.bump();
    }

    pub fn apply_set_slot(&mut self, window_id: i8, state_id: i32, slot: i16, item: Option<ItemStack>) {
        match window_id {
            -1 => self.cursor = item,
            -2 => self.player.set(slot, item),
            id if id >= 0 => {
                let w = self.window_mut(id as u8);
                w.state_id = state_id;
                w.set(slot, item);
            }
            _ => return,
        }
        self.loaded = true;
        self.bump();
    }

    pub fn open_window(&mut self, id: u8, kind: i32, title: String) {
        self.open = Some(Window { id, title, kind, state_id: 0, slots: vec![] });
        self.bump();
    }

    pub fn close_window(&mut self, id: u8) {
        if self.open.as_ref().map(|w| w.id == id).unwrap_or(false) {
            self.open = None;
            self.bump();
        }
    }

    pub fn set_held(&mut self, slot: i32) {
        self.held = slot;
        self.bump();
    }

    pub fn snapshot(&self) -> Value {
        let w = self.current();
        json!({
            "window_id": w.id,
            "title": w.title,
            "kind": w.kind,
            "state_id": w.state_id,
            "slots": w.slots.iter().map(|s| s.as_ref().map(|i| i.to_json())).collect::<Vec<_>>(),
            "cursor": self.cursor.as_ref().map(|i| i.to_json()),
            "held": self.held,
        })
    }
}

/// Window title (JSON text component) to plain text.
pub fn plain_title(json: &str) -> String {
    chat::strip_codes(&chat::json_to_legacy(json))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::codec::*;

    #[test]
    fn reads_slots_with_and_without_nbt() {
        let mut b = Vec::new();
        b.push(0); // empty
        b.push(1);
        write_varint(&mut b, 5);
        b.push(3);
        b.push(0); // no NBT
        b.push(1);
        write_varint(&mut b, 9);
        b.push(1);
        b.extend_from_slice(&[10, 0, 0, 3, 0, 1, b'x', 0, 0, 0, 7, 0]); // NBT {x:7}
        b.push(0xEE);
        let mut r = Reader::new(&b);
        assert_eq!(read_slot(&mut r).unwrap(), None);
        assert_eq!(read_slot(&mut r).unwrap(), Some(ItemStack::new(5, 3)));
        assert_eq!(read_slot(&mut r).unwrap(), Some(ItemStack::new(9, 1)));
        assert_eq!(r.read_u8().unwrap(), 0xEE);
    }

    #[test]
    fn slot_with_display_name_and_lore() {
        let mut b = vec![1];
        write_varint(&mut b, 5);
        b.push(2);
        b.extend_from_slice(&[10, 0, 0, 10, 0, 7]);
        b.extend_from_slice(b"display");
        b.extend_from_slice(&[8, 0, 4]);
        b.extend_from_slice(b"Name");
        let name = r#"{"text":"Buy","color":"green"}"#;
        b.extend_from_slice(&(name.len() as u16).to_be_bytes());
        b.extend_from_slice(name.as_bytes());
        b.extend_from_slice(&[9, 0, 4]);
        b.extend_from_slice(b"Lore");
        let lore = r#"{"text":"$10"}"#;
        b.extend_from_slice(&[8, 0, 0, 0, 1]);
        b.extend_from_slice(&(lore.len() as u16).to_be_bytes());
        b.extend_from_slice(lore.as_bytes());
        b.push(0);
        b.push(0);
        let item = read_slot(&mut Reader::new(&b)).unwrap().unwrap();
        assert_eq!(item.count, 2);
        assert_eq!(item.custom_name.as_deref(), Some("\u{a7}r\u{a7}aBuy"));
        assert_eq!(item.lore, vec!["$10".to_string()]);
        assert!(!item.enchanted);
    }

    #[test]
    fn windows_open_update_close() {
        let mut s = InvState::new();
        let mut items = vec![None; 46];
        items[36] = Some(ItemStack::new(1, 64));
        s.apply_items(0, 7, items, None);
        assert_eq!(s.player.state_id, 7);
        s.apply_set_slot(0, 8, 37, Some(ItemStack::new(2, 2)));
        assert_eq!(s.player.slots[37], Some(ItemStack::new(2, 2)));
        s.open_window(3, 2, "Chest".into());
        s.apply_items(3, 1, vec![None; 63], None);
        assert_eq!(s.current().id, 3);
        s.apply_set_slot(-1, 0, -1, Some(ItemStack::new(4, 1)));
        assert_eq!(s.cursor, Some(ItemStack::new(4, 1)));
        s.close_window(3);
        assert_eq!(s.current().id, 0);
    }

    #[test]
    fn item_names_resolve() {
        assert_eq!(item_name(0), "air");
        assert_eq!(item_name(-5), "unknown");
        assert!(crate::items::ITEM_NAMES.contains(&"diamond_sword"));
    }
}
