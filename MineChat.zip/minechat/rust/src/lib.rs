// Copyright (c) 2026 ZORVI Studios. All rights reserved. See LICENSE.
//! MineChat core: a from-scratch Minecraft Java protocol client written in Rust.
//! Targets protocol 763 (Minecraft 1.20.1). Offline-mode login only.

pub mod auth;
pub mod blocks;
pub mod chat;
pub mod codec;
pub mod collision;
pub mod error;
pub mod ffi;
pub mod hud;
pub mod inventory;
pub mod items;
pub mod maps;
pub mod physics;
pub mod session;
pub mod srv;
pub mod status;
pub mod world;
