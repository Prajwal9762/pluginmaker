// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
//! In-game map items (clientbound "map" packet): 128x128 palette-indexed pixels.

const BASE: [u32; 62] = [
    0x000000, 0x7FB238, 0xF7E9A3, 0xC7C7C7, 0xFF0000, 0xA0A0FF, 0xA7A7A7, 0x007C00, 0xFFFFFF, 0xA4A8B8,
    0x976D4D, 0x707070, 0x4040FF, 0x8F7748, 0xFFFCF5, 0xD87F33, 0xB24CD8, 0x6699D8, 0xE5E533, 0x7FCC19,
    0xF27FA5, 0x4C4C4C, 0x999999, 0x4C7F99, 0x7F3FB2, 0x334CB2, 0x664C33, 0x667F33, 0x993333, 0x191919,
    0xFAEE4D, 0x5CDBD5, 0x4A80FF, 0x00D93A, 0x815631, 0x700200, 0xD1B1A1, 0x9F5224, 0x95576C, 0x706C8A,
    0xBA8524, 0x677535, 0xA04D4E, 0x392923, 0x876B62, 0x575C5C, 0x7A4958, 0x4C3E5C, 0x4C3223, 0x4C522A,
    0x8E3C2E, 0x251610, 0xBD3031, 0x943F61, 0x5C191D, 0x167E86, 0x3A8E8C, 0x562C3E, 0x14B485, 0x646464,
    0xD8AF93, 0x7FA796,
];

/// ARGB colour for a map pixel value (0 = transparent).
pub fn color(index: u8) -> u32 {
    let base = (index / 4) as usize;
    if base == 0 || base >= BASE.len() {
        return 0;
    }
    let m = [180u32, 220, 255, 135][(index % 4) as usize];
    let c = BASE[base];
    let (r, g, b) = ((c >> 16) & 255, (c >> 8) & 255, c & 255);
    0xFF00_0000 | ((r * m / 255) << 16) | ((g * m / 255) << 8) | (b * m / 255)
}

pub struct MapData {
    pub scale: i8,
    pub locked: bool,
    pub pixels: Vec<u8>,
}

impl MapData {
    pub fn new() -> MapData {
        MapData { scale: 0, locked: false, pixels: vec![0; 128 * 128] }
    }

    /// Copy a `cols` x `rows` patch at (x, y) into the map.
    pub fn apply(&mut self, x: usize, y: usize, cols: usize, rows: usize, data: &[u8]) {
        for row in 0..rows {
            for col in 0..cols {
                let (px, py) = (x + col, y + row);
                if px < 128 && py < 128 {
                    if let Some(v) = data.get(row * cols + col) {
                        self.pixels[py * 128 + px] = *v;
                    }
                }
            }
        }
    }

    pub fn argb(&self) -> Vec<i32> {
        self.pixels.iter().map(|&p| color(p) as i32).collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn colours_and_shades() {
        assert_eq!(color(0), 0);
        assert_eq!(color(3), 0);
        // base 1 (grass) shade 2 is the unmodified colour
        assert_eq!(color(4 + 2), 0xFF7FB238);
        assert_eq!(color(4) >> 24, 0xFF);
        assert!(color(4 + 3) != color(4 + 2));
        assert_eq!(color(255), 0); // base 63 does not exist
    }

    #[test]
    fn patch_is_applied_and_clipped() {
        let mut m = MapData::new();
        m.apply(126, 127, 4, 2, &[6, 6, 6, 6, 6, 6, 6, 6]);
        assert_eq!(m.pixels[127 * 128 + 126], 6);
        assert_eq!(m.pixels[127 * 128 + 127], 6);
        assert_eq!(m.pixels[0], 0);
        assert_eq!(m.argb().len(), 128 * 128);
    }
}
