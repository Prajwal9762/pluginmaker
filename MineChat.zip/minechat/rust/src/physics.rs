// Copyright (c) 2026 ZORVI Studios. All rights reserved. See LICENSE.
//! Survival movement: gravity, jumping, collisions with real blocks, sneaking at edges, ladders,
//! water and a reach/line-of-sight check for right-clicking blocks. Nothing here lets the player
//! fly, walk through blocks or teleport, so the movement stays inside what survival servers accept.

use crate::blocks;
use crate::collision;
use crate::world::World;

const HALF_W: f64 = 0.3;
const EPS: f64 = 1e-4;
const SPEED: f64 = 0.1; // movement speed attribute (walking)
const INPUT: f64 = 0.98; // strength of a pressed direction key
const GROUND_DRAG: f64 = 0.546; // 0.6 block slipperiness * 0.91
const AIR_DRAG: f64 = 0.91;
const STEP: f64 = 0.6;
/// How far a block can be right-clicked (the survival reach).
pub const REACH: f64 = 4.5;
/// Longest drop that safe walking allows.
const SAFE_DROP: f64 = 3.0;

#[derive(Clone, Copy, Default, Debug, PartialEq)]
pub struct Input {
    pub forward: i8,
    pub strafe: i8,
    pub jump: bool,
    pub sneak: bool,
    pub sprint: bool,
}

#[derive(Clone, Copy, Debug)]
pub struct Body {
    pub x: f64,
    pub y: f64,
    pub z: f64,
    pub vx: f64,
    pub vy: f64,
    pub vz: f64,
    pub on_ground: bool,
    /// Ticks until holding jump starts another jump (the game waits 10).
    pub jump_delay: u8,
}

impl Body {
    pub fn at(x: f64, y: f64, z: f64) -> Body {
        Body { x, y, z, vx: 0.0, vy: 0.0, vz: 0.0, on_ground: false, jump_delay: 0 }
    }
}

pub struct Params {
    pub input: Input,
    pub yaw: f32,
    pub can_sprint: bool,
    /// Safe walking: do not step off long drops or into lava, fire, cactus and similar.
    pub safe: bool,
}

#[derive(Default, Debug, PartialEq)]
pub struct Outcome {
    /// Position or ground state changed, so the server needs a movement packet.
    pub moved: bool,
    /// The player is inside a block or in an unloaded chunk; nothing was simulated.
    pub idle: bool,
    pub blocked: Option<&'static str>,
}

fn cell(v: f64) -> i32 {
    v.floor() as i32
}

/// True when a player box with its feet at (x, y, z) overlaps a block. Unloaded chunks count as solid.
fn collides(world: &World, x: f64, y: f64, z: f64, height: f64) -> bool {
    let (x0, x1) = (cell(x - HALF_W + EPS), cell(x + HALF_W - EPS));
    let (z0, z1) = (cell(z - HALF_W + EPS), cell(z + HALF_W - EPS));
    let (y0, y1) = (cell(y) - 1, cell(y + height - EPS));
    for bx in x0..=x1 {
        for bz in z0..=z1 {
            for by in y0..=y1 {
                let Some(state) = world.block(bx, by, bz) else { return true };
                let h = collision::height(state);
                if h > 0.0 && (by as f64 + h) > y + EPS && (by as f64) < y + height - EPS {
                    return true;
                }
            }
        }
    }
    false
}

fn block_at(world: &World, x: f64, y: f64, z: f64) -> u32 {
    world.block(cell(x), cell(y), cell(z)).unwrap_or(0)
}

/// What is ahead of a candidate position, for safe walking.
fn unsafe_reason(world: &World, x: f64, y: f64, z: f64, height: f64) -> Option<&'static str> {
    // dangerous block in the player's own space
    for dy in [0.0, 1.0] {
        if collision::is_danger(block_at(world, x, y + dy, z)) {
            return Some("Stopped: dangerous block ahead (lava, fire, cactus). Turn off Safe walking to continue");
        }
    }
    // find what we would land on
    let mut d = 0.0;
    while d <= SAFE_DROP + 0.5 {
        if collides(world, x, y - d, z, height) {
            let below = block_at(world, x, y - d - 0.5, z);
            if collision::is_danger(below) {
                return Some("Stopped: dangerous block ahead (lava, fire, cactus...)");
            }
            return None;
        }
        d += 0.1;
    }
    Some("Stopped: drop of more than 3 blocks ahead (turn off Safe walking to go down)")
}

fn move_y(world: &World, b: &mut Body, height: f64) -> bool {
    let target = b.y + b.vy;
    if !collides(world, b.x, target, b.z, height) {
        b.y = target;
        return false;
    }
    let (mut lo, mut hi) = (b.y, target);
    for _ in 0..18 {
        let mid = (lo + hi) / 2.0;
        if collides(world, b.x, mid, b.z, height) {
            hi = mid;
        } else {
            lo = mid;
        }
    }
    b.y = lo;
    true
}

/// Advance the player by one tick (50 ms) with the same acceleration, friction, gravity and jump
/// rules as the game, so servers with movement checks see a normal player.
pub fn tick(world: &World, b: &mut Body, p: &Params) -> Outcome {
    let height = if p.input.sneak { 1.5 } else { 1.8 };
    if collides(world, b.x, b.y, b.z, height) {
        return Outcome { idle: true, ..Default::default() };
    }
    let before = (b.x, b.y, b.z, b.on_ground);
    let feet = block_at(world, b.x, b.y, b.z);
    let in_water = blocks::is_water(feet);
    let in_lava = collision::is_lava(feet);
    let climbing = collision::is_climbable(feet);
    let sprinting = p.input.sprint && p.can_sprint && p.input.forward > 0 && !p.input.sneak;
    let was_ground = b.on_ground;
    let yaw = (p.yaw as f64).to_radians();
    let mut out = Outcome::default();

    // the game zeroes tiny velocities every tick
    for v in [&mut b.vx, &mut b.vy, &mut b.vz] {
        if v.abs() < 0.003 {
            *v = 0.0;
        }
    }

    // jumping: holding the key jumps again after 10 ticks; swimming pushes up
    if b.jump_delay > 0 {
        b.jump_delay -= 1;
    }
    if p.input.jump {
        if in_water || in_lava {
            b.vy += 0.04;
        } else if was_ground && b.jump_delay == 0 {
            b.vy = 0.42;
            if sprinting {
                b.vx += -yaw.sin() * 0.2;
                b.vz += yaw.cos() * 0.2;
            }
            b.jump_delay = 10;
        }
    } else {
        b.jump_delay = 0;
    }

    // acceleration from the pressed keys (sneaking scales the keys by 0.3)
    let mut f = p.input.forward as f64 * INPUT;
    let mut s = p.input.strafe as f64 * INPUT;
    if p.input.sneak {
        f *= 0.3;
        s *= 0.3;
    }
    let len2 = f * f + s * s;
    if len2 >= 1e-7 {
        if len2 > 1.0 {
            let l = len2.sqrt();
            f /= l;
            s /= l;
        }
        let accel = if in_water || in_lava {
            0.02
        } else if was_ground {
            SPEED * if sprinting { 1.3 } else { 1.0 }
        } else if sprinting {
            0.026
        } else {
            0.02
        };
        b.vx += (-yaw.sin() * f - yaw.cos() * s) * accel;
        b.vz += (yaw.cos() * f - yaw.sin() * s) * accel;
    }

    if climbing {
        b.vx = b.vx.clamp(-0.15, 0.15);
        b.vz = b.vz.clamp(-0.15, 0.15);
        b.vy = b.vy.max(-0.15);
        if p.input.jump {
            b.vy = 0.2;
        } else if p.input.sneak && b.vy < 0.0 {
            b.vy = 0.0;
        }
    }

    // move: vertical first, then X, then Z (the order the game uses)
    let blocked_y = move_y(world, b, height);
    if blocked_y {
        b.on_ground = b.vy < 0.0;
        b.vy = 0.0;
    } else {
        b.on_ground = false;
    }

    for axis in 0..2 {
        let d = if axis == 0 { b.vx } else { b.vz };
        if d.abs() < 1e-9 {
            continue;
        }
        let mut cand = *b;
        if axis == 0 { cand.x += d } else { cand.z += d }
        let mut hit_wall = false;
        let mut did_step = false;
        if collides(world, cand.x, cand.y, cand.z, height) {
            // step up small ledges (slabs, carpets) while standing on the ground
            let mut stepped = false;
            if was_ground || b.on_ground {
                let mut up = 0.0625;
                while up <= STEP + 1e-9 {
                    if !collides(world, cand.x, cand.y + up, cand.z, height) {
                        cand.y += up;
                        stepped = true;
                        did_step = true;
                        break;
                    }
                    up += 0.0625;
                }
            }
            if !stepped {
                hit_wall = true;
            }
        }
        if hit_wall {
            if axis == 0 { b.vx = 0.0 } else { b.vz = 0.0 }
            continue;
        }
        let grounded = b.on_ground || was_ground;
        // sneaking never walks off an edge
        if p.input.sneak && grounded && !collides(world, cand.x, cand.y - STEP, cand.z, height) {
            if axis == 0 { b.vx = 0.0 } else { b.vz = 0.0 }
            continue;
        }
        if p.safe && !p.input.sneak {
            if let Some(reason) = unsafe_reason(world, cand.x, cand.y, cand.z, height) {
                // only refuse moves that make things worse (already-unsafe spots can be left)
                if unsafe_reason(world, b.x, b.y, b.z, height).is_none() {
                    out.blocked = Some(reason);
                    if axis == 0 { b.vx = 0.0 } else { b.vz = 0.0 }
                    continue;
                }
            }
        }
        *b = cand;
        if did_step {
            b.on_ground = true;
            b.vy = 0.0;
        }
    }

    // friction and gravity for the next tick
    if in_water {
        b.vx *= 0.8;
        b.vy = b.vy * 0.8 - 0.005;
        b.vz *= 0.8;
    } else if in_lava {
        b.vx *= 0.5;
        b.vy = b.vy * 0.5 - 0.005;
        b.vz *= 0.5;
    } else {
        let drag = if was_ground { GROUND_DRAG } else { AIR_DRAG };
        b.vx *= drag;
        b.vz *= drag;
        b.vy = (b.vy - 0.08) * 0.98;
        if climbing {
            b.vy = b.vy.max(-0.15);
        }
    }
    out.moved = (b.x - before.0).abs() > 1e-9
        || (b.y - before.1).abs() > 1e-9
        || (b.z - before.2).abs() > 1e-9
        || b.on_ground != before.3;
    out
}

/// Checks that the block at `target` can be right-clicked from `eye` (within reach and not behind
/// another solid block). Returns the face that was hit (0 down, 1 up, 2 north, 3 south, 4 west, 5 east).
pub fn raycast_to_block(
    world: &World,
    eye: (f64, f64, f64),
    target: (i32, i32, i32),
    max: f64,
) -> Result<u8, &'static str> {
    let center = (target.0 as f64 + 0.5, target.1 as f64 + 0.5, target.2 as f64 + 0.5);
    let d = (center.0 - eye.0, center.1 - eye.1, center.2 - eye.2);
    let dist = (d.0 * d.0 + d.1 * d.1 + d.2 * d.2).sqrt();
    if dist > max {
        return Err("Too far away: move closer (reach is about 4.5 blocks)");
    }
    let steps = ((dist / 0.02).ceil() as usize).max(1);
    let mut prev = (cell(eye.0), cell(eye.1), cell(eye.2));
    for i in 1..=steps {
        let t = i as f64 / steps as f64;
        let c = (cell(eye.0 + d.0 * t), cell(eye.1 + d.1 * t), cell(eye.2 + d.2 * t));
        if c == prev {
            continue;
        }
        if c == target {
            let diff = (prev.0 - target.0, prev.1 - target.1, prev.2 - target.2);
            let (ax, ay, az) = (diff.0.abs(), diff.1.abs(), diff.2.abs());
            return Ok(if ay >= ax && ay >= az {
                if diff.1 > 0 { 1 } else { 0 }
            } else if az >= ax {
                if diff.2 > 0 { 3 } else { 2 }
            } else if diff.0 > 0 {
                5
            } else {
                4
            });
        }
        match world.block(c.0, c.1, c.2) {
            None => return Err("That area has not loaded yet"),
            Some(s) if collision::height16(s) > 0 => return Err("Another block is in the way"),
            Some(_) => {}
        }
        prev = c;
    }
    Ok(1)
}

/// Yaw and pitch (degrees, game convention) that look from `eye` at `target`.
pub fn look_at(eye: (f64, f64, f64), target: (f64, f64, f64)) -> (f32, f32) {
    let (dx, dy, dz) = (target.0 - eye.0, target.1 - eye.1, target.2 - eye.2);
    let yaw = (-dx).atan2(dz).to_degrees();
    let pitch = (-dy).atan2((dx * dx + dz * dz).sqrt()).to_degrees();
    (yaw as f32, pitch as f32)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::world::Chunk;

    /// Flat stone world whose top surface is at y = 64 (stone fills up to y = 63).
    fn flat_world() -> World {
        let mut w = World::default();
        for cx in -2..=2 {
            for cz in -2..=2 {
                w.insert(cx, cz, Chunk::from_fn(12, |_, yi, _| if (yi as i32) - 64 <= 63 { 1 } else { 0 }));
            }
        }
        w
    }

    fn run(w: &World, b: &mut Body, input: Input, ticks: usize, safe: bool) -> Vec<Outcome> {
        let p = Params { input, yaw: 0.0, can_sprint: true, safe };
        (0..ticks).map(|_| tick(w, b, &p)).collect()
    }

    #[test]
    fn falls_and_lands_on_the_ground() {
        let w = flat_world();
        let mut b = Body::at(0.5, 70.0, 0.5);
        run(&w, &mut b, Input::default(), 60, true);
        assert!((b.y - 64.0).abs() < 0.01, "landed at {}", b.y);
        assert!(b.on_ground);
    }

    #[test]
    fn jump_height_is_about_one_and_a_quarter_blocks() {
        let w = flat_world();
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 3, true);
        let mut top: f64 = 64.0;
        let jump = Input { jump: true, ..Default::default() };
        let p = Params { input: jump, yaw: 0.0, can_sprint: true, safe: true };
        tick(&w, &mut b, &p);
        let idle = Params { input: Input::default(), yaw: 0.0, can_sprint: true, safe: true };
        for _ in 0..30 {
            tick(&w, &mut b, &idle);
            top = top.max(b.y);
        }
        assert!(top > 65.2 && top < 65.35, "apex {top}");
        assert!((b.y - 64.0).abs() < 0.01 && b.on_ground);
    }

    /// Distance walked along +Z during the last `window` ticks after `warmup` ticks of walking.
    fn steady_speed(input: Input, warmup: usize, window: usize) -> f64 {
        let w = flat_world();
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 3, false);
        run(&w, &mut b, input, warmup, false);
        let z0 = b.z;
        run(&w, &mut b, input, window, false);
        (b.z - z0) / window as f64
    }

    #[test]
    fn walking_accelerates_like_the_game() {
        let w = flat_world();
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 3, false);
        let z0 = b.z;
        run(&w, &mut b, Input { forward: 1, ..Default::default() }, 1, false);
        // the first tick from standing still moves 0.098 blocks
        assert!((b.z - z0 - 0.098).abs() < 0.001, "first tick {}", b.z - z0);
        // and the steady walking speed is 4.317 blocks per second (0.2158 per tick)
        let v = steady_speed(Input { forward: 1, ..Default::default() }, 60, 20);
        assert!((v - 0.2158).abs() < 0.002, "walking {v}");
    }

    #[test]
    fn sprint_and_sneak_speeds_match_the_game() {
        let sprint = steady_speed(Input { forward: 1, sprint: true, ..Default::default() }, 60, 20);
        assert!((sprint - 0.2806).abs() < 0.003, "sprint {sprint}"); // 5.612 blocks per second
        let sneak = steady_speed(Input { forward: 1, sneak: true, ..Default::default() }, 60, 20);
        assert!((sneak - 0.0647).abs() < 0.002, "sneak {sneak}"); // 1.3 blocks per second
    }

    #[test]
    fn one_second_of_walking_moves_several_blocks() {
        let w = flat_world();
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 3, false);
        let z0 = b.z;
        run(&w, &mut b, Input { forward: 1, ..Default::default() }, 20, false);
        assert!(b.z - z0 > 3.0, "only {} blocks in a second", b.z - z0);
    }

    #[test]
    fn falls_into_a_wide_hole_and_reaches_the_bottom() {
        let mut w = flat_world();
        for x in -1..=1 {
            for z in 5..=7 {
                for y in 50..64 {
                    w.set_block(x, y, z, 0);
                }
            }
        }
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 3, false);
        run(&w, &mut b, Input { forward: 1, ..Default::default() }, 150, false);
        assert!((b.y - 50.0).abs() < 0.02 && b.on_ground, "ended at y = {}", b.y);
    }

    #[test]
    fn falls_down_a_one_block_wide_hole() {
        let mut w = flat_world();
        for y in 40..64 {
            w.set_block(0, y, 5, 0);
        }
        let mut b = Body::at(0.5, 70.0, 5.5); // straight above the hole
        run(&w, &mut b, Input::default(), 120, false);
        assert!((b.y - 40.0).abs() < 0.02 && b.on_ground, "ended at y = {}", b.y);
    }

    #[test]
    fn removing_the_ground_under_a_standing_player_makes_it_fall() {
        let mut w = flat_world();
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 10, true);
        assert!(b.on_ground);
        for x in -2..=2 {
            for z in -2..=2 {
                for y in 45..64 {
                    w.set_block(x, y, z, 0);
                }
            }
        }
        run(&w, &mut b, Input::default(), 120, true);
        assert!((b.y - 45.0).abs() < 0.02, "did not fall: y = {}", b.y);
    }

    #[test]
    fn safe_walking_off_still_lets_you_walk_down_a_hole_edge() {
        let mut w = flat_world();
        for x in -1..=1 {
            for z in 5..=7 {
                for y in 50..64 {
                    w.set_block(x, y, z, 0);
                }
            }
        }
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 3, true);
        let outs = run(&w, &mut b, Input { forward: 1, ..Default::default() }, 80, true);
        assert!(b.y > 63.9, "safe walking should stop at the edge, y = {}", b.y);
        assert!(outs.iter().any(|o| o.blocked.is_some()));
    }

    #[test]
    fn cannot_float_in_the_air_or_move_up_without_blocks() {
        let w = flat_world();
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 3, true);
        // holding jump in the air keeps falling back down; no flying
        let jump = Input { jump: true, ..Default::default() };
        run(&w, &mut b, jump, 200, true);
        assert!(b.y < 66.0, "y = {}", b.y);
    }

    #[test]
    fn holding_jump_and_forward_never_climbs_without_blocks() {
        let w = flat_world();
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 3, true);
        let mut top: f64 = 0.0;
        let p = Params { input: Input { forward: 1, jump: true, ..Default::default() }, yaw: 0.0, can_sprint: true, safe: false };
        for _ in 0..300 {
            tick(&w, &mut b, &p);
            top = top.max(b.y);
        }
        assert!(top < 65.4, "reached {top}");
        assert!((b.y - 64.0).abs() < 0.01 || b.y < 66.0);
    }

    #[test]
    fn walls_stop_the_player() {
        let mut w = flat_world();
        for y in 64..67 {
            for x in -3..=3 {
                w.set_block(x, y, 5, 1);
            }
        }
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 3, true);
        run(&w, &mut b, Input { forward: 1, ..Default::default() }, 60, true);
        assert!(b.z < 5.0 - 0.3 + 0.01 && b.z > 4.5, "z = {}", b.z);
    }

    #[test]
    fn a_one_block_ledge_needs_a_jump() {
        let mut w = flat_world();
        for x in -3..=3 {
            for z in 5..9 {
                w.set_block(x, 64, z, 1);
            }
        }
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 3, true);
        run(&w, &mut b, Input { forward: 1, ..Default::default() }, 60, true);
        assert!(b.y < 64.1, "walked up a full block: y = {}", b.y);
        run(&w, &mut b, Input { forward: 1, jump: true, ..Default::default() }, 12, true);
        run(&w, &mut b, Input::default(), 40, true); // release jump and settle
        assert!((b.y - 65.0).abs() < 0.01 && b.on_ground, "y = {}", b.y);
        assert!(b.z > 4.5, "did not get onto the ledge: z = {}", b.z);
    }

    #[test]
    fn sneaking_stops_at_the_edge() {
        let mut w = flat_world();
        // remove the ground from z >= 3 so there is a cliff
        for z in 3..16 {
            for x in -3..=3 {
                for y in 50..64 {
                    w.set_block(x, y, z, 0);
                }
            }
        }
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 3, true);
        run(&w, &mut b, Input { forward: 1, sneak: true, ..Default::default() }, 200, false);
        assert!(b.y > 63.9 && b.z < 3.31, "fell or went too far: y {} z {}", b.y, b.z);
    }

    #[test]
    fn safe_walking_refuses_long_drops_but_can_be_turned_off() {
        let mut w = flat_world();
        for z in 3..16 {
            for x in -3..=3 {
                for y in 40..64 {
                    w.set_block(x, y, z, 0);
                }
            }
        }
        let mut safe = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut safe, Input::default(), 3, true);
        let outs = run(&w, &mut safe, Input { forward: 1, ..Default::default() }, 100, true);
        assert!(safe.y > 63.9, "safe walker fell to {}", safe.y);
        assert!(outs.iter().any(|o| o.blocked.is_some()));
        let mut unsafe_walker = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut unsafe_walker, Input::default(), 3, false);
        run(&w, &mut unsafe_walker, Input { forward: 1, ..Default::default() }, 100, false);
        assert!(unsafe_walker.y < 60.0, "y = {}", unsafe_walker.y);
    }

    #[test]
    fn lava_ahead_is_refused_in_safe_mode() {
        let mut w = flat_world();
        for z in 3..6 {
            for x in -1..=1 {
                w.set_block(x, 63, z, 96); // lava source
            }
        }
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 3, true);
        let outs = run(&w, &mut b, Input { forward: 1, ..Default::default() }, 60, true);
        assert!(b.z < 3.0, "walked toward lava: z = {}", b.z);
        assert!(outs.iter().any(|o| o.blocked.is_some()));
    }

    #[test]
    fn ladders_can_be_climbed() {
        let mut w = flat_world();
        for y in 64..70 {
            w.set_block(0, y, 1, 1); // wall behind
            w.set_block(0, y, 0, 4654); // ladder
        }
        let mut b = Body::at(0.5, 64.0, 0.5);
        run(&w, &mut b, Input::default(), 3, true);
        run(&w, &mut b, Input { jump: true, ..Default::default() }, 30, true);
        assert!(b.y > 66.0, "climbed to {}", b.y);
    }

    #[test]
    fn water_slows_falling() {
        let mut w = flat_world();
        for y in 64..80 {
            for x in -3..=3 {
                for z in -3..=3 {
                    w.set_block(x, y, z, 80);
                }
            }
        }
        let mut b = Body::at(0.5, 75.0, 0.5);
        run(&w, &mut b, Input::default(), 20, true);
        assert!(b.y > 72.0, "sank too fast: {}", b.y);
    }

    #[test]
    fn unloaded_chunks_stop_all_movement() {
        let w = World::default();
        let mut b = Body::at(0.5, 70.0, 0.5);
        let outs = run(&w, &mut b, Input { forward: 1, ..Default::default() }, 10, true);
        assert!(outs.iter().all(|o| o.idle));
        assert_eq!((b.x, b.y, b.z), (0.5, 70.0, 0.5));
    }

    #[test]
    fn raycast_respects_reach_and_walls() {
        let mut w = flat_world();
        let eye = (0.5, 65.62, 0.5);
        // block under the player: the ray comes from above, so the face is the top
        assert_eq!(raycast_to_block(&w, eye, (0, 63, 0), REACH), Ok(1));
        assert!(raycast_to_block(&w, eye, (0, 63, 20), REACH).is_err()); // too far
        w.set_block(2, 65, 0, 1);
        w.set_block(2, 66, 0, 1);
        w.set_block(4, 65, 0, 1); // target behind the wall
        assert_eq!(raycast_to_block(&w, eye, (4, 65, 0), REACH), Err("Another block is in the way"));
        w.set_block(2, 65, 0, 0);
        w.set_block(2, 66, 0, 0);
        assert!(raycast_to_block(&w, eye, (4, 65, 0), REACH).is_ok());
    }

    #[test]
    fn look_at_uses_game_angles() {
        let (yaw, _) = look_at((0.0, 0.0, 0.0), (0.0, 0.0, 5.0));
        assert!(yaw.abs() < 0.01); // south is yaw 0
        let (yaw, _) = look_at((0.0, 0.0, 0.0), (-5.0, 0.0, 0.0));
        assert!((yaw - 90.0).abs() < 0.01); // west is yaw 90
        let (_, pitch) = look_at((0.0, 10.0, 0.0), (0.0, 0.0, 5.0));
        assert!(pitch > 40.0 && pitch < 70.0);
    }
}
