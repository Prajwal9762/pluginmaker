// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
//! A live connection to a Minecraft server (protocol 763 / 1.20.1, offline-mode login).
//!
//! The Android side polls `Shared::poll_json()`; everything else happens on a Tokio runtime.

use crate::auth::{self, AuthMode};
use crate::chat;
use crate::codec::*;
use crate::entities;
use crate::hud::Scoreboard;
use crate::inventory::{self, InvState};
use crate::srv;
use crate::maps::MapData;
use crate::world::{self, World};
use crate::error::{Error, Result};
use crate::status::{connect_tcp, handshake_payload, PROTOCOL_VERSION};
use serde::Serialize;
use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, AtomicI32, AtomicU32, AtomicU64, Ordering::Relaxed};
use std::sync::{Arc, Mutex, MutexGuard, OnceLock};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};
use tokio::io::{AsyncRead, AsyncWriteExt, BufReader};
use tokio::sync::{mpsc, Notify};

#[derive(Debug, Clone)]
pub struct ConnectParams {
    pub host: String,
    pub port: u16,
    pub username: String,
    pub auth: AuthMode,
    pub protocol: i32,
    pub auto_reconnect: bool,
    pub max_retries: u32,
    /// Chunks the server should send around you (2-12). Higher shows more of the minimap.
    pub view_distance: u8,
}

impl ConnectParams {
    pub fn offline(host: &str, port: u16, username: &str) -> Self {
        ConnectParams {
            host: host.to_string(),
            port,
            username: username.to_string(),
            auth: AuthMode::Offline,
            protocol: PROTOCOL_VERSION,
            auto_reconnect: true,
            max_retries: 5,
            view_distance: 4,
        }
    }
}

#[derive(Serialize, Clone, Debug)]
pub struct PlayerJson {
    pub uuid: String,
    pub name: String,
    pub latency: i32,
}

#[derive(Serialize, Clone, Debug)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum Event {
    State { state: String, detail: String },
    /// kind: "player" | "system"
    Chat { kind: String, sender: String, text: String, ts: i64 },
    Players { players: Vec<PlayerJson>, max_players: i32 },
    Info { max_players: i32, entity_id: i32, game_mode: i32, uuid: String, username: String },
    Position { x: f64, y: f64, z: f64 },
    Presence { name: String, joined: bool },
    /// Tab-completion result (start/length are offsets into the text that was sent).
    Completions { tx: i32, start: i32, length: i32, matches: Vec<String> },
    /// kind: "title" | "subtitle" | "actionbar" | "clear"
    Title { kind: String, text: String },
    /// action: "add" | "remove" | "health" | "title" | "style" | "flags"
    BossBar { id: String, action: String, title: String, health: f32, color: i32 },
    /// Sidebar scoreboard snapshot (empty title and lines when none is shown).
    Sidebar { title: String, lines: Vec<SidebarLine> },
    /// Health (20 = ten hearts), food (20 = ten drumsticks) and saturation from the server.
    Vitals { health: f32, food: i32, saturation: f32 },
}

#[derive(Serialize, Clone, Debug)]
pub struct SidebarLine {
    pub text: String,
    pub score: i32,
}

#[derive(Default)]
struct Vitals {
    xp_bar: f32,
    xp_level: i32,
    xp_total: i32,
    time: i64,
    age: i64,
    rain: bool,
}

struct Ent {
    kind: u8,
    name: &'static str,
    uuid: [u8; 16],
    x: f64,
    y: f64,
    z: f64,
}

fn lock<T>(m: &Mutex<T>) -> MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

pub fn now_ms() -> i64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis() as i64).unwrap_or(0)
}

const MAX_QUEUED_EVENTS: usize = 5000;

pub struct Shared {
    events: Mutex<Vec<Event>>,
    state: Mutex<(String, String)>,
    out_tx: Mutex<Option<mpsc::UnboundedSender<Vec<u8>>>>,
    threshold: AtomicI32,
    pos: Mutex<(f64, f64, f64, f32, f32)>,
    bytes_in: AtomicU64,
    bytes_out: AtomicU64,
    packets_in: AtomicU64,
    play_since_ms: Mutex<i64>,
    reconnects: AtomicU32,
    self_latency: AtomicI32,
    reached_play: AtomicBool,
    inv: Mutex<InvState>,
    inv_sent: AtomicU64,
    world: Mutex<World>,
    vitals: Mutex<Vitals>,
    maps: Mutex<HashMap<i32, MapData>>,
    tab_tx: AtomicI32,
    seq: AtomicI32,
    entities: Mutex<HashMap<i32, Ent>>,
    cancelled: AtomicBool,
    cancel: Notify,
}

impl Shared {
    pub fn new() -> Arc<Shared> {
        Arc::new(Shared {
            events: Mutex::new(Vec::new()),
            state: Mutex::new(("connecting".into(), String::new())),
            out_tx: Mutex::new(None),
            threshold: AtomicI32::new(-1),
            pos: Mutex::new((0.0, 0.0, 0.0, 0.0, 0.0)),
            bytes_in: AtomicU64::new(0),
            bytes_out: AtomicU64::new(0),
            packets_in: AtomicU64::new(0),
            play_since_ms: Mutex::new(0),
            reconnects: AtomicU32::new(0),
            self_latency: AtomicI32::new(-1),
            reached_play: AtomicBool::new(false),
            inv: Mutex::new(InvState::new()),
            inv_sent: AtomicU64::new(u64::MAX),
            world: Mutex::new(World::default()),
            vitals: Mutex::new(Vitals::default()),
            maps: Mutex::new(HashMap::new()),
            tab_tx: AtomicI32::new(0),
            seq: AtomicI32::new(0),
            entities: Mutex::new(HashMap::new()),
            cancelled: AtomicBool::new(false),
            cancel: Notify::new(),
        })
    }

    fn push(&self, e: Event) {
        let mut q = lock(&self.events);
        if q.len() >= MAX_QUEUED_EVENTS {
            q.remove(0);
        }
        q.push(e);
    }

    fn set_state(&self, state: &str, detail: impl Into<String>) {
        let detail = detail.into();
        *lock(&self.state) = (state.to_string(), detail.clone());
        self.push(Event::State { state: state.to_string(), detail });
    }

    fn send_raw(&self, payload: Vec<u8>) -> bool {
        match lock(&self.out_tx).as_ref() {
            Some(tx) => tx.send(payload).is_ok(),
            None => false,
        }
    }

    pub fn disconnect(&self) {
        self.cancelled.store(true, Relaxed);
        self.cancel.notify_one();
    }

    /// Send a chat message (or a command when it starts with '/').
    pub fn send_chat(&self, text: &str) -> Result<()> {
        let text = text.trim_end();
        if text.is_empty() {
            return Ok(());
        }
        if text.chars().count() > 256 {
            return Err(Error::Protocol("message is longer than 256 characters".into()));
        }
        let ts = now_ms();
        let mut p = Vec::new();
        if let Some(cmd) = text.strip_prefix('/') {
            write_varint(&mut p, 0x04);
            write_string(&mut p, cmd);
            write_i64(&mut p, ts);
            write_i64(&mut p, 0);
            write_varint(&mut p, 0); // no argument signatures
            write_varint(&mut p, 0); // message count
            p.extend_from_slice(&[0, 0, 0]); // acknowledged bitset
        } else {
            write_varint(&mut p, 0x05);
            write_string(&mut p, text);
            write_i64(&mut p, ts);
            write_i64(&mut p, 0);
            p.push(0); // no signature (offline-mode)
            write_varint(&mut p, 0);
            p.extend_from_slice(&[0, 0, 0]);
        }
        if self.send_raw(p) {
            Ok(())
        } else {
            Err(Error::Protocol("not connected".into()))
        }
    }

    /// Move by a relative offset (no collision or physics; the server may correct it).
    pub fn move_by(&self, dx: f64, dy: f64, dz: f64) -> Result<()> {
        let (x, y, z) = {
            let mut p = lock(&self.pos);
            p.0 += dx;
            p.1 += dy;
            p.2 += dz;
            (p.0, p.1, p.2)
        };
        let mut p = Vec::new();
        write_varint(&mut p, 0x14);
        write_f64(&mut p, x);
        write_f64(&mut p, y);
        write_f64(&mut p, z);
        p.push(1);
        if self.send_raw(p) {
            self.push(Event::Position { x, y, z });
            Ok(())
        } else {
            Err(Error::Protocol("not connected".into()))
        }
    }


    fn current_state_id(&self, window_id: u8) -> Result<i32> {
        lock(&self.inv)
            .window_by_id(window_id)
            .map(|w| w.state_id)
            .ok_or_else(|| Error::Protocol("that window is not open".into()))
    }

    /// Click a slot. mode: 0 click, 1 shift-click, 2 hotbar swap (button = hotbar 0-8), 4 drop.
    /// Slot -999 with mode 0 drops the held (cursor) item. The server's reply updates the mirror.
    pub fn click_slot(&self, window_id: u8, slot: i16, button: i8, mode: i32) -> Result<()> {
        let state_id = self.current_state_id(window_id)?;
        let mut p = Vec::new();
        write_varint(&mut p, 0x0b);
        p.push(window_id);
        write_varint(&mut p, state_id);
        p.extend_from_slice(&slot.to_be_bytes());
        p.push(button as u8);
        write_varint(&mut p, mode);
        write_varint(&mut p, 0); // no predicted slot changes: the server corrects us
        p.push(0); // no predicted cursor item
        if self.send_raw(p) { Ok(()) } else { Err(Error::Protocol("not connected".into())) }
    }

    pub fn close_window(&self, window_id: u8) -> Result<()> {
        lock(&self.inv).close_window(window_id);
        let mut p = Vec::new();
        write_varint(&mut p, 0x0c);
        p.push(window_id);
        if self.send_raw(p) { Ok(()) } else { Err(Error::Protocol("not connected".into())) }
    }

    /// Select a hotbar slot 0-8.
    pub fn hold_slot(&self, slot: i16) -> Result<()> {
        if !(0..=8).contains(&slot) {
            return Err(Error::Protocol("hotbar slot must be 0-8".into()));
        }
        let mut p = Vec::new();
        write_varint(&mut p, 0x28);
        p.extend_from_slice(&slot.to_be_bytes());
        if self.send_raw(p) {
            lock(&self.inv).set_held(slot as i32);
            Ok(())
        } else {
            Err(Error::Protocol("not connected".into()))
        }
    }

    /// Ask the server for tab-completions of `text` (include the leading '/' for commands).
    /// The answer arrives later as an `Event::Completions` with the returned transaction id.
    pub fn request_completions(&self, text: &str) -> Result<i32> {
        if text.chars().count() > 256 {
            return Err(Error::Protocol("text is longer than 256 characters".into()));
        }
        let tx = self.tab_tx.fetch_add(1, Relaxed) + 1;
        let mut p = Vec::new();
        write_varint(&mut p, 0x09);
        write_varint(&mut p, tx);
        write_string(&mut p, text);
        if self.send_raw(p) {
            Ok(tx)
        } else {
            Err(Error::Protocol("not connected".into()))
        }
    }

    /// Top-down minimap around the player: `[width, height, originX, originZ, ARGB pixels...]`.
    pub fn minimap(&self, radius: i32) -> Vec<i32> {
        let (x, z) = {
            let p = lock(&self.pos);
            (p.0, p.2)
        };
        lock(&self.world).render(x, z, radius)
    }

    /// JSON list of the item maps received so far: `[{"id":1,"scale":0,"locked":false}]`.
    pub fn map_list_json(&self) -> String {
        let maps = lock(&self.maps);
        let mut ids: Vec<i32> = maps.keys().copied().collect();
        ids.sort();
        let list: Vec<serde_json::Value> = ids
            .iter()
            .map(|id| {
                let m = &maps[id];
                serde_json::json!({ "id": id, "scale": m.scale, "locked": m.locked })
            })
            .collect();
        serde_json::Value::Array(list).to_string()
    }

    /// 128x128 ARGB pixels of an item map, or empty when unknown.
    pub fn map_pixels(&self, id: i32) -> Vec<i32> {
        lock(&self.maps).get(&id).map(|m| m.argb()).unwrap_or_default()
    }

    fn next_seq(&self) -> i32 {
        self.seq.fetch_add(1, Relaxed) + 1
    }

    /// Right-click with the item in the given hand (0 main, 1 off hand), for example a menu compass.
    pub fn use_item(&self, hand: i32) -> Result<()> {
        let mut p = Vec::new();
        write_varint(&mut p, 0x32);
        write_varint(&mut p, hand);
        write_varint(&mut p, self.next_seq());
        if self.send_raw(p) { Ok(()) } else { Err(Error::Protocol("not connected".into())) }
    }

    pub fn swing(&self) -> Result<()> {
        let mut p = Vec::new();
        write_varint(&mut p, 0x2f);
        write_varint(&mut p, 0);
        if self.send_raw(p) { Ok(()) } else { Err(Error::Protocol("not connected".into())) }
    }

    /// Right-click the block at (x, y, z) on the given face (0 down, 1 up, 2..5 sides).
    /// Opens chests and doors, presses buttons. The server checks reach distance.
    pub fn interact_block(&self, x: i32, y: i32, z: i32, face: i32) -> Result<()> {
        let pos: u64 = (((x as i64 & 0x3FF_FFFF) as u64) << 38)
            | (((z as i64 & 0x3FF_FFFF) as u64) << 12)
            | ((y as i64 & 0xFFF) as u64);
        let mut p = Vec::new();
        write_varint(&mut p, 0x31);
        write_varint(&mut p, 0); // main hand
        p.extend_from_slice(&pos.to_be_bytes());
        write_varint(&mut p, face);
        let cy = if face == 1 { 1.0f32 } else { 0.5 };
        write_f32(&mut p, 0.5);
        write_f32(&mut p, cy);
        write_f32(&mut p, 0.5);
        p.push(0); // not inside the block
        write_varint(&mut p, self.next_seq());
        if self.send_raw(p) { Ok(()) } else { Err(Error::Protocol("not connected".into())) }
    }

    /// Nearby entities for the radar as JSON: `[{"id","k","n","x","y","z","u"}]` (closest 400).
    pub fn entities_json(&self) -> String {
        let (px, pz) = {
            let p = lock(&self.pos);
            (p.0, p.2)
        };
        let ents = lock(&self.entities);
        let mut v: Vec<(f64, serde_json::Value)> = ents
            .iter()
            .map(|(id, e)| {
                let d = (e.x - px).powi(2) + (e.z - pz).powi(2);
                (
                    d,
                    serde_json::json!({
                        "id": id, "k": e.kind, "n": e.name,
                        "x": e.x, "y": e.y, "z": e.z,
                        "u": auth::uuid_to_string(&e.uuid),
                    }),
                )
            })
            .collect();
        v.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));
        v.truncate(400);
        serde_json::Value::Array(v.into_iter().map(|(_, j)| j).collect()).to_string()
    }

    /// Drain pending events and report current state and statistics as JSON.
    pub fn poll_json(&self) -> String {
        let events: Vec<Event> = std::mem::take(&mut *lock(&self.events));
        let (state, detail) = lock(&self.state).clone();
        let since = *lock(&self.play_since_ms);
        let uptime = if state == "play" && since > 0 { now_ms() - since } else { 0 };
        let pos = *lock(&self.pos);
        let vit = lock(&self.vitals);
        let inventory = {
            let inv = lock(&self.inv);
            if inv.loaded && inv.version != self.inv_sent.load(Relaxed) {
                self.inv_sent.store(inv.version, Relaxed);
                inv.snapshot()
            } else {
                serde_json::Value::Null
            }
        };
        serde_json::json!({
            "inventory": inventory,
            "state": state,
            "detail": detail,
            "events": events,
            "stats": {
                "bytes_in": self.bytes_in.load(Relaxed),
                "bytes_out": self.bytes_out.load(Relaxed),
                "packets_in": self.packets_in.load(Relaxed),
                "uptime_ms": uptime,
                "reconnects": self.reconnects.load(Relaxed),
                "latency_ms": self.self_latency.load(Relaxed),
                "x": pos.0, "y": pos.1, "z": pos.2,
                "xp_level": vit.xp_level, "xp_bar": vit.xp_bar, "xp_total": vit.xp_total,
                "time": vit.time, "age": vit.age, "rain": vit.rain,
            }
        })
        .to_string()
    }
}

struct PlayerEntry {
    name: String,
    latency: i32,
    listed: bool,
}

struct PlayState {
    sb: Scoreboard,
    last_sidebar: String,
    players: HashMap<[u8; 16], PlayerEntry>,
    max_players: i32,
    username: String,
    uuid: [u8; 16],
    play_start: Instant,
}

impl PlayState {
    fn emit_sidebar(&mut self, sh: &Shared) {
        let (title, lines) = match self.sb.sidebar_lines() {
            Some((t, l)) => (t, l),
            None => (String::new(), Vec::new()),
        };
        let key = format!("{title}\u{1}{lines:?}");
        if key == self.last_sidebar {
            return;
        }
        self.last_sidebar = key;
        let lines = lines.into_iter().map(|(text, score)| SidebarLine { text, score }).collect();
        sh.push(Event::Sidebar { title, lines });
    }

    fn emit_players(&self, sh: &Shared) {
        let mut v: Vec<PlayerJson> = self
            .players
            .iter()
            .filter(|(_, p)| p.listed && !p.name.is_empty())
            .map(|(u, p)| PlayerJson { uuid: auth::uuid_to_string(u), name: p.name.clone(), latency: p.latency })
            .collect();
        v.sort_by(|a, b| a.name.to_lowercase().cmp(&b.name.to_lowercase()));
        if let Some(me) = self.players.get(&self.uuid) {
            sh.self_latency.store(me.latency, Relaxed);
        }
        sh.push(Event::Players { players: v, max_players: self.max_players });
    }
}

async fn recv<R: AsyncRead + Unpin>(rd: &mut R, sh: &Shared, to: Duration) -> Result<Vec<u8>> {
    if sh.cancelled.load(Relaxed) {
        return Err(Error::Cancelled);
    }
    let th = sh.threshold.load(Relaxed);
    tokio::select! {
        _ = sh.cancel.notified() => Err(Error::Cancelled),
        r = tokio::time::timeout(to, read_packet(rd, th)) => match r {
            Err(_) => Err(Error::Timeout),
            Ok(Err(e)) => Err(e),
            Ok(Ok((p, wire))) => {
                sh.bytes_in.fetch_add(wire as u64, Relaxed);
                sh.packets_in.fetch_add(1, Relaxed);
                Ok(p)
            }
        }
    }
}

async fn run_once(p: &ConnectParams, sh: &Arc<Shared>) -> Result<()> {
    auth::validate_username(&p.username)?;
    if p.auth == AuthMode::Microsoft {
        return Err(Error::OnlineModeRequired);
    }
    sh.reached_play.store(false, Relaxed);
    sh.threshold.store(-1, Relaxed);
    sh.self_latency.store(-1, Relaxed);
    *lock(&sh.inv) = InvState::new();
    sh.inv_sent.store(u64::MAX, Relaxed);
    sh.set_state("connecting", format!("{}:{}", p.host, p.port));

    let (rhost, rport) = srv::resolve(&p.host, p.port).await;
    let stream = connect_tcp(&rhost, rport, Duration::from_secs(10)).await?;
    let (rd, mut wr) = stream.into_split();
    let mut rd = BufReader::new(rd);

    let uuid = auth::offline_uuid(&p.username);
    let mut login = Vec::new();
    write_varint(&mut login, 0x00);
    write_string(&mut login, &p.username);
    login.push(1);
    login.extend_from_slice(&uuid);
    let mut first = encode_packet(&handshake_payload(p.protocol, &rhost, rport, 2), -1);
    first.extend_from_slice(&encode_packet(&login, -1));
    wr.write_all(&first).await?;
    sh.bytes_out.fetch_add(first.len() as u64, Relaxed);
    sh.set_state("login", "offline-mode login");

    let (tx, mut rx) = mpsc::unbounded_channel::<Vec<u8>>();
    *lock(&sh.out_tx) = Some(tx);
    let sh_w = sh.clone();
    let writer = tokio::spawn(async move {
        while let Some(payload) = rx.recv().await {
            let frame = encode_packet(&payload, sh_w.threshold.load(Relaxed));
            if wr.write_all(&frame).await.is_err() {
                break;
            }
            sh_w.bytes_out.fetch_add(frame.len() as u64, Relaxed);
        }
        let _ = wr.shutdown().await;
    });

    let result = login_and_play(p, sh, &mut rd, uuid).await;
    *lock(&sh.out_tx) = None;
    writer.abort();
    result
}

async fn login_and_play<R: AsyncRead + Unpin>(
    p: &ConnectParams,
    sh: &Arc<Shared>,
    rd: &mut R,
    offline_uuid: [u8; 16],
) -> Result<()> {
    let mut st = PlayState {
        sb: Scoreboard::default(),
        last_sidebar: String::new(),
        players: HashMap::new(),
        max_players: -1,
        username: p.username.clone(),
        uuid: offline_uuid,
        play_start: Instant::now(),
    };
    loop {
        let pkt = recv(rd, sh, Duration::from_secs(20)).await?;
        let mut r = Reader::new(&pkt);
        match r.read_varint()? {
            0x00 => return Err(Error::Disconnected(chat::json_to_legacy(&r.read_string()?))),
            0x01 => return Err(Error::OnlineModeRequired),
            0x03 => sh.threshold.store(r.read_varint()?, Relaxed),
            0x02 => {
                st.uuid = r.read_uuid()?;
                st.username = r.read_string()?;
                break;
            }
            0x04 => {
                let id = r.read_varint()?;
                let mut resp = Vec::new();
                write_varint(&mut resp, 0x02);
                write_varint(&mut resp, id);
                resp.push(0); // not understood
                sh.send_raw(resp);
            }
            other => return Err(Error::Protocol(format!("unexpected login packet 0x{other:02x}"))),
        }
    }

    sh.reached_play.store(true, Relaxed);
    st.play_start = Instant::now();
    *lock(&sh.play_since_ms) = now_ms();
    sh.set_state("play", format!("joined as {}", st.username));
    send_client_hello(sh, p.view_distance);

    loop {
        let pkt = recv(rd, sh, Duration::from_secs(40)).await?;
        let mut r = Reader::new(&pkt);
        let id = r.read_varint()?;
        match handle_play(id, &mut r, sh, &mut st) {
            Err(e @ Error::Disconnected(_)) => return Err(e),
            Err(_) => {} // malformed or unsupported non-critical packet: ignore
            Ok(()) => {}
        }
    }
}

fn send_client_hello(sh: &Shared, view_distance: u8) {
    let mut brand = Vec::new();
    write_varint(&mut brand, 0x0d);
    write_string(&mut brand, "minecraft:brand");
    write_string(&mut brand, "MineChat");
    sh.send_raw(brand);

    let mut s = Vec::new();
    write_varint(&mut s, 0x08);
    write_string(&mut s, "en_US");
    s.push(view_distance.clamp(2, 12)); // view distance (chunks)
    write_varint(&mut s, 0); // chat: enabled
    s.push(1); // chat colours
    s.push(0x7f); // skin parts
    write_varint(&mut s, 1); // main hand: right
    s.push(0); // text filtering
    s.push(1); // allow server listing
    sh.send_raw(s);
}

fn chat_event(sh: &Shared, kind: &str, sender: String, text: String) {
    sh.push(Event::Chat { kind: kind.to_string(), sender, text, ts: now_ms() });
}

fn handle_play(id: i32, r: &mut Reader, sh: &Arc<Shared>, st: &mut PlayState) -> Result<()> {
    match id {
        0x23 => {
            let k = r.read_i64()?;
            let mut p = Vec::new();
            write_varint(&mut p, 0x12);
            write_i64(&mut p, k);
            sh.send_raw(p);
        }
        0x32 => {
            let k = r.read_i32()?;
            let mut p = Vec::new();
            write_varint(&mut p, 0x20);
            p.extend_from_slice(&k.to_be_bytes());
            sh.send_raw(p);
        }
        0x1a => {
            let reason = r.read_string()?;
            return Err(Error::Disconnected(chat::json_to_legacy(&reason)));
        }
        0x28 => {
            lock(&sh.world).clear(); // fresh world after (re)joining
            lock(&sh.entities).clear();
            st.sb.clear();
            let entity_id = r.read_i32()?;
            let _hardcore = r.read_bool()?;
            let game_mode = r.read_u8()? as i32;
            let _prev = r.read_i8()?;
            let n = r.read_varint()?;
            for _ in 0..n.max(0) {
                r.read_string()?;
            }
            skip_nbt(r)?; // dimension codec
            let _world_type = r.read_string()?;
            let _world = r.read_string()?;
            let _seed = r.read_i64()?;
            st.max_players = r.read_varint()?;
            sh.push(Event::Info {
                max_players: st.max_players,
                entity_id,
                game_mode,
                uuid: auth::uuid_to_string(&st.uuid),
                username: st.username.clone(),
            });
        }
        0x3c => {
            let (mut x, mut y, mut z) = (r.read_f64()?, r.read_f64()?, r.read_f64()?);
            let (mut yaw, mut pitch) = (r.read_f32()?, r.read_f32()?);
            let flags = r.read_i8()?;
            let tid = r.read_varint()?;
            {
                let mut pos = lock(&sh.pos);
                if flags & 0x01 != 0 { x += pos.0; }
                if flags & 0x02 != 0 { y += pos.1; }
                if flags & 0x04 != 0 { z += pos.2; }
                if flags & 0x08 != 0 { pitch += pos.4; }
                if flags & 0x10 != 0 { yaw += pos.3; }
                *pos = (x, y, z, yaw, pitch);
            }
            let mut c = Vec::new();
            write_varint(&mut c, 0x00);
            write_varint(&mut c, tid);
            sh.send_raw(c);
            let mut pl = Vec::new();
            write_varint(&mut pl, 0x15);
            write_f64(&mut pl, x);
            write_f64(&mut pl, y);
            write_f64(&mut pl, z);
            write_f32(&mut pl, yaw);
            write_f32(&mut pl, pitch);
            pl.push(0);
            sh.send_raw(pl);
            sh.push(Event::Position { x, y, z });
        }
        0x35 => {
            let sender = r.read_uuid()?;
            let _index = r.read_varint()?;
            if r.read_bool()? {
                r.skip(256)?;
            }
            let plain = r.read_string()?;
            // Everything after the plain text is only used for nicer display; tolerate errors.
            let rest = (|| -> Result<(Option<String>, String)> {
                let _ts = r.read_i64()?;
                let _salt = r.read_i64()?;
                let n = r.read_varint()?;
                for _ in 0..n.max(0) {
                    if r.read_varint()? == 0 {
                        r.skip(256)?;
                    }
                }
                let unsigned = r.read_opt_string()?;
                let filter = r.read_varint()?;
                if filter == 2 {
                    let n = r.read_varint()?.max(0) as usize;
                    r.skip(n * 8)?;
                }
                let _ty = r.read_varint()?;
                let net_name = r.read_string()?;
                Ok((unsigned, net_name))
            })();
            let (unsigned, net_name) = match rest {
                Ok((u, n)) => (u, Some(n)),
                Err(_) => (None, None),
            };
            let name = st
                .players
                .get(&sender)
                .map(|p| p.name.clone())
                .filter(|n| !n.is_empty())
                .or_else(|| net_name.map(|n| chat::strip_codes(&chat::json_to_legacy(&n))))
                .unwrap_or_else(|| auth::uuid_to_string(&sender)[..8].to_string());
            let text = unsigned.map(|u| chat::json_to_legacy(&u)).unwrap_or(plain);
            chat_event(sh, "player", name, text);
        }
        0x1b => {
            let msg = r.read_string()?;
            let _ty = r.read_varint()?;
            let name = r.read_string()?;
            chat_event(
                sh,
                "player",
                chat::strip_codes(&chat::json_to_legacy(&name)),
                chat::json_to_legacy(&msg),
            );
        }
        0x64 => {
            let content = r.read_string()?;
            let action_bar = r.read_bool().unwrap_or(false);
            if !action_bar {
                chat_event(sh, "system", String::new(), chat::json_to_legacy(&content));
            }
        }
        0x3a => {
            let flags = r.read_u8()?;
            let n = r.read_varint()?;
            for _ in 0..n.max(0) {
                let uuid = r.read_uuid()?;
                if flags & 0x01 != 0 {
                    let name = r.read_string()?;
                    let props = r.read_varint()?;
                    for _ in 0..props.max(0) {
                        r.read_string()?;
                        r.read_string()?;
                        if r.read_bool()? {
                            r.read_string()?;
                        }
                    }
                    let is_new = !st.players.contains_key(&uuid);
                    st.players.insert(uuid, PlayerEntry { name: name.clone(), latency: 0, listed: true });
                    if is_new && st.play_start.elapsed() > Duration::from_secs(3) && uuid != st.uuid {
                        sh.push(Event::Presence { name, joined: true });
                    }
                }
                if flags & 0x02 != 0 && r.read_bool()? {
                    r.skip(16 + 8)?;
                    let l = r.read_varint()?.max(0) as usize;
                    r.skip(l)?;
                    let l2 = r.read_varint()?.max(0) as usize;
                    r.skip(l2)?;
                }
                if flags & 0x04 != 0 {
                    r.read_varint()?;
                }
                let listed = if flags & 0x08 != 0 { Some(r.read_u8()? != 0) } else { None };
                let latency = if flags & 0x10 != 0 { Some(r.read_varint()?) } else { None };
                if flags & 0x20 != 0 && r.read_bool()? {
                    r.read_string()?;
                }
                if let Some(e) = st.players.get_mut(&uuid) {
                    if let Some(l) = listed { e.listed = l; }
                    if let Some(l) = latency { e.latency = l; }
                }
            }
            st.emit_players(sh);
        }
        0x39 => {
            let n = r.read_varint()?;
            for _ in 0..n.max(0) {
                let uuid = r.read_uuid()?;
                if let Some(p) = st.players.remove(&uuid) {
                    if st.play_start.elapsed() > Duration::from_secs(3) {
                        sh.push(Event::Presence { name: p.name, joined: false });
                    }
                }
            }
            st.emit_players(sh);
        }
        0x38 => {
            let _pid = r.read_varint()?;
            let msg = r.read_string()?;
            chat_event(sh, "system", String::new(), chat::json_to_legacy(&msg));
            let mut p = Vec::new();
            write_varint(&mut p, 0x07);
            write_varint(&mut p, 0); // perform respawn
            sh.send_raw(p);
        }
        0x12 => {
            let wid = r.read_u8()?;
            let sid = r.read_varint()?;
            let n = r.read_varint()?;
            if !(0..=200).contains(&n) {
                return Err(Error::Protocol("bad window item count".into()));
            }
            let mut items = Vec::with_capacity(n as usize);
            for _ in 0..n {
                items.push(inventory::read_slot(r)?);
            }
            let carried = inventory::read_slot(r)?;
            lock(&sh.inv).apply_items(wid, sid, items, carried);
        }
        0x14 => {
            let wid = r.read_i8()?;
            let sid = r.read_varint()?;
            let slot = r.read_i16()?;
            let item = inventory::read_slot(r)?;
            lock(&sh.inv).apply_set_slot(wid, sid, slot, item);
        }
        0x30 => {
            let id = r.read_varint()?;
            let kind = r.read_varint()?;
            let title = inventory::plain_title(&r.read_string()?);
            lock(&sh.inv).open_window(id as u8, kind, title);
        }
        0x11 => {
            let id = r.read_u8()?;
            lock(&sh.inv).close_window(id);
        }
        0x4d => {
            let slot = r.read_i8()? as i32;
            lock(&sh.inv).set_held(slot);
        }
        0x0f => {
            let tx = r.read_varint()?;
            let start = r.read_varint()?;
            let length = r.read_varint()?;
            let n = r.read_varint()?.clamp(0, 1000);
            let mut matches = Vec::with_capacity(n as usize);
            for _ in 0..n {
                matches.push(r.read_string()?);
                if r.read_bool()? {
                    r.read_string()?; // tooltip (ignored)
                }
            }
            sh.push(Event::Completions { tx, start, length, matches });
        }
        0x24 => {
            let cx = r.read_i32()?;
            let cz = r.read_i32()?;
            skip_nbt(r)?; // heightmaps
            let len = r.read_varint()?;
            if len < 0 {
                return Err(Error::Protocol("negative chunk size".into()));
            }
            let chunk = world::parse_chunk(r.read_bytes(len as usize)?)?;
            lock(&sh.world).insert(cx, cz, chunk);
        }
        0x1e => {
            let cx = r.read_i32()?;
            let cz = r.read_i32()?;
            lock(&sh.world).remove(cx, cz);
        }
        0x41 => {
            lock(&sh.world).clear(); // dimension change
            lock(&sh.entities).clear();
        }
        0x29 => {
            let id = r.read_varint()?;
            let scale = r.read_i8()?;
            let locked = r.read_bool()?;
            if r.read_bool()? {
                let n = r.read_varint()?.clamp(0, 1024);
                for _ in 0..n {
                    r.read_varint()?; // type
                    r.read_i8()?;
                    r.read_i8()?;
                    r.read_u8()?;
                    if r.read_bool()? {
                        r.read_string()?;
                    }
                }
            }
            let cols = r.read_u8()? as usize;
            let mut maps = lock(&sh.maps);
            let m = maps.entry(id).or_insert_with(MapData::new);
            m.scale = scale;
            m.locked = locked;
            if cols > 0 {
                let rows = r.read_u8()? as usize;
                let x = r.read_u8()? as usize;
                let y = r.read_u8()? as usize;
                let len = r.read_varint()?.max(0) as usize;
                let data = r.read_bytes(len)?;
                m.apply(x, y, cols, rows, data);
            }
        }
        0x01 => {
            let id = r.read_varint()?;
            let uuid = r.read_uuid()?;
            let ty = r.read_varint()?;
            let (x, y, z) = (r.read_f64()?, r.read_f64()?, r.read_f64()?);
            let (name, kind) = entities::lookup(ty);
            let mut e = lock(&sh.entities);
            if e.len() < 4000 {
                e.insert(id, Ent { kind, name, uuid, x, y, z });
            }
        }
        0x03 => {
            let id = r.read_varint()?;
            let uuid = r.read_uuid()?;
            let (x, y, z) = (r.read_f64()?, r.read_f64()?, r.read_f64()?);
            let mut e = lock(&sh.entities);
            if e.len() < 4000 {
                e.insert(id, Ent { kind: 1, name: "player", uuid, x, y, z });
            }
        }
        0x3e => {
            let n = r.read_varint()?.clamp(0, 4096);
            let mut e = lock(&sh.entities);
            for _ in 0..n {
                e.remove(&r.read_varint()?);
            }
        }
        0x2b | 0x2c => {
            let id = r.read_varint()?;
            let (dx, dy, dz) = (r.read_i16()? as f64, r.read_i16()? as f64, r.read_i16()? as f64);
            if let Some(e) = lock(&sh.entities).get_mut(&id) {
                e.x += dx / 4096.0;
                e.y += dy / 4096.0;
                e.z += dz / 4096.0;
            }
        }
        0x68 => {
            let id = r.read_varint()?;
            let (x, y, z) = (r.read_f64()?, r.read_f64()?, r.read_f64()?);
            if let Some(e) = lock(&sh.entities).get_mut(&id) {
                e.x = x;
                e.y = y;
                e.z = z;
            }
        }
        0x57 => {
            let health = r.read_f32()?;
            let food = r.read_varint()?;
            let saturation = r.read_f32()?;
            sh.push(Event::Vitals { health, food, saturation });
        }
        0x56 => {
            let bar = r.read_f32()?;
            let level = r.read_varint()?;
            let total = r.read_varint()?;
            let mut v = lock(&sh.vitals);
            v.xp_bar = bar;
            v.xp_level = level;
            v.xp_total = total;
        }
        0x5e => {
            let age = r.read_i64()?;
            let time = r.read_i64()?;
            let mut v = lock(&sh.vitals);
            v.age = age;
            v.time = time;
        }
        0x1f => {
            let reason = r.read_u8()?;
            if reason == 1 {
                lock(&sh.vitals).rain = true;
            } else if reason == 2 {
                lock(&sh.vitals).rain = false;
            }
        }
        0x5f | 0x5d | 0x46 => {
            let text = chat::json_to_legacy(&r.read_string()?);
            let kind = match id { 0x5f => "title", 0x5d => "subtitle", _ => "actionbar" };
            sh.push(Event::Title { kind: kind.to_string(), text });
        }
        0x0e => {
            sh.push(Event::Title { kind: "clear".to_string(), text: String::new() });
        }
        0x0b => {
            let uuid = auth::uuid_to_string(&r.read_uuid()?);
            let action = r.read_varint()?;
            let (mut title, mut health, mut color) = (String::new(), 0.0f32, 0);
            let name = match action {
                0 => {
                    title = chat::json_to_legacy(&r.read_string()?);
                    health = r.read_f32()?;
                    color = r.read_varint()?;
                    "add"
                }
                1 => "remove",
                2 => {
                    health = r.read_f32()?;
                    "health"
                }
                3 => {
                    title = chat::json_to_legacy(&r.read_string()?);
                    "title"
                }
                4 => {
                    color = r.read_varint()?;
                    "style"
                }
                _ => "flags",
            };
            sh.push(Event::BossBar { id: uuid, action: name.to_string(), title, health, color });
        }
        0x58 => {
            let name = r.read_string()?;
            let action = r.read_i8()?;
            let title = if action == 0 || action == 2 {
                Some(chat::json_to_legacy(&r.read_string()?))
            } else {
                None
            };
            st.sb.objective(&name, action, title);
            st.emit_sidebar(sh);
        }
        0x51 => {
            let pos = r.read_i8()?;
            let name = r.read_string()?;
            st.sb.display(pos, &name);
            st.emit_sidebar(sh);
        }
        0x5b => {
            let entry = r.read_string()?;
            let action = r.read_varint()?;
            let objective = r.read_string()?;
            let value = if action != 1 { r.read_varint()? } else { 0 };
            st.sb.score(&entry, action, &objective, value);
            st.emit_sidebar(sh);
        }
        0x5a => {
            let name = r.read_string()?;
            let mode = r.read_i8()?;
            let mut info = None;
            if mode == 0 || mode == 2 {
                let _display = r.read_string()?;
                let _friendly = r.read_i8()?;
                let _tag = r.read_string()?;
                let _collision = r.read_string()?;
                let _format = r.read_varint()?;
                let prefix = chat::json_to_legacy(&r.read_string()?);
                let suffix = chat::json_to_legacy(&r.read_string()?);
                info = Some((prefix, suffix));
            }
            let mut players = Vec::new();
            if mode == 0 || mode == 3 || mode == 4 {
                let n = r.read_varint()?.clamp(0, 2048);
                for _ in 0..n {
                    players.push(r.read_string()?);
                }
            }
            st.sb.team(&name, mode, info, players);
            st.emit_sidebar(sh);
        }
        0x40 => {
            // Resource pack offer: honestly decline (this client cannot load packs).
            let mut p = Vec::new();
            write_varint(&mut p, 0x24);
            write_varint(&mut p, 1);
            sh.send_raw(p);
        }
        _ => {}
    }
    Ok(())
}

fn is_retryable(e: &Error) -> bool {
    matches!(e, Error::Io(_) | Error::Timeout | Error::Eof)
}

async fn supervise(p: ConnectParams, sh: Arc<Shared>) {
    let mut attempt: u32 = 0;
    loop {
        let res = run_once(&p, &sh).await;
        if sh.reached_play.load(Relaxed) {
            attempt = 0;
        }
        match res {
            Err(Error::Cancelled) | Ok(()) => {
                sh.set_state("disconnected", "Disconnected");
                return;
            }
            Err(e) => {
                let retry = p.auto_reconnect && is_retryable(&e) && attempt < p.max_retries && !sh.cancelled.load(Relaxed);
                if !retry {
                    let kind = if matches!(e, Error::Disconnected(_)) { "disconnected" } else { "error" };
                    sh.set_state(kind, e.to_string());
                    return;
                }
                attempt += 1;
                sh.reconnects.fetch_add(1, Relaxed);
                let delay = Duration::from_secs((2u64 << attempt.min(4)).min(30));
                sh.set_state(
                    "reconnecting",
                    format!("{e} - retry {attempt}/{} in {}s", p.max_retries, delay.as_secs()),
                );
                tokio::select! {
                    _ = sh.cancel.notified() => {}
                    _ = tokio::time::sleep(delay) => {}
                }
                if sh.cancelled.load(Relaxed) {
                    sh.set_state("disconnected", "Disconnected");
                    return;
                }
            }
        }
    }
}

static RUNTIME: OnceLock<tokio::runtime::Runtime> = OnceLock::new();

pub fn runtime() -> &'static tokio::runtime::Runtime {
    RUNTIME.get_or_init(|| {
        tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)
            .enable_all()
            .thread_name("minechat-net")
            .build()
            .expect("tokio runtime")
    })
}

/// Start a session on the shared runtime.
pub fn start(params: ConnectParams) -> Arc<Shared> {
    let sh = Shared::new();
    let sh2 = sh.clone();
    runtime().spawn(supervise(params, sh2));
    sh
}
