// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
//! Minecraft SRV record lookup (`_minecraft._tcp.<host>`), so servers reachable by a plain
//! domain name work without typing the port. Uses public DNS resolvers over UDP.

use std::net::IpAddr;
use std::time::Duration;
use tokio::net::UdpSocket;
use tokio::time::timeout;

pub fn build_query(id: u16, name: &str) -> Vec<u8> {
    let mut q = Vec::new();
    q.extend_from_slice(&id.to_be_bytes());
    q.extend_from_slice(&[0x01, 0x00]); // recursion desired
    q.extend_from_slice(&[0, 1, 0, 0, 0, 0, 0, 0]); // 1 question
    for label in name.split('.') {
        q.push(label.len().min(63) as u8);
        q.extend_from_slice(&label.as_bytes()[..label.len().min(63)]);
    }
    q.push(0);
    q.extend_from_slice(&[0, 33, 0, 1]); // SRV, IN
    q
}

fn read_name(buf: &[u8], start: usize) -> Option<(String, usize)> {
    let mut pos = start;
    let mut end = None;
    let mut hops = 0;
    let mut out = String::new();
    loop {
        let len = *buf.get(pos)? as usize;
        if len == 0 {
            pos += 1;
            break;
        }
        if len & 0xC0 == 0xC0 {
            let lo = *buf.get(pos + 1)? as usize;
            if end.is_none() {
                end = Some(pos + 2);
            }
            pos = ((len & 0x3F) << 8) | lo;
            hops += 1;
            if hops > 16 {
                return None;
            }
            continue;
        }
        let label = buf.get(pos + 1..pos + 1 + len)?;
        if !out.is_empty() {
            out.push('.');
        }
        out.push_str(&String::from_utf8_lossy(label));
        pos += 1 + len;
    }
    Some((out, end.unwrap_or(pos)))
}

fn u16_at(buf: &[u8], pos: usize) -> Option<u16> {
    Some(u16::from_be_bytes([*buf.get(pos)?, *buf.get(pos + 1)?]))
}

/// Pick the best SRV answer (lowest priority, highest weight) from a DNS response.
pub fn parse_srv(resp: &[u8], id: u16) -> Option<(String, u16)> {
    if u16_at(resp, 0)? != id || resp.get(3)? & 0x0F != 0 {
        return None;
    }
    let qd = u16_at(resp, 4)? as usize;
    let an = u16_at(resp, 6)? as usize;
    let mut pos = 12;
    for _ in 0..qd {
        let (_, p) = read_name(resp, pos)?;
        pos = p + 4;
    }
    let mut best: Option<(u16, u16, String, u16)> = None; // priority, weight, target, port
    for _ in 0..an {
        let (_, p) = read_name(resp, pos)?;
        let rtype = u16_at(resp, p)?;
        let rdlen = u16_at(resp, p + 8)? as usize;
        let rdata = p + 10;
        if rtype == 33 {
            let priority = u16_at(resp, rdata)?;
            let weight = u16_at(resp, rdata + 2)?;
            let port = u16_at(resp, rdata + 4)?;
            let (target, _) = read_name(resp, rdata + 6)?;
            let better = match &best {
                None => true,
                Some((bp, bw, _, _)) => priority < *bp || (priority == *bp && weight > *bw),
            };
            if better && !target.is_empty() {
                best = Some((priority, weight, target, port));
            }
        }
        pos = rdata + rdlen;
    }
    best.map(|(_, _, t, p)| (t, p))
}

async fn query(server: &str, host: &str) -> Option<(String, u16)> {
    let sock = UdpSocket::bind("0.0.0.0:0").await.ok()?;
    sock.connect(server).await.ok()?;
    let id: u16 = 0x4d43;
    sock.send(&build_query(id, &format!("_minecraft._tcp.{host}"))).await.ok()?;
    let mut buf = [0u8; 1500];
    let n = timeout(Duration::from_secs(2), sock.recv(&mut buf)).await.ok()?.ok()?;
    parse_srv(&buf[..n], id)
}

pub async fn lookup(host: &str) -> Option<(String, u16)> {
    for server in ["1.1.1.1:53", "8.8.8.8:53"] {
        if let Some(r) = query(server, host).await {
            return Some(r);
        }
    }
    None
}

/// Returns the address to connect to: the SRV target when the user did not give a port
/// (25565) and the name has an SRV record, otherwise the input unchanged.
pub async fn resolve(host: &str, port: u16) -> (String, u16) {
    if port != 25565 || !host.contains('.') || host.parse::<IpAddr>().is_ok() {
        return (host.to_string(), port);
    }
    match timeout(Duration::from_secs(4), lookup(host)).await {
        Ok(Some(r)) => r,
        _ => (host.to_string(), port),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn labels(name: &str) -> Vec<u8> {
        let mut v = Vec::new();
        for l in name.split('.') {
            v.push(l.len() as u8);
            v.extend_from_slice(l.as_bytes());
        }
        v.push(0);
        v
    }

    #[test]
    fn query_has_expected_shape() {
        let q = build_query(7, "_minecraft._tcp.example.com");
        assert_eq!(&q[0..2], &[0, 7]);
        assert_eq!(&q[4..6], &[0, 1]);
        assert_eq!(&q[q.len() - 4..], &[0, 33, 0, 1]);
    }

    #[test]
    fn parses_srv_with_name_compression() {
        let mut r = vec![0, 1, 0x81, 0x80, 0, 1, 0, 2, 0, 0, 0, 0];
        r.extend(labels("_minecraft._tcp.example.com"));
        r.extend_from_slice(&[0, 33, 0, 1]);
        for (prio, weight, port, target) in [(10u16, 5u16, 25570u16, "b.example.com"), (0, 1, 25999, "mc.example.com")] {
            r.extend_from_slice(&[0xC0, 0x0C, 0, 33, 0, 1, 0, 0, 0, 60]);
            let mut rd = Vec::new();
            rd.extend_from_slice(&prio.to_be_bytes());
            rd.extend_from_slice(&weight.to_be_bytes());
            rd.extend_from_slice(&port.to_be_bytes());
            rd.extend(labels(target));
            r.extend_from_slice(&(rd.len() as u16).to_be_bytes());
            r.extend(rd);
        }
        assert_eq!(parse_srv(&r, 1), Some(("mc.example.com".to_string(), 25999)));
        assert_eq!(parse_srv(&r, 2), None); // wrong transaction id
        r[3] = 0x83; // NXDOMAIN
        assert_eq!(parse_srv(&r, 1), None);
    }

    #[tokio::test]
    async fn ip_addresses_and_explicit_ports_are_left_alone() {
        assert_eq!(resolve("127.0.0.1", 25565).await, ("127.0.0.1".to_string(), 25565));
        assert_eq!(resolve("example.com", 25570).await, ("example.com".to_string(), 25570));
        assert_eq!(resolve("localhost", 25565).await, ("localhost".to_string(), 25565));
    }
}
