// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
//! Server List Ping (status) including latency and protocol/version detection.

use crate::chat;
use crate::codec::*;
use crate::error::{Error, Result};
use serde::Serialize;
use std::time::{Duration, Instant};
use tokio::io::{AsyncWriteExt, BufReader};
use tokio::net::TcpStream;
use tokio::time::timeout;

/// Protocol version this engine speaks for the play state (Minecraft 1.20.1).
pub const PROTOCOL_VERSION: i32 = 763;

#[derive(Debug, Serialize, Default, Clone)]
pub struct StatusInfo {
    pub version_name: String,
    pub protocol: i32,
    pub players_online: i32,
    pub players_max: i32,
    pub sample: Vec<String>,
    /// MOTD with §-codes.
    pub motd: String,
    pub favicon: Option<String>,
    pub latency_ms: i64,
    /// True when the server reports the same protocol version this engine implements.
    pub exact_protocol_match: bool,
}

pub async fn connect_tcp(host: &str, port: u16, to: Duration) -> Result<TcpStream> {
    let s = timeout(to, TcpStream::connect((host, port)))
        .await
        .map_err(|_| Error::Timeout)??;
    let _ = s.set_nodelay(true);
    Ok(s)
}

pub fn handshake_payload(protocol: i32, host: &str, port: u16, next_state: i32) -> Vec<u8> {
    let mut p = Vec::new();
    write_varint(&mut p, 0x00);
    write_varint(&mut p, protocol);
    write_string(&mut p, host);
    p.extend_from_slice(&port.to_be_bytes());
    write_varint(&mut p, next_state);
    p
}

pub async fn ping(host: &str, port: u16, to: Duration) -> Result<StatusInfo> {
    timeout(to, ping_inner(host, port, to))
        .await
        .map_err(|_| Error::Timeout)?
}

async fn ping_inner(host: &str, port: u16, to: Duration) -> Result<StatusInfo> {
    let (rhost, rport) = crate::srv::resolve(host, port).await;
    let stream = connect_tcp(&rhost, rport, to).await?;
    let (rd, mut wr) = stream.into_split();
    let mut rd = BufReader::new(rd);

    wr.write_all(&encode_packet(&handshake_payload(PROTOCOL_VERSION, &rhost, rport, 1), -1)).await?;
    wr.write_all(&encode_packet(&[0x00], -1)).await?;

    let (pkt, _) = read_packet(&mut rd, -1).await?;
    let mut r = Reader::new(&pkt);
    if r.read_varint()? != 0x00 {
        return Err(Error::Protocol("expected status response".into()));
    }
    let json = r.read_string()?;
    let mut info = parse_status_json(&json)?;

    let t0 = Instant::now();
    let mut p = Vec::new();
    write_varint(&mut p, 0x01);
    write_i64(&mut p, 0x4343);
    wr.write_all(&encode_packet(&p, -1)).await?;
    let (pong, _) = read_packet(&mut rd, -1).await?;
    if Reader::new(&pong).read_varint()? == 0x01 {
        info.latency_ms = t0.elapsed().as_millis() as i64;
    }
    Ok(info)
}

pub fn parse_status_json(json: &str) -> Result<StatusInfo> {
    let v: serde_json::Value =
        serde_json::from_str(json).map_err(|e| Error::Protocol(format!("bad status JSON: {e}")))?;
    let mut info = StatusInfo::default();
    info.version_name = v["version"]["name"].as_str().unwrap_or("?").to_string();
    info.protocol = v["version"]["protocol"].as_i64().unwrap_or(-1) as i32;
    info.players_online = v["players"]["online"].as_i64().unwrap_or(0) as i32;
    info.players_max = v["players"]["max"].as_i64().unwrap_or(0) as i32;
    if let Some(sample) = v["players"]["sample"].as_array() {
        info.sample = sample
            .iter()
            .filter_map(|p| p["name"].as_str().map(|s| s.to_string()))
            .collect();
    }
    info.motd = chat::value_to_legacy(&v["description"]);
    info.favicon = v["favicon"].as_str().map(|s| s.to_string());
    info.exact_protocol_match = info.protocol == PROTOCOL_VERSION;
    Ok(info)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_typical_paper_status() {
        let j = r#"{"version":{"name":"Paper 1.20.1","protocol":763},"players":{"max":20,"online":2,"sample":[{"name":"A","id":"x"}]},"description":{"text":"Hi","color":"green"}}"#;
        let i = parse_status_json(j).unwrap();
        assert_eq!(i.protocol, 763);
        assert!(i.exact_protocol_match);
        assert_eq!(i.players_online, 2);
        assert_eq!(i.sample, vec!["A"]);
        assert_eq!(i.motd, "§r§aHi");
    }

    #[test]
    fn motd_plain_string_and_other_version() {
        let j = r#"{"version":{"name":"1.21","protocol":767},"players":{"max":5,"online":0},"description":"A plain MOTD"}"#;
        let i = parse_status_json(j).unwrap();
        assert!(!i.exact_protocol_match);
        assert_eq!(i.motd, "A plain MOTD");
    }
}
