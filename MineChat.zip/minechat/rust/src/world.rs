// Copyright (c) 2026 ZORVI Studios. All rights reserved. See LICENSE.
//! Chunk decoding for the top-down minimap (1.20.1 chunk format).

use crate::blocks;
use crate::codec::Reader;
use crate::error::{Error, Result};
use std::collections::HashMap;

/// One chunk reduced to its visible top layer.
pub struct Chunk {
    /// ARGB per column, index `z * 16 + x`; 0 when nothing visible.
    pub colors: Vec<u32>,
    /// Height (section * 16 + y, relative to the world bottom) of each column's top block.
    pub heights: Vec<i16>,
    /// All block states, bottom section first (kept for collision and block updates).
    pub sections: Vec<Section>,
}

pub enum Section {
    Uniform(u32),
    Blocks(Vec<u16>),
}

impl Section {
    pub fn get(&self, i: usize) -> u32 {
        match self {
            Section::Uniform(v) => *v,
            Section::Blocks(b) => b[i] as u32,
        }
    }
}

fn read_longs(r: &mut Reader) -> Result<Vec<u64>> {
    let n = r.read_varint()?;
    if n < 0 || (n as usize) * 8 > r.remaining() {
        return Err(Error::Protocol("bad long array length".into()));
    }
    let mut v = Vec::with_capacity(n as usize);
    for _ in 0..n {
        v.push(r.read_i64()? as u64);
    }
    Ok(v)
}

fn read_block_states(r: &mut Reader) -> Result<Section> {
    let bits = r.read_u8()? as usize;
    if bits == 0 {
        let v = r.read_varint()?;
        read_longs(r)?;
        return Ok(Section::Uniform(v as u32));
    }
    if bits > 32 {
        return Err(Error::Protocol("bad bits per entry".into()));
    }
    let palette = if bits <= 8 {
        let n = r.read_varint()?;
        if !(0..=512).contains(&n) {
            return Err(Error::Protocol("bad palette size".into()));
        }
        let mut p = Vec::with_capacity(n as usize);
        for _ in 0..n {
            p.push(r.read_varint()? as u32);
        }
        Some(p)
    } else {
        None
    };
    let data = read_longs(r)?;
    let epl = 64 / bits;
    let mask = (1u64 << bits) - 1;
    let mut out = vec![0u16; 4096];
    for (i, slot) in out.iter_mut().enumerate() {
        let word = *data.get(i / epl).ok_or(Error::Eof)?;
        let v = ((word >> ((i % epl) * bits)) & mask) as usize;
        let state = match &palette {
            Some(p) => *p.get(v).unwrap_or(&0),
            None => v as u32,
        };
        *slot = if state > u16::MAX as u32 { 0 } else { state as u16 };
    }
    Ok(Section::Blocks(out))
}

fn skip_biomes(r: &mut Reader) -> Result<()> {
    let bits = r.read_u8()?;
    if bits == 0 {
        r.read_varint()?;
    } else if bits <= 3 {
        let n = r.read_varint()?;
        for _ in 0..n.clamp(0, 64) {
            r.read_varint()?;
        }
    }
    read_longs(r)?;
    Ok(())
}

fn water_color(depth: u32) -> u32 {
    let t = ((depth.saturating_sub(1)) as f32 / 16.0).min(1.0);
    let lerp = |a: u32, b: u32| (a as f32 + (b as f32 - a as f32) * t) as u32;
    0xFF00_0000 | (lerp(0x5B, 0x1B) << 16) | (lerp(0x9B, 0x3A) << 8) | lerp(0xEF, 0x9E)
}

/// Colour and height of the visible top block of one column.
fn top_of_column(sections: &[Section], x: usize, z: usize) -> (u32, i16) {
    let at = |si: usize, y: usize| sections[si].get((y << 8) | (z << 4) | x);
    for si in (0..sections.len()).rev() {
        for y in (0..16usize).rev() {
            let st = at(si, y);
            let c = blocks::color(st);
            if c == 0 {
                continue;
            }
            let height = (si * 16 + y) as i16;
            if blocks::is_water(st) {
                let (mut s2, mut y2, mut depth) = (si, y, 1u32);
                loop {
                    if y2 == 0 {
                        if s2 == 0 {
                            break;
                        }
                        s2 -= 1;
                        y2 = 15;
                    } else {
                        y2 -= 1;
                    }
                    if blocks::is_water(at(s2, y2)) && depth < 24 {
                        depth += 1;
                    } else {
                        break;
                    }
                }
                return (water_color(depth), height);
            }
            return (c, height);
        }
    }
    (0, 0)
}

fn build_chunk(sections: Vec<Section>) -> Chunk {
    let mut colors = vec![0u32; 256];
    let mut heights = vec![0i16; 256];
    for z in 0..16usize {
        for x in 0..16usize {
            let (c, h) = top_of_column(&sections, x, z);
            colors[z * 16 + x] = c;
            heights[z * 16 + x] = h;
        }
    }
    Chunk { colors, heights, sections }
}

impl Chunk {
    /// Builds a chunk from a block function `(x, y, z) -> state` where y counts from the world bottom.
    pub fn from_fn(section_count: usize, f: impl Fn(usize, usize, usize) -> u16) -> Chunk {
        let mut sections = Vec::new();
        for si in 0..section_count {
            let mut v = vec![0u16; 4096];
            for y in 0..16usize {
                for z in 0..16usize {
                    for x in 0..16usize {
                        v[(y << 8) | (z << 4) | x] = f(x, si * 16 + y, z);
                    }
                }
            }
            if v.iter().all(|&b| b == v[0]) {
                sections.push(Section::Uniform(v[0] as u32));
            } else {
                sections.push(Section::Blocks(v));
            }
        }
        build_chunk(sections)
    }
}

/// Decode the `chunkData` byte array of a chunk packet.
pub fn parse_chunk(data: &[u8]) -> Result<Chunk> {
    let mut r = Reader::new(data);
    let mut sections = Vec::new();
    while r.remaining() > 0 && sections.len() < 64 {
        let _non_air = r.read_i16()?;
        sections.push(read_block_states(&mut r)?);
        skip_biomes(&mut r)?;
    }
    Ok(build_chunk(sections))
}

pub struct World {
    pub chunks: HashMap<(i32, i32), Chunk>,
    /// Lowest block Y of the current dimension (-64 overworld, 0 nether and end).
    pub min_y: i32,
}

impl Default for World {
    fn default() -> Self {
        World { chunks: HashMap::new(), min_y: -64 }
    }
}

impl World {
    pub fn insert(&mut self, x: i32, z: i32, chunk: Chunk) {
        if self.chunks.len() >= 2048 {
            // keep memory bounded: drop the chunk farthest from the new one
            let far = self
                .chunks
                .keys()
                .max_by_key(|(cx, cz)| (cx - x).abs().max((cz - z).abs()))
                .copied();
            if let Some(k) = far {
                self.chunks.remove(&k);
            }
        }
        self.chunks.insert((x, z), chunk);
    }

    pub fn remove(&mut self, x: i32, z: i32) {
        self.chunks.remove(&(x, z));
    }

    pub fn clear(&mut self) {
        self.chunks.clear();
    }

    /// Sets the world bottom from the dimension type name sent by the server.
    pub fn set_dimension(&mut self, dimension: &str) {
        self.min_y = if dimension.contains("nether") || dimension.contains("the_end") { 0 } else { -64 };
    }

    /// Block state at a position. `None` when that chunk has not been received yet.
    pub fn block(&self, x: i32, y: i32, z: i32) -> Option<u32> {
        let ch = self.chunks.get(&(x.div_euclid(16), z.div_euclid(16)))?;
        let sy = y - self.min_y;
        if sy < 0 {
            return Some(0);
        }
        let section = match ch.sections.get((sy >> 4) as usize) {
            Some(s) => s,
            None => return Some(0),
        };
        let idx = (((sy & 15) as usize) << 8) | ((z.rem_euclid(16) as usize) << 4) | (x.rem_euclid(16) as usize);
        Some(section.get(idx))
    }

    /// Applies a block update from the server. Ignored when the chunk is not loaded.
    pub fn set_block(&mut self, x: i32, y: i32, z: i32, state: u32) {
        let min_y = self.min_y;
        let Some(ch) = self.chunks.get_mut(&(x.div_euclid(16), z.div_euclid(16))) else { return };
        let sy = y - min_y;
        if sy < 0 || sy >= 64 * 16 || state > u16::MAX as u32 {
            return;
        }
        let si = (sy >> 4) as usize;
        while ch.sections.len() <= si {
            ch.sections.push(Section::Uniform(0));
        }
        let idx = (((sy & 15) as usize) << 8) | ((z.rem_euclid(16) as usize) << 4) | (x.rem_euclid(16) as usize);
        let sec = &mut ch.sections[si];
        if let Section::Uniform(v) = sec {
            if *v == state {
                return;
            }
            *sec = Section::Blocks(vec![*v as u16; 4096]);
        }
        if let Section::Blocks(b) = sec {
            b[idx] = state as u16;
        }
        let (lx, lz) = (x.rem_euclid(16) as usize, z.rem_euclid(16) as usize);
        let (c, h) = top_of_column(&ch.sections, lx, lz);
        ch.colors[lz * 16 + lx] = c;
        ch.heights[lz * 16 + lx] = h;
    }

    fn height_at(&self, bx: i32, bz: i32) -> Option<i16> {
        let c = self.chunks.get(&(bx.div_euclid(16), bz.div_euclid(16)))?;
        Some(c.heights[(bz.rem_euclid(16) * 16 + bx.rem_euclid(16)) as usize])
    }

    /// Render the area around (px, pz). Returns `[width, height, originX, originZ, ARGB pixels...]`.
    pub fn render(&self, px: f64, pz: f64, radius: i32) -> Vec<i32> {
        let r = radius.clamp(1, 12);
        let (cx, cz) = ((px.floor() as i32).div_euclid(16), (pz.floor() as i32).div_euclid(16));
        let w = ((2 * r + 1) * 16) as usize;
        let (ox, oz) = ((cx - r) * 16, (cz - r) * 16);
        let mut out = vec![0i32; 4 + w * w];
        out[0] = w as i32;
        out[1] = w as i32;
        out[2] = ox;
        out[3] = oz;
        for py in 0..w {
            for pxl in 0..w {
                let (bx, bz) = (ox + pxl as i32, oz + py as i32);
                let col = match self.chunks.get(&(bx.div_euclid(16), bz.div_euclid(16))) {
                    None => {
                        if ((bx.div_euclid(16) + bz.div_euclid(16)) & 1) == 0 { 0xFF1E1E1E } else { 0xFF262626 }
                    }
                    Some(ch) => {
                        let i = (bz.rem_euclid(16) * 16 + bx.rem_euclid(16)) as usize;
                        let c = ch.colors[i];
                        if c == 0 {
                            0xFF111111
                        } else if blocks_is_water_color(c) {
                            c
                        } else {
                            let h = ch.heights[i] as i32;
                            let hn = self.height_at(bx, bz - 1).map(|v| v as i32).unwrap_or(h);
                            let delta = (h - hn).clamp(-3, 3) as f32;
                            shade(c, 1.0 + delta * 0.07)
                        }
                    }
                };
                out[4 + py * w + pxl] = col as i32;
            }
        }
        out
    }
}

/// Water columns are tinted by depth and keep their colour (no relief shading).
fn blocks_is_water_color(c: u32) -> bool {
    let (r, g, b) = ((c >> 16) & 255, (c >> 8) & 255, c & 255);
    b > 0x90 && b > r + 0x40 && g < 0xA0 && r < 0x60
}

fn shade(c: u32, f: f32) -> u32 {
    let ch = |v: u32| ((v as f32 * f).clamp(0.0, 255.0)) as u32;
    0xFF00_0000 | (ch((c >> 16) & 255) << 16) | (ch((c >> 8) & 255) << 8) | ch(c & 255)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::codec::write_varint;

    fn uniform_section(state: i32) -> Vec<u8> {
        let mut b = vec![0, 0]; // non-air count
        b.push(0); // bits per entry = 0 (single value)
        write_varint(&mut b, state);
        write_varint(&mut b, 0); // no data longs
        b.extend_from_slice(&[0, 0, 0]); // biomes: single value 0, no data
        b
    }

    /// Section with a palette [air, stone] and stone only at y == 0.
    fn floor_section() -> Vec<u8> {
        let mut b = vec![0, 0];
        b.push(4); // 4 bits per entry
        write_varint(&mut b, 2);
        write_varint(&mut b, 0);
        write_varint(&mut b, 1);
        let longs = 4096 / 16; // 16 entries per long
        write_varint(&mut b, longs as i32);
        for l in 0..longs {
            // entries 0..255 are y == 0 (index = y<<8|z<<4|x); each long holds 16 entries
            let word: u64 = if l < 16 { 0x1111_1111_1111_1111 } else { 0 };
            b.extend_from_slice(&word.to_be_bytes());
        }
        b.extend_from_slice(&[0, 0, 0]);
        b
    }

    #[test]
    fn top_block_and_height() {
        let mut data = uniform_section(0); // air below... section 0 all air
        data.extend(floor_section()); // section 1: stone floor at y=0 -> height 16
        let ch = parse_chunk(&data).unwrap();
        assert_eq!(ch.heights[0], 16);
        assert_eq!(ch.colors[255] >> 24, 0xFF);
    }

    #[test]
    fn uniform_stone_and_empty_columns() {
        let data = uniform_section(1);
        let ch = parse_chunk(&data).unwrap();
        assert_eq!(ch.heights[17], 15);
        let air = parse_chunk(&uniform_section(0)).unwrap();
        assert_eq!(air.colors[3], 0);
    }

    #[test]
    fn water_gets_darker_with_depth() {
        let shallow = water_color(1);
        let deep = water_color(20);
        assert!((shallow & 0xFF) > (deep & 0xFF));
        let ch = parse_chunk(&uniform_section(80)).unwrap(); // all water
        assert_eq!(ch.colors[0], water_color(16));
    }

    #[test]
    fn block_lookup_and_updates() {
        let mut w = World::default();
        assert_eq!(w.block(0, 0, 0), None);
        // stone floor up to world y index 10 (absolute y = -64 + 10), air above
        w.insert(0, 0, Chunk::from_fn(2, |_, y, _| if y <= 10 { 1 } else { 0 }));
        assert_eq!(w.block(3, -54, 3), Some(1));
        assert_eq!(w.block(3, -53, 3), Some(0));
        assert_eq!(w.block(-1, -54, 3), None); // neighbouring chunk missing
        assert_eq!(w.block(3, -500, 3), Some(0)); // below the world
        w.set_block(3, -53, 3, 1);
        assert_eq!(w.block(3, -53, 3), Some(1));
        assert_eq!(w.chunks[&(0, 0)].heights[3 * 16 + 3], 11);
        w.set_block(3, -53, 3, 0);
        assert_eq!(w.chunks[&(0, 0)].heights[3 * 16 + 3], 10);
        w.set_dimension("minecraft:the_nether");
        assert_eq!(w.min_y, 0);
    }

    #[test]
    fn truncated_data_is_an_error() {
        let mut d = uniform_section(1);
        d.truncate(4);
        assert!(parse_chunk(&d).is_err());
    }

    #[test]
    fn render_marks_missing_chunks_and_positions_origin() {
        let mut w = World::default();
        w.insert(0, 0, parse_chunk(&uniform_section(1)).unwrap());
        let img = w.render(5.0, 5.0, 1);
        assert_eq!((img[0], img[1], img[2], img[3]), (48, 48, -16, -16));
        let centre = img[4 + (16 + 5) * 48 + (16 + 5)] as u32;
        assert_eq!(centre >> 24, 0xFF);
        assert_ne!(centre, 0xFF1E1E1E);
        assert!(img[4] as u32 == 0xFF1E1E1E || img[4] as u32 == 0xFF262626);
    }
}
