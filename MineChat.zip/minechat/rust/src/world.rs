// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
//! Chunk decoding for the top-down minimap (1.20.1 chunk format).

use crate::blocks;
use crate::codec::Reader;
use crate::error::{Error, Result};
use std::collections::HashMap;

/// One chunk reduced to its visible top layer.
pub struct Chunk {
    /// ARGB per column, index `z * 16 + x`; 0 when nothing visible.
    pub colors: Vec<u32>,
    /// Height (section * 16 + y, relative to the world bottom) of each column's top block.
    pub heights: Vec<i16>,
}

enum Section {
    Uniform(u32),
    Blocks(Vec<u32>),
}

impl Section {
    fn get(&self, i: usize) -> u32 {
        match self {
            Section::Uniform(v) => *v,
            Section::Blocks(b) => b[i],
        }
    }
}

fn read_longs(r: &mut Reader) -> Result<Vec<u64>> {
    let n = r.read_varint()?;
    if n < 0 || (n as usize) * 8 > r.remaining() {
        return Err(Error::Protocol("bad long array length".into()));
    }
    let mut v = Vec::with_capacity(n as usize);
    for _ in 0..n {
        v.push(r.read_i64()? as u64);
    }
    Ok(v)
}

fn read_block_states(r: &mut Reader) -> Result<Section> {
    let bits = r.read_u8()? as usize;
    if bits == 0 {
        let v = r.read_varint()?;
        read_longs(r)?;
        return Ok(Section::Uniform(v as u32));
    }
    if bits > 32 {
        return Err(Error::Protocol("bad bits per entry".into()));
    }
    let palette = if bits <= 8 {
        let n = r.read_varint()?;
        if !(0..=512).contains(&n) {
            return Err(Error::Protocol("bad palette size".into()));
        }
        let mut p = Vec::with_capacity(n as usize);
        for _ in 0..n {
            p.push(r.read_varint()? as u32);
        }
        Some(p)
    } else {
        None
    };
    let data = read_longs(r)?;
    let epl = 64 / bits;
    let mask = (1u64 << bits) - 1;
    let mut out = vec![0u32; 4096];
    for (i, slot) in out.iter_mut().enumerate() {
        let word = *data.get(i / epl).ok_or(Error::Eof)?;
        let v = ((word >> ((i % epl) * bits)) & mask) as usize;
        *slot = match &palette {
            Some(p) => *p.get(v).unwrap_or(&0),
            None => v as u32,
        };
    }
    Ok(Section::Blocks(out))
}

fn skip_biomes(r: &mut Reader) -> Result<()> {
    let bits = r.read_u8()?;
    if bits == 0 {
        r.read_varint()?;
    } else if bits <= 3 {
        let n = r.read_varint()?;
        for _ in 0..n.clamp(0, 64) {
            r.read_varint()?;
        }
    }
    read_longs(r)?;
    Ok(())
}

fn water_color(depth: u32) -> u32 {
    let t = ((depth.saturating_sub(1)) as f32 / 16.0).min(1.0);
    let lerp = |a: u32, b: u32| (a as f32 + (b as f32 - a as f32) * t) as u32;
    0xFF00_0000 | (lerp(0x5B, 0x1B) << 16) | (lerp(0x9B, 0x3A) << 8) | lerp(0xEF, 0x9E)
}

/// Decode the `chunkData` byte array of a chunk packet.
pub fn parse_chunk(data: &[u8]) -> Result<Chunk> {
    let mut r = Reader::new(data);
    let mut sections = Vec::new();
    while r.remaining() > 0 && sections.len() < 64 {
        let _non_air = r.read_i16()?;
        sections.push(read_block_states(&mut r)?);
        skip_biomes(&mut r)?;
    }
    let mut colors = vec![0u32; 256];
    let mut heights = vec![0i16; 256];
    for z in 0..16usize {
        for x in 0..16usize {
            let at = |si: usize, y: usize| sections[si].get((y << 8) | (z << 4) | x);
            'column: for si in (0..sections.len()).rev() {
                for y in (0..16usize).rev() {
                    let st = at(si, y);
                    let c = blocks::color(st);
                    if c == 0 {
                        continue;
                    }
                    heights[z * 16 + x] = (si * 16 + y) as i16;
                    if blocks::is_water(st) {
                        let (mut s2, mut y2, mut depth) = (si, y, 1u32);
                        loop {
                            if y2 == 0 {
                                if s2 == 0 {
                                    break;
                                }
                                s2 -= 1;
                                y2 = 15;
                            } else {
                                y2 -= 1;
                            }
                            if blocks::is_water(at(s2, y2)) && depth < 24 {
                                depth += 1;
                            } else {
                                break;
                            }
                        }
                        colors[z * 16 + x] = water_color(depth);
                    } else {
                        colors[z * 16 + x] = c;
                    }
                    break 'column;
                }
            }
        }
    }
    Ok(Chunk { colors, heights })
}

#[derive(Default)]
pub struct World {
    pub chunks: HashMap<(i32, i32), Chunk>,
}

impl World {
    pub fn insert(&mut self, x: i32, z: i32, chunk: Chunk) {
        if self.chunks.len() >= 2048 {
            // keep memory bounded: drop the chunk farthest from the new one
            let far = self
                .chunks
                .keys()
                .max_by_key(|(cx, cz)| (cx - x).abs().max((cz - z).abs()))
                .copied();
            if let Some(k) = far {
                self.chunks.remove(&k);
            }
        }
        self.chunks.insert((x, z), chunk);
    }

    pub fn remove(&mut self, x: i32, z: i32) {
        self.chunks.remove(&(x, z));
    }

    pub fn clear(&mut self) {
        self.chunks.clear();
    }

    fn height_at(&self, bx: i32, bz: i32) -> Option<i16> {
        let c = self.chunks.get(&(bx.div_euclid(16), bz.div_euclid(16)))?;
        Some(c.heights[(bz.rem_euclid(16) * 16 + bx.rem_euclid(16)) as usize])
    }

    /// Render the area around (px, pz). Returns `[width, height, originX, originZ, ARGB pixels...]`.
    pub fn render(&self, px: f64, pz: f64, radius: i32) -> Vec<i32> {
        let r = radius.clamp(1, 12);
        let (cx, cz) = ((px.floor() as i32).div_euclid(16), (pz.floor() as i32).div_euclid(16));
        let w = ((2 * r + 1) * 16) as usize;
        let (ox, oz) = ((cx - r) * 16, (cz - r) * 16);
        let mut out = vec![0i32; 4 + w * w];
        out[0] = w as i32;
        out[1] = w as i32;
        out[2] = ox;
        out[3] = oz;
        for py in 0..w {
            for pxl in 0..w {
                let (bx, bz) = (ox + pxl as i32, oz + py as i32);
                let col = match self.chunks.get(&(bx.div_euclid(16), bz.div_euclid(16))) {
                    None => {
                        if ((bx.div_euclid(16) + bz.div_euclid(16)) & 1) == 0 { 0xFF1E1E1E } else { 0xFF262626 }
                    }
                    Some(ch) => {
                        let i = (bz.rem_euclid(16) * 16 + bx.rem_euclid(16)) as usize;
                        let c = ch.colors[i];
                        if c == 0 {
                            0xFF111111
                        } else if blocks_is_water_color(c) {
                            c
                        } else {
                            let h = ch.heights[i] as i32;
                            let hn = self.height_at(bx, bz - 1).map(|v| v as i32).unwrap_or(h);
                            let delta = (h - hn).clamp(-3, 3) as f32;
                            shade(c, 1.0 + delta * 0.07)
                        }
                    }
                };
                out[4 + py * w + pxl] = col as i32;
            }
        }
        out
    }
}

/// Water columns are tinted by depth and keep their colour (no relief shading).
fn blocks_is_water_color(c: u32) -> bool {
    let (r, g, b) = ((c >> 16) & 255, (c >> 8) & 255, c & 255);
    b > 0x90 && b > r + 0x40 && g < 0xA0 && r < 0x60
}

fn shade(c: u32, f: f32) -> u32 {
    let ch = |v: u32| ((v as f32 * f).clamp(0.0, 255.0)) as u32;
    0xFF00_0000 | (ch((c >> 16) & 255) << 16) | (ch((c >> 8) & 255) << 8) | ch(c & 255)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::codec::write_varint;

    fn uniform_section(state: i32) -> Vec<u8> {
        let mut b = vec![0, 0]; // non-air count
        b.push(0); // bits per entry = 0 (single value)
        write_varint(&mut b, state);
        write_varint(&mut b, 0); // no data longs
        b.extend_from_slice(&[0, 0, 0]); // biomes: single value 0, no data
        b
    }

    /// Section with a palette [air, stone] and stone only at y == 0.
    fn floor_section() -> Vec<u8> {
        let mut b = vec![0, 0];
        b.push(4); // 4 bits per entry
        write_varint(&mut b, 2);
        write_varint(&mut b, 0);
        write_varint(&mut b, 1);
        let longs = 4096 / 16; // 16 entries per long
        write_varint(&mut b, longs as i32);
        for l in 0..longs {
            // entries 0..255 are y == 0 (index = y<<8|z<<4|x); each long holds 16 entries
            let word: u64 = if l < 16 { 0x1111_1111_1111_1111 } else { 0 };
            b.extend_from_slice(&word.to_be_bytes());
        }
        b.extend_from_slice(&[0, 0, 0]);
        b
    }

    #[test]
    fn top_block_and_height() {
        let mut data = uniform_section(0); // air below... section 0 all air
        data.extend(floor_section()); // section 1: stone floor at y=0 -> height 16
        let ch = parse_chunk(&data).unwrap();
        assert_eq!(ch.heights[0], 16);
        assert_eq!(ch.colors[255] >> 24, 0xFF);
    }

    #[test]
    fn uniform_stone_and_empty_columns() {
        let data = uniform_section(1);
        let ch = parse_chunk(&data).unwrap();
        assert_eq!(ch.heights[17], 15);
        let air = parse_chunk(&uniform_section(0)).unwrap();
        assert_eq!(air.colors[3], 0);
    }

    #[test]
    fn water_gets_darker_with_depth() {
        let shallow = water_color(1);
        let deep = water_color(20);
        assert!((shallow & 0xFF) > (deep & 0xFF));
        let ch = parse_chunk(&uniform_section(80)).unwrap(); // all water
        assert_eq!(ch.colors[0], water_color(16));
    }

    #[test]
    fn truncated_data_is_an_error() {
        let mut d = uniform_section(1);
        d.truncate(4);
        assert!(parse_chunk(&d).is_err());
    }

    #[test]
    fn render_marks_missing_chunks_and_positions_origin() {
        let mut w = World::default();
        w.insert(0, 0, parse_chunk(&uniform_section(1)).unwrap());
        let img = w.render(5.0, 5.0, 1);
        assert_eq!((img[0], img[1], img[2], img[3]), (48, 48, -16, -16));
        let centre = img[4 + (16 + 5) * 48 + (16 + 5)] as u32;
        assert_eq!(centre >> 24, 0xFF);
        assert_ne!(centre, 0xFF1E1E1E);
        assert!(img[4] as u32 == 0xFF1E1E1E || img[4] as u32 == 0xFF262626);
    }
}
