// Copyright (c) 2026 SAROJGMG (Prajwal). All rights reserved. See LICENSE.
//! End-to-end tests: the real client engine against an in-process mock server that speaks
//! protocol 763 (status, offline login, compression, play packets).
//! NOTE: this is a mock written from the protocol spec, not a real Paper/Purpur server.

use chatcraft_core::codec::*;
use chatcraft_core::session::{self, ConnectParams};
use chatcraft_core::status;
use serde_json::Value;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use tokio::io::{AsyncWriteExt, BufReader};
use tokio::net::{TcpListener, TcpStream};

const THRESHOLD: i32 = 64;

/// (window, state id, slot, button, mode, changed slots, cursor present) of every window click received.
static CLICKS: Mutex<Vec<(u8, i32, i16, i8, i32, i32, u8)>> = Mutex::new(Vec::new());

fn sword_id() -> i32 {
    chatcraft_core::items::ITEM_NAMES.iter().position(|n| *n == "diamond_sword").unwrap() as i32
}

fn slot_bytes(p: &mut Vec<u8>, item: Option<(i32, i8)>) {
    match item {
        None => p.push(0),
        Some((id, n)) => {
            p.push(1);
            write_varint(p, id);
            p.push(n as u8);
            p.push(0); // no NBT
        }
    }
}

fn uuid_n(n: u8) -> [u8; 16] {
    let mut u = [0u8; 16];
    u[15] = n;
    u
}

async fn send(w: &mut tokio::net::tcp::OwnedWriteHalf, payload: Vec<u8>, th: i32) {
    w.write_all(&encode_packet(&payload, th)).await.unwrap();
}

fn play_login_packet() -> Vec<u8> {
    let mut p = Vec::new();
    write_varint(&mut p, 0x28);
    p.extend_from_slice(&7i32.to_be_bytes()); // entity id
    p.push(0); // hardcore
    p.push(1); // gamemode
    p.push(0xFF); // previous gamemode (-1)
    write_varint(&mut p, 1);
    write_string(&mut p, "minecraft:overworld");
    p.extend_from_slice(&[10, 0, 0, 8, 0, 1, b'k', 0, 1, b'v', 0]); // NBT compound { "k": "v" }
    write_string(&mut p, "minecraft:overworld");
    write_string(&mut p, "minecraft:overworld");
    write_i64(&mut p, 12345);
    write_varint(&mut p, 20); // max players
    write_varint(&mut p, 8);
    write_varint(&mut p, 8);
    p.extend_from_slice(&[0, 1, 0, 0]); // reducedDebug, respawnScreen, isDebug, isFlat
    p.push(0); // no death location
    write_varint(&mut p, 0);
    p
}

async fn handle(stream: TcpStream, seen: Arc<Mutex<Vec<i32>>>, mode: &'static str) {
    let (rd, mut wr) = stream.into_split();
    let mut rd = BufReader::new(rd);
    let (hs, _) = read_packet(&mut rd, -1).await.unwrap();
    let mut r = Reader::new(&hs);
    assert_eq!(r.read_varint().unwrap(), 0);
    assert_eq!(r.read_varint().unwrap(), 763, "client must announce protocol 763");
    let _host = r.read_string().unwrap();
    let _port = r.read_u16().unwrap();
    let next = r.read_varint().unwrap();

    if next == 1 {
        let _req = read_packet(&mut rd, -1).await.unwrap();
        let json = r#"{"version":{"name":"Mock 1.20.1","protocol":763},"players":{"max":20,"online":1},"description":{"text":"Mock MOTD","color":"gold"}}"#;
        let mut p = Vec::new();
        write_varint(&mut p, 0);
        write_string(&mut p, json);
        send(&mut wr, p, -1).await;
        let (ping, _) = read_packet(&mut rd, -1).await.unwrap();
        send(&mut wr, ping, -1).await;
        return;
    }

    let (ls, _) = read_packet(&mut rd, -1).await.unwrap();
    let mut r = Reader::new(&ls);
    assert_eq!(r.read_varint().unwrap(), 0);
    let name = r.read_string().unwrap();

    if mode == "online" {
        let mut p = Vec::new();
        write_varint(&mut p, 0x01);
        write_string(&mut p, "");
        write_varint(&mut p, 4);
        p.extend_from_slice(&[1, 2, 3, 4]);
        write_varint(&mut p, 4);
        p.extend_from_slice(&[5, 6, 7, 8]);
        send(&mut wr, p, -1).await;
        tokio::time::sleep(Duration::from_millis(500)).await;
        return;
    }

    let mut p = Vec::new();
    write_varint(&mut p, 0x03);
    write_varint(&mut p, THRESHOLD);
    send(&mut wr, p, -1).await;
    let mut p = Vec::new();
    write_varint(&mut p, 0x02);
    p.extend_from_slice(&uuid_n(1));
    write_string(&mut p, &name);
    write_varint(&mut p, 0);
    send(&mut wr, p, THRESHOLD).await;

    send(&mut wr, play_login_packet(), THRESHOLD).await;

    // position sync
    let mut p = Vec::new();
    write_varint(&mut p, 0x3c);
    write_f64(&mut p, 10.0);
    write_f64(&mut p, 64.0);
    write_f64(&mut p, -5.5);
    write_f32(&mut p, 90.0);
    write_f32(&mut p, 0.0);
    p.push(0);
    write_varint(&mut p, 42);
    send(&mut wr, p, THRESHOLD).await;

    // player info: add + listed + latency for the bot (1) and Alice (2)
    let mut p = Vec::new();
    write_varint(&mut p, 0x3a);
    p.push(0x01 | 0x08 | 0x10);
    write_varint(&mut p, 2);
    for (n, nm, lat) in [(1u8, name.as_str(), 5), (2u8, "Alice", 12)] {
        p.extend_from_slice(&uuid_n(n));
        write_string(&mut p, nm);
        write_varint(&mut p, 0);
        p.push(1);
        write_varint(&mut p, lat);
    }
    send(&mut wr, p, THRESHOLD).await;

    // system chat with colours + a long line to exercise compression
    let mut p = Vec::new();
    write_varint(&mut p, 0x64);
    let long = "x".repeat(300);
    write_string(&mut p, &format!(r#"{{"text":"Welcome {long}","color":"green"}}"#));
    p.push(0);
    send(&mut wr, p, THRESHOLD).await;

    // signed-style player chat from Alice (no signature present)
    let mut p = Vec::new();
    write_varint(&mut p, 0x35);
    p.extend_from_slice(&uuid_n(2));
    write_varint(&mut p, 0);
    p.push(0); // no signature
    write_string(&mut p, "hello from Alice ✓");
    write_i64(&mut p, 1);
    write_i64(&mut p, 2);
    write_varint(&mut p, 0); // previous messages
    p.push(0); // no unsigned content
    write_varint(&mut p, 0); // filter type
    write_varint(&mut p, 0); // chat type
    write_string(&mut p, r#"{"text":"Alice"}"#);
    p.push(0);
    send(&mut wr, p, THRESHOLD).await;

    // held item slot = 3
    send(&mut wr, vec![0x4d, 3], THRESHOLD).await;

    // player inventory (window 0): sword in hotbar slot 36
    let mut p = Vec::new();
    write_varint(&mut p, 0x12);
    p.push(0);
    write_varint(&mut p, 5);
    write_varint(&mut p, 46);
    for i in 0..46 {
        slot_bytes(&mut p, if i == 36 { Some((sword_id(), 1)) } else { None });
    }
    slot_bytes(&mut p, None);
    send(&mut wr, p, THRESHOLD).await;

    // a chest (window 2) with 63 slots; slot 4 holds 2 swords
    let mut p = Vec::new();
    write_varint(&mut p, 0x30);
    write_varint(&mut p, 2);
    write_varint(&mut p, 2);
    write_string(&mut p, r#"{"text":"Chest"}"#);
    send(&mut wr, p, THRESHOLD).await;
    let mut p = Vec::new();
    write_varint(&mut p, 0x12);
    p.push(2);
    write_varint(&mut p, 1);
    write_varint(&mut p, 63);
    for i in 0..63 {
        slot_bytes(&mut p, if i == 4 { Some((sword_id(), 2)) } else { None });
    }
    slot_bytes(&mut p, None);
    send(&mut wr, p, THRESHOLD).await;

    // keep alive
    let mut p = Vec::new();
    write_varint(&mut p, 0x23);
    write_i64(&mut p, 777);
    send(&mut wr, p, THRESHOLD).await;

    // chunk (0,-1): one uniform stone section
    let mut p = Vec::new();
    write_varint(&mut p, 0x24);
    p.extend_from_slice(&0i32.to_be_bytes());
    p.extend_from_slice(&(-1i32).to_be_bytes());
    p.extend_from_slice(&[10, 0, 0, 0]); // empty heightmaps NBT
    let section = [0u8, 0, 0, 1, 0, 0, 0, 0];
    write_varint(&mut p, section.len() as i32);
    p.extend_from_slice(&section);
    write_varint(&mut p, 0); // block entities
    for _ in 0..6 {
        write_varint(&mut p, 0); // light masks and arrays
    }
    send(&mut wr, p, THRESHOLD).await;

    // item map 7: 4x2 patch at (10, 20)
    let mut p = Vec::new();
    write_varint(&mut p, 0x29);
    write_varint(&mut p, 7);
    p.push(2); // scale
    p.push(0); // locked
    p.push(0); // no icons
    p.extend_from_slice(&[4, 2, 10, 20]);
    write_varint(&mut p, 8);
    p.extend_from_slice(&[6; 8]);
    send(&mut wr, p, THRESHOLD).await;

    // HUD: title, boss bar, sidebar scoreboard
    let mut p = Vec::new();
    write_varint(&mut p, 0x5f);
    write_string(&mut p, r#"{"text":"Hello","color":"gold"}"#);
    send(&mut wr, p, THRESHOLD).await;
    let mut p = Vec::new();
    write_varint(&mut p, 0x0b);
    p.extend_from_slice(&uuid_n(9));
    write_varint(&mut p, 0);
    write_string(&mut p, r#"{"text":"Boss"}"#);
    write_f32(&mut p, 0.5);
    write_varint(&mut p, 1);
    write_varint(&mut p, 0);
    p.push(0);
    send(&mut wr, p, THRESHOLD).await;
    let mut p = Vec::new();
    write_varint(&mut p, 0x58);
    write_string(&mut p, "side");
    p.push(0);
    write_string(&mut p, r#"{"text":"Side"}"#);
    write_varint(&mut p, 0);
    send(&mut wr, p, THRESHOLD).await;
    let mut p = Vec::new();
    write_varint(&mut p, 0x51);
    p.push(1);
    write_string(&mut p, "side");
    send(&mut wr, p, THRESHOLD).await;
    let mut p = Vec::new();
    write_varint(&mut p, 0x5b);
    write_string(&mut p, "Alice");
    write_varint(&mut p, 0);
    write_string(&mut p, "side");
    write_varint(&mut p, 3);
    send(&mut wr, p, THRESHOLD).await;

    // entities: a zombie (type 118) that then moves one block east, and a player
    let mut p = Vec::new();
    write_varint(&mut p, 0x01);
    write_varint(&mut p, 50);
    p.extend_from_slice(&uuid_n(5));
    write_varint(&mut p, 118);
    write_f64(&mut p, 12.0);
    write_f64(&mut p, 64.0);
    write_f64(&mut p, -4.0);
    send(&mut wr, p, THRESHOLD).await;
    let mut p = Vec::new();
    write_varint(&mut p, 0x2b);
    write_varint(&mut p, 50);
    p.extend_from_slice(&4096i16.to_be_bytes());
    p.extend_from_slice(&[0, 0, 0, 0, 1]);
    send(&mut wr, p, THRESHOLD).await;
    let mut p = Vec::new();
    write_varint(&mut p, 0x03);
    write_varint(&mut p, 51);
    p.extend_from_slice(&uuid_n(2));
    write_f64(&mut p, 8.0);
    write_f64(&mut p, 64.0);
    write_f64(&mut p, -3.0);
    send(&mut wr, p, THRESHOLD).await;

    loop {
        let (pkt, _) = match read_packet(&mut rd, THRESHOLD).await {
            Ok(x) => x,
            Err(_) => return,
        };
        let mut r = Reader::new(&pkt);
        let id = r.read_varint().unwrap();
        seen.lock().unwrap().push(id);
        if id == 0x0b {
            let w = r.read_u8().unwrap();
            let st = r.read_varint().unwrap();
            let sl = r.read_i16().unwrap();
            let b = r.read_i8().unwrap();
            let m = r.read_varint().unwrap();
            let ch = r.read_varint().unwrap();
            let cur = r.read_u8().unwrap();
            CLICKS.lock().unwrap().push((w, st, sl, b, m, ch, cur));
        }
        if id == 0x09 {
            let tx = r.read_varint().unwrap();
            let text = r.read_string().unwrap();
            assert_eq!(text, "/he");
            let mut p = Vec::new();
            write_varint(&mut p, 0x0f);
            write_varint(&mut p, tx);
            write_varint(&mut p, 1); // start (after the slash)
            write_varint(&mut p, 2); // length
            write_varint(&mut p, 2);
            for m in ["help", "heal"] {
                write_string(&mut p, m);
                p.push(0); // no tooltip
            }
            send(&mut wr, p, THRESHOLD).await;
        }
        if id == 0x05 {
            let msg = r.read_string().unwrap();
            if msg == "bye" {
                let mut p = Vec::new();
                write_varint(&mut p, 0x1a);
                write_string(&mut p, r#"{"text":"Kicked: test over","color":"red"}"#);
                send(&mut wr, p, THRESHOLD).await;
                return;
            }
            let mut p = Vec::new();
            write_varint(&mut p, 0x64);
            write_string(&mut p, &format!(r#"{{"text":"echo:{msg}"}}"#));
            p.push(0);
            send(&mut wr, p, THRESHOLD).await;
        }
    }
}

async fn spawn_server(mode: &'static str) -> (u16, Arc<Mutex<Vec<i32>>>) {
    let l = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = l.local_addr().unwrap().port();
    let seen = Arc::new(Mutex::new(Vec::new()));
    let s2 = seen.clone();
    tokio::spawn(async move {
        loop {
            let (s, _) = l.accept().await.unwrap();
            let s3 = s2.clone();
            tokio::spawn(handle(s, s3, mode));
        }
    });
    (port, seen)
}

fn poll(sh: &Arc<session::Shared>) -> Value {
    serde_json::from_str(&sh.poll_json()).unwrap()
}

async fn collect_until(sh: &Arc<session::Shared>, secs: u64, done: impl Fn(&[Value], &Value) -> bool) -> (Vec<Value>, Value) {
    let end = Instant::now() + Duration::from_secs(secs);
    let mut all = Vec::new();
    loop {
        let v = poll(sh);
        all.extend(v["events"].as_array().unwrap().iter().cloned());
        if !v["inventory"].is_null() {
            all.push(serde_json::json!({ "type": "inventory", "inv": v["inventory"].clone() }));
        }
        if done(&all, &v) {
            return (all, v);
        }
        assert!(Instant::now() < end, "timed out; events so far: {all:#?}");
        tokio::time::sleep(Duration::from_millis(50)).await;
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn status_ping_reports_version_motd_latency() {
    let (port, _) = spawn_server("offline").await;
    let info = status::ping("127.0.0.1", port, Duration::from_secs(5)).await.unwrap();
    assert_eq!(info.version_name, "Mock 1.20.1");
    assert!(info.exact_protocol_match);
    assert_eq!(info.players_online, 1);
    assert_eq!(info.motd, "§r§6Mock MOTD");
}

#[test]
fn full_offline_session_chat_players_position_kick() {
    let rt = tokio::runtime::Runtime::new().unwrap();
    let (port, seen) = rt.block_on(spawn_server("offline"));
    let mut p = ConnectParams::offline("127.0.0.1", port, "MrBoss");
    p.auto_reconnect = false;
    let sh = session::start(p);

    let ok = |ev: &[Value]| {
        ev.iter().any(|e| e["type"] == "chat" && e["text"].as_str().unwrap_or("").contains("echo:hi there"))
    };
    // wait until the join burst has arrived
    rt.block_on(async {
        let (ev, _) = collect_until(&sh, 10, |ev, _| {
            ev.iter().any(|e| e["type"] == "chat" && e["kind"] == "player")
                && ev.iter().any(|e| e["type"] == "position")
                && ev.iter().any(|e| e["type"] == "inventory" && e["inv"]["window_id"] == 2 && e["inv"]["slots"].as_array().map(|a| a.len() == 63).unwrap_or(false))
                && ev.iter().any(|e| e["type"] == "title")
                && ev.iter().any(|e| e["type"] == "boss_bar")
                && ev.iter().any(|e| e["type"] == "sidebar" && e["lines"].as_array().map(|l| !l.is_empty()).unwrap_or(false))
        })
        .await;
        let t = ev.iter().find(|e| e["type"] == "title").unwrap();
        assert_eq!(t["kind"], "title");
        assert_eq!(t["text"], "§r§6Hello");
        let b = ev.iter().find(|e| e["type"] == "boss_bar").unwrap();
        assert_eq!((b["action"].as_str().unwrap(), b["title"].as_str().unwrap()), ("add", "Boss"));
        assert_eq!(b["health"], 0.5);
        let sb = ev.iter().rev().find(|e| e["type"] == "sidebar").unwrap();
        assert_eq!(sb["title"], "Side");
        assert_eq!(sb["lines"][0]["text"], "Alice");
        assert_eq!(sb["lines"][0]["score"], 3);
        let st: Vec<_> = ev.iter().filter(|e| e["type"] == "state").map(|e| e["state"].as_str().unwrap()).collect();
        assert_eq!(st, ["connecting", "login", "play"]);
        let info = ev.iter().find(|e| e["type"] == "info").unwrap();
        assert_eq!(info["max_players"], 20);
        assert_eq!(info["username"], "MrBoss");
        assert_eq!(info["uuid"], "00000000-0000-0000-0000-000000000001");
        let players = ev.iter().rev().find(|e| e["type"] == "players").unwrap();
        let names: Vec<_> = players["players"].as_array().unwrap().iter().map(|p| p["name"].as_str().unwrap()).collect();
        assert_eq!(names, ["Alice", "MrBoss"]);
        assert_eq!(players["players"][0]["latency"], 12);
        let sys = ev.iter().find(|e| e["type"] == "chat" && e["kind"] == "system").unwrap();
        assert!(sys["text"].as_str().unwrap().starts_with("§r§aWelcome xxx"));
        let pc = ev.iter().find(|e| e["type"] == "chat" && e["kind"] == "player").unwrap();
        assert_eq!(pc["sender"], "Alice");
        assert_eq!(pc["text"], "hello from Alice ✓");
        let pos = ev.iter().find(|e| e["type"] == "position").unwrap();
        assert_eq!(pos["x"], 10.0);
        assert_eq!(pos["z"], -5.5);
        let chest = ev.iter().rev().find(|e| e["type"] == "inventory" && e["inv"]["window_id"] == 2).unwrap();
        assert_eq!(chest["inv"]["title"], "Chest");
        assert_eq!(chest["inv"]["slots"][4]["name"], "diamond_sword");
        assert_eq!(chest["inv"]["slots"][4]["count"], 2);
        assert!(chest["inv"]["slots"][5].is_null());
        assert_eq!(chest["inv"]["held"], 3);
    });

    sh.click_slot(2, 4, 1, 0).unwrap(); // right-click chest slot 4
    sh.click_slot(2, 7, 0, 4).unwrap(); // drop-one from slot 7
    sh.hold_slot(5).unwrap();
    assert!(sh.click_slot(9, 0, 0, 0).is_err(), "clicking a window that is not open must fail");
    sh.close_window(2).unwrap();
    let tx = sh.request_completions("/he").unwrap();
    sh.send_chat("hi there").unwrap();
    sh.send_chat("/list").unwrap();
    sh.move_by(1.0, 0.0, 0.0).unwrap();
    sh.use_item(0).unwrap();
    sh.swing().unwrap();
    sh.interact_block(1, 64, -3, 1).unwrap();
    rt.block_on(async {
        let (ev, v) = collect_until(&sh, 10, |ev, _| {
            ok(ev)
                && ev.iter().any(|e| e["type"] == "completions")
        })
        .await;
        assert!(v["stats"]["bytes_in"].as_u64().unwrap() > 300);
        assert!(v["stats"]["packets_in"].as_u64().unwrap() >= 6);
        let c = ev.iter().find(|e| e["type"] == "completions").unwrap();
        assert_eq!(c["tx"], tx);
        assert_eq!(c["start"], 1);
        assert_eq!(c["length"], 2);
        assert_eq!(c["matches"][0], "help");
        assert_eq!(c["matches"][1], "heal");
    });
    {
        // minimap and item map were decoded from the chunk / map packets
        let end = Instant::now() + Duration::from_secs(5);
        loop {
            let mm = sh.minimap(1);
            let px = mm[4 + 26 * 48 + 27] as u32; // block (11, -6)
            let map_ok = sh.map_pixels(7).get(20 * 128 + 10).copied() == Some(0xFF7FB238u32 as i32);
            if px >> 24 == 0xFF && px != 0xFF1E1E1E && px != 0xFF262626 && map_ok {
                assert_eq!((mm[0], mm[1], mm[2], mm[3]), (48, 48, -16, -32));
                assert!(sh.map_list_json().contains("\"id\":7"));
                break;
            }
            assert!(Instant::now() < end, "minimap/map never arrived");
            std::thread::sleep(Duration::from_millis(50));
        }
    }
    {
        // radar: the zombie moved one block east by the relative-move packet; the player is listed too
        let end = Instant::now() + Duration::from_secs(5);
        loop {
            let list: Value = serde_json::from_str(&sh.entities_json()).unwrap();
            let arr = list.as_array().unwrap();
            let z = arr.iter().find(|e| e["n"] == "zombie");
            let pl = arr.iter().find(|e| e["n"] == "player");
            if let (Some(z), Some(_)) = (z, pl) {
                if (z["x"].as_f64().unwrap() - 13.0).abs() < 0.001 && z["k"] == 2 {
                    break;
                }
            }
            assert!(Instant::now() < end, "radar entities never arrived: {list}");
            std::thread::sleep(Duration::from_millis(50));
        }
    }
    {
        let want_ids = [0x08, 0x0d, 0x00, 0x15, 0x12, 0x05, 0x04, 0x14, 0x0b, 0x0c, 0x28, 0x32, 0x2f, 0x31];
        let end = Instant::now() + Duration::from_secs(5);
        loop {
            let ids = seen.lock().unwrap().clone();
            let missing: Vec<_> = want_ids.iter().filter(|w| !ids.contains(w)).collect();
            if missing.is_empty() {
                break;
            }
            assert!(Instant::now() < end, "server never received packets {missing:x?}; got {ids:x?}");
            std::thread::sleep(Duration::from_millis(50));
        }
    }

    {
        let clicks = CLICKS.lock().unwrap().clone();
        assert!(clicks.contains(&(2, 1, 4, 1, 0, 0, 0)), "clicks: {clicks:?}");
        assert!(clicks.contains(&(2, 1, 7, 0, 4, 0, 0)), "clicks: {clicks:?}");
    }
    sh.send_chat("bye").unwrap();
    rt.block_on(async {
        let (ev, v) = collect_until(&sh, 10, |_, v| v["state"] == "disconnected").await;
        let _ = ev;
        assert!(v["detail"].as_str().unwrap().contains("Kicked: test over"));
    });
}

#[test]
fn online_mode_server_is_refused_honestly() {
    let rt = tokio::runtime::Runtime::new().unwrap();
    let (port, _) = rt.block_on(spawn_server("online"));
    let mut p = ConnectParams::offline("127.0.0.1", port, "Tester");
    p.auto_reconnect = false;
    let sh = session::start(p);
    rt.block_on(async {
        let (_, v) = collect_until(&sh, 10, |_, v| v["state"] == "error").await;
        assert!(v["detail"].as_str().unwrap().contains("online-mode"));
    });
}

#[test]
fn reconnects_after_connection_loss_and_can_be_cancelled() {
    let rt = tokio::runtime::Runtime::new().unwrap();
    // Nothing listens on this port: expect "reconnecting", then clean cancel.
    let l = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
    let port = l.local_addr().unwrap().port();
    drop(l);
    let mut p = ConnectParams::offline("127.0.0.1", port, "Tester");
    p.max_retries = 3;
    let sh = session::start(p);
    rt.block_on(async {
        collect_until(&sh, 10, |ev, _| ev.iter().any(|e| e["state"] == "reconnecting")).await;
    });
    sh.disconnect();
    rt.block_on(async {
        collect_until(&sh, 10, |_, v| v["state"] == "disconnected").await;
    });
}

#[test]
fn invalid_username_is_rejected_before_connecting() {
    let mut p = ConnectParams::offline("127.0.0.1", 1, "no spaces!");
    p.auto_reconnect = false;
    let sh = session::start(p);
    let end = Instant::now() + Duration::from_secs(5);
    loop {
        let v = poll(&sh);
        if v["state"] == "error" {
            assert!(v["detail"].as_str().unwrap().contains("Username"));
            return;
        }
        assert!(Instant::now() < end);
        std::thread::sleep(Duration::from_millis(50));
    }
}
