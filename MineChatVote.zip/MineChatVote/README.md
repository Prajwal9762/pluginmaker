# MineChatVote

A voting system plugin for Minecraft servers with rewards and voteparty features.

## Features

- **Multiple Voting Sites:** Add as many voting sites as you want (TopMC, TopG, MinecraftMP, custom, etc.)
- **Per-Site Configuration:** Each site has its own rewards, cooldown, icon, and URL
- **Randomized Rewards:** Keys with min/max amounts and chance percentages
- **VoteParty:** Every 20 verified votes, all online players get bonus rewards
- **GUI-Based:** `/vote` for players, `/vote admin` for staff (also editable via config.yml)
- **Easy Integration:** Works with CoinsPlus (requires it as a dependency)

## Commands

- `/vote` - Open the voting GUI
- `/vote top` - Show top voters
- `/vote admin` - Admin panel (staff only, permission: `minechatvote.admin`)
- `/vote confirm <player> <site>` - Manually confirm a vote

## Installation

1. Place `MineChatVote.jar` in your `plugins/` folder
2. Make sure `CoinsPlus` is installed (dependency)
3. Restart the server
4. Edit `plugins/MineChatVote/config.yml` to configure your voting sites
5. Replace the example URLs with your real voting site server IDs
6. Run `/coinsadmin reload` to reload configs

## Configuration

Edit `config.yml` to:
- Enable/disable voting sites
- Change URLs and icons
- Adjust reward amounts and chances
- Set cooldown times
- Configure voteparty triggers and rewards

Example site configuration:
```yaml
sites:
  topmc:
    enabled: true
    name: "&a&lTopMC"
    icon: DIAMOND
    url: "https://topmc.com/server/YOUR-SERVER-ID/vote"
    cooldown-minutes: 1440
    rewards:
      coins: 50
      keys:
        daily:  { min: 2, max: 5, chance: 100 }
        rare:   { min: 1, max: 3, chance: 100 }
        money:  { min: 1, max: 2, chance: 20 }
```

## Reward Mechanics

### Keys
Each key type can have:
- **min:** Minimum number of keys to give
- **max:** Maximum number of keys to give (random between min-max)
- **chance:** Percentage chance to receive this key type

### VoteParty
- Triggers every 20 real verified votes (across all sites)
- All online players receive the configured rewards
- Resets count after giving rewards

## Voting Sites Examples

### TopMC
1. Get your server ID from TopMC dashboard
2. Replace `YOUR-SERVER-ID` in the URL
3. Enable the site in config.yml
4. Restart or `/vote admin reload`

### TopG / Top.gg
1. Get your server ID from the Top.gg dashboard
2. Replace `YOUR-SERVER-ID` in the URL
3. Same as TopMC setup

### MinecraftMP
1. Get your server IP and port
2. Replace in URL
3. Enable in config

### Custom Site
1. Change the URL to your voting site
2. Customize rewards
3. Enable

## Permissions

- `minechatvote.admin` - Access `/vote admin` command

## Depends On

- **CoinsPlus** - For giving coins and keys

## Support

Edit `config.yml` to customize everything. No additional setup needed beyond CoinsPlus integration.
