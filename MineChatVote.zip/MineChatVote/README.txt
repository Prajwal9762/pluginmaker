MineChatVote 1.0.0

Voting system with rewards and voteparty.

COMMANDS:
  /vote              open the voting GUI
  /vote top          show top voters
  /vote admin        admin panel (needs minechatvote.admin permission)
  /vote confirm <player> <site>  manually confirm a vote

SETUP:
  1. CoinsPlus must be installed (dependency)
  2. Edit config.yml with your voting site URLs
  3. Enable sites and set rewards
  4. Restart or do /coinsadmin reload

VOTING SITES:
  - TopMC, TopG, MinecraftMP examples are included
  - Change the URLs to your real server IDs
  - Each site is independent: rewards, cooldown, icon

VOTEPARTY:
  - Every 20 real verified votes, all online players get rewards
  - Configured in voteparty: section of config.yml
  - Default: 10k coins + 10 daily keys + 3 rare keys per player

REWARDS:
  Each key can have min/max amounts (random) and a chance %.
  Example: { min: 2, max: 5, chance: 100 }
    = 2-5 keys, guaranteed (100%)
  
  Example: { min: 1, max: 1, chance: 20 }
    = 1 key, only 20% of the time

KEYS MUST EXIST in CoinsPlus config.yml!
  Make sure your key ids (daily, rare, money) match CoinsPlus.

For more info, see config.yml comments.
