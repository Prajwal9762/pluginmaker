package com.minechat.vote;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;

public class AdminGUI {
    private static final int RELOAD_SLOT = 41;
    private static final int CLOSE_SLOT = 43;

    private final VotePlugin pl;

    public AdminGUI(VotePlugin pl) { this.pl = pl; }

    public void open(Player p) {
        if (!p.hasPermission("minechatvote.admin")) { pl.msg(p, "&cNo permission."); return; }

        MenuHolder holder = new MenuHolder(MenuHolder.Type.ADMIN, null);
        Inventory inv = Bukkit.createInventory(holder, 45, pl.mm("&c&lVote Admin"));
        holder.setInventory(inv);

        inv.setItem(4, pl.item(Material.WRITABLE_BOOK, "&c&lVoting sites",
                List.of("&7Edit in config.yml", "&7Then click reload (or /vote reload)")));

        int idx = 0;
        for (String id : pl.getSites()) {
            if (idx >= VotePlugin.SITE_SLOTS.length) break;
            String url = pl.siteUrl(id);
            inv.setItem(VotePlugin.SITE_SLOTS[idx++], pl.item(pl.siteIcon(id), pl.siteName(id), List.of(
                    "&7ID: &f" + id,
                    "&7Enabled: " + (pl.siteEnabled(id) ? "&ayes" : "&cno"),
                    "&7URL: &f" + url.substring(0, Math.min(50, url.length()))
            )));
        }

        inv.setItem(RELOAD_SLOT, pl.item(Material.REDSTONE_TORCH, "&a&lReload config", null));
        inv.setItem(CLOSE_SLOT, pl.item(Material.BARRIER, "&7Close", null));
        p.openInventory(inv);
    }

    public void handleClick(Player p, int slot) {
        if (!p.hasPermission("minechatvote.admin")) return;
        if (slot == CLOSE_SLOT) {
            p.closeInventory();
        } else if (slot == RELOAD_SLOT) {
            pl.reloadAll();
            pl.msg(p, "&aMineChatVote reloaded.");
            open(p);
        }
    }
}
