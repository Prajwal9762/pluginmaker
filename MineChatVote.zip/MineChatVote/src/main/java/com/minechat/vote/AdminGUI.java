package com.minechat.vote;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;

public class AdminGUI {
    private final VotePlugin pl;

    public AdminGUI(VotePlugin pl) { this.pl = pl; }

    public void open(Player p) {
        if (!p.hasPermission("minechatvote.admin")) { pl.msg(p, "&cNo permission."); return; }
        Inventory inv = Bukkit.createInventory(null, 45, pl.mm("&c&lVote Admin"));
        
        ItemStack info = new ItemStack(Material.WRITABLE_BOOK);
        ItemMeta im = info.getItemMeta();
        im.displayName(pl.mm("&c&lVoting sites"));
        im.lore(List.of(pl.mm("&7Edit in config.yml"), pl.mm("&7Then do /coinsadmin reload")));
        info.setItemMeta(im);
        inv.setItem(4, info);
        
        int idx = 0;
        for (String id : pl.getSites()) {
            ItemStack it = new ItemStack(pl.siteIcon(id));
            ItemMeta itm = it.getItemMeta();
            itm.displayName(pl.mm(pl.siteName(id)));
            itm.lore(List.of(
                pl.mm("&7ID: &f" + id),
                pl.mm("&7Enabled: " + (pl.siteEnabled(id) ? "&ayes" : "&cno")),
                pl.mm("&7URL: &f" + pl.siteUrl(id).substring(0, Math.min(50, pl.siteUrl(id).length())))
            ));
            it.setItemMeta(itm);
            int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33};
            if (idx < slots.length) inv.setItem(slots[idx++], it);
        }
        
        ItemStack reload = new ItemStack(Material.REDSTONE_TORCH);
        ItemMeta rm = reload.getItemMeta();
        rm.displayName(pl.mm("&a&lReload config"));
        reload.setItemMeta(rm);
        inv.setItem(41, reload);
        
        inv.setItem(43, pl.mm("&7Close"));
        p.openInventory(inv);
    }
}
