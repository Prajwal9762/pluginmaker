package com.minechat.vote;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Marks our inventories so clicks are handled safely (no title matching). */
public final class MenuHolder implements InventoryHolder {

    public enum Type { VOTE_MAIN, VOTE_SITE, TOP, ADMIN }

    private final Type type;
    private final String siteId;
    private Inventory inventory;

    public MenuHolder(Type type, String siteId) {
        this.type = type;
        this.siteId = siteId;
    }

    public Type type() { return type; }
    public String siteId() { return siteId; }
    void setInventory(Inventory inventory) { this.inventory = inventory; }

    @Override
    public Inventory getInventory() { return inventory; }
}
