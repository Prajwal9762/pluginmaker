package com.minechat.vote;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.*;

public class VoteGUI {
    private final VotePlugin pl;
    private final Map<UUID, String> currentSite = new HashMap<>();

    public VoteGUI(VotePlugin pl) { this.pl = pl; }

    public void open(Player p) {
        Inventory inv = Bukkit.createInventory(null, 45, pl.mm("&a&lVote for the server"));
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta sm = (SkullMeta) head.getItemMeta();
        sm.setOwningPlayer(p);
        sm.displayName(pl.mm("&e&l" + p.getName()));
        sm.lore(List.of(pl.mm("&7Total votes: &f" + pl.getVoteCount(p.getUniqueId()))));
        head.setItemMeta(sm);
        inv.setItem(4, head);

        int idx = 0;
        for (String id : pl.getSites()) {
            if (!pl.siteEnabled(id)) continue;
            ItemStack it = new ItemStack(pl.siteIcon(id));
            ItemMeta im = it.getItemMeta();
            im.displayName(pl.mm(pl.siteName(id)));
            List<String> lore = new ArrayList<>();
            long coins = pl.getConfig().getLong("sites." + id + ".rewards.coins", 50);
            if (coins > 0) lore.add(pl.mm("&eReward: &6" + coins + " coins"));
            org.bukkit.configuration.ConfigurationSection keys = pl.getConfig().getConfigurationSection("sites." + id + ".rewards.keys");
            if (keys != null) for (String k : keys.getKeys(false)) {
                int min = keys.getInt(k + ".min", 1);
                int max = keys.getInt(k + ".max", 1);
                double chance = keys.getDouble(k + ".chance", 100);
                if (min > 0) lore.add(pl.mm("&eReward: &6" + k + " ×" + (min == max ? min : min + "-" + max) + (chance < 100 ? " &7(" + (int)chance + "%)" : " &a(guaranteed)")));
            }
            lore.add(pl.mm("&eClick to vote"));
            im.lore(lore);
            it.setItemMeta(im);
            int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33};
            if (idx < slots.length) inv.setItem(slots[idx++], it);
        }

        inv.setItem(37, pl.mm("&e&lTop voters"));
        inv.setItem(43, pl.mm("&7Close"));
        p.openInventory(inv);
    }

    public void handleClick(InventoryClickEvent e) {
        Player p = (Player) e.getWhoClicked();
        e.setCancelled(true);
        int slot = e.getSlot();
        String title = e.getView().getTitle();
        
        if (title.contains("Vote on")) {
            String id = currentSite.get(p.getUniqueId());
            if (id == null) return;
            if (slot == 11) {
                String url = pl.siteUrl(id);
                p.closeInventory();
                p.sendMessage(pl.mm(pl.prefix() + "&eVoting on &r" + pl.siteName(id) + "&e:"));
                p.sendMessage(net.kyori.adventure.text.Component.text("  ").append(
                    net.kyori.adventure.text.Component.text("[CLICK TO VOTE]", net.kyori.adventure.text.format.NamedTextColor.GREEN, net.kyori.adventure.text.format.TextDecoration.BOLD)
                        .clickEvent(net.kyori.adventure.text.event.ClickEvent.openUrl(url))
                ));
            } else if (slot == 15) {
                p.closeInventory();
                pl.registerVote(p, id);
                currentSite.remove(p.getUniqueId());
            } else if (slot == 26) {
                currentSite.remove(p.getUniqueId());
                open(p);
            }
            return;
        }
        
        if (slot == 43) p.closeInventory();
        else if (slot == 37) showTop(p);
        else {
            List<String> ids = pl.getSites().stream().filter(pl::siteEnabled).toList();
            int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33};
            for (int i = 0; i < slots.length && i < ids.size(); i++) if (slots[i] == slot) { openVotePage(p, ids.get(i)); return; }
        }
    }

    private void openVotePage(Player p, String id) {
        currentSite.put(p.getUniqueId(), id);
        Inventory inv = Bukkit.createInventory(null, 27, pl.mm("&a&lVote on &r" + pl.siteName(id)));
        
        ItemStack vote = new ItemStack(Material.COMPASS);
        ItemMeta vm = vote.getItemMeta();
        vm.displayName(pl.mm("&a&l[CLICK TO VOTE]"));
        vm.lore(List.of(pl.mm("&7Open the voting page"), pl.mm("&8" + pl.siteUrl(id))));
        vote.setItemMeta(vm);
        inv.setItem(11, vote);
        
        ItemStack claim = new ItemStack(Material.LIME_CONCRETE);
        ItemMeta cm = claim.getItemMeta();
        cm.displayName(pl.mm("&a&lI VOTED - CLAIM REWARD"));
        cm.lore(List.of(pl.mm("&7After voting, click here")));
        claim.setItemMeta(cm);
        inv.setItem(15, claim);
        
        inv.setItem(26, pl.mm("&7« Back"));
        p.openInventory(inv);
    }

    public void showTop(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, pl.mm("&e&lTop voters"));
        List<Map.Entry<UUID, Integer>> top = new ArrayList<>(pl.getVoteCounts().entrySet());
        top.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        
        int[] slots = {11, 12, 13, 14, 15, 20, 21, 22, 23, 24};
        for (int i = 0; i < Math.min(slots.length, top.size()); i++) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(top.get(i).getKey());
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(op);
            sm.displayName(pl.mm("&6#" + (i + 1) + " &f" + (op.getName() == null ? "Unknown" : op.getName())));
            sm.lore(List.of(pl.mm("&7" + top.get(i).getValue() + " votes")));
            head.setItemMeta(sm);
            inv.setItem(slots[i], head);
        }
        inv.setItem(26, pl.mm("&7« Back"));
        p.openInventory(inv);
    }
}
