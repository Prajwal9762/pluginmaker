package com.minechat.vote;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class VoteGUI {
    private final VotePlugin pl;

    public VoteGUI(VotePlugin pl) { this.pl = pl; }

    private Inventory create(MenuHolder.Type type, String siteId, int size, String title) {
        MenuHolder holder = new MenuHolder(type, siteId);
        Inventory inv = Bukkit.createInventory(holder, size, pl.mm(title));
        holder.setInventory(inv);
        return inv;
    }

    // ------------------------------------------------------------------ main menu

    public void open(Player p) {
        Inventory inv = create(MenuHolder.Type.VOTE_MAIN, null, 45, "&a&lVote for the server");

        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta sm = (SkullMeta) head.getItemMeta();
        sm.setOwningPlayer(p);
        sm.displayName(pl.ic("&e&l" + p.getName()));
        sm.lore(List.of(pl.ic("&7Total votes: &f" + pl.getVoteCount(p.getUniqueId()))));
        head.setItemMeta(sm);
        inv.setItem(4, head);

        int idx = 0;
        for (String id : pl.getEnabledSites()) {
            if (idx >= VotePlugin.SITE_SLOTS.length) break;

            List<String> lore = new ArrayList<>();
            long coins = pl.getConfig().getLong("sites." + id + ".rewards.coins", 50);
            if (coins > 0) lore.add("&eReward: &6" + coins + " coins");

            ConfigurationSection keys = pl.getConfig().getConfigurationSection("sites." + id + ".rewards.keys");
            if (keys != null) {
                for (String k : keys.getKeys(false)) {
                    int min = keys.getInt(k + ".min", 1);
                    int max = keys.getInt(k + ".max", 1);
                    double chance = keys.getDouble(k + ".chance", 100);
                    if (min <= 0) continue;
                    String amount = min == max ? String.valueOf(min) : min + "-" + max;
                    String chanceText = chance < 100 ? " &7(" + (int) chance + "%)" : " &a(guaranteed)";
                    lore.add("&eReward: &6" + k + " x" + amount + chanceText);
                }
            }

            long cd = pl.cooldownMs(id);
            long remaining = pl.getLastVote(p.getUniqueId(), id) + cd - System.currentTimeMillis();
            if (cd > 0 && remaining > 0) lore.add("&cCooldown: &f" + pl.formatTime(remaining));
            else lore.add("&eClick to vote");

            inv.setItem(VotePlugin.SITE_SLOTS[idx++], pl.item(pl.siteIcon(id), pl.siteName(id), lore));
        }

        inv.setItem(37, pl.item(Material.GOLDEN_HELMET, "&e&lTop voters", null));
        inv.setItem(43, pl.item(Material.BARRIER, "&7Close", null));
        p.openInventory(inv);
    }

    // ------------------------------------------------------------------ click handling

    public void handleClick(Player p, MenuHolder holder, int slot) {
        switch (holder.type()) {
            case VOTE_MAIN -> {
                if (slot == 43) { p.closeInventory(); return; }
                if (slot == 37) { showTop(p); return; }
                List<String> ids = pl.getEnabledSites();
                for (int i = 0; i < VotePlugin.SITE_SLOTS.length && i < ids.size(); i++) {
                    if (VotePlugin.SITE_SLOTS[i] == slot) { openVotePage(p, ids.get(i)); return; }
                }
            }
            case VOTE_SITE -> {
                String id = holder.siteId();
                if (id == null) return;
                if (slot == 11) {
                    String url = pl.siteUrl(id).replace("%player%", p.getName());
                    p.closeInventory();
                    p.sendMessage(pl.mm(pl.prefix() + "&eVoting on &r" + pl.siteName(id) + "&e:"));
                    p.sendMessage(Component.text("  ").append(
                            Component.text("[CLICK TO VOTE]", NamedTextColor.GREEN, TextDecoration.BOLD)
                                    .clickEvent(ClickEvent.openUrl(url))));
                } else if (slot == 15) {
                    p.closeInventory();
                    pl.registerVote(p, id);
                } else if (slot == 26) {
                    open(p);
                }
            }
            case TOP -> {
                if (slot == 26) open(p);
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ sub menus

    private void openVotePage(Player p, String id) {
        Inventory inv = create(MenuHolder.Type.VOTE_SITE, id, 27, "&a&lVote on &r" + pl.siteName(id));

        inv.setItem(11, pl.item(Material.COMPASS, "&a&l[CLICK TO VOTE]",
                List.of("&7Open the voting page", "&8" + pl.siteUrl(id))));
        inv.setItem(15, pl.item(Material.LIME_CONCRETE, "&a&lI VOTED - CLAIM REWARD",
                List.of("&7After voting, click here")));
        inv.setItem(26, pl.item(Material.ARROW, "&7<< Back", null));
        p.openInventory(inv);
    }

    public void showTop(Player p) {
        Inventory inv = create(MenuHolder.Type.TOP, null, 27, "&e&lTop voters");
        List<Map.Entry<UUID, Integer>> top = new ArrayList<>(pl.getVoteCounts().entrySet());
        top.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));

        int[] slots = {11, 12, 13, 14, 15, 20, 21, 22, 23, 24};
        for (int i = 0; i < Math.min(slots.length, top.size()); i++) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(top.get(i).getKey());
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(op);
            sm.displayName(pl.ic("&6#" + (i + 1) + " &f" + (op.getName() == null ? "Unknown" : op.getName())));
            sm.lore(List.of(pl.ic("&7" + top.get(i).getValue() + " votes")));
            head.setItemMeta(sm);
            inv.setItem(slots[i], head);
        }
        inv.setItem(26, pl.item(Material.ARROW, "&7<< Back", null));
        p.openInventory(inv);
    }
}
