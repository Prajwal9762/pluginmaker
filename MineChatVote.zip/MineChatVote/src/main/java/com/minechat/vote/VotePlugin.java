package com.minechat.vote;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

public class VotePlugin extends JavaPlugin implements Listener {

    private File configFile, dataFile;
    private YamlConfiguration config, data;
    private final Map<UUID, Integer> voteCount = new HashMap<>();
    private final Map<UUID, Map<String, Long>> lastVote = new HashMap<>();
    private int partyCount = 0;
    private VoteGUI voteGUI;
    private AdminGUI adminGUI;

    @Override
    public void onEnable() {
        configFile = new File(getDataFolder(), "config.yml");
        dataFile = new File(getDataFolder(), "votedata.yml");
        if (!configFile.exists()) saveDefaultConfig();
        loadAll();
        voteGUI = new VoteGUI(this);
        adminGUI = new AdminGUI(this);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("MineChatVote enabled - use /vote");
    }

    @Override
    public void onDisable() {
        saveData();
    }

    public void loadAll() {
        config = YamlConfiguration.loadConfiguration(configFile);
        data = YamlConfiguration.loadConfiguration(dataFile);
        voteCount.clear();
        lastVote.clear();
        ConfigurationSection vc = data.getConfigurationSection("votes");
        if (vc != null) for (String k : vc.getKeys(false)) {
            try {
                UUID id = UUID.fromString(k);
                voteCount.put(id, vc.getInt(k + ".count", 0));
                Map<String, Long> m = new HashMap<>();
                ConfigurationSection lv = vc.getConfigurationSection(k + ".last");
                if (lv != null) for (String site : lv.getKeys(false)) m.put(site, lv.getLong(site));
                lastVote.put(id, m);
            } catch (IllegalArgumentException ignored) {}
        }
        partyCount = data.getInt("voteparty.count", 0);
    }

    public void saveData() {
        data.set("votes", null);
        for (Map.Entry<UUID, Integer> e : voteCount.entrySet()) {
            data.set("votes." + e.getKey() + ".count", e.getValue());
            Map<String, Long> m = lastVote.getOrDefault(e.getKey(), Map.of());
            for (Map.Entry<String, Long> lv : m.entrySet()) data.set("votes." + e.getKey() + ".last." + lv.getKey(), lv.getValue());
        }
        data.set("voteparty.count", partyCount);
        try { data.save(dataFile); } catch (IOException ex) { getLogger().severe("Could not save data: " + ex); }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        if (args.length == 0) { voteGUI.open(p); return true; }
        switch (args[0].toLowerCase()) {
            case "admin" -> adminGUI.open(p);
            case "confirm" -> {
                if (!p.hasPermission("minechatvote.admin")) { msg(p, "&cNo permission."); return true; }
                if (args.length < 3) { msg(p, "&cUsage: /vote confirm <player> <site>"); return true; }
                confirmVote(p, args[1], args[2]);
            }
            case "top" -> voteGUI.showTop(p);
            default -> voteGUI.open(p);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) return List.of("top", "admin", "confirm").stream().filter(s -> s.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        if (args.length == 2 && args[0].equalsIgnoreCase("confirm")) return Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList());
        if (args.length == 3 && args[0].equalsIgnoreCase("confirm")) return getSites();
        return List.of();
    }

    void msg(CommandSender s, String m) { s.sendMessage(mm(m)); }
    net.kyori.adventure.text.Component mm(String s) { return MiniMessage.miniMessage().deserialize(s.replace('&', '<').replace(">", "</").replaceAll("<([0-9a-fk-or])", "<color:$1>")); }
    String prefix() { return config.getString("prefix", "&8[&bVote&8]&r "); }

    List<String> getSites() {
        ConfigurationSection s = config.getConfigurationSection("sites");
        return s == null ? new ArrayList<>() : new ArrayList<>(s.getKeys(false));
    }

    ConfigurationSection site(String id) { return config.getConfigurationSection("sites." + id); }
    boolean siteEnabled(String id) { return config.getBoolean("sites." + id + ".enabled", true); }
    String siteUrl(String id) { return config.getString("sites." + id + ".url", "https://example.com"); }
    String siteName(String id) { return config.getString("sites." + id + ".name", "&e" + id); }
    Material siteIcon(String id) {
        Material m = Material.matchMaterial(config.getString("sites." + id + ".icon", "PAPER"));
        return m == null ? Material.PAPER : m;
    }

    long cooldownMs(String id) {
        long min = config.getLong("sites." + id + ".cooldown-minutes", 1440);
        return Math.max(0, min) * 60_000L;
    }

    void registerVote(Player p, String siteId) {
        UUID id = p.getUniqueId();
        long cd = cooldownMs(siteId), now = System.currentTimeMillis();
        long lv = lastVote.getOrDefault(id, Map.of()).getOrDefault(siteId, 0);
        if (cd > 0 && now - lv < cd) { msg(p, "&cCooldown active. Next vote in &f" + formatTime(lv + cd - now)); return; }
        
        lastVote.computeIfAbsent(id, k -> new HashMap<>()).put(siteId, now);
        voteCount.merge(id, 1, Integer::sum);
        partyCount++;
        saveData();
        
        giveRewards(p, siteId);
        msg(p, "&a&lThanks for voting on &r" + siteName(siteId) + "&a!");
        p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1, 1.4f);
        
        if (partyCount >= config.getInt("voteparty.per-votes", 20)) triggerVoteParty();
    }

    void giveRewards(Player p, String siteId) {
        String b = "sites." + siteId + ".rewards.";
        long coins = config.getLong(b + "coins", 50);
        if (coins > 0) {
            try { getServer().dispatchCommand(getServer().getConsoleSender(), "coins give " + p.getName() + " " + coins); } catch (Exception ignored) {}
        }
        ConfigurationSection keys = config.getConfigurationSection(b + "keys");
        if (keys != null) for (String k : keys.getKeys(false)) {
            int min = keys.getInt(k + ".min", 1);
            int max = keys.getInt(k + ".max", 1);
            double chance = keys.getDouble(k + ".chance", 100);
            if (min <= 0 || max < min) continue;
            if (chance < 100 && ThreadLocalRandom.current().nextDouble() * 100 >= chance) continue;
            int amt = min == max ? min : min + ThreadLocalRandom.current().nextInt(max - min + 1);
            try { getServer().dispatchCommand(getServer().getConsoleSender(), "coins key give " + p.getName() + " " + k + " " + amt); }
            catch (Exception ex) { getLogger().warning("Could not give key " + k); }
        }
    }

    void triggerVoteParty() {
        partyCount = 0;
        int online = Bukkit.getOnlinePlayers().size();
        if (online == 0) { saveData(); return; }
        
        Bukkit.broadcast(mm(prefix() + "&6&lVOTE PARTY! &eAll online players get rewards!"));
        ConfigurationSection vr = config.getConfigurationSection("voteparty.rewards");
        long coins = vr == null ? 10000 : vr.getLong("coins", 10000);
        for (Player p : Bukkit.getOnlinePlayers()) {
            try {
                getServer().dispatchCommand(getServer().getConsoleSender(), "coins give " + p.getName() + " " + coins);
                ConfigurationSection partyKeys = vr == null ? null : vr.getConfigurationSection("keys");
                if (partyKeys != null) for (String k : partyKeys.getKeys(false)) {
                    int amt = partyKeys.getInt(k + ".amount", 0);
                    if (amt > 0) getServer().dispatchCommand(getServer().getConsoleSender(), "coins key give " + p.getName() + " " + k + " " + amt);
                }
                msg(p, "&a&lVOTE PARTY! &7You got: &6" + coins + " coins");
            } catch (Exception ex) { getLogger().warning("Vote party failed for " + p.getName()); }
            p.playSound(p, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1, 2);
        }
        saveData();
    }

    void confirmVote(CommandSender admin, String playerName, String siteId) {
        OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(playerName);
        if (op == null) op = Bukkit.getPlayer(playerName);
        if (op == null || (!op.hasPlayedBefore() && !op.isOnline())) { msg(admin, "&cPlayer not found."); return; }
        UUID id = op.getUniqueId();
        lastVote.computeIfAbsent(id, k -> new HashMap<>()).put(siteId, System.currentTimeMillis());
        voteCount.merge(id, 1, Integer::sum);
        partyCount++;
        saveData();
        msg(admin, "&aManual vote confirmed for " + op.getName());
        if (op.isOnline()) giveRewards(op.getPlayer(), siteId);
        if (partyCount >= config.getInt("voteparty.per-votes", 20)) triggerVoteParty();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!config.getBoolean("remind-on-join", true)) return;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.isOnline()) return;
            long now = System.currentTimeMillis();
            for (String id : getSites()) {
                if (!siteEnabled(id)) continue;
                long cd = cooldownMs(id);
                long lv = lastVote.getOrDefault(p.getUniqueId(), Map.of()).getOrDefault(id, 0);
                if (cd <= 0 || now - lv >= cd) {
                    msg(p, prefix() + "&eYou can vote! &f/vote");
                    return;
                }
            }
        }, 40L);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = e.getView().getTitle();
        if (title.contains("Vote")) voteGUI.handleClick(e);
    }

    String formatTime(long ms) { long m = Math.max(0, ms) / 60000L; return (m / 60) + "h " + (m % 60) + "m"; }
    int getVoteCount(UUID id) { return voteCount.getOrDefault(id, 0); }
    Map<UUID, Integer> getVoteCounts() { return new HashMap<>(voteCount); }
    long getLastVote(UUID id, String site) { return lastVote.getOrDefault(id, Map.of()).getOrDefault(site, 0); }
    YamlConfiguration getConfig() { return config; }
}
