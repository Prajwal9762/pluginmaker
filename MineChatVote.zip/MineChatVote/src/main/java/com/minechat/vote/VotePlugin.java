package com.minechat.vote;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class VotePlugin extends JavaPlugin implements Listener {

    static final int[] SITE_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33};
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private File dataFile;
    private YamlConfiguration data;
    private final Map<UUID, Integer> voteCount = new HashMap<>();
    private final Map<UUID, Map<String, Long>> lastVote = new HashMap<>();
    private int partyCount = 0;
    private VoteGUI voteGUI;
    private AdminGUI adminGUI;

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "votedata.yml");
        loadData();
        voteGUI = new VoteGUI(this);
        adminGUI = new AdminGUI(this);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("MineChatVote enabled - use /vote");
    }

    @Override
    public void onDisable() {
        saveData();
    }

    /** Reloads config.yml and votedata.yml. */
    public void reloadAll() {
        reloadConfig();
        loadData();
    }

    private void loadData() {
        data = YamlConfiguration.loadConfiguration(dataFile);
        voteCount.clear();
        lastVote.clear();
        ConfigurationSection vc = data.getConfigurationSection("votes");
        if (vc != null) {
            for (String k : vc.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(k);
                    voteCount.put(id, vc.getInt(k + ".count", 0));
                    Map<String, Long> m = new HashMap<>();
                    ConfigurationSection lv = vc.getConfigurationSection(k + ".last");
                    if (lv != null) {
                        for (String site : lv.getKeys(false)) m.put(site, lv.getLong(site));
                    }
                    lastVote.put(id, m);
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
        partyCount = data.getInt("voteparty.count", 0);
    }

    public void saveData() {
        if (data == null) return;
        data.set("votes", null);
        for (Map.Entry<UUID, Integer> e : voteCount.entrySet()) {
            data.set("votes." + e.getKey() + ".count", e.getValue());
            Map<String, Long> m = lastVote.get(e.getKey());
            if (m != null) {
                for (Map.Entry<String, Long> lv : m.entrySet()) {
                    data.set("votes." + e.getKey() + ".last." + lv.getKey(), lv.getValue());
                }
            }
        }
        data.set("voteparty.count", partyCount);
        try {
            data.save(dataFile);
        } catch (IOException ex) {
            getLogger().severe("Could not save data: " + ex);
        }
    }

    // ------------------------------------------------------------------ commands

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "confirm" -> {
                if (!sender.hasPermission("minechatvote.admin")) { msg(sender, "&cNo permission."); break; }
                if (args.length < 3) { msg(sender, "&cUsage: /vote confirm <player> <site>"); break; }
                confirmVote(sender, args[1], args[2]);
            }
            case "reload" -> {
                if (!sender.hasPermission("minechatvote.admin")) { msg(sender, "&cNo permission."); break; }
                reloadAll();
                msg(sender, "&aMineChatVote reloaded.");
            }
            case "admin" -> {
                if (sender instanceof Player p) adminGUI.open(p);
                else msg(sender, "&cPlayers only.");
            }
            case "top" -> {
                if (sender instanceof Player p) voteGUI.showTop(p);
                else msg(sender, "&cPlayers only.");
            }
            default -> {
                if (sender instanceof Player p) voteGUI.open(p);
                else msg(sender, "&cPlayers only.");
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        boolean admin = sender.hasPermission("minechatvote.admin");
        if (args.length == 1) {
            List<String> opts = new ArrayList<>(List.of("top"));
            if (admin) opts.addAll(List.of("admin", "confirm", "reload"));
            for (String s : opts) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (admin && args.length == 2 && args[0].equalsIgnoreCase("confirm")) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        } else if (admin && args.length == 3 && args[0].equalsIgnoreCase("confirm")) {
            out.addAll(getSites());
        }
        return out;
    }

    // ------------------------------------------------------------------ text / item helpers

    Component mm(String s) {
        return LEGACY.deserialize(s);
    }

    /** Like mm() but without Minecraft's default italics (for item names / lore). */
    Component ic(String s) {
        return LEGACY.deserialize(s).decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    ItemStack item(Material mat, String name, List<String> lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(ic(name));
        if (lore != null && !lore.isEmpty()) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(ic(s));
            meta.lore(l);
        }
        it.setItemMeta(meta);
        return it;
    }

    void msg(CommandSender s, String m) {
        s.sendMessage(mm(m));
    }

    String prefix() {
        return getConfig().getString("prefix", "&8[&bVote&8]&r ");
    }

    // ------------------------------------------------------------------ config helpers

    List<String> getSites() {
        ConfigurationSection s = getConfig().getConfigurationSection("sites");
        return s == null ? new ArrayList<>() : new ArrayList<>(s.getKeys(false));
    }

    List<String> getEnabledSites() {
        List<String> out = new ArrayList<>();
        for (String id : getSites()) if (siteEnabled(id)) out.add(id);
        return out;
    }

    boolean siteEnabled(String id) { return getConfig().getBoolean("sites." + id + ".enabled", true); }

    String siteUrl(String id) {
        return getConfig().getString("sites." + id + ".url", "https://example.com");
    }

    String siteName(String id) { return getConfig().getString("sites." + id + ".name", "&e" + id); }

    Material siteIcon(String id) {
        Material m = Material.matchMaterial(getConfig().getString("sites." + id + ".icon", "PAPER"));
        return m == null ? Material.PAPER : m;
    }

    long cooldownMs(String id) {
        long min = getConfig().getLong("sites." + id + ".cooldown-minutes", 1440);
        return Math.max(0, min) * 60_000L;
    }

    // ------------------------------------------------------------------ vote data helpers

    int getVoteCount(UUID id) {
        Integer v = voteCount.get(id);
        return v == null ? 0 : v;
    }

    Map<UUID, Integer> getVoteCounts() { return new HashMap<>(voteCount); }

    long getLastVote(UUID id, String site) {
        Map<String, Long> m = lastVote.get(id);
        if (m == null) return 0L;
        Long v = m.get(site);
        return v == null ? 0L : v;
    }

    String formatTime(long ms) {
        long m = Math.max(0, ms) / 60000L;
        return (m / 60) + "h " + (m % 60) + "m";
    }

    // ------------------------------------------------------------------ voting logic

    void registerVote(Player p, String siteId) {
        if (!siteEnabled(siteId)) { msg(p, "&cThat voting site is disabled."); return; }
        UUID id = p.getUniqueId();
        long cd = cooldownMs(siteId);
        long now = System.currentTimeMillis();
        long last = getLastVote(id, siteId);
        if (cd > 0 && now - last < cd) {
            msg(p, prefix() + "&cCooldown active. Next vote in &f" + formatTime(last + cd - now));
            return;
        }

        addVote(id, siteId, now);
        giveRewards(p, siteId);
        msg(p, prefix() + "&a&lThanks for voting on &r" + siteName(siteId) + "&a!");
        p.playSound(p, Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.4f);

        checkVoteParty();
    }

    private void addVote(UUID id, String siteId, long now) {
        lastVote.computeIfAbsent(id, k -> new HashMap<>()).put(siteId, now);
        voteCount.merge(id, 1, Integer::sum);
        partyCount++;
        saveData();
    }

    private void checkVoteParty() {
        if (partyCount >= Math.max(1, getConfig().getInt("voteparty.per-votes", 20))) triggerVoteParty();
    }

    /** Runs a reward command from the config's "commands" section. */
    private void runReward(String template, String player, String key, long amount) {
        String cmd = template
                .replace("%player%", player)
                .replace("%key%", key)
                .replace("%amount%", String.valueOf(amount));
        try {
            boolean ok = getServer().dispatchCommand(getServer().getConsoleSender(), cmd);
            if (!ok) getLogger().warning("Reward command failed or unknown: /" + cmd);
        } catch (Exception ex) {
            getLogger().warning("Reward command error (/" + cmd + "): " + ex.getMessage());
        }
    }

    private void giveCoins(String player, long amount) {
        if (amount <= 0) return;
        runReward(getConfig().getString("commands.coins", "coins give %player% %amount%"), player, "", amount);
    }

    private void giveKey(String player, String key, long amount) {
        if (amount <= 0) return;
        runReward(getConfig().getString("commands.key", "coins key give %player% %key% %amount%"), player, key, amount);
    }

    void giveRewards(Player p, String siteId) {
        String base = "sites." + siteId + ".rewards.";
        giveCoins(p.getName(), getConfig().getLong(base + "coins", 50));

        ConfigurationSection keys = getConfig().getConfigurationSection(base + "keys");
        if (keys == null) return;
        for (String k : keys.getKeys(false)) {
            int min = keys.getInt(k + ".min", 1);
            int max = keys.getInt(k + ".max", 1);
            double chance = keys.getDouble(k + ".chance", 100);
            if (min <= 0 || max < min) continue;
            if (chance < 100 && ThreadLocalRandom.current().nextDouble() * 100 >= chance) continue;
            int amt = min == max ? min : min + ThreadLocalRandom.current().nextInt(max - min + 1);
            giveKey(p.getName(), k, amt);
        }
    }

    void triggerVoteParty() {
        partyCount = 0;
        if (Bukkit.getOnlinePlayers().isEmpty()) { saveData(); return; }

        Bukkit.broadcast(mm(prefix() + "&6&lVOTE PARTY! &eAll online players get rewards!"));
        ConfigurationSection vr = getConfig().getConfigurationSection("voteparty.rewards");
        long coins = vr == null ? 10000 : vr.getLong("coins", 10000);
        ConfigurationSection partyKeys = vr == null ? null : vr.getConfigurationSection("keys");

        for (Player p : new ArrayList<>(Bukkit.getOnlinePlayers())) {
            giveCoins(p.getName(), coins);
            if (partyKeys != null) {
                for (String k : partyKeys.getKeys(false)) {
                    giveKey(p.getName(), k, partyKeys.getInt(k + ".amount", 0));
                }
            }
            msg(p, prefix() + "&a&lVOTE PARTY! &7You got: &6" + coins + " coins &7and keys!");
            p.playSound(p, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 2f);
        }
        saveData();
    }

    void confirmVote(CommandSender admin, String playerName, String siteId) {
        if (getConfig().getConfigurationSection("sites." + siteId) == null) {
            msg(admin, "&cUnknown site: &f" + siteId);
            return;
        }
        Player online = Bukkit.getPlayerExact(playerName);
        OfflinePlayer op = online != null ? online : Bukkit.getOfflinePlayerIfCached(playerName);
        if (op == null || (!op.hasPlayedBefore() && !op.isOnline())) {
            msg(admin, "&cPlayer not found.");
            return;
        }
        addVote(op.getUniqueId(), siteId, System.currentTimeMillis());
        msg(admin, "&aManual vote confirmed for " + op.getName());
        if (online != null) giveRewards(online, siteId);
        checkVoteParty();
    }

    // ------------------------------------------------------------------ events

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!getConfig().getBoolean("remind-on-join", true)) return;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.isOnline()) return;
            long now = System.currentTimeMillis();
            for (String id : getEnabledSites()) {
                long cd = cooldownMs(id);
                if (cd <= 0 || now - getLastVote(p.getUniqueId(), id) >= cd) {
                    msg(p, prefix() + "&eYou can vote! &f/vote");
                    return;
                }
            }
        }, 40L);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof MenuHolder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        // Ignore clicks in the player's own inventory
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;

        if (holder.type() == MenuHolder.Type.ADMIN) adminGUI.handleClick(p, e.getSlot());
        else voteGUI.handleClick(p, holder, e.getSlot());
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof MenuHolder) e.setCancelled(true);
    }
}
