package com.minechatvote;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.net.http.HttpClient;
import java.time.Duration;
import java.util.UUID;

public class MineChatVote extends JavaPlugin {

    private HttpClient http;
    private File dataFile;
    private FileConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        http = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(8))
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);

        VoteCommand cmd = new VoteCommand(this);
        getCommand("vote").setExecutor(cmd);
        getCommand("vote").setTabCompleter(cmd);
        getLogger().info("MineChatVote enabled.");
    }

    public HttpClient http() {
        return http;
    }

    public String msg(String key) {
        String prefix = getConfig().getString("messages.prefix", "");
        return color(prefix + getConfig().getString("messages." + key, key));
    }

    public String raw(String key) {
        return color(getConfig().getString("messages." + key, key));
    }

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public long getLastClaim(UUID uuid, String site) {
        return data.getLong(uuid + "." + site, 0L);
    }

    public synchronized void setLastClaim(UUID uuid, String site, long time) {
        data.set(uuid + "." + site, time);
        try {
            data.save(dataFile);
        } catch (IOException e) {
            getLogger().warning("Could not save data.yml: " + e.getMessage());
        }
    }
}
