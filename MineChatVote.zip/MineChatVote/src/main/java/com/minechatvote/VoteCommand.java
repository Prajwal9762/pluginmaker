package com.minechatvote;

import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.hover.content.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class VoteCommand implements CommandExecutor, TabCompleter {

    private final MineChatVote plugin;

    public VoteCommand(MineChatVote plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("minechatvote.admin")) {
                sender.sendMessage(plugin.msg("no-permission"));
                return true;
            }
            plugin.reloadConfig();
            sender.sendMessage(plugin.msg("reloaded"));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("players-only"));
            return true;
        }
        if (!player.hasPermission("minechatvote.use")) {
            player.sendMessage(plugin.msg("no-permission"));
            return true;
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("claim")) {
            claim(player);
        } else {
            showLinks(player);
        }
        return true;
    }

    private String fill(String s, Player p) {
        return s.replace("{player}", URLEncoder.encode(p.getName(), StandardCharsets.UTF_8))
                .replace("{uuid}", p.getUniqueId().toString());
    }

    private void showLinks(Player player) {
        ConfigurationSection sites = plugin.getConfig().getConfigurationSection("sites");
        if (sites == null || sites.getKeys(false).isEmpty()) {
            player.sendMessage(plugin.msg("no-sites"));
            return;
        }
        player.sendMessage(plugin.raw("header"));
        int i = 1;
        for (String key : sites.getKeys(false)) {
            ConfigurationSection s = sites.getConfigurationSection(key);
            if (s == null) continue;
            String url = fill(s.getString("vote-url", ""), player);
            if (url.isBlank()) continue;

            TextComponent line = new TextComponent(MineChatVote.color("&7" + i++ + ". &f" + s.getString("name", key) + " "));
            TextComponent click = new TextComponent(plugin.raw("click-to-vote"));
            click.setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, url));
            click.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                    new Text(new ComponentBuilder(plugin.raw("hover-vote")).create())));
            line.addExtra(click);
            player.spigot().sendMessage(line);
        }
        player.sendMessage(plugin.raw("claim-hint"));
    }

    private void claim(Player player) {
        ConfigurationSection sites = plugin.getConfig().getConfigurationSection("sites");
        if (sites == null || sites.getKeys(false).isEmpty()) {
            player.sendMessage(plugin.msg("no-sites"));
            return;
        }
        player.sendMessage(plugin.msg("checking"));

        for (String key : sites.getKeys(false)) {
            ConfigurationSection s = sites.getConfigurationSection(key);
            if (s == null) continue;

            String confirmUrl = s.getString("confirmation-url", "");
            if (confirmUrl.isBlank()) continue;

            String siteName = s.getString("name", key);
            long cooldownMs = (long) (s.getDouble("cooldown-hours", 24) * 3600_000L);
            long last = plugin.getLastClaim(player.getUniqueId(), key);
            if (System.currentTimeMillis() - last < cooldownMs) {
                player.sendMessage(plugin.msg("on-cooldown").replace("{site}", siteName));
                continue;
            }

            String url = fill(confirmUrl, player);
            String expected = s.getString("success-response", "");
            List<String> rewards = new ArrayList<>(s.getStringList("rewards"));

            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                boolean reached = false;
                boolean voted = false;
                try {
                    HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                            .timeout(Duration.ofSeconds(8))
                            .header("User-Agent", "MineChatVote/1.0")
                            .GET().build();
                    HttpResponse<String> res = plugin.http().send(req, HttpResponse.BodyHandlers.ofString());
                    reached = res.statusCode() == 200;
                    if (reached) {
                        voted = expected.isEmpty()
                                || res.body().trim().toLowerCase().contains(expected.toLowerCase());
                    }
                } catch (Exception e) {
                    plugin.getLogger().warning("Vote check failed for " + siteName + ": " + e.getMessage());
                }

                final boolean fReached = reached, fVoted = voted;
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (!player.isOnline()) return;
                    if (!fReached) {
                        player.sendMessage(plugin.msg("check-failed").replace("{site}", siteName));
                    } else if (!fVoted) {
                        player.sendMessage(plugin.msg("not-voted").replace("{site}", siteName));
                    } else {
                        // re-check cooldown to prevent double claims
                        if (System.currentTimeMillis() - plugin.getLastClaim(player.getUniqueId(), key) < cooldownMs) return;
                        plugin.setLastClaim(player.getUniqueId(), key, System.currentTimeMillis());
                        for (String c : rewards) {
                            Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                                    c.replace("{player}", player.getName())
                                     .replace("{uuid}", player.getUniqueId().toString()));
                        }
                        player.sendMessage(plugin.msg("claimed").replace("{site}", siteName));
                        if (plugin.getConfig().getBoolean("broadcast.enabled", true)) {
                            Bukkit.broadcastMessage(MineChatVote.color(
                                    plugin.getConfig().getString("broadcast.message", "")
                                            .replace("{player}", player.getName())
                                            .replace("{site}", siteName)));
                        }
                    }
                });
            });
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.add("claim");
            if (sender.hasPermission("minechatvote.admin")) out.add("reload");
            out.removeIf(s -> !s.startsWith(args[0].toLowerCase()));
        }
        return out;
    }
}
