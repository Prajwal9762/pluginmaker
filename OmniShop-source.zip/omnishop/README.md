# OmniShop

One plugin replacing EzShops: a shop for **every item in Minecraft**, rotating **Daily Specials**,
dynamic prices, sign shops, player chest shops and a full **Player Warps** system. Everything has a GUI and sounds.

Requires: Paper/Spigot 1.21+, Java 21 (builds with 17+), Vault + any economy plugin (EssentialsX, CMI, ...).

## Build
    mvn clean package          ->  target/OmniShop-1.0.0.jar
Or push this folder to a GitHub repo - the included Actions workflow builds the jar for you (Actions tab > Artifacts).
Drop the jar in /plugins, remove EzShops, restart.

## Shop
/shop (GUI) | /shop <category> | /shop search <text> | /shop buy <item> [amt] | /shop sell <item> [amt|all]
/sell (GUI: drop items in, close = paid) | /sell hand | /sell all | /sellhand [all] | /sellall
/price [item] | /specials | /market
GUI clicks: left buy 1, shift-left buy 64, right sell 1, shift-right sell all, middle = amount picker.

prices.yml is generated on first start with EVERY item of your server version (and new items are appended
automatically after Minecraft updates). Edit freely; -1 disables buying or selling an item.

## Daily Specials
Every `specials.interval-hours` a new set of items is picked (never the same as the last rotation): cheaper to BUY and
paying extra when you SELL, plus one JACKPOT item. Anti-abuse: sell price can never exceed 90% of the buy price,
and bonus sells are capped per player per rotation.

## Other features
Dynamic pricing (demand moves prices, they recover over time) - `/market` shows movers
Daily sell limit, permission boosts `omnishop.boost.<percent>`, durability-scaled prices
Admin signs:  [Shop] / 16 / DIAMOND / buy      (right-click to trade at live prices)
Player chest shops: place a sign on a chest holding the item:  [PShop] / amount / total price  (+protection, tax)
/shopadmin set|disable|reset|resetall|rotate|reload|regenerate

## Player Warps
/pwarps (browser GUI) | /pwarps v <name> | set <name> | delete <name> | list | top | search | info | rate
seticon / setdesc / setcategory / setfee / private / public / move / rename / ban / unban
Features: categories, sorting, ratings, visit counter, entry fees paid to the owner, banned players, warmup + cooldown,
safe-location check, per-rank limits via `omnishop.pwarp.limit.<n>`.

## Permissions
omnishop.use/buy/sell (default true), omnishop.admin, omnishop.pwarp.use/create (true), omnishop.pwarp.admin,
omnishop.sign.create (op), omnishop.playershop.create/use (true), omnishop.limit.bypass
