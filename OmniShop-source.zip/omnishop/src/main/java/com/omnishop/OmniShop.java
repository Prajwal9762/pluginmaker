package com.omnishop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class OmniShop extends JavaPlugin {

    private static OmniShop instance;
    private Economy economy;
    private PriceBook prices;
    private SpecialsManager specials;
    private ShopManager shop;
    private ShopGui shopGui;
    private WarpManager warps;
    private WarpGui warpGui;
    private PlayerShopManager playerShops;
    private boolean started = false;

    public static OmniShop get() { return instance; }
    public Economy eco() { return economy; }
    public PriceBook prices() { return prices; }
    public SpecialsManager specials() { return specials; }
    public ShopManager shop() { return shop; }
    public ShopGui shopGui() { return shopGui; }
    public WarpManager warps() { return warps; }
    public WarpGui warpGui() { return warpGui; }
    public PlayerShopManager playerShops() { return playerShops; }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        // Economy plugins may register after us, so retry one tick later.
        if (setupEconomy()) {
            start();
        } else {
            Bukkit.getScheduler().runTask(this, () -> {
                if (setupEconomy()) {
                    start();
                } else {
                    getLogger().severe("Vault found, but no economy plugin (EssentialsX, CMI, ...). Disabling.");
                    Bukkit.getPluginManager().disablePlugin(this);
                }
            });
        }
    }

    private boolean setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) return false;
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        economy = rsp.getProvider();
        return economy != null;
    }

    private void start() {
        if (started) return;
        started = true;
        getDataFolder().mkdirs();

        prices = new PriceBook(this);
        prices.load();
        specials = new SpecialsManager(this);
        shop = new ShopManager(this);
        shop.reindex();
        specials.load();
        shopGui = new ShopGui(this);
        warps = new WarpManager(this);
        warps.load();
        warpGui = new WarpGui(this);
        playerShops = new PlayerShopManager(this);
        playerShops.load();

        Bukkit.getPluginManager().registerEvents(shopGui, this);
        Bukkit.getPluginManager().registerEvents(warpGui, this);
        Bukkit.getPluginManager().registerEvents(playerShops, this);
        Bukkit.getPluginManager().registerEvents(new SignShopListener(this), this);

        ShopCommands sc = new ShopCommands(this);
        for (String name : new String[]{"shop", "sell", "sellhand", "sellall", "price", "specials", "market", "shopadmin"}) {
            PluginCommand pc = getCommand(name);
            if (pc != null) { pc.setExecutor(sc); pc.setTabCompleter(sc); }
        }
        PluginCommand ps = getCommand("playershops");
        if (ps != null) ps.setExecutor(playerShops);
        WarpCommand wc = new WarpCommand(this);
        PluginCommand pw = getCommand("pwarps");
        if (pw != null) { pw.setExecutor(wc); pw.setTabCompleter(wc); }

        // once a minute: price recovery + market drift, and special rotation check
        Bukkit.getScheduler().runTaskTimer(this, () -> prices.tick(), 20L * 60, 20L * 60);
        Bukkit.getScheduler().runTaskTimer(this, () -> specials.checkRotation(), 20L * 30, 20L * 30);
        // autosave every 5 minutes
        Bukkit.getScheduler().runTaskTimer(this, this::saveAll, 20L * 300, 20L * 300);

        getLogger().info("OmniShop enabled: " + prices.all().size() + " items, "
                + warps.all().size() + " player warps.");
    }

    public void saveAll() {
        if (!started) return;
        prices.saveDynamic();
        specials.save();
        shop.saveLimits();
        warps.save();
        playerShops.save();
    }

    public void reloadAll() {
        reloadConfig();
        prices.load();
        shop.reindex();
        warpGui.refreshAll();
    }

    @Override
    public void onDisable() {
        saveAll();
    }
}
