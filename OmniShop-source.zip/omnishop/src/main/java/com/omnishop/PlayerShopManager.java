package com.omnishop;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Chest;
import org.bukkit.block.Sign;
import org.bukkit.block.data.Directional;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.DoubleChestInventory;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Player chest shops. Put a sign on a chest:
 *   [PShop]
 *   <amount>
 *   <total price>
 * while holding the item you want to sell. Customers right-click the sign.
 */
public class PlayerShopManager implements Listener, CommandExecutor {

    public static class Shop {
        public UUID owner;
        public String ownerName;
        public Material item;
        public int amount;
        public double price;
        public String signKey;
        public List<String> chestKeys = new ArrayList<>();
    }

    private final OmniShop plugin;
    private final File file;
    private final Map<String, Shop> bySign = new HashMap<>();
    private final Map<String, Shop> byChest = new HashMap<>();

    public PlayerShopManager(OmniShop plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "playershops.yml");
    }

    private static String key(Block b) {
        return b.getWorld().getName() + ";" + b.getX() + ";" + b.getY() + ";" + b.getZ();
    }

    public void load() {
        bySign.clear();
        byChest.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = y.getConfigurationSection("shops");
        if (root == null) return;
        for (String k : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(k);
            if (s == null) continue;
            Shop sh = new Shop();
            try { sh.owner = UUID.fromString(s.getString("owner", "")); } catch (IllegalArgumentException ex) { continue; }
            sh.ownerName = s.getString("owner-name", "?");
            sh.item = Material.matchMaterial(s.getString("item", "AIR"));
            if (sh.item == null) continue;
            sh.amount = s.getInt("amount", 1);
            sh.price = s.getDouble("price", 1);
            sh.signKey = s.getString("sign", k.replace('|', ';'));
            sh.chestKeys = s.getStringList("chests");
            register(sh);
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        int i = 0;
        for (Shop sh : bySign.values()) {
            String p = "shops.s" + (i++);
            y.set(p + ".owner", sh.owner.toString());
            y.set(p + ".owner-name", sh.ownerName);
            y.set(p + ".item", sh.item.name());
            y.set(p + ".amount", sh.amount);
            y.set(p + ".price", sh.price);
            y.set(p + ".sign", sh.signKey);
            y.set(p + ".chests", sh.chestKeys);
        }
        try { y.save(file); } catch (IOException ex) { plugin.getLogger().warning("playershops.yml: " + ex.getMessage()); }
    }

    private void register(Shop sh) {
        bySign.put(sh.signKey, sh);
        for (String c : sh.chestKeys) byChest.put(c, sh);
    }

    private void unregister(Shop sh) {
        bySign.remove(sh.signKey);
        for (String c : sh.chestKeys) byChest.remove(c);
    }

    private int countOwned(UUID id) {
        int n = 0;
        for (Shop s : bySign.values()) if (s.owner.equals(id)) n++;
        return n;
    }

    private Block chestBehind(Block signBlock) {
        if (signBlock.getBlockData() instanceof Directional) {
            Block back = signBlock.getRelative(((Directional) signBlock.getBlockData()).getFacing().getOppositeFace());
            if (back.getType() == Material.CHEST || back.getType() == Material.TRAPPED_CHEST) return back;
        }
        Block below = signBlock.getRelative(BlockFace.DOWN);
        if (below.getType() == Material.CHEST || below.getType() == Material.TRAPPED_CHEST) return below;
        return null;
    }

    private List<String> chestKeys(Block chestBlock) {
        List<String> keys = new ArrayList<>();
        keys.add(key(chestBlock));
        if (chestBlock.getState() instanceof Chest) {
            Inventory inv = ((Chest) chestBlock.getState()).getInventory();
            if (inv instanceof DoubleChestInventory) {
                DoubleChestInventory d = (DoubleChestInventory) inv;
                if (d.getLeftSide().getLocation() != null) keys.add(key(d.getLeftSide().getLocation().getBlock()));
                if (d.getRightSide().getLocation() != null) keys.add(key(d.getRightSide().getLocation().getBlock()));
            }
        }
        return new ArrayList<>(new LinkedHashSet<>(keys));
    }

    private String header() { return plugin.getConfig().getString("player-shops.header", "[PShop]"); }

    // ------------------------------------------------------------------ events

    @SuppressWarnings("deprecation")
    @EventHandler
    public void onSign(SignChangeEvent e) {
        if (!plugin.getConfig().getBoolean("player-shops.enabled", true)) return;
        if (!e.getLine(0).equalsIgnoreCase(header())) return;
        Player p = e.getPlayer();
        if (!p.hasPermission("omnishop.playershop.create")) { Util.send(p, "no-permission"); e.setCancelled(true); return; }
        Block chest = chestBehind(e.getBlock());
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (chest == null || hand == null || hand.getType() == Material.AIR || !plugin.shop().plain(hand)) {
            Util.send(p, "pshop-bad"); e.setCancelled(true); return;
        }
        if (byChest.containsKey(key(chest))) { Util.send(p, "pshop-bad"); e.setCancelled(true); return; }
        int max = plugin.getConfig().getInt("player-shops.max-per-player", 10);
        if (max > 0 && countOwned(p.getUniqueId()) >= max && !p.hasPermission("omnishop.playershop.admin")) {
            Util.send(p, "pshop-limit"); e.setCancelled(true); return;
        }
        int amount; double price;
        try {
            amount = Math.max(1, Math.min(2304, Integer.parseInt(e.getLine(1).trim())));
            price = Double.parseDouble(e.getLine(2).trim().replace("$", ""));
            if (price <= 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) { Util.send(p, "pshop-bad"); e.setCancelled(true); return; }

        Shop sh = new Shop();
        sh.owner = p.getUniqueId();
        sh.ownerName = p.getName();
        sh.item = hand.getType();
        sh.amount = amount;
        sh.price = Util.round(price);
        sh.signKey = key(e.getBlock());
        sh.chestKeys = chestKeys(chest);
        register(sh);
        save();
        writeSign(e, sh, stockOf(sh) >= sh.amount);
        Util.send(p, "pshop-created");
        Util.play(p, "success");
    }

    @SuppressWarnings("deprecation")
    private void writeSign(SignChangeEvent e, Shop sh, boolean inStock) {
        e.setLine(0, (inStock ? ChatColor.DARK_GREEN : ChatColor.DARK_RED) + "" + ChatColor.BOLD + "[PShop]");
        e.setLine(1, ChatColor.BLACK + "" + sh.amount + "x " + Util.pretty(sh.item));
        e.setLine(2, ChatColor.GOLD + Util.money(sh.price));
        e.setLine(3, ChatColor.GRAY + sh.ownerName);
    }

    @SuppressWarnings("deprecation")
    private void refreshSign(Shop sh) {
        String[] k = sh.signKey.split(";");
        World w = Bukkit.getWorld(k[0]);
        if (w == null) return;
        Block b = w.getBlockAt(Integer.parseInt(k[1]), Integer.parseInt(k[2]), Integer.parseInt(k[3]));
        if (!(b.getState() instanceof Sign)) return;
        Sign s = (Sign) b.getState();
        boolean in = stockOf(sh) >= sh.amount;
        s.setLine(0, (in ? ChatColor.DARK_GREEN : ChatColor.DARK_RED) + "" + ChatColor.BOLD + "[PShop]");
        s.update();
    }

    private Inventory inventoryOf(Shop sh) {
        if (sh.chestKeys.isEmpty()) return null;
        String[] k = sh.chestKeys.get(0).split(";");
        World w = Bukkit.getWorld(k[0]);
        if (w == null) return null;
        Block b = w.getBlockAt(Integer.parseInt(k[1]), Integer.parseInt(k[2]), Integer.parseInt(k[3]));
        if (!(b.getState() instanceof Chest)) return null;
        return ((Chest) b.getState()).getInventory();
    }

    private int stockOf(Shop sh) {
        Inventory inv = inventoryOf(sh);
        if (inv == null) return 0;
        int n = 0;
        for (ItemStack s : inv.getContents()) if (s != null && s.getType() == sh.item && plugin.shop().plain(s)) n += s.getAmount();
        return n;
    }

    @SuppressWarnings("deprecation")
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getClickedBlock() == null) return;
        Block b = e.getClickedBlock();
        Player p = e.getPlayer();
        // opening a protected chest
        Shop chestShop = byChest.get(key(b));
        if (chestShop != null && e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            if (!chestShop.owner.equals(p.getUniqueId()) && !p.hasPermission("omnishop.playershop.admin")) {
                e.setCancelled(true);
                Util.send(p, "pshop-protected", "owner", chestShop.ownerName);
            }
            return;
        }
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Shop sh = bySign.get(key(b));
        if (sh == null) return;
        e.setCancelled(true);
        if (sh.owner.equals(p.getUniqueId())) {
            p.sendMessage(Util.c("&7Your shop: &f" + sh.amount + "x " + Util.pretty(sh.item) + " &7for &6" + Util.money(sh.price)
                    + " &7- stock: &f" + stockOf(sh)));
            return;
        }
        if (!p.hasPermission("omnishop.playershop.use")) { Util.send(p, "no-permission"); return; }
        Inventory inv = inventoryOf(sh);
        if (inv == null || stockOf(sh) < sh.amount) { Util.send(p, "pshop-out"); Util.play(p, "error"); refreshSign(sh); return; }
        if (!plugin.eco().has(p, sh.price)) { Util.send(p, "no-money", "cost", Util.money(sh.price)); Util.play(p, "error"); return; }
        // space check
        ItemStack probe = new ItemStack(sh.item);
        int space = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s == null) space += sh.item.getMaxStackSize();
            else if (s.isSimilar(probe)) space += sh.item.getMaxStackSize() - s.getAmount();
        }
        if (space < sh.amount) { Util.send(p, "inv-full"); Util.play(p, "error"); return; }

        // take from chest
        int left = sh.amount;
        for (int i = 0; i < inv.getSize() && left > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (s == null || s.getType() != sh.item || !plugin.shop().plain(s)) continue;
            int take = Math.min(left, s.getAmount());
            if (take >= s.getAmount()) inv.setItem(i, null); else s.setAmount(s.getAmount() - take);
            left -= take;
        }
        int rem = sh.amount;
        while (rem > 0) {
            int n = Math.min(rem, sh.item.getMaxStackSize());
            p.getInventory().addItem(new ItemStack(sh.item, n));
            rem -= n;
        }
        plugin.eco().withdrawPlayer(p, sh.price);
        double tax = plugin.getConfig().getDouble("player-shops.tax-percent", 5.0);
        double net = Util.round(sh.price * (1 - tax / 100.0));
        OfflinePlayer owner = Bukkit.getOfflinePlayer(sh.owner);
        plugin.eco().depositPlayer(owner, net);
        Util.send(p, "pshop-sold", "amount", String.valueOf(sh.amount), "item", Util.pretty(sh.item), "owner", sh.ownerName, "cost", Util.money(sh.price));
        Util.play(p, "buy");
        Player op = owner.getPlayer();
        if (op != null) {
            Util.send(op, "pshop-owner-sale", "buyer", p.getName(), "amount", String.valueOf(sh.amount), "item", Util.pretty(sh.item), "cost", Util.money(net));
            Util.play(op, "sell");
        }
        refreshSign(sh);
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        Shop sh = bySign.get(key(b));
        if (sh == null) sh = byChest.get(key(b));
        if (sh == null) return;
        Player p = e.getPlayer();
        if (sh.owner.equals(p.getUniqueId()) || p.hasPermission("omnishop.playershop.admin")) {
            if (bySign.containsKey(key(b))) { unregister(sh); save(); }
            else { // breaking the chest removes the shop
                unregister(sh);
                save();
            }
        } else {
            e.setCancelled(true);
            Util.send(p, "pshop-protected", "owner", sh.ownerName);
        }
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> bySign.containsKey(key(b)) || byChest.containsKey(key(b)));
    }

    @EventHandler
    public void onExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> bySign.containsKey(key(b)) || byChest.containsKey(key(b)));
    }

    @EventHandler
    public void onHopper(InventoryMoveItemEvent e) {
        if (e.getSource().getLocation() == null) return;
        Block b = e.getSource().getLocation().getBlock();
        if (byChest.containsKey(key(b))) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ /playershops

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        s.sendMessage(Util.c("&6&m      &r &e&lPlayer Shops &6&m      "));
        if (bySign.isEmpty()) { s.sendMessage(Util.c("&7No player shops yet. Place a &f[PShop] &7sign on a chest!")); return true; }
        int n = 0;
        for (Shop sh : bySign.values()) {
            if (n++ >= 20) { s.sendMessage(Util.c("&7...and more")); break; }
            String[] k = sh.signKey.split(";");
            s.sendMessage(Util.c(" &f" + sh.amount + "x " + Util.pretty(sh.item) + " &8- &6" + Util.money(sh.price)
                    + " &8by &7" + sh.ownerName + " &8(" + k[0] + " " + k[1] + "," + k[2] + "," + k[3] + ")"));
        }
        return true;
    }
}
