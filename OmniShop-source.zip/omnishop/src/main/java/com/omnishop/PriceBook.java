package com.omnishop;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Holds the base buy/sell price of every tradable item (prices.yml) plus the live
 * "market" multiplier of each item (supply & demand).
 */
public class PriceBook {

    public static class Entry {
        public double buy;   // <= 0 means "cannot be bought"
        public double sell;  // <= 0 means "cannot be sold"
    }

    private final OmniShop plugin;
    private final File pricesFile;
    private final File dynFile;
    private final Map<Material, Entry> map = new EnumMap<>(Material.class);
    private final Map<Material, Double> dyn = new EnumMap<>(Material.class);
    private YamlConfiguration yml;

    public PriceBook(OmniShop plugin) {
        this.plugin = plugin;
        this.pricesFile = new File(plugin.getDataFolder(), "prices.yml");
        this.dynFile = new File(plugin.getDataFolder(), "market.yml");
    }

    // ------------------------------------------------------------------ load/save

    public void load() {
        if (!pricesFile.exists()) generateFile(true);
        yml = YamlConfiguration.loadConfiguration(pricesFile);
        map.clear();
        ConfigurationSection items = yml.getConfigurationSection("items");
        if (items != null) {
            for (String k : items.getKeys(false)) {
                Material m = Material.matchMaterial(k);
                if (m == null) continue;
                Entry e = new Entry();
                e.buy = items.getDouble(k + ".buy", -1);
                e.sell = items.getDouble(k + ".sell", -1);
                map.put(m, e);
            }
        }
        // new items added by a Minecraft update are appended automatically
        boolean added = false;
        for (Material m : Material.values()) {
            if (tradable(m) && !map.containsKey(m)) {
                Entry e = generated(m);
                map.put(m, e);
                yml.set("items." + m.name() + ".buy", e.buy);
                yml.set("items." + m.name() + ".sell", e.sell);
                added = true;
            }
        }
        if (added) saveYml();

        dyn.clear();
        if (dynFile.exists()) {
            YamlConfiguration d = YamlConfiguration.loadConfiguration(dynFile);
            for (String k : d.getKeys(false)) {
                Material m = Material.matchMaterial(k);
                if (m != null) dyn.put(m, d.getDouble(k, 1.0));
            }
        }
    }

    private void generateFile(boolean firstTime) {
        YamlConfiguration y = new YamlConfiguration();
        y.options().header("OmniShop prices. buy/sell per ONE item. Use -1 to disable buying or selling an item.\n"
                + "Generated automatically for every item in your Minecraft version - edit freely, then /shopadmin reload");
        for (Material m : Material.values()) {
            if (!tradable(m)) continue;
            Entry e = generated(m);
            y.set("items." + m.name() + ".buy", e.buy);
            y.set("items." + m.name() + ".sell", e.sell);
        }
        try {
            y.save(pricesFile);
        } catch (IOException ex) {
            plugin.getLogger().severe("Could not write prices.yml: " + ex.getMessage());
        }
    }

    /** Wipes prices.yml and rebuilds it from the built-in value table. */
    public void regenerate() {
        generateFile(false);
        load();
    }

    private Entry generated(Material m) {
        double buyMul = plugin.getConfig().getDouble("pricing.buy-multiplier", 1.25);
        double sellRatio = plugin.getConfig().getDouble("pricing.sell-ratio", 0.35);
        double minBuy = 0.05;
        double v = value(m);
        Entry e = new Entry();
        e.buy = Math.max(minBuy, Util.round(v * buyMul));
        e.sell = Math.max(0.01, Util.round(v * sellRatio));
        return e;
    }

    private void saveYml() {
        try {
            yml.save(pricesFile);
        } catch (IOException ex) {
            plugin.getLogger().severe("Could not save prices.yml: " + ex.getMessage());
        }
    }

    public void saveDynamic() {
        YamlConfiguration d = new YamlConfiguration();
        for (Map.Entry<Material, Double> e : dyn.entrySet()) {
            if (Math.abs(e.getValue() - 1.0) > 0.0005) d.set(e.getKey().name(), Util.round(e.getValue() * 10000) / 10000.0);
        }
        try {
            d.save(dynFile);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save market.yml: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------ queries

    public Set<Material> all() { return map.keySet(); }
    public boolean has(Material m) { return map.containsKey(m); }
    public boolean canBuy(Material m) { Entry e = map.get(m); return e != null && e.buy > 0; }
    public boolean canSell(Material m) { Entry e = map.get(m); return e != null && e.sell > 0; }
    public double baseBuy(Material m) { Entry e = map.get(m); return e == null ? -1 : e.buy; }
    public double baseSell(Material m) { Entry e = map.get(m); return e == null ? -1 : e.sell; }

    public double mult(Material m) {
        if (!plugin.getConfig().getBoolean("dynamic-pricing.enabled", true)) return 1.0;
        return dyn.getOrDefault(m, 1.0);
    }

    // ------------------------------------------------------------------ admin edits

    public void set(Material m, double buy, double sell) {
        Entry e = map.computeIfAbsent(m, k -> new Entry());
        e.buy = buy;
        e.sell = sell;
        yml.set("items." + m.name() + ".buy", buy);
        yml.set("items." + m.name() + ".sell", sell);
        saveYml();
    }

    public void disable(Material m, boolean buy) {
        Entry e = map.get(m);
        if (e == null) return;
        set(m, buy ? -1 : e.buy, buy ? e.sell : -1);
    }

    public void resetDynamic(Material m) { dyn.remove(m); }
    public void resetAllDynamic() { dyn.clear(); }

    // ------------------------------------------------------------------ market dynamics

    /** Called by ShopManager after a purchase/sale. */
    public void impact(Material m, int amount, boolean buying) {
        if (!plugin.getConfig().getBoolean("dynamic-pricing.enabled", true)) return;
        double min = plugin.getConfig().getDouble("dynamic-pricing.min-multiplier", 0.5);
        double max = plugin.getConfig().getDouble("dynamic-pricing.max-multiplier", 2.5);
        double bi = plugin.getConfig().getDouble("dynamic-pricing.buy-impact", 0.0004);
        double si = plugin.getConfig().getDouble("dynamic-pricing.sell-impact", 0.0004);
        double cur = dyn.getOrDefault(m, 1.0);
        cur += buying ? amount * bi : -amount * si;
        dyn.put(m, Math.max(min, Math.min(max, cur)));
    }

    /** Once a minute: prices drift back toward normal and wobble a little (market feel). */
    public void tick() {
        if (!plugin.getConfig().getBoolean("dynamic-pricing.enabled", true)) return;
        double rec = plugin.getConfig().getDouble("dynamic-pricing.recovery", 0.02);
        double vol = plugin.getConfig().getDouble("dynamic-pricing.volatility", 0.003);
        double min = plugin.getConfig().getDouble("dynamic-pricing.min-multiplier", 0.5);
        double max = plugin.getConfig().getDouble("dynamic-pricing.max-multiplier", 2.5);
        Random r = new Random();
        Iterator<Map.Entry<Material, Double>> it = dyn.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Material, Double> e = it.next();
            double v = e.getValue();
            v += (1.0 - v) * rec;
            if (vol > 0) v += (r.nextDouble() * 2 - 1) * vol;
            v = Math.max(min, Math.min(max, v));
            if (Math.abs(v - 1.0) < 0.0005) it.remove(); else e.setValue(v);
        }
        // a few random items start to move even if nobody trades them
        if (vol > 0) {
            List<Material> pool = new ArrayList<>(map.keySet());
            for (int i = 0; i < 6 && !pool.isEmpty(); i++) {
                Material m = pool.get(r.nextInt(pool.size()));
                double v = dyn.getOrDefault(m, 1.0) + (r.nextDouble() * 2 - 1) * vol * 4;
                dyn.put(m, Math.max(min, Math.min(max, v)));
            }
        }
    }

    /** Items whose price is currently furthest from normal (for /market). */
    public List<Map.Entry<Material, Double>> movers() {
        List<Map.Entry<Material, Double>> l = new ArrayList<>(dyn.entrySet());
        l.sort((a, b) -> Double.compare(Math.abs(b.getValue() - 1), Math.abs(a.getValue() - 1)));
        return l;
    }

    // ------------------------------------------------------------------ item rules

    private static final Set<String> BLOCKED = new HashSet<>(Arrays.asList(
            "BEDROCK", "BARRIER", "LIGHT", "STRUCTURE_BLOCK", "STRUCTURE_VOID", "JIGSAW", "COMMAND_BLOCK", "CHAIN_COMMAND_BLOCK",
            "REPEATING_COMMAND_BLOCK", "COMMAND_BLOCK_MINECART", "DEBUG_STICK", "KNOWLEDGE_BOOK", "REINFORCED_DEEPSLATE", "END_PORTAL_FRAME",
            "PETRIFIED_OAK_SLAB", "CHORUS_PLANT", "BUDDING_AMETHYST", "FROGSPAWN", "TRIAL_SPAWNER", "VAULT", "SPAWNER", "FILLED_MAP",
            "WRITTEN_BOOK", "ENCHANTED_BOOK", "TIPPED_ARROW", "POTION", "SPLASH_POTION", "LINGERING_POTION", "PLAYER_HEAD", "SUSPICIOUS_STEW",
            "FIREWORK_ROCKET", "FIREWORK_STAR", "OMINOUS_BOTTLE", "BUNDLE", "AIR", "CAVE_AIR", "VOID_AIR", "WATER", "LAVA", "FIRE", "SOUL_FIRE",
            "GOAT_HORN", "TEST_BLOCK", "TEST_INSTANCE_BLOCK", "SUSPICIOUS_SAND", "SUSPICIOUS_GRAVEL", "INFESTED_STONE", "TRIAL_KEY",
            "OMINOUS_TRIAL_KEY", "COPPER_GOLEM_SPAWN_EGG"));

    public static boolean tradable(Material m) {
        if (m.isLegacy() || !m.isItem() || m.isAir()) return false;
        String n = m.name();
        if (BLOCKED.contains(n)) {
            if (n.equals("SPAWNER")) return OmniShop.get().getConfig().getBoolean("pricing.allow-spawners", false);
            return false;
        }
        if (n.startsWith("TEST_") || n.startsWith("INFESTED_") || n.endsWith("_COMMAND_BLOCK")) return false;
        if (n.endsWith("_SPAWN_EGG") && !OmniShop.get().getConfig().getBoolean("pricing.allow-spawn-eggs", true)) return false;
        return true;
    }

    // ------------------------------------------------------------------ the value table

    private static final Map<String, Double> BASE = new HashMap<>();
    private static final LinkedHashMap<String, Double> SUFFIX = new LinkedHashMap<>();

    private static void b(double v, String... names) { for (String n : names) BASE.put(n, v); }

    static {
        // natural / building
        b(1, "DIRT", "COBBLESTONE", "COBBLED_DEEPSLATE", "NETHERRACK", "GRASS_BLOCK", "COARSE_DIRT", "ROOTED_DIRT", "MUD", "SAND", "RED_SAND",
                "GRAVEL", "SHORT_GRASS", "TALL_GRASS", "FERN", "LARGE_FERN", "DEAD_BUSH", "SEAGRASS", "SNOWBALL", "SNOW", "CLAY_BALL", "FLINT",
                "PODZOL", "MYCELIUM", "CRIMSON_NYLIUM", "WARPED_NYLIUM", "STICK", "VINE", "LILY_PAD", "BAMBOO", "KELP", "SCAFFOLDING");
        b(2, "STONE", "DEEPSLATE", "ANDESITE", "DIORITE", "GRANITE", "TUFF", "CALCITE", "DRIPSTONE_BLOCK", "SMOOTH_BASALT", "BASALT", "BLACKSTONE",
                "END_STONE", "SANDSTONE", "RED_SANDSTONE", "SNOW_BLOCK", "ICE", "CLAY", "BRICK", "MOSS_BLOCK", "PACKED_MUD", "SOUL_SAND", "SOUL_SOIL",
                "SPONGE", "POINTED_DRIPSTONE", "COBWEB", "GLOWSTONE_DUST", "MAGMA_BLOCK", "BONE_BLOCK");
        b(3, "STONE_BRICKS", "SMOOTH_STONE", "BRICKS", "DEEPSLATE_BRICKS", "DEEPSLATE_TILES", "POLISHED_ANDESITE", "POLISHED_DIORITE", "POLISHED_GRANITE",
                "POLISHED_DEEPSLATE", "POLISHED_BLACKSTONE", "POLISHED_TUFF", "NETHER_BRICKS", "MUD_BRICKS", "PRISMARINE", "END_STONE_BRICKS",
                "CUT_SANDSTONE", "SMOOTH_SANDSTONE", "SMOOTH_RED_SANDSTONE", "CHISELED_STONE_BRICKS", "CRACKED_STONE_BRICKS", "MOSSY_COBBLESTONE",
                "MOSSY_STONE_BRICKS", "PACKED_ICE", "SEA_LANTERN", "NETHER_BRICK", "NETHER_WART_BLOCK", "WARPED_WART_BLOCK", "SHROOMLIGHT",
                "TORCH", "SOUL_TORCH", "LANTERN", "SOUL_LANTERN", "BARREL", "CHEST", "CRAFTING_TABLE", "FURNACE", "LADDER", "BOWL", "PAPER");
        b(4, "OBSIDIAN", "CRYING_OBSIDIAN", "BLUE_ICE", "GLOWSTONE", "QUARTZ_BLOCK", "SMOOTH_QUARTZ", "PURPUR_BLOCK", "PURPUR_PILLAR", "PRISMARINE_BRICKS",
                "DARK_PRISMARINE", "TERRACOTTA", "CHISELED_QUARTZ_BLOCK", "QUARTZ_BRICKS", "QUARTZ_PILLAR", "BLAST_FURNACE", "SMOKER", "CAMPFIRE",
                "SOUL_CAMPFIRE", "BOOK");
        // wood
        b(5, "OAK_LOG", "SPRUCE_LOG", "BIRCH_LOG", "JUNGLE_LOG", "ACACIA_LOG", "DARK_OAK_LOG", "MANGROVE_LOG", "CHERRY_LOG", "PALE_OAK_LOG", "CRIMSON_STEM",
                "WARPED_STEM", "BAMBOO_BLOCK", "MANGROVE_ROOTS", "MUDDY_MANGROVE_ROOTS");
        // ores and minerals (value of ONE item)
        b(8, "COAL", "CHARCOAL", "LAPIS_LAZULI", "QUARTZ", "COPPER_INGOT", "RAW_COPPER", "COPPER_NUGGET");
        b(6, "REDSTONE");
        b(10, "AMETHYST_SHARD", "NETHERITE_UPGRADE_SMITHING_TEMPLATE");
        b(12, "ECHO_SHARD");
        b(25, "IRON_INGOT");
        b(20, "RAW_IRON");
        b(2.8, "IRON_NUGGET");
        b(40, "GOLD_INGOT");
        b(32, "RAW_GOLD");
        b(4.5, "GOLD_NUGGET");
        b(100, "EMERALD");
        b(150, "DIAMOND");
        b(300, "NETHERITE_SCRAP");
        b(350, "ANCIENT_DEBRIS");
        b(1500, "NETHERITE_INGOT");
        b(22, "IRON_ORE", "DEEPSLATE_IRON_ORE");
        b(9, "COPPER_ORE", "DEEPSLATE_COPPER_ORE");
        b(9, "COAL_ORE", "DEEPSLATE_COAL_ORE");
        b(35, "GOLD_ORE", "DEEPSLATE_GOLD_ORE", "NETHER_GOLD_ORE");
        b(12, "REDSTONE_ORE", "DEEPSLATE_REDSTONE_ORE", "LAPIS_ORE", "DEEPSLATE_LAPIS_ORE", "NETHER_QUARTZ_ORE");
        b(110, "EMERALD_ORE", "DEEPSLATE_EMERALD_ORE");
        b(160, "DIAMOND_ORE", "DEEPSLATE_DIAMOND_ORE");
        b(72, "COAL_BLOCK", "COPPER_BLOCK", "LAPIS_BLOCK", "REDSTONE_BLOCK", "RAW_COPPER_BLOCK", "AMETHYST_BLOCK");
        b(225, "IRON_BLOCK");
        b(180, "RAW_IRON_BLOCK");
        b(360, "GOLD_BLOCK");
        b(288, "RAW_GOLD_BLOCK");
        b(900, "EMERALD_BLOCK");
        b(1350, "DIAMOND_BLOCK");
        b(13500, "NETHERITE_BLOCK");
        // farming & food
        b(3, "WHEAT", "CARROT", "POTATO", "BEETROOT", "SUGAR_CANE", "CACTUS", "COCOA_BEANS", "SWEET_BERRIES", "MELON_SLICE", "COOKIE", "EGG",
                "WHEAT_SEEDS", "PUMPKIN_SEEDS", "MELON_SEEDS", "BEETROOT_SEEDS", "TORCHFLOWER_SEEDS", "PITCHER_POD", "NETHER_WART", "SUGAR",
                "DRIED_KELP", "BROWN_MUSHROOM", "RED_MUSHROOM", "BONE_MEAL", "POISONOUS_POTATO", "GLOW_BERRIES", "SPIDER_EYE", "ROTTEN_FLESH",
                "BEETROOT_SOUP", "TROPICAL_FISH", "PUFFERFISH", "COD", "SALMON", "CHORUS_FRUIT", "SEA_PICKLE");
        b(4.5, "BAKED_POTATO", "BREAD", "APPLE", "COOKED_COD", "COOKED_SALMON", "RABBIT", "CHICKEN", "MUTTON", "PORKCHOP", "BEEF");
        b(9, "COOKED_BEEF", "COOKED_PORKCHOP", "COOKED_CHICKEN", "COOKED_MUTTON", "COOKED_RABBIT", "PUMPKIN_PIE", "MUSHROOM_STEW", "RABBIT_STEW",
                "HAY_BLOCK", "MELON", "PUMPKIN", "CARVED_PUMPKIN", "JACK_O_LANTERN", "HONEY_BOTTLE", "MILK_BUCKET", "DRIED_KELP_BLOCK", "GOLDEN_CARROT");
        b(60, "CAKE", "GLISTERING_MELON_SLICE");
        b(250, "GOLDEN_APPLE");
        b(4000, "ENCHANTED_GOLDEN_APPLE");
        b(12, "HONEYCOMB", "BEE_NEST", "BEEHIVE", "NAME_TAG");
        // mob drops
        b(4, "BONE", "STRING", "FEATHER", "LEATHER", "INK_SAC", "GLOW_INK_SAC", "RABBIT_HIDE", "PRISMARINE_SHARD", "PRISMARINE_CRYSTALS");
        b(8, "GUNPOWDER", "SLIME_BALL", "FERMENTED_SPIDER_EYE", "BLAZE_POWDER", "FIRE_CHARGE");
        b(15, "MAGMA_CREAM", "RABBIT_FOOT");
        b(20, "PHANTOM_MEMBRANE", "TURTLE_SCUTE", "SCUTE", "ARMADILLO_SCUTE", "BREEZE_ROD", "WIND_CHARGE");
        b(30, "BLAZE_ROD");
        b(40, "ENDER_PEARL", "ENDER_EYE");
        b(60, "GHAST_TEAR");
        b(100, "NAUTILUS_SHELL");
        b(200, "SHULKER_SHELL", "DRAGON_BREATH", "END_CRYSTAL");
        b(800, "HEART_OF_THE_SEA");
        b(1200, "TRIDENT");
        b(1500, "TOTEM_OF_UNDYING", "MACE");
        b(2000, "WITHER_SKELETON_SKULL");
        b(3000, "DRAGON_HEAD", "CONDUIT");
        b(5000, "NETHER_STAR");
        b(6000, "ELYTRA");
        b(7000, "BEACON");
        b(20000, "DRAGON_EGG");
        // redstone
        b(5, "REDSTONE_TORCH", "LEVER", "TRIPWIRE_HOOK", "TARGET");
        b(15, "REPEATER", "OBSERVER", "DAYLIGHT_DETECTOR", "NOTE_BLOCK", "DISPENSER", "DROPPER", "PISTON", "TNT", "RAIL");
        b(20, "COMPARATOR", "HOPPER", "STICKY_PISTON", "POWERED_RAIL", "DETECTOR_RAIL", "ACTIVATOR_RAIL", "SLIME_BLOCK", "HONEY_BLOCK",
                "TRAPPED_CHEST", "LIGHTNING_ROD", "COPPER_BULB", "CRAFTER");
        b(60, "JUKEBOX", "SCULK_SENSOR", "SCULK_CATALYST", "SCULK_SHRIEKER", "CALIBRATED_SCULK_SENSOR", "BELL");
        // tools / misc gear
        b(12, "FISHING_ROD", "CARROT_ON_A_STICK", "WARPED_FUNGUS_ON_A_STICK", "LEAD", "COMPASS", "CLOCK", "BUCKET", "BRUSH", "SADDLE");
        b(20, "BOW", "ARROW", "SPECTRAL_ARROW", "FLINT_AND_STEEL", "SPYGLASS");
        b(35, "SHEARS", "CROSSBOW");
        b(40, "SHIELD", "IRON_HORSE_ARMOR", "WATER_BUCKET", "LAVA_BUCKET", "POWDER_SNOW_BUCKET");
        b(150, "GOLDEN_HORSE_ARMOR", "WOLF_ARMOR");
        b(450, "DIAMOND_HORSE_ARMOR");
        b(400, "RECOVERY_COMPASS");
        // magic / utility
        b(10, "GLASS_BOTTLE", "BREWING_STAND");
        b(25, "EXPERIENCE_BOTTLE", "ENCHANTING_TABLE", "ANVIL", "BOOKSHELF", "GRINDSTONE", "LECTERN", "CAULDRON", "LODESTONE", "RESPAWN_ANCHOR");
        b(30, "STONECUTTER", "LOOM", "CARTOGRAPHY_TABLE", "FLETCHING_TABLE", "SMITHING_TABLE", "COMPOSTER", "FLOWER_POT", "PAINTING", "ITEM_FRAME",
                "GLOW_ITEM_FRAME", "ARMOR_STAND");
        b(60, "ENDER_CHEST");
        b(30, "END_ROD", "CHAIN", "AMETHYST_CLUSTER");

        // generic suffix rules, order matters (more specific first)
        String[][] s = {
                {"_STAINED_GLASS_PANE", "1.5"}, {"_STAINED_GLASS", "4"}, {"_GLAZED_TERRACOTTA", "5"}, {"_TERRACOTTA", "3"},
                {"_CONCRETE_POWDER", "3"}, {"_CONCRETE", "3"}, {"_WOOL", "6"}, {"_CARPET", "3"}, {"_BED", "20"}, {"_BANNER", "15"},
                {"_CANDLE", "8"}, {"_DYE", "3"}, {"_SHULKER_BOX", "250"}, {"_BUNDLE", "40"},
                {"_HANGING_SIGN", "14"}, {"_SIGN", "8"}, {"_CHEST_BOAT", "16"}, {"_BOAT", "8"}, {"_RAFT", "8"}, {"_CHEST_RAFT", "16"},
                {"_FENCE_GATE", "5"}, {"_FENCE", "2.5"}, {"_TRAPDOOR", "4"}, {"_DOOR", "5"}, {"_PRESSURE_PLATE", "3"}, {"_BUTTON", "1.5"},
                {"_STAIRS", "2.2"}, {"_SLAB", "1.2"}, {"_WALL", "2.5"}, {"_MOSAIC", "2"},
                {"_PLANKS", "1.5"}, {"_LOG", "5"}, {"_WOOD", "5"}, {"_STEM", "5"}, {"_HYPHAE", "5"}, {"_LEAVES", "1"}, {"_SAPLING", "4"},
                {"_PROPAGULE", "4"}, {"_CORAL_BLOCK", "6"}, {"_CORAL_FAN", "6"}, {"_CORAL", "6"}, {"_PETALS", "3"},
                {"_ORE", "25"}, {"_BLOCK", "30"}, {"_TULIP", "2"}, {"_ROOTS", "2"}, {"_FUNGUS", "4"},
        };
        for (String[] r : s) SUFFIX.put(r[0], Double.parseDouble(r[1]));
    }

    private static double tierUnit(String t) {
        switch (t) {
            case "WOODEN": return 1.5;
            case "STONE": return 1;
            case "GOLDEN": return 40;
            case "IRON": return 25;
            case "DIAMOND": return 150;
            case "NETHERITE": return 150;
            case "LEATHER": return 6;
            case "CHAINMAIL": return 12;
            case "COPPER": return 8;
            case "TURTLE": return 20;
            default: return -1;
        }
    }

    private static int pieceCount(String p) {
        switch (p) {
            case "SWORD": return 2;
            case "AXE": case "PICKAXE": return 3;
            case "SHOVEL": return 1;
            case "HOE": return 2;
            case "HELMET": return 5;
            case "CHESTPLATE": return 8;
            case "LEGGINGS": return 7;
            case "BOOTS": return 4;
            default: return -1;
        }
    }

    /** "Fair value" of one item. Buy and sell prices are derived from this. */
    public static double value(Material m) {
        String n = m.name();
        Double d = BASE.get(n);
        if (d != null) return d;
        if (n.endsWith("_SPAWN_EGG")) return 400;
        if (n.startsWith("MUSIC_DISC_")) return 300;
        if (n.endsWith("_SMITHING_TEMPLATE")) return n.startsWith("NETHERITE") ? 1500 : 500;
        if (n.endsWith("_POTTERY_SHERD")) return 80;
        if (n.endsWith("_BANNER_PATTERN")) return 60;
        if (n.endsWith("_HEAD") || n.endsWith("_SKULL")) return 300;
        if (n.endsWith("_HORSE_ARMOR")) return 150;
        int us = n.indexOf('_');
        if (us > 0) {
            String tier = n.substring(0, us);
            String piece = n.substring(us + 1);
            double u = tierUnit(tier);
            int cnt = pieceCount(piece);
            if (u > 0 && cnt > 0) {
                if (tier.equals("NETHERITE")) return cnt * u + 1500 + 2;
                return cnt * u + 1;
            }
        }
        for (Map.Entry<String, Double> e : SUFFIX.entrySet()) if (n.endsWith(e.getKey())) return e.getValue();
        if (n.contains("COPPER")) return 72;
        return 10;
    }
}
