package com.omnishop;

import org.bukkit.Material;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Every tradable item is auto-sorted into one of these categories. */
public enum ShopCategory {
    BLOCKS("&7&lBuilding Blocks", Material.STONE_BRICKS, 10),
    WOOD("&6&lWood & Planks", Material.OAK_LOG, 11),
    ORES("&b&lOres & Minerals", Material.DIAMOND, 12),
    TOOLS("&e&lTools & Weapons", Material.DIAMOND_PICKAXE, 13),
    ARMOR("&9&lArmor", Material.DIAMOND_CHESTPLATE, 14),
    FOOD("&c&lFood", Material.COOKED_BEEF, 15),
    FARMING("&a&lFarming & Nature", Material.WHEAT, 16),
    MOB_DROPS("&2&lMob Drops", Material.BONE, 19),
    REDSTONE("&4&lRedstone", Material.REDSTONE, 20),
    DECORATION("&d&lDecoration & Colors", Material.WHITE_BANNER, 21),
    NETHER_END("&5&lNether & End", Material.NETHERRACK, 22),
    BREWING("&3&lBrewing & Magic", Material.BREWING_STAND, 23),
    TRANSPORT("&f&lTransport", Material.MINECART, 24),
    SPAWN_EGGS("&a&lSpawn Eggs", Material.CREEPER_SPAWN_EGG, 25),
    MISC("&8&lMiscellaneous", Material.NAME_TAG, 31);

    public final String title;
    public final Material icon;
    public final int slot;

    ShopCategory(String title, Material icon, int slot) {
        this.title = title;
        this.icon = icon;
        this.slot = slot;
    }

    private static Set<String> set(String... s) { return new HashSet<>(Arrays.asList(s)); }

    private static final Set<String> MOB = set("BONE", "BONE_MEAL", "STRING", "SPIDER_EYE", "GUNPOWDER", "ENDER_PEARL", "BLAZE_ROD",
            "GHAST_TEAR", "SLIME_BALL", "MAGMA_CREAM", "PHANTOM_MEMBRANE", "SHULKER_SHELL", "NETHER_STAR", "DRAGON_BREATH",
            "TOTEM_OF_UNDYING", "ROTTEN_FLESH", "FEATHER", "LEATHER", "RABBIT_HIDE", "RABBIT_FOOT", "INK_SAC", "GLOW_INK_SAC",
            "PRISMARINE_SHARD", "PRISMARINE_CRYSTALS", "SCUTE", "TURTLE_SCUTE", "ARMADILLO_SCUTE", "NAUTILUS_SHELL", "HEART_OF_THE_SEA",
            "TRIDENT", "WITHER_SKELETON_SKULL", "BREEZE_ROD", "WIND_CHARGE", "OMINOUS_TRIAL_KEY", "TRIAL_KEY", "ECHO_SHARD",
            "DRAGON_EGG", "DRAGON_HEAD", "EGG", "HONEYCOMB", "FERMENTED_SPIDER_EYE", "SPONGE", "WET_SPONGE");
    private static final Set<String> FARM = set("WHEAT", "HAY_BLOCK", "SUGAR_CANE", "SUGAR", "BAMBOO", "CACTUS", "KELP", "DRIED_KELP_BLOCK",
            "MELON", "PUMPKIN", "CARVED_PUMPKIN", "JACK_O_LANTERN", "COCOA_BEANS", "NETHER_WART", "LILY_PAD", "MOSS_BLOCK", "MOSS_CARPET",
            "VINE", "GLOW_LICHEN", "SEA_PICKLE", "BROWN_MUSHROOM", "RED_MUSHROOM", "MUSHROOM_STEM", "BROWN_MUSHROOM_BLOCK",
            "RED_MUSHROOM_BLOCK", "COMPOSTER", "FARMLAND", "BEE_NEST", "BEEHIVE", "AZALEA", "FLOWERING_AZALEA", "SPORE_BLOSSOM",
            "BIG_DRIPLEAF", "SMALL_DRIPLEAF", "HANGING_ROOTS", "GRASS_BLOCK", "SHORT_GRASS", "GRASS", "TALL_GRASS", "FERN", "LARGE_FERN",
            "DEAD_BUSH", "SEAGRASS", "TORCHFLOWER", "PITCHER_PLANT", "CHORUS_FRUIT", "CHORUS_FLOWER", "FIREFLY_BUSH", "LEAF_LITTER",
            "WILDFLOWERS", "BUSH", "CACTUS_FLOWER", "OPEN_EYEBLOSSOM", "CLOSED_EYEBLOSSOM", "PODZOL", "MYCELIUM", "ROOTED_DIRT", "MUD");
    private static final Set<String> REDSTONE_SET = set("REDSTONE", "REDSTONE_BLOCK", "REDSTONE_TORCH", "REPEATER", "COMPARATOR", "PISTON",
            "STICKY_PISTON", "OBSERVER", "HOPPER", "DROPPER", "DISPENSER", "LEVER", "TNT", "TARGET", "DAYLIGHT_DETECTOR", "TRIPWIRE_HOOK",
            "LIGHTNING_ROD", "NOTE_BLOCK", "JUKEBOX", "SCULK_SENSOR", "CALIBRATED_SCULK_SENSOR", "SCULK_SHRIEKER", "SCULK_CATALYST",
            "COPPER_BULB", "CRAFTER", "SLIME_BLOCK", "HONEY_BLOCK", "TRAPPED_CHEST", "STONE_BUTTON", "POLISHED_BLACKSTONE_BUTTON",
            "STONE_PRESSURE_PLATE", "POLISHED_BLACKSTONE_PRESSURE_PLATE", "LIGHT_WEIGHTED_PRESSURE_PLATE", "HEAVY_WEIGHTED_PRESSURE_PLATE",
            "POWERED_RAIL", "DETECTOR_RAIL", "ACTIVATOR_RAIL", "BELL", "TRIPWIRE", "STRING_TRIPWIRE");
    private static final Set<String> BREW = set("BREWING_STAND", "CAULDRON", "GLASS_BOTTLE", "BLAZE_POWDER", "ENCHANTING_TABLE", "BOOKSHELF",
            "CHISELED_BOOKSHELF", "EXPERIENCE_BOTTLE", "BOOK", "ANVIL", "CHIPPED_ANVIL", "DAMAGED_ANVIL", "GRINDSTONE", "LECTERN",
            "GLISTERING_MELON_SLICE", "GOLDEN_CARROT", "ENDER_EYE", "WRITABLE_BOOK", "ENCHANTED_BOOK", "SPYGLASS", "RECOVERY_COMPASS",
            "END_CRYSTAL", "BEACON", "CONDUIT", "RESPAWN_ANCHOR", "LODESTONE", "AMETHYST_SHARD", "AMETHYST_CLUSTER", "FIREWORK_STAR",
            "FIREWORK_ROCKET", "PAPER", "MAP", "FILLED_MAP", "EMPTY_MAP", "OMINOUS_BOTTLE", "SUGAR");
    private static final Set<String> FOOD_EXTRA = set("CAKE", "MILK_BUCKET", "HONEY_BOTTLE", "SUGAR", "EGG", "COCOA_BEANS", "WHEAT_SEEDS");
    private static final Set<String> ORE_EXTRA = set("COAL", "CHARCOAL", "DIAMOND", "EMERALD", "LAPIS_LAZULI", "QUARTZ", "AMETHYST_SHARD",
            "ANCIENT_DEBRIS", "NETHERITE_SCRAP", "COAL_BLOCK", "IRON_BLOCK", "GOLD_BLOCK", "DIAMOND_BLOCK", "EMERALD_BLOCK",
            "LAPIS_BLOCK", "COPPER_BLOCK", "NETHERITE_BLOCK", "RAW_IRON_BLOCK", "RAW_GOLD_BLOCK", "RAW_COPPER_BLOCK", "AMETHYST_BLOCK",
            "GLOWSTONE_DUST", "FLINT", "CLAY_BALL", "BRICK", "NETHER_BRICK", "RESIN_CLUMP", "RESIN_BRICK");
    private static final Set<String> TRANSPORT_EXTRA = set("RAIL", "SADDLE", "MINECART", "CHEST_MINECART", "FURNACE_MINECART",
            "HOPPER_MINECART", "TNT_MINECART", "COMMAND_BLOCK_MINECART", "CARROT_ON_A_STICK", "WARPED_FUNGUS_ON_A_STICK", "LEAD", "ELYTRA",
            "ENDER_PEARL", "NAME_TAG");
    private static final Set<String> TOOL_EXTRA = set("BOW", "CROSSBOW", "TRIDENT", "MACE", "FISHING_ROD", "SHEARS", "FLINT_AND_STEEL",
            "ARROW", "SPECTRAL_ARROW", "BRUSH", "COMPASS", "CLOCK", "BUCKET", "WATER_BUCKET", "LAVA_BUCKET", "POWDER_SNOW_BUCKET",
            "COD_BUCKET", "SALMON_BUCKET", "PUFFERFISH_BUCKET", "TROPICAL_FISH_BUCKET", "AXOLOTL_BUCKET", "TADPOLE_BUCKET", "FIRE_CHARGE",
            "TORCH", "SOUL_TORCH", "LANTERN", "SOUL_LANTERN", "TOTEM_OF_UNDYING", "WIND_CHARGE");
    private static final String[] WOOD_NAMES = {"OAK", "SPRUCE", "BIRCH", "JUNGLE", "ACACIA", "DARK_OAK", "MANGROVE", "CHERRY", "BAMBOO",
            "CRIMSON", "WARPED", "PALE_OAK"};
    private static final String[] WOOD_SUFFIX = {"_LOG", "_WOOD", "_PLANKS", "_STEM", "_HYPHAE", "_SLAB", "_STAIRS", "_FENCE", "_FENCE_GATE",
            "_DOOR", "_TRAPDOOR", "_SIGN", "_HANGING_SIGN", "_BUTTON", "_PRESSURE_PLATE", "_LEAVES", "_BLOCK", "_MOSAIC", "_MOSAIC_SLAB",
            "_MOSAIC_STAIRS"};

    public static ShopCategory of(Material m) {
        String n = m.name();
        if (n.endsWith("_SPAWN_EGG")) return SPAWN_EGGS;
        if (n.endsWith("_HELMET") || n.endsWith("_CHESTPLATE") || n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS")
                || n.endsWith("_HORSE_ARMOR") || n.endsWith("_WOLF_ARMOR") || n.equals("SHIELD") || n.equals("ELYTRA")) return ARMOR;
        if (n.endsWith("_SWORD") || n.endsWith("_AXE") || n.endsWith("_PICKAXE") || n.endsWith("_SHOVEL") || n.endsWith("_HOE")
                || TOOL_EXTRA.contains(n)) return TOOLS;
        if (n.contains("BOAT") || n.contains("RAFT") || n.endsWith("_RAIL") || n.endsWith("_MINECART") || TRANSPORT_EXTRA.contains(n)) return TRANSPORT;
        if (m.isEdible() || FOOD_EXTRA.contains(n)) {
            if (!n.endsWith("_SEEDS") && !n.equals("COCOA_BEANS") && !n.equals("SUGAR") && !n.equals("EGG")) return FOOD;
        }
        if (MOB.contains(n)) return MOB_DROPS;
        if (n.endsWith("_ORE") || n.endsWith("_INGOT") || n.endsWith("_NUGGET") || n.startsWith("RAW_") || ORE_EXTRA.contains(n)) return ORES;
        if (REDSTONE_SET.contains(n)) return REDSTONE;
        if (BREW.contains(n) || n.contains("POTION") || n.contains("TIPPED_ARROW")) return BREWING;
        if (n.endsWith("_WOOL") || n.endsWith("_CARPET") || n.endsWith("_BED") || n.endsWith("_BANNER") || n.endsWith("_CANDLE") || n.equals("CANDLE")
                || n.endsWith("_DYE") || n.contains("GLASS") || n.endsWith("_CONCRETE") || n.endsWith("_CONCRETE_POWDER")
                || n.endsWith("TERRACOTTA") || n.endsWith("_HEAD") || n.endsWith("_SKULL") || n.equals("PAINTING") || n.equals("ITEM_FRAME")
                || n.equals("GLOW_ITEM_FRAME") || n.equals("FLOWER_POT") || n.endsWith("_SHULKER_BOX") || n.equals("SHULKER_BOX")
                || n.endsWith("_BANNER_PATTERN") || n.endsWith("_POTTERY_SHERD") || n.equals("ARMOR_STAND") || n.endsWith("_BUNDLE")
                || n.equals("BUNDLE") || n.equals("DANDELION") || n.equals("POPPY") || n.endsWith("_TULIP") || n.equals("BLUE_ORCHID")
                || n.equals("ALLIUM") || n.equals("AZURE_BLUET") || n.equals("OXEYE_DAISY") || n.equals("CORNFLOWER")
                || n.equals("LILY_OF_THE_VALLEY") || n.equals("WITHER_ROSE") || n.equals("SUNFLOWER") || n.equals("LILAC")
                || n.equals("ROSE_BUSH") || n.equals("PEONY") || n.equals("CHAIN") || n.equals("END_ROD")
                || n.endsWith("_COPPER_LANTERN")) return DECORATION;
        if (n.contains("NETHER") || n.startsWith("END_") || n.contains("ENDER") || n.contains("PURPUR") || n.contains("CHORUS")
                || n.contains("BLACKSTONE") || n.contains("BASALT") || n.contains("SOUL_") || n.equals("GLOWSTONE") || n.equals("MAGMA_BLOCK")
                || n.equals("SHROOMLIGHT") || n.equals("CRYING_OBSIDIAN") || n.equals("OBSIDIAN") || n.equals("CRIMSON_FUNGUS")
                || n.equals("WARPED_FUNGUS") || n.endsWith("_NYLIUM") || n.endsWith("_ROOTS") || n.equals("WEEPING_VINES")
                || n.equals("TWISTING_VINES") || n.equals("WARPED_WART_BLOCK") || n.equals("SHULKER_SHELL")) return NETHER_END;
        if (FARM.contains(n) || n.endsWith("_SEEDS") || n.endsWith("_SAPLING") || n.endsWith("_LEAVES") || n.endsWith("_PROPAGULE")
                || n.endsWith("CORAL") || n.endsWith("CORAL_FAN") || n.endsWith("CORAL_BLOCK")) return FARMING;
        for (String w : WOOD_NAMES) {
            if (n.startsWith(w + "_")) {
                for (String suf : WOOD_SUFFIX) if (n.endsWith(suf)) return WOOD;
            }
        }
        if (n.equals("STICK") || n.equals("CHEST") || n.equals("CRAFTING_TABLE") || n.equals("BARREL") || n.equals("LADDER") || n.equals("BOWL")
                || n.equals("LOOM") || n.equals("CARTOGRAPHY_TABLE") || n.equals("FLETCHING_TABLE") || n.equals("SMITHING_TABLE")
                || n.equals("COMPOSTER") || n.equals("SCAFFOLDING")) return WOOD;
        if (n.startsWith("MUSIC_DISC_") || n.endsWith("_SMITHING_TEMPLATE") || n.equals("DISC_FRAGMENT_5") || n.endsWith("_ARMOR_TRIM")
                || n.equals("KNOWLEDGE_BOOK") || n.equals("SADDLE") || n.equals("GOAT_HORN") || n.equals("FIREWORK_ROCKET")
                || n.equals("TRIAL_KEY") || n.equals("OMINOUS_TRIAL_KEY") || n.equals("HEAVY_CORE") || n.equals("MUSIC_DISC")) return MISC;
        return m.isBlock() ? BLOCKS : MISC;
    }
}
