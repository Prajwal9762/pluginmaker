package com.omnishop;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.stream.Collectors;

public class ShopCommands implements CommandExecutor, TabCompleter {

    private final OmniShop plugin;

    public ShopCommands(OmniShop plugin) { this.plugin = plugin; }

    private Material parse(String s) {
        Material m = Material.matchMaterial(s.toUpperCase(Locale.ROOT));
        return (m != null && plugin.prices().has(m)) ? m : null;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] a) {
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        if (name.equals("shopadmin")) return admin(sender, a);
        if (name.equals("market")) { sendMarket(sender, plugin); return true; }
        if (!(sender instanceof Player)) { Util.send(sender, "player-only"); return true; }
        Player p = (Player) sender;
        if (!p.hasPermission("omnishop.use")) { Util.send(p, "no-permission"); return true; }

        switch (name) {
            case "shop": return shop(p, a);
            case "sell":
                if (a.length > 0 && a[0].equalsIgnoreCase("hand")) plugin.shop().sellHand(p, false);
                else if (a.length > 0 && a[0].equalsIgnoreCase("all")) plugin.shop().sellInventory(p, null, -1);
                else plugin.shopGui().openSellGui(p);
                return true;
            case "sellhand":
                plugin.shop().sellHand(p, a.length > 0 && a[0].equalsIgnoreCase("all"));
                return true;
            case "sellall":
                plugin.shop().sellInventory(p, null, -1);
                return true;
            case "specials":
                plugin.shopGui().openSpecials(p);
                return true;
            case "price":
                return price(p, a);
            default:
                return false;
        }
    }

    private boolean shop(Player p, String[] a) {
        if (a.length == 0) { plugin.shopGui().openMain(p); return true; }
        String sub = a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "specials": case "deals": plugin.shopGui().openSpecials(p); return true;
            case "search":
                if (a.length < 2) { p.sendMessage(Util.c("&cUsage: /shop search <text>")); return true; }
                plugin.shopGui().openSearch(p, String.join(" ", Arrays.copyOfRange(a, 1, a.length)));
                return true;
            case "buy": case "sell": {
                if (a.length < 2) { p.sendMessage(Util.c("&cUsage: /shop " + sub + " <item> [amount" + (sub.equals("sell") ? "|all" : "") + "]")); return true; }
                Material m = parse(a[1]);
                if (m == null) { Util.send(p, "unknown-item", "item", a[1]); return true; }
                int amount = 1;
                boolean all = false;
                if (a.length > 2) {
                    if (a[2].equalsIgnoreCase("all")) all = true;
                    else try { amount = Math.max(1, Integer.parseInt(a[2])); } catch (NumberFormatException ex) { p.sendMessage(Util.c("&cInvalid amount.")); return true; }
                }
                if (sub.equals("buy")) plugin.shop().buy(p, m, amount);
                else plugin.shop().sellInventory(p, m, all ? -1 : amount);
                return true;
            }
            default:
                for (ShopCategory c : ShopCategory.values()) {
                    if (c.name().equalsIgnoreCase(sub) || c.name().replace("_", "").equalsIgnoreCase(sub)) {
                        plugin.shopGui().openCategory(p, c, 0);
                        return true;
                    }
                }
                plugin.shopGui().openSearch(p, String.join(" ", a));
                return true;
        }
    }

    private boolean price(Player p, String[] a) {
        Material m;
        if (a.length == 0) {
            ItemStack hand = p.getInventory().getItemInMainHand();
            if (hand == null || hand.getType() == Material.AIR) { p.sendMessage(Util.c("&cUsage: /price <item> (or hold an item)")); return true; }
            m = hand.getType();
        } else {
            m = parse(a[0]);
        }
        if (m == null || !plugin.prices().has(m)) { Util.send(p, "unknown-item", "item", a.length > 0 ? a[0] : "?"); return true; }
        double buy = plugin.shop().buyPrice(m), sell = plugin.shop().sellPrice(m, p);
        Util.raw(p, "price-header", "item", Util.pretty(m));
        p.sendMessage(buy < 0 ? Util.c("&7Buy:  &cnot for sale") : Util.msg("price-buy", "price", Util.money(buy)));
        p.sendMessage(sell < 0 ? Util.c("&7Sell: &cnot accepted") : Util.msg("price-sell", "price", Util.money(sell)));
        SpecialsManager.Deal d = plugin.specials().get(m);
        if (d != null) Util.raw(p, "price-special", "left", String.valueOf(plugin.specials().allowance(p.getUniqueId(), m)));
        Util.raw(p, "price-trend", "trend", Util.c(ShopGui.trend(plugin.prices().mult(m))));
        return true;
    }

    public static void sendMarket(CommandSender s, OmniShop plugin) {
        s.sendMessage(Util.c("&6&m      &r &e&lMarket Movers &6&m      "));
        List<Map.Entry<Material, Double>> l = plugin.prices().movers();
        if (l.isEmpty()) { s.sendMessage(Util.c("&7All prices are stable right now.")); return; }
        int n = 0;
        for (Map.Entry<Material, Double> e : l) {
            if (n++ >= 10) break;
            s.sendMessage(Util.c(" &f" + Util.pretty(e.getKey()) + " &8- " + ShopGui.trend(e.getValue())));
        }
        s.sendMessage(Util.c("&7&oRed = pricier (people are buying), green = cheaper (people are selling)."));
    }

    private boolean admin(CommandSender s, String[] a) {
        if (!s.hasPermission("omnishop.admin")) { Util.send(s, "no-permission"); return true; }
        if (a.length == 0) {
            s.sendMessage(Util.c("&6/shopadmin &fset <item> <buy> <sell> &7| &fdisable <buy|sell> <item> &7| &freset <item> &7| &fresetall"));
            s.sendMessage(Util.c("&6/shopadmin &frotate &7(new daily specials) | &freload &7| &fregenerate &7(rebuild prices.yml)"));
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "set": {
                if (a.length < 4) { s.sendMessage(Util.c("&cUsage: /shopadmin set <item> <buy> <sell> (-1 disables)")); return true; }
                Material m = Material.matchMaterial(a[1].toUpperCase(Locale.ROOT));
                if (m == null) { Util.send(s, "unknown-item", "item", a[1]); return true; }
                try {
                    double b = Double.parseDouble(a[2]), se = Double.parseDouble(a[3]);
                    plugin.prices().set(m, b, se);
                    plugin.shop().reindex();
                    Util.send(s, "admin-set", "item", Util.pretty(m), "buy", String.valueOf(b), "sell", String.valueOf(se));
                } catch (NumberFormatException ex) { s.sendMessage(Util.c("&cInvalid number.")); }
                return true;
            }
            case "disable": {
                if (a.length < 3) { s.sendMessage(Util.c("&cUsage: /shopadmin disable <buy|sell> <item>")); return true; }
                Material m = Material.matchMaterial(a[2].toUpperCase(Locale.ROOT));
                if (m == null) { Util.send(s, "unknown-item", "item", a[2]); return true; }
                plugin.prices().disable(m, a[1].equalsIgnoreCase("buy"));
                s.sendMessage(Util.c("&aDisabled " + a[1] + " for &f" + Util.pretty(m)));
                return true;
            }
            case "reset":
                if (a.length < 2) return true;
                Material m = Material.matchMaterial(a[1].toUpperCase(Locale.ROOT));
                if (m == null) { Util.send(s, "unknown-item", "item", a[1]); return true; }
                plugin.prices().resetDynamic(m);
                Util.send(s, "admin-reset", "item", Util.pretty(m));
                return true;
            case "resetall":
                plugin.prices().resetAllDynamic();
                s.sendMessage(Util.c("&aAll market prices reset."));
                return true;
            case "rotate":
                plugin.specials().rotate(true);
                s.sendMessage(Util.c("&aDaily specials rotated."));
                return true;
            case "reload":
                plugin.reloadAll();
                Util.send(s, "admin-reload");
                return true;
            case "regenerate":
                plugin.prices().regenerate();
                plugin.shop().reindex();
                s.sendMessage(Util.c("&aprices.yml regenerated for " + plugin.prices().all().size() + " items."));
                return true;
            default:
                return false;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] a) {
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        String last = a[a.length - 1].toLowerCase(Locale.ROOT);
        if (name.equals("shop")) {
            if (a.length == 1) {
                out.addAll(Arrays.asList("buy", "sell", "search", "specials"));
                for (ShopCategory c : ShopCategory.values()) out.add(c.name().toLowerCase(Locale.ROOT));
            } else if (a.length == 2 && (a[0].equalsIgnoreCase("buy") || a[0].equalsIgnoreCase("sell"))) {
                return items(last);
            } else if (a.length == 3 && a[0].equalsIgnoreCase("sell")) out.add("all");
        } else if (name.equals("price") && a.length == 1) {
            return items(last);
        } else if (name.equals("sell") && a.length == 1) {
            out.addAll(Arrays.asList("hand", "all"));
        } else if (name.equals("sellhand") && a.length == 1) {
            out.add("all");
        } else if (name.equals("shopadmin")) {
            if (a.length == 1) out.addAll(Arrays.asList("set", "disable", "reset", "resetall", "rotate", "reload", "regenerate"));
            else if (a.length == 2 && a[0].equalsIgnoreCase("disable")) out.addAll(Arrays.asList("buy", "sell"));
            else if ((a.length == 2 && (a[0].equalsIgnoreCase("set") || a[0].equalsIgnoreCase("reset")))
                    || (a.length == 3 && a[0].equalsIgnoreCase("disable"))) return items(last);
        }
        return out.stream().filter(x -> x.toLowerCase(Locale.ROOT).startsWith(last)).collect(Collectors.toList());
    }

    private List<String> items(String prefix) {
        List<String> out = new ArrayList<>();
        for (Material m : plugin.prices().all()) {
            String n = m.name().toLowerCase(Locale.ROOT);
            if (n.startsWith(prefix)) out.add(n);
            if (out.size() >= 40) break;
        }
        return out;
    }
}
