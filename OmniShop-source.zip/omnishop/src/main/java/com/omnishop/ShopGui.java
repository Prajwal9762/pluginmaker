package com.omnishop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/** Every shop GUI: main menu, category lists, search, specials, amount picker and the /sell GUI. */
public class ShopGui implements Listener {

    public enum Type { MAIN, LIST, SPECIALS, AMOUNT, SELL }

    public static class Holder implements InventoryHolder {
        public Type type;
        public ShopCategory category;
        public String title;
        public List<Material> items = new ArrayList<>();
        public int page;
        public Material target;
        public int amount = 1;
        public Holder back; // where the amount picker returns to
        public Inventory inv;

        @Override public Inventory getInventory() { return inv; }
    }

    private final OmniShop plugin;
    private static final int PER_PAGE = 45;

    public ShopGui(OmniShop plugin) { this.plugin = plugin; }

    private ShopManager sm() { return plugin.shop(); }

    // ================================================================= MAIN MENU

    public void openMain(Player p) {
        Holder h = new Holder();
        h.type = Type.MAIN;
        h.inv = Bukkit.createInventory(h, 54, Util.c("&8» &6&lOmniShop &8- &7Categories"));
        renderMain(p, h);
        p.openInventory(h.inv);
        Util.play(p, "open");
    }

    private void renderMain(Player p, Holder h) {
        Inventory inv = h.inv;
        for (int i = 0; i < 54; i++) inv.setItem(i, Util.pane(i < 9 || i >= 45 ? Material.BLACK_STAINED_GLASS_PANE : Material.GRAY_STAINED_GLASS_PANE));
        for (ShopCategory c : ShopCategory.values()) {
            int n = sm().items(c).size();
            inv.setItem(c.slot, Util.icon(c.icon, c.title, "&7Items: &f" + n, "", "&eClick to browse"));
        }
        // daily specials
        List<String> lore = new ArrayList<>();
        if (plugin.specials().enabled()) {
            lore.add("&7Rotating deals: items are &acheaper to buy");
            lore.add("&7and pay &dextra &7when you sell!");
            lore.add("");
            lore.add("&7Changes in: &e" + Util.duration(plugin.specials().remainingMillis()));
            lore.add("");
            lore.add("&eClick to view today's deals");
        } else {
            lore.add("&cDaily specials are disabled.");
        }
        inv.setItem(4, Util.icon(Material.NETHER_STAR, "&d&l★ Daily Specials ★", lore));
        inv.setItem(45, Util.icon(Material.ENDER_PEARL, "&b&lPlayer Warps", "&7Visit warps made by players", "", "&eClick to browse"));
        inv.setItem(47, Util.icon(Material.HOPPER, "&a&lSell Items", "&7Open the sell GUI. Drop items in,", "&7close it and get paid.", "", "&eClick to open"));
        inv.setItem(48, Util.icon(Material.CHEST, "&a&lSell Everything", "&7Sell every sellable item in", "&7your inventory right now.", "", "&eClick to sell"));
        inv.setItem(49, Util.icon(Material.GOLD_INGOT, "&6&lYour Balance", "&f" + Util.money(plugin.eco().getBalance(p)),
                "", "&7Tip: &f/shop search <name>", "&7Tip: &f/price <item>"));
        inv.setItem(50, Util.icon(Material.COMPASS, "&e&lMarket Trends", "&7See which prices are moving", "", "&eClick to view"));
        inv.setItem(53, Util.icon(Material.BARRIER, "&c&lClose"));
    }

    // ================================================================= LIST (category / search)

    public void openCategory(Player p, ShopCategory c, int page) {
        Holder h = new Holder();
        h.type = Type.LIST;
        h.category = c;
        h.items = new ArrayList<>(sm().items(c));
        h.title = c.title;
        h.page = page;
        openList(p, h);
    }

    public void openSearch(Player p, String query) {
        Holder h = new Holder();
        h.type = Type.LIST;
        h.items = sm().search(query);
        h.title = "&e&lSearch: &f" + query;
        openList(p, h);
    }

    private void openList(Player p, Holder h) {
        h.inv = Bukkit.createInventory(h, 54, Util.c("&8» " + h.title + " &8(" + h.items.size() + ")"));
        renderList(p, h);
        p.openInventory(h.inv);
        Util.play(p, "open");
    }

    private void renderList(Player p, Holder h) {
        Inventory inv = h.inv;
        int pages = Math.max(1, (int) Math.ceil(h.items.size() / (double) PER_PAGE));
        h.page = Math.max(0, Math.min(h.page, pages - 1));
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = h.page * PER_PAGE + i;
            inv.setItem(i, idx < h.items.size() ? itemIcon(p, h.items.get(idx)) : null);
        }
        for (int i = 45; i < 54; i++) inv.setItem(i, Util.pane(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(45, h.page > 0 ? Util.icon(Material.ARROW, "&a« Previous page", "&7Page " + h.page + "/" + pages) : Util.pane(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(47, Util.icon(Material.OAK_DOOR, "&e« Back to categories"));
        inv.setItem(49, Util.icon(Material.GOLD_INGOT, "&6Balance: &f" + Util.money(plugin.eco().getBalance(p)),
                "&7Page &f" + (h.page + 1) + "&7/&f" + pages,
                "",
                "&aLeft-click &7buy 1   &aShift-left &7buy 64",
                "&cRight-click &7sell 1   &cShift-right &7sell all",
                "&eMiddle-click &7choose amount"));
        inv.setItem(51, Util.icon(Material.NETHER_STAR, "&d★ Daily Specials", "&eClick to view"));
        inv.setItem(53, h.page < pages - 1 ? Util.icon(Material.ARROW, "&aNext page »", "&7Page " + (h.page + 2) + "/" + pages) : Util.pane(Material.BLACK_STAINED_GLASS_PANE));
    }

    /** The item icon with live buy/sell prices in its lore. */
    public ItemStack itemIcon(Player p, Material m) {
        double buy = sm().buyPrice(m);
        double sell = sm().sellPrice(m, p);
        SpecialsManager.Deal d = plugin.specials().get(m);
        List<String> lore = new ArrayList<>();
        if (d != null) lore.add(d.jackpot ? "&d&l★ JACKPOT DEAL ★" : "&d★ Daily Special");
        lore.add(buy < 0 ? "&7Buy:  &cnot for sale" : "&7Buy:  &a" + Util.money(buy) + (d != null ? " &d(-" + d.discountPercent() + "%)" : ""));
        lore.add(sell < 0 ? "&7Sell: &cnot accepted" : "&7Sell: &e" + Util.money(sell) + (d != null ? " &d(+" + d.bonusPercent() + "%)" : ""));
        double mult = plugin.prices().mult(m);
        if (Math.abs(mult - 1.0) >= 0.01) lore.add("&7Market: " + trend(mult));
        lore.add("");
        lore.add("&aL-click &7buy 1  &8|  &aShift &7buy 64");
        lore.add("&cR-click &7sell 1  &8|  &cShift &7sell all");
        lore.add("&eMiddle-click &7custom amount");
        ItemStack it = Util.icon(m, "&f" + Util.pretty(m), lore);
        return it;
    }

    public static String trend(double mult) {
        int pct = (int) Math.round((mult - 1.0) * 100);
        if (pct > 0) return "&c▲ +" + pct + "%";
        if (pct < 0) return "&a▼ " + pct + "%";
        return "&7■ stable";
    }

    // ================================================================= SPECIALS

    public void openSpecials(Player p) {
        Holder h = new Holder();
        h.type = Type.SPECIALS;
        h.inv = Bukkit.createInventory(h, 36, Util.c("&8» &d&l★ Daily Specials ★"));
        renderSpecials(p, h);
        p.openInventory(h.inv);
        Util.play(p, "special");
    }

    private final int[] SPECIAL_SLOTS = {11, 12, 13, 14, 15, 20, 21, 22, 23, 24, 10, 16, 19, 25};

    private void renderSpecials(Player p, Holder h) {
        Inventory inv = h.inv;
        h.items.clear();
        for (int i = 0; i < 36; i++) inv.setItem(i, Util.pane(Material.PURPLE_STAINED_GLASS_PANE));
        int i = 0;
        // jackpot centred at top
        for (SpecialsManager.Deal d : plugin.specials().deals()) {
            int slot;
            if (d.jackpot) slot = 4;
            else slot = SPECIAL_SLOTS[Math.min(i++, SPECIAL_SLOTS.length - 1)];
            ItemStack it = itemIcon(p, d.material);
            inv.setItem(slot, it);
            h.items.add(d.material);
        }
        inv.setItem(27, Util.icon(Material.ARROW, "&e« Back"));
        inv.setItem(31, Util.icon(Material.CLOCK, "&e&lNext rotation in &f" + Util.duration(plugin.specials().remainingMillis()),
                "&7New deals appear automatically.", "&7Bonus sells are limited to",
                "&f" + plugin.getConfig().getInt("specials.per-player-sell-limit", 512) + " &7items per deal."));
        inv.setItem(35, Util.icon(Material.BARRIER, "&cClose"));
    }

    private Material specialAt(Holder h, int slot) {
        ItemStack it = h.inv.getItem(slot);
        if (it == null) return null;
        Material m = it.getType();
        return h.items.contains(m) ? m : null;
    }

    // ================================================================= AMOUNT PICKER

    public void openAmount(Player p, Material m, Holder back) {
        Holder h = new Holder();
        h.type = Type.AMOUNT;
        h.target = m;
        h.back = back;
        h.amount = 1;
        h.inv = Bukkit.createInventory(h, 27, Util.c("&8» &6" + Util.pretty(m)));
        renderAmount(p, h);
        p.openInventory(h.inv);
        Util.play(p, "click");
    }

    private void renderAmount(Player p, Holder h) {
        Inventory inv = h.inv;
        Material m = h.target;
        for (int i = 0; i < 27; i++) inv.setItem(i, Util.pane(Material.GRAY_STAINED_GLASS_PANE));
        double buy = sm().buyPrice(m);
        double sell = sm().sellPrice(m, p);
        int inInv = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) if (s != null && s.getType() == m && sm().plain(s)) inInv += s.getAmount();
        inv.setItem(10, Util.icon(Material.RED_STAINED_GLASS_PANE, "&c-64"));
        inv.setItem(11, Util.icon(Material.RED_STAINED_GLASS_PANE, "&c-10"));
        inv.setItem(12, Util.icon(Material.RED_STAINED_GLASS_PANE, "&c-1"));
        ItemStack center = itemIcon(p, m);
        center.setAmount(Math.max(1, Math.min(64, h.amount)));
        org.bukkit.inventory.meta.ItemMeta meta = center.getItemMeta();
        if (meta != null) {
            List<String> lore = new ArrayList<>();
            lore.add("&7Amount: &f" + h.amount + " &8(you have " + inInv + ")");
            lore.add(buy < 0 ? "&7Total buy:  &cn/a" : "&7Total buy:  &a" + Util.money(buy * h.amount));
            lore.add(sell < 0 ? "&7Total sell: &cn/a" : "&7Total sell: &e" + Util.money(sell * Math.min(h.amount, Math.max(inInv, 0))));
            meta.setLore(Util.c(lore));
            center.setItemMeta(meta);
        }
        inv.setItem(13, center);
        inv.setItem(14, Util.icon(Material.LIME_STAINED_GLASS_PANE, "&a+1"));
        inv.setItem(15, Util.icon(Material.LIME_STAINED_GLASS_PANE, "&a+10"));
        inv.setItem(16, Util.icon(Material.LIME_STAINED_GLASS_PANE, "&a+64"));
        inv.setItem(20, Util.icon(Material.EMERALD_BLOCK, "&a&lBUY " + h.amount, buy < 0 ? "&cNot for sale" : "&7Cost: &6" + Util.money(buy * h.amount)));
        inv.setItem(22, Util.icon(Material.OAK_DOOR, "&e« Back"));
        inv.setItem(24, Util.icon(Material.REDSTONE_BLOCK, "&c&lSELL " + Math.min(h.amount, inInv) + (h.amount > inInv ? " &7(all you have)" : ""),
                sell < 0 ? "&cNot accepted" : "&7Earn: &6" + Util.money(sell * Math.min(h.amount, inInv))));
        inv.setItem(18, Util.icon(Material.HOPPER, "&7Reset to &f1"));
        inv.setItem(26, Util.icon(Material.CHEST, "&7Set to &fall in inventory", "&7(" + inInv + " items)"));
    }

    // ================================================================= SELL GUI

    public void openSellGui(Player p) {
        if (!p.hasPermission("omnishop.sell")) { Util.send(p, "no-permission"); return; }
        Holder h = new Holder();
        h.type = Type.SELL;
        h.inv = Bukkit.createInventory(h, 54, Util.c("&8» &a&lSell Items &8- &7put items in, then close"));
        for (int i = 45; i < 54; i++) h.inv.setItem(i, Util.pane(Material.BLACK_STAINED_GLASS_PANE));
        updateSellButton(p, h);
        p.openInventory(h.inv);
        Util.play(p, "open");
    }

    private void updateSellButton(Player p, Holder h) {
        ItemStack[] stacks = new ItemStack[45];
        for (int i = 0; i < 45; i++) stacks[i] = h.inv.getItem(i);
        ShopManager.Sale s = sm().evaluate(p, stacks, null, -1);
        h.inv.setItem(49, Util.icon(Material.EMERALD, "&a&lSELL NOW &7(or just close)",
                "&7Items accepted: &f" + s.items, "&7You will receive: &6" + Util.money(s.money),
                s.special ? "&d★ Includes daily special bonus!" : "&8Unsellable items are returned.", "", "&eClick to sell"));
        h.inv.setItem(45, Util.icon(Material.BARRIER, "&cCancel", "&7Return items & close"));
    }

    // ================================================================= EVENTS

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        InventoryHolder ih = e.getInventory().getHolder();
        if (!(ih instanceof Holder)) return;
        Holder h = (Holder) ih;
        if (!(e.getWhoClicked() instanceof Player)) return;
        Player p = (Player) e.getWhoClicked();
        boolean top = e.getClickedInventory() != null && e.getClickedInventory().equals(e.getView().getTopInventory());

        if (h.type == Type.SELL) {
            if (top && e.getSlot() >= 45) {
                e.setCancelled(true);
                if (e.getSlot() == 49) { p.closeInventory(); }
                else if (e.getSlot() == 45) { h.target = Material.BARRIER; p.closeInventory(); } // cancel flag
                return;
            }
            if (e.getClick() == ClickType.DOUBLE_CLICK || e.getAction() == InventoryAction.COLLECT_TO_CURSOR) { e.setCancelled(true); return; }
            Bukkit.getScheduler().runTask(plugin, () -> updateSellButton(p, h));
            return;
        }

        e.setCancelled(true);
        if (!top) return;
        int slot = e.getSlot();

        switch (h.type) {
            case MAIN: clickMain(p, h, slot); break;
            case LIST: clickList(p, h, slot, e.getClick()); break;
            case SPECIALS: clickSpecials(p, h, slot, e.getClick()); break;
            case AMOUNT: clickAmount(p, h, slot); break;
            default: break;
        }
    }

    private void clickMain(Player p, Holder h, int slot) {
        for (ShopCategory c : ShopCategory.values()) {
            if (c.slot == slot) { Util.play(p, "click"); openCategory(p, c, 0); return; }
        }
        switch (slot) {
            case 4: openSpecials(p); break;
            case 45: Util.play(p, "click"); plugin.warpGui().openBrowser(p); break;
            case 47: openSellGui(p); break;
            case 48: sm().sellInventory(p, null, -1); renderMain(p, h); break;
            case 50: Util.play(p, "click"); p.closeInventory(); ShopCommands.sendMarket(p, plugin); break;
            case 53: Util.play(p, "click"); p.closeInventory(); break;
            default: break;
        }
    }

    private void clickList(Player p, Holder h, int slot, ClickType click) {
        if (slot < PER_PAGE) {
            int idx = h.page * PER_PAGE + slot;
            if (idx >= h.items.size()) return;
            Material m = h.items.get(idx);
            switch (click) {
                case LEFT: sm().buy(p, m, 1); break;
                case SHIFT_LEFT: sm().buy(p, m, 64); break;
                case RIGHT: sm().sellInventory(p, m, 1); break;
                case SHIFT_RIGHT: sm().sellInventory(p, m, -1); break;
                case MIDDLE: case DROP: case CONTROL_DROP: case SWAP_OFFHAND: openAmount(p, m, h); return;
                default: return;
            }
            renderList(p, h);
            return;
        }
        if (slot == 45 && h.page > 0) { h.page--; Util.play(p, "page"); renderList(p, h); }
        else if (slot == 53) { h.page++; Util.play(p, "page"); renderList(p, h); }
        else if (slot == 47) { Util.play(p, "click"); openMain(p); }
        else if (slot == 51) openSpecials(p);
    }

    private void clickSpecials(Player p, Holder h, int slot, ClickType click) {
        if (slot == 27) { Util.play(p, "click"); openMain(p); return; }
        if (slot == 35) { Util.play(p, "click"); p.closeInventory(); return; }
        Material m = specialAt(h, slot);
        if (m == null) return;
        switch (click) {
            case LEFT: sm().buy(p, m, 1); break;
            case SHIFT_LEFT: sm().buy(p, m, 64); break;
            case RIGHT: sm().sellInventory(p, m, 1); break;
            case SHIFT_RIGHT: sm().sellInventory(p, m, -1); break;
            case MIDDLE: case DROP: openAmount(p, m, h); return;
            default: return;
        }
        renderSpecials(p, h);
    }

    private void clickAmount(Player p, Holder h, int slot) {
        Material m = h.target;
        int inInv = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) if (s != null && s.getType() == m && sm().plain(s)) inInv += s.getAmount();
        switch (slot) {
            case 10: h.amount -= 64; break;
            case 11: h.amount -= 10; break;
            case 12: h.amount -= 1; break;
            case 14: h.amount += 1; break;
            case 15: h.amount += 10; break;
            case 16: h.amount += 64; break;
            case 18: h.amount = 1; break;
            case 26: h.amount = Math.max(1, inInv); break;
            case 20: sm().buy(p, m, h.amount); break;
            case 24: sm().sellInventory(p, m, Math.min(h.amount, Math.max(inInv, 0)) == 0 ? 1 : Math.min(h.amount, inInv)); break;
            case 22:
                Util.play(p, "click");
                if (h.back == null) openMain(p);
                else if (h.back.type == Type.SPECIALS) openSpecials(p);
                else openList(p, h.back);
                return;
            default: return;
        }
        h.amount = Math.max(1, Math.min(2304, h.amount));
        if (slot != 20 && slot != 24) Util.play(p, "click");
        renderAmount(p, h);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        InventoryHolder ih = e.getInventory().getHolder();
        if (!(ih instanceof Holder)) return;
        Holder h = (Holder) ih;
        for (int raw : e.getRawSlots()) {
            if (raw < e.getInventory().getSize() && (h.type != Type.SELL || raw >= 45)) { e.setCancelled(true); return; }
        }
        if (h.type == Type.SELL && e.getWhoClicked() instanceof Player) {
            Player p = (Player) e.getWhoClicked();
            Bukkit.getScheduler().runTask(plugin, () -> updateSellButton(p, h));
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        InventoryHolder ih = e.getInventory().getHolder();
        if (!(ih instanceof Holder)) return;
        Holder h = (Holder) ih;
        if (h.type != Type.SELL || !(e.getPlayer() instanceof Player)) return;
        Player p = (Player) e.getPlayer();
        ItemStack[] stacks = new ItemStack[45];
        for (int i = 0; i < 45; i++) stacks[i] = h.inv.getItem(i);
        h.inv.clear();
        boolean cancelled = h.target == Material.BARRIER;
        if (!cancelled) {
            ShopManager.Sale sale = sm().evaluate(p, stacks, null, -1);
            if (sale.items > 0) sm().remove(stacks, sale);
            sm().pay(p, sale, true);
        }
        for (ItemStack s : stacks) {
            if (s == null || s.getType() == Material.AIR) continue;
            Map<Integer, ItemStack> over = p.getInventory().addItem(s);
            for (ItemStack o : over.values()) p.getWorld().dropItemNaturally(p.getLocation(), o);
        }
    }
}
