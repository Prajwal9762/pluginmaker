package com.omnishop;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Material;
import org.bukkit.block.Container;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.BundleMeta;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.permissions.PermissionAttachmentInfo;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.*;

/** All buying / selling logic. GUI code lives in ShopGui. */
public class ShopManager {

    /** Result of evaluating a sale (nothing has been removed yet). */
    public static class Sale {
        public int[] taken;
        public int items;
        public double money;
        public boolean special;
        public boolean limited;
        public final Map<Material, Integer> counts = new EnumMap<>(Material.class);
        public final Map<Material, Double> earned = new EnumMap<>(Material.class);
        public final Map<Material, Integer> specialCounts = new EnumMap<>(Material.class);
    }

    private final OmniShop plugin;
    private final File limitFile;
    private final Map<UUID, int[]> limits = new HashMap<>(); // uuid -> {dayOfYearKey, count}
    private final Map<ShopCategory, List<Material>> index = new EnumMap<>(ShopCategory.class);

    public ShopManager(OmniShop plugin) {
        this.plugin = plugin;
        this.limitFile = new File(plugin.getDataFolder(), "limits.yml");
        loadLimits();
    }

    // ------------------------------------------------------------------ index

    public void reindex() {
        index.clear();
        for (ShopCategory c : ShopCategory.values()) index.put(c, new ArrayList<>());
        for (Material m : plugin.prices().all()) index.get(ShopCategory.of(m)).add(m);
        for (List<Material> l : index.values()) l.sort(Comparator.comparing(Material::name));
    }

    public List<Material> items(ShopCategory c) { return index.getOrDefault(c, Collections.emptyList()); }

    public List<Material> search(String q) {
        String needle = q.toLowerCase(Locale.ROOT).replace(' ', '_');
        List<Material> out = new ArrayList<>();
        for (Material m : plugin.prices().all()) if (m.name().toLowerCase(Locale.ROOT).contains(needle)) out.add(m);
        out.sort(Comparator.comparing(Material::name));
        return out;
    }

    // ------------------------------------------------------------------ prices

    private double rawBuy(Material m) {
        PriceBook pb = plugin.prices();
        if (!pb.canBuy(m)) return -1;
        double p = pb.baseBuy(m) * pb.mult(m);
        SpecialsManager.Deal d = plugin.specials().get(m);
        if (d != null) p *= d.buyMult;
        return p;
    }

    /** Current price to BUY one item, or -1 if not for sale. */
    public double buyPrice(Material m) {
        double p = rawBuy(m);
        return p < 0 ? -1 : Math.max(0.01, Util.round(p));
    }

    /** Current price the shop PAYS for one item (includes specials + permission boost), or -1. */
    public double sellPrice(Material m, Player pl) {
        return sellPrice(m, pl, true);
    }

    public double sellPrice(Material m, Player pl, boolean withSpecial) {
        PriceBook pb = plugin.prices();
        if (!pb.canSell(m)) return -1;
        double p = pb.baseSell(m) * pb.mult(m);
        if (withSpecial) {
            SpecialsManager.Deal d = plugin.specials().get(m);
            if (d != null) p *= d.sellMult;
        }
        if (pl != null) p *= boost(pl);
        // anti-exploit: never pay more than a fraction of the buy price
        if (pb.canBuy(m)) {
            double buy = pb.baseBuy(m) * pb.mult(m);
            if (withSpecial) {
                SpecialsManager.Deal d = plugin.specials().get(m);
                if (d != null) buy *= d.buyMult;
            }
            double ratio = plugin.getConfig().getDouble("pricing.max-sell-to-buy-ratio", 0.9);
            p = Math.min(p, buy * ratio);
        }
        return Math.max(0.01, Util.round(p));
    }

    public double boost(Player p) {
        if (!plugin.getConfig().getBoolean("sell.boosts-enabled", true)) return 1.0;
        int best = 0;
        for (PermissionAttachmentInfo i : p.getEffectivePermissions()) {
            String perm = i.getPermission();
            if (i.getValue() && perm.startsWith("omnishop.boost.")) {
                try { best = Math.max(best, Integer.parseInt(perm.substring("omnishop.boost.".length()))); }
                catch (NumberFormatException ignored) { }
            }
        }
        return 1.0 + best / 100.0;
    }

    // ------------------------------------------------------------------ buying

    public int freeSpace(Player p, Material m) {
        int space = 0;
        ItemStack probe = new ItemStack(m);
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s == null || s.getType() == Material.AIR) space += m.getMaxStackSize();
            else if (s.isSimilar(probe)) space += Math.max(0, m.getMaxStackSize() - s.getAmount());
        }
        return space;
    }

    public boolean buy(Player p, Material m, int amount) {
        if (!p.hasPermission("omnishop.buy")) { Util.send(p, "no-permission"); Util.play(p, "error"); return false; }
        double unit = buyPrice(m);
        if (unit < 0) { Util.send(p, "not-for-sale", "item", Util.pretty(m)); Util.play(p, "error"); return false; }
        Economy eco = plugin.eco();
        int space = freeSpace(p, m);
        if (space <= 0) { Util.send(p, "inv-full"); Util.play(p, "error"); return false; }
        amount = Math.min(amount, space);
        double cost = Util.round(unit * amount);
        if (!eco.has(p, cost)) {
            int afford = (int) Math.floor(eco.getBalance(p) / unit);
            if (afford <= 0) { Util.send(p, "no-money", "cost", Util.money(unit)); Util.play(p, "error"); return false; }
            amount = Math.min(amount, afford);
            cost = Util.round(unit * amount);
        }
        EconomyResponse r = eco.withdrawPlayer(p, cost);
        if (!r.transactionSuccess()) { Util.send(p, "no-money", "cost", Util.money(cost)); Util.play(p, "error"); return false; }
        int left = amount;
        while (left > 0) {
            int n = Math.min(left, m.getMaxStackSize());
            Map<Integer, ItemStack> over = p.getInventory().addItem(new ItemStack(m, n));
            if (!over.isEmpty()) { // should not happen, refund what did not fit
                int notGiven = 0;
                for (ItemStack o : over.values()) notGiven += o.getAmount();
                eco.depositPlayer(p, Util.round(unit * notGiven));
                amount -= notGiven;
                cost = Util.round(unit * amount);
                break;
            }
            left -= n;
        }
        plugin.prices().impact(m, amount, true);
        Util.send(p, "bought", "amount", String.valueOf(amount), "item", Util.pretty(m), "cost", Util.money(cost));
        Util.play(p, plugin.specials().get(m) != null ? "special" : "buy");
        return true;
    }

    // ------------------------------------------------------------------ selling

    /** Items with custom names/lore/enchants or containers with contents are never auto-sold. */
    public boolean plain(ItemStack s) {
        if (s == null || !s.hasItemMeta()) return true;
        ItemMeta meta = s.getItemMeta();
        if (meta == null) return true;
        if (meta.hasDisplayName() || meta.hasLore() || meta.hasEnchants()) return false;
        if (meta instanceof BundleMeta && ((BundleMeta) meta).hasItems()) return false;
        if (meta instanceof BlockStateMeta) {
            BlockStateMeta bsm = (BlockStateMeta) meta;
            if (bsm.hasBlockState() && bsm.getBlockState() instanceof Container) {
                Container c = (Container) bsm.getBlockState();
                for (ItemStack i : c.getInventory().getContents()) if (i != null) return false;
            }
        }
        return true;
    }

    private double durabilityFactor(ItemStack s) {
        if (!plugin.getConfig().getBoolean("sell.scale-by-durability", true)) return 1.0;
        if (s.getType().getMaxDurability() <= 0 || !s.hasItemMeta()) return 1.0;
        ItemMeta meta = s.getItemMeta();
        if (meta instanceof Damageable && ((Damageable) meta).hasDamage()) {
            double f = 1.0 - ((Damageable) meta).getDamage() / (double) s.getType().getMaxDurability();
            return Math.max(0.1, f);
        }
        return 1.0;
    }

    /**
     * Works out what would be paid for the given stacks without touching them.
     * @param only restrict to one material (or null for everything)
     * @param max  maximum items to sell (-1 = no limit)
     */
    public Sale evaluate(Player p, ItemStack[] stacks, Material only, int max) {
        Sale sale = new Sale();
        sale.taken = new int[stacks.length];
        int cap = max < 0 ? Integer.MAX_VALUE : max;
        int allowance = dailyAllowance(p);
        if (allowance <= 0) { sale.limited = true; return sale; }
        Map<Material, Double> normal = new EnumMap<>(Material.class);
        Map<Material, Double> special = new EnumMap<>(Material.class);
        Map<Material, Integer> specialLeft = new EnumMap<>(Material.class);

        for (int i = 0; i < stacks.length; i++) {
            ItemStack s = stacks[i];
            if (s == null || s.getType() == Material.AIR) continue;
            Material m = s.getType();
            if (only != null && m != only) continue;
            if (!plugin.prices().canSell(m) || !plugin.shop().plain(s)) continue;
            int room = Math.min(cap - sale.items, allowance - sale.items);
            if (room <= 0) { if (allowance - sale.items <= 0) sale.limited = true; break; }
            int take = Math.min(s.getAmount(), room);
            double fac = durabilityFactor(s);
            double un = normal.computeIfAbsent(m, k -> sellPrice(k, p, false));
            SpecialsManager.Deal deal = plugin.specials().get(m);
            double total;
            int spec = 0;
            if (deal != null) {
                double sp = special.computeIfAbsent(m, k -> sellPrice(k, p, true));
                int left = specialLeft.computeIfAbsent(m, k -> plugin.specials().allowance(p.getUniqueId(), k));
                spec = Math.min(take, left);
                specialLeft.put(m, left - spec);
                total = (spec * sp + (take - spec) * un) * fac;
            } else {
                total = take * un * fac;
            }
            sale.taken[i] = take;
            sale.items += take;
            sale.money += total;
            sale.counts.merge(m, take, Integer::sum);
            sale.earned.merge(m, total, Double::sum);
            if (spec > 0) { sale.special = true; sale.specialCounts.merge(m, spec, Integer::sum); }
        }
        sale.money = Util.round(sale.money);
        return sale;
    }

    /** Applies the result of {@link #evaluate} to the given array (removes the sold items). */
    public void remove(ItemStack[] stacks, Sale sale) {
        for (int i = 0; i < stacks.length; i++) {
            if (sale.taken[i] <= 0 || stacks[i] == null) continue;
            if (sale.taken[i] >= stacks[i].getAmount()) stacks[i] = null;
            else stacks[i].setAmount(stacks[i].getAmount() - sale.taken[i]);
        }
    }

    /** Pays the player and records market / limit / special statistics. */
    public void pay(Player p, Sale sale, boolean showBreakdown) {
        if (sale.items <= 0) {
            if (sale.limited) Util.send(p, "daily-limit", "limit", String.valueOf(plugin.getConfig().getInt("sell.daily-limit", 0)));
            else Util.send(p, "nothing-to-sell");
            Util.play(p, "error");
            return;
        }
        plugin.eco().depositPlayer(p, sale.money);
        for (Map.Entry<Material, Integer> e : sale.counts.entrySet()) plugin.prices().impact(e.getKey(), e.getValue(), false);
        for (Map.Entry<Material, Integer> e : sale.specialCounts.entrySet()) plugin.specials().addSold(p.getUniqueId(), e.getKey(), e.getValue());
        addSoldToday(p, sale.items);
        Util.send(p, "sold", "amount", String.valueOf(sale.items), "cost", Util.money(sale.money),
                "note", sale.special ? Util.msg("sold-special") : "");
        if (showBreakdown && sale.counts.size() > 1) {
            List<Map.Entry<Material, Double>> list = new ArrayList<>(sale.earned.entrySet());
            list.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
            int shown = 0;
            for (Map.Entry<Material, Double> e : list) {
                if (shown++ >= 6) break;
                Util.raw(p, "sold-line", "amount", String.valueOf(sale.counts.get(e.getKey())),
                        "item", Util.pretty(e.getKey()), "cost", Util.money(e.getValue()));
            }
        }
        Util.play(p, sale.special ? "special" : "sell");
    }

    /** Sell from the player's main inventory. */
    public Sale sellInventory(Player p, Material only, int max) {
        if (!p.hasPermission("omnishop.sell")) { Util.send(p, "no-permission"); Util.play(p, "error"); return null; }
        ItemStack[] c = p.getInventory().getStorageContents();
        Sale sale = evaluate(p, c, only, max);
        if (sale.items > 0) {
            remove(c, sale);
            p.getInventory().setStorageContents(c);
        }
        pay(p, sale, only == null);
        return sale;
    }

    public void sellHand(Player p, boolean all) {
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand == null || hand.getType() == Material.AIR) { Util.send(p, "nothing-to-sell"); Util.play(p, "error"); return; }
        if (all) { sellInventory(p, hand.getType(), -1); return; }
        if (!p.hasPermission("omnishop.sell")) { Util.send(p, "no-permission"); return; }
        ItemStack[] one = new ItemStack[]{hand.clone()};
        Sale sale = evaluate(p, one, null, -1);
        if (sale.items > 0) {
            remove(one, sale);
            p.getInventory().setItemInMainHand(one[0]);
        }
        pay(p, sale, false);
    }

    // ------------------------------------------------------------------ daily limit

    private int today() {
        LocalDate d = LocalDate.now();
        return d.getYear() * 1000 + d.getDayOfYear();
    }

    public int dailyAllowance(Player p) {
        int limit = plugin.getConfig().getInt("sell.daily-limit", 0);
        if (limit <= 0 || p.hasPermission("omnishop.limit.bypass")) return Integer.MAX_VALUE;
        int[] e = limits.get(p.getUniqueId());
        if (e == null || e[0] != today()) return limit;
        return Math.max(0, limit - e[1]);
    }

    private void addSoldToday(Player p, int n) {
        int[] e = limits.get(p.getUniqueId());
        if (e == null || e[0] != today()) { e = new int[]{today(), 0}; limits.put(p.getUniqueId(), e); }
        e[1] += n;
    }

    private void loadLimits() {
        if (!limitFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(limitFile);
        for (String k : y.getKeys(false)) {
            try { limits.put(UUID.fromString(k), new int[]{y.getInt(k + ".day"), y.getInt(k + ".count")}); }
            catch (IllegalArgumentException ignored) { }
        }
    }

    public void saveLimits() {
        YamlConfiguration y = new YamlConfiguration();
        int t = today();
        for (Map.Entry<UUID, int[]> e : limits.entrySet()) {
            if (e.getValue()[0] != t) continue;
            y.set(e.getKey() + ".day", e.getValue()[0]);
            y.set(e.getKey() + ".count", e.getValue()[1]);
        }
        try { y.save(limitFile); } catch (IOException ex) { plugin.getLogger().warning("limits.yml: " + ex.getMessage()); }
    }
}
