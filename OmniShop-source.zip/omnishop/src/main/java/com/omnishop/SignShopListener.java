package com.omnishop;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Locale;

/** Admin sign shops:  [Shop] / amount / ITEM / buy|sell. Right-click to trade at the live shop price. */
public class SignShopListener implements Listener {

    private final OmniShop plugin;

    public SignShopListener(OmniShop plugin) { this.plugin = plugin; }

    private String header() { return plugin.getConfig().getString("signs.header", "[Shop]"); }

    @SuppressWarnings("deprecation")
    @EventHandler
    public void onCreate(SignChangeEvent e) {
        if (!e.getLine(0).equalsIgnoreCase(header())) return;
        Player p = e.getPlayer();
        if (!p.hasPermission("omnishop.sign.create")) { Util.send(p, "no-permission"); e.setCancelled(true); return; }
        int amount;
        Material m;
        try {
            amount = Math.max(1, Math.min(2304, Integer.parseInt(e.getLine(1).trim())));
            m = Material.matchMaterial(e.getLine(2).trim().toUpperCase(Locale.ROOT).replace(' ', '_'));
        } catch (NumberFormatException ex) { Util.send(p, "sign-bad"); e.setCancelled(true); return; }
        String mode = e.getLine(3).trim().toLowerCase(Locale.ROOT);
        if (m == null || !plugin.prices().has(m) || !(mode.equals("buy") || mode.equals("sell") || mode.isEmpty())) {
            Util.send(p, "sign-bad"); e.setCancelled(true); return;
        }
        if (mode.isEmpty()) mode = "buy";
        e.setLine(0, ChatColor.DARK_BLUE + "" + ChatColor.BOLD + header());
        e.setLine(1, ChatColor.BLACK + "" + amount + "x");
        e.setLine(2, ChatColor.DARK_GREEN + Util.pretty(m));
        e.setLine(3, (mode.equals("buy") ? ChatColor.GREEN + "BUY" : ChatColor.RED + "SELL"));
        Util.send(p, "sign-created");
        Util.play(p, "success");
    }

    @SuppressWarnings("deprecation")
    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null) return;
        Block b = e.getClickedBlock();
        if (!(b.getState() instanceof Sign)) return;
        Sign sign = (Sign) b.getState();
        String l0 = ChatColor.stripColor(sign.getLine(0));
        if (!l0.equalsIgnoreCase(header())) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        if (!p.hasPermission("omnishop.sign.use")) { Util.send(p, "no-permission"); return; }
        try {
            int amount = Integer.parseInt(ChatColor.stripColor(sign.getLine(1)).replace("x", "").trim());
            Material m = Material.matchMaterial(ChatColor.stripColor(sign.getLine(2)).trim().toUpperCase(Locale.ROOT).replace(' ', '_'));
            if (m == null) return;
            boolean buy = ChatColor.stripColor(sign.getLine(3)).equalsIgnoreCase("BUY");
            if (buy) plugin.shop().buy(p, m, amount);
            else plugin.shop().sellInventory(p, m, amount);
        } catch (NumberFormatException ignored) { }
    }
}
