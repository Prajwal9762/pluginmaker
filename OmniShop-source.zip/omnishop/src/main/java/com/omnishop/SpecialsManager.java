package com.omnishop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Rotating Daily Specials: a handful of items become cheap to BUY and pay extra when you SELL.
 * A new set is picked every rotation (config: specials.interval-hours); items from the previous
 * rotation are skipped so the selection keeps changing.
 */
public class SpecialsManager {

    public static class Deal {
        public Material material;
        public double buyMult = 1.0;   // price multiplier when buying  (e.g. 0.6 = 40% off)
        public double sellMult = 1.0;  // price multiplier when selling (e.g. 2.0 = +100%)
        public boolean jackpot;

        public int discountPercent() { return (int) Math.round((1 - buyMult) * 100); }
        public int bonusPercent() { return (int) Math.round((sellMult - 1) * 100); }
    }

    private final OmniShop plugin;
    private final File file;
    private final Map<Material, Deal> deals = new LinkedHashMap<>();
    private final Set<Material> last = new HashSet<>();
    private final Map<UUID, Map<Material, Integer>> sold = new HashMap<>();
    private long endsAt = 0;

    public SpecialsManager(OmniShop plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "specials.yml");
    }

    // ---------------------------------------------------------------- persistence

    public void load() {
        deals.clear();
        sold.clear();
        last.clear();
        if (file.exists()) {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
            endsAt = y.getLong("ends-at", 0);
            for (String s : y.getStringList("last")) {
                Material m = Material.matchMaterial(s);
                if (m != null) last.add(m);
            }
            ConfigurationSection ds = y.getConfigurationSection("deals");
            if (ds != null) {
                for (String k : ds.getKeys(false)) {
                    Material m = Material.matchMaterial(k);
                    if (m == null) continue;
                    Deal d = new Deal();
                    d.material = m;
                    d.buyMult = ds.getDouble(k + ".buy", 1);
                    d.sellMult = ds.getDouble(k + ".sell", 1);
                    d.jackpot = ds.getBoolean(k + ".jackpot", false);
                    deals.put(m, d);
                }
            }
            ConfigurationSection ss = y.getConfigurationSection("sold");
            if (ss != null) {
                for (String u : ss.getKeys(false)) {
                    try {
                        UUID id = UUID.fromString(u);
                        Map<Material, Integer> mm = new EnumMap<>(Material.class);
                        ConfigurationSection inner = ss.getConfigurationSection(u);
                        if (inner != null) for (String mk : inner.getKeys(false)) {
                            Material m = Material.matchMaterial(mk);
                            if (m != null) mm.put(m, inner.getInt(mk));
                        }
                        sold.put(id, mm);
                    } catch (IllegalArgumentException ignored) { }
                }
            }
        }
        if (enabled() && (deals.isEmpty() || System.currentTimeMillis() >= endsAt)) rotate(false);
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("ends-at", endsAt);
        List<String> l = new ArrayList<>();
        for (Material m : last) l.add(m.name());
        y.set("last", l);
        for (Deal d : deals.values()) {
            String p = "deals." + d.material.name();
            y.set(p + ".buy", d.buyMult);
            y.set(p + ".sell", d.sellMult);
            y.set(p + ".jackpot", d.jackpot);
        }
        for (Map.Entry<UUID, Map<Material, Integer>> e : sold.entrySet()) {
            for (Map.Entry<Material, Integer> i : e.getValue().entrySet()) {
                y.set("sold." + e.getKey() + "." + i.getKey().name(), i.getValue());
            }
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save specials.yml: " + ex.getMessage());
        }
    }

    // ---------------------------------------------------------------- rotation

    public boolean enabled() { return plugin.getConfig().getBoolean("specials.enabled", true); }

    public void checkRotation() {
        if (enabled() && System.currentTimeMillis() >= endsAt) rotate(true);
    }

    private double between(double min, double max) {
        return min + ThreadLocalRandom.current().nextDouble() * Math.max(0, max - min);
    }

    public void rotate(boolean announce) {
        PriceBook pb = plugin.prices();
        double minValue = plugin.getConfig().getDouble("specials.min-item-value", 3.0);
        int count = Math.max(1, plugin.getConfig().getInt("specials.count", 9));
        double dMin = plugin.getConfig().getDouble("specials.buy-discount.min", 25);
        double dMax = plugin.getConfig().getDouble("specials.buy-discount.max", 55);
        double bMin = plugin.getConfig().getDouble("specials.sell-bonus.min", 40);
        double bMax = plugin.getConfig().getDouble("specials.sell-bonus.max", 120);
        double jDisc = plugin.getConfig().getDouble("specials.jackpot-buy-discount", 70);
        double jBonus = plugin.getConfig().getDouble("specials.jackpot-sell-bonus", 200);
        double hours = plugin.getConfig().getDouble("specials.interval-hours", 24);

        List<Material> pool = new ArrayList<>();
        for (Material m : pb.all()) {
            if (!pb.canBuy(m) || !pb.canSell(m)) continue;
            if (pb.baseBuy(m) < minValue) continue;
            if (ShopCategory.of(m) == ShopCategory.SPAWN_EGGS) continue;
            if (last.contains(m)) continue;
            pool.add(m);
        }
        Collections.shuffle(pool);

        // at most 2 per category first so the list is varied, then fill up
        Map<ShopCategory, Integer> perCat = new EnumMap<>(ShopCategory.class);
        List<Material> picked = new ArrayList<>();
        for (Material m : pool) {
            if (picked.size() >= count) break;
            ShopCategory c = ShopCategory.of(m);
            int n = perCat.getOrDefault(c, 0);
            if (n >= 2) continue;
            perCat.put(c, n + 1);
            picked.add(m);
        }
        for (Material m : pool) {
            if (picked.size() >= count) break;
            if (!picked.contains(m)) picked.add(m);
        }

        deals.clear();
        sold.clear();
        last.clear();
        boolean first = true;
        for (Material m : picked) {
            Deal d = new Deal();
            d.material = m;
            d.jackpot = first;
            double disc = first ? jDisc : between(dMin, dMax);
            double bonus = first ? jBonus : between(bMin, bMax);
            d.buyMult = Math.max(0.05, 1 - disc / 100.0);
            d.sellMult = 1 + bonus / 100.0;
            deals.put(m, d);
            last.add(m);
            first = false;
        }
        endsAt = System.currentTimeMillis() + (long) (hours * 3600_000L);
        save();

        if (announce && plugin.getConfig().getBoolean("specials.broadcast", true)) {
            Bukkit.broadcastMessage(Util.c(plugin.getConfig().getString("prefix", "")) + Util.msg("special-new"));
            for (Player p : Bukkit.getOnlinePlayers()) Util.play(p, "rotate");
        }
    }

    // ---------------------------------------------------------------- queries

    public Deal get(Material m) { return enabled() ? deals.get(m) : null; }
    public Collection<Deal> deals() { return enabled() ? deals.values() : Collections.emptyList(); }
    public long remainingMillis() { return Math.max(0, endsAt - System.currentTimeMillis()); }

    /** How many more items this player may sell at the bonus price in this rotation. */
    public int allowance(UUID id, Material m) {
        int limit = plugin.getConfig().getInt("specials.per-player-sell-limit", 512);
        if (limit <= 0) return Integer.MAX_VALUE;
        return Math.max(0, limit - sold.getOrDefault(id, Collections.emptyMap()).getOrDefault(m, 0));
    }

    public void addSold(UUID id, Material m, int amount) {
        sold.computeIfAbsent(id, k -> new EnumMap<>(Material.class)).merge(m, amount, Integer::sum);
    }
}
