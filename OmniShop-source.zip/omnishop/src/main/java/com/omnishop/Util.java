package com.omnishop;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public final class Util {
    private Util() {}

    public static String c(String s) {
        return s == null ? "" : ChatColor.translateAlternateColorCodes('&', s);
    }

    public static List<String> c(List<String> in) {
        List<String> out = new ArrayList<>(in.size());
        for (String s : in) out.add(c(s));
        return out;
    }

    public static String pretty(Material m) {
        String[] parts = m.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
        }
        return sb.toString();
    }

    public static double round(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    public static String money(double d) {
        String fmt = OmniShop.get().getConfig().getString("currency-format", "$%,.2f");
        try {
            return String.format(Locale.US, fmt, d);
        } catch (Exception e) {
            return String.format(Locale.US, "$%,.2f", d);
        }
    }

    public static String msg(String key, String... kv) {
        String t = OmniShop.get().getConfig().getString("messages." + key, "&c[missing message: " + key + "]");
        for (int i = 0; i + 1 < kv.length; i += 2) t = t.replace("{" + kv[i] + "}", kv[i + 1]);
        return c(t);
    }

    public static void send(CommandSender s, String key, String... kv) {
        s.sendMessage(c(OmniShop.get().getConfig().getString("prefix", "")) + msg(key, kv));
    }

    public static void raw(CommandSender s, String key, String... kv) {
        s.sendMessage(msg(key, kv));
    }

    public static ItemStack icon(Material m, String name, String... lore) {
        return icon(m, name, Arrays.asList(lore));
    }

    public static ItemStack icon(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(c(name));
            if (lore != null && !lore.isEmpty()) meta.setLore(c(lore));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            it.setItemMeta(meta);
        }
        return it;
    }

    public static ItemStack pane(Material m) {
        return icon(m, "&r ");
    }

    public static void play(Player p, String key) {
        if (p == null) return;
        ConfigurationSection root = OmniShop.get().getConfig().getConfigurationSection("sounds");
        if (root == null || !root.getBoolean("enabled", true)) return;
        ConfigurationSection s = root.getConfigurationSection(key);
        if (s == null) return;
        String name = s.getString("name");
        if (name == null || name.isEmpty()) return;
        p.playSound(p.getLocation(), name, (float) s.getDouble("volume", 1.0), (float) s.getDouble("pitch", 1.0));
    }

    public static String duration(long ms) {
        long s = Math.max(0, ms / 1000);
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        if (h > 0) return h + "h " + m + "m";
        if (m > 0) return m + "m " + sec + "s";
        return sec + "s";
    }

    public static String stars(double rating) {
        int full = (int) Math.round(rating);
        StringBuilder sb = new StringBuilder("&e");
        for (int i = 0; i < 5; i++) {
            if (i == full) sb.append("&8");
            sb.append("★");
        }
        return sb.toString();
    }
}
