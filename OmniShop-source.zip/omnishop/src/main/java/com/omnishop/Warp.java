package com.omnishop;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class Warp {
    public String name;
    public UUID owner;
    public String ownerName;
    public String world;
    public double x, y, z;
    public float yaw, pitch;
    public Material icon = Material.ENDER_PEARL;
    public String description = "&7No description set.";
    public WarpCategory category = WarpCategory.GENERAL;
    public boolean open = true;
    public double fee = 0;
    public int visits = 0;
    public long created = System.currentTimeMillis();
    public final Map<UUID, Integer> ratings = new HashMap<>();
    public final Set<UUID> banned = new HashSet<>();

    public Location location() {
        World w = Bukkit.getWorld(world);
        return w == null ? null : new Location(w, x, y, z, yaw, pitch);
    }

    public void setLocation(Location l) {
        world = l.getWorld().getName();
        x = l.getX();
        y = l.getY();
        z = l.getZ();
        yaw = l.getYaw();
        pitch = l.getPitch();
    }

    public double rating() {
        if (ratings.isEmpty()) return 0;
        double sum = 0;
        for (int r : ratings.values()) sum += r;
        return sum / ratings.size();
    }
}
