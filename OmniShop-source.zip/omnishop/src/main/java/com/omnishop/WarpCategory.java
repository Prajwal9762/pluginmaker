package com.omnishop;

import org.bukkit.Material;

public enum WarpCategory {
    GENERAL("General", Material.COMPASS),
    SHOP("Shops & Markets", Material.GOLD_INGOT),
    FARM("Farms", Material.WHEAT),
    BUILD("Builds & Art", Material.BRICKS),
    MINING("Mines", Material.DIAMOND_PICKAXE),
    PVP("PvP & Arenas", Material.IRON_SWORD),
    GAMES("Games & Parkour", Material.FIREWORK_ROCKET),
    HOME("Towns & Bases", Material.RED_BED);

    public final String display;
    public final Material icon;

    WarpCategory(String display, Material icon) {
        this.display = display;
        this.icon = icon;
    }

    public WarpCategory next() { return values()[(ordinal() + 1) % values().length]; }

    public static WarpCategory parse(String s) {
        for (WarpCategory c : values()) if (c.name().equalsIgnoreCase(s) || c.display.equalsIgnoreCase(s)) return c;
        return null;
    }
}
