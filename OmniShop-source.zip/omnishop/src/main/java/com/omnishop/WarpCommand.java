package com.omnishop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/** /pwarps ... (aliases /pwarp, /pw) */
public class WarpCommand implements CommandExecutor, TabCompleter {

    private final OmniShop plugin;

    public WarpCommand(OmniShop plugin) { this.plugin = plugin; }

    private WarpManager wm() { return plugin.warps(); }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] a) {
        if (!(sender instanceof Player)) { Util.send(sender, "player-only"); return true; }
        Player p = (Player) sender;
        if (!p.hasPermission("omnishop.pwarp.use")) { Util.send(p, "no-permission"); return true; }
        if (a.length == 0) { plugin.warpGui().openBrowser(p); return true; }

        String sub = a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "v": case "visit": case "tp": case "go": {
                if (a.length < 2) { p.sendMessage(Util.c("&cUsage: /pwarps v <name>")); return true; }
                Warp w = wm().get(a[1]);
                if (w == null) { Util.send(p, "pw-notfound", "name", a[1]); Util.play(p, "error"); return true; }
                wm().visit(p, w);
                return true;
            }
            case "set": case "create": case "add":
                if (a.length < 2) { p.sendMessage(Util.c("&cUsage: /pwarps set <name>")); return true; }
                wm().create(p, a[1]);
                return true;
            case "delete": case "del": case "remove": {
                Warp w = need(p, a, 2, "/pwarps delete <name>");
                if (w != null) wm().delete(p, w);
                return true;
            }
            case "list": case "my": case "mine":
                plugin.warpGui().openBrowser(p, p.getUniqueId(), null);
                return true;
            case "gui": case "menu": case "browse":
                plugin.warpGui().openBrowser(p);
                return true;
            case "search":
                if (a.length < 2) { p.sendMessage(Util.c("&cUsage: /pwarps search <text>")); return true; }
                plugin.warpGui().openBrowser(p, null, a[1]);
                return true;
            case "top": {
                List<Warp> l = new ArrayList<>(wm().all());
                l.removeIf(w -> !w.open);
                l.sort((x, y) -> Integer.compare(y.visits, x.visits));
                p.sendMessage(Util.c("&6&m      &r &e&lTop Player Warps &6&m      "));
                int n = 1;
                for (Warp w : l) {
                    if (n > 10) break;
                    p.sendMessage(Util.c(" &e#" + n++ + " &f" + w.name + " &7by " + w.ownerName + " &8- &f" + w.visits + " visits &8- " + Util.stars(w.rating())));
                }
                return true;
            }
            case "info": {
                Warp w = need(p, a, 2, "/pwarps info <name>");
                if (w == null) return true;
                p.sendMessage(Util.c("&6&m      &r &e&l" + w.name + " &6&m      "));
                p.sendMessage(Util.c("&7Owner: &f" + w.ownerName + " &8| &7Category: &f" + w.category.display));
                p.sendMessage(Util.c("&7Visits: &f" + w.visits + " &8| &7Rating: " + Util.stars(w.rating()) + " &8(" + w.ratings.size() + ")"));
                p.sendMessage(Util.c("&7Entry fee: &f" + (w.fee > 0 ? Util.money(w.fee) : "Free") + " &8| " + (w.open ? "&aPublic" : "&cPrivate")));
                p.sendMessage(Util.c(w.description));
                return true;
            }
            case "rate": {
                if (a.length < 3) { p.sendMessage(Util.c("&cUsage: /pwarps rate <name> <1-5>")); return true; }
                Warp w = wm().get(a[1]);
                if (w == null) { Util.send(p, "pw-notfound", "name", a[1]); return true; }
                try { wm().rate(p, w, Integer.parseInt(a[2])); }
                catch (NumberFormatException ex) { p.sendMessage(Util.c("&cRating must be 1-5.")); }
                return true;
            }
            case "rename": {
                Warp w = owned(p, a, 3, "/pwarps rename <old> <new>");
                if (w == null) return true;
                if (!wm().validName(a[2])) { Util.send(p, "pw-badname", "min", "3", "max", "16"); return true; }
                if (!wm().rename(w, a[2])) { Util.send(p, "pw-exists"); return true; }
                Util.send(p, "pw-updated"); Util.play(p, "success");
                return true;
            }
            case "seticon": case "icon": {
                Warp w = owned(p, a, 2, "/pwarps seticon <name> [material] (or hold an item)");
                if (w == null) return true;
                Material m = a.length > 2 ? Material.matchMaterial(a[2].toUpperCase(Locale.ROOT)) : p.getInventory().getItemInMainHand().getType();
                if (m == null || m == Material.AIR || !m.isItem()) { p.sendMessage(Util.c("&cInvalid item. Hold one or give a material name.")); return true; }
                w.icon = m; wm().save();
                Util.send(p, "pw-updated"); Util.play(p, "success");
                return true;
            }
            case "setdesc": case "desc": case "description": {
                Warp w = owned(p, a, 3, "/pwarps setdesc <name> <text>");
                if (w == null) return true;
                String text = String.join(" ", Arrays.copyOfRange(a, 2, a.length));
                if (text.length() > 60) text = text.substring(0, 60);
                w.description = "&7" + text; wm().save();
                Util.send(p, "pw-updated"); Util.play(p, "success");
                return true;
            }
            case "setcategory": case "category": {
                Warp w = owned(p, a, 3, "/pwarps setcategory <name> <" + Arrays.stream(WarpCategory.values()).map(c -> c.name().toLowerCase(Locale.ROOT)).collect(Collectors.joining("|")) + ">");
                if (w == null) return true;
                WarpCategory c = WarpCategory.parse(a[2]);
                if (c == null) { p.sendMessage(Util.c("&cUnknown category.")); return true; }
                w.category = c; wm().save();
                Util.send(p, "pw-updated"); Util.play(p, "success");
                return true;
            }
            case "setfee": case "fee": {
                Warp w = owned(p, a, 3, "/pwarps setfee <name> <amount>");
                if (w == null) return true;
                try {
                    double fee = Double.parseDouble(a[2]);
                    double max = plugin.getConfig().getDouble("pwarps.max-fee", 10000);
                    if (fee < 0 || fee > max) { p.sendMessage(Util.c("&cFee must be between 0 and " + Util.money(max))); return true; }
                    w.fee = Util.round(fee); wm().save();
                    Util.send(p, "pw-updated"); Util.play(p, "success");
                } catch (NumberFormatException ex) { p.sendMessage(Util.c("&cInvalid amount.")); }
                return true;
            }
            case "private": case "public": {
                Warp w = owned(p, a, 2, "/pwarps " + sub + " <name>");
                if (w == null) return true;
                w.open = sub.equals("public"); wm().save();
                Util.send(p, "pw-updated"); Util.play(p, "success");
                return true;
            }
            case "move": case "setpos": {
                Warp w = owned(p, a, 2, "/pwarps move <name>");
                if (w == null) return true;
                w.setLocation(p.getLocation()); wm().save();
                Util.send(p, "pw-updated"); Util.play(p, "success");
                return true;
            }
            case "ban": case "unban": {
                Warp w = owned(p, a, 3, "/pwarps " + sub + " <warp> <player>");
                if (w == null) return true;
                @SuppressWarnings("deprecation")
                OfflinePlayer t = Bukkit.getOfflinePlayer(a[2]);
                if (!t.hasPlayedBefore() && !t.isOnline()) { p.sendMessage(Util.c("&cUnknown player.")); return true; }
                if (sub.equals("ban")) w.banned.add(t.getUniqueId()); else w.banned.remove(t.getUniqueId());
                wm().save();
                Util.send(p, "pw-updated"); Util.play(p, "success");
                return true;
            }
            case "help": case "?":
                help(p);
                return true;
            default: {
                // /pwarps <name> is a shortcut for visiting
                Warp w = wm().get(a[0]);
                if (w != null) { wm().visit(p, w); return true; }
                help(p);
                return true;
            }
        }
    }

    private Warp need(Player p, String[] a, int len, String usage) {
        if (a.length < len) { p.sendMessage(Util.c("&cUsage: " + usage)); return null; }
        Warp w = wm().get(a[1]);
        if (w == null) { Util.send(p, "pw-notfound", "name", a[1]); Util.play(p, "error"); }
        return w;
    }

    private Warp owned(Player p, String[] a, int len, String usage) {
        Warp w = need(p, a, len, usage);
        if (w == null) return null;
        if (!wm().canEdit(p, w)) { Util.send(p, "pw-notowner"); Util.play(p, "error"); return null; }
        return w;
    }

    private void help(Player p) {
        p.sendMessage(Util.c("&6&m      &r &e&lPlayer Warps &6&m      "));
        String[][] h = {
                {"/pwarps", "open the warp browser"},
                {"/pwarps v <name>", "visit a warp"},
                {"/pwarps set <name>", "create a warp here"},
                {"/pwarps delete <name>", "delete your warp"},
                {"/pwarps list", "your warps"},
                {"/pwarps top | search <text> | info <name>", "discover warps"},
                {"/pwarps rate <name> <1-5>", "rate a warp"},
                {"/pwarps seticon|setdesc|setcategory|setfee <name> ...", "customise"},
                {"/pwarps private|public|move|rename <name>", "manage"},
                {"/pwarps ban|unban <name> <player>", "block a player"},
        };
        for (String[] r : h) p.sendMessage(Util.c(" &6" + r[0] + " &8- &7" + r[1]));
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] a) {
        List<String> out = new ArrayList<>();
        String last = a[a.length - 1].toLowerCase(Locale.ROOT);
        if (a.length == 1) {
            out.addAll(Arrays.asList("v", "set", "delete", "list", "gui", "top", "search", "info", "rate", "rename", "seticon", "setdesc",
                    "setcategory", "setfee", "private", "public", "move", "ban", "unban", "help"));
            for (Warp w : wm().all()) if (w.open) out.add(w.name);
        } else if (a.length == 2) {
            String sub = a[0].toLowerCase(Locale.ROOT);
            if (!sub.equals("set") && !sub.equals("create") && !sub.equals("search") && !sub.equals("help"))
                for (Warp w : wm().all()) out.add(w.name);
        } else if (a.length == 3) {
            String sub = a[0].toLowerCase(Locale.ROOT);
            if (sub.equals("setcategory")) for (WarpCategory c : WarpCategory.values()) out.add(c.name().toLowerCase(Locale.ROOT));
            else if (sub.equals("rate")) out.addAll(Arrays.asList("1", "2", "3", "4", "5"));
            else if (sub.equals("ban") || sub.equals("unban")) for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        }
        return out.stream().filter(x -> x.toLowerCase(Locale.ROOT).startsWith(last)).collect(Collectors.toList());
    }
}
