package com.omnishop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.text.SimpleDateFormat;
import java.util.*;

/** Browser, rating and management menus for player warps. */
public class WarpGui implements Listener {

    public enum Type { BROWSER, RATE, MANAGE }
    public enum Sort {
        VISITS("Most visited"), RATING("Top rated"), NEWEST("Newest"), NAME("A - Z");
        public final String label;
        Sort(String l) { label = l; }
        Sort next() { return values()[(ordinal() + 1) % values().length]; }
    }

    public static class Holder implements InventoryHolder {
        Type type;
        int page;
        Sort sort = Sort.VISITS;
        WarpCategory filter = null;
        UUID ownerFilter = null;
        String search = null;
        String warpName;           // RATE / MANAGE target
        boolean confirmDelete;
        List<Warp> list = new ArrayList<>();
        Inventory inv;
        @Override public Inventory getInventory() { return inv; }
    }

    private final OmniShop plugin;
    private static final int PER_PAGE = 45;
    private final SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");

    public WarpGui(OmniShop plugin) { this.plugin = plugin; }

    /** Called after /shopadmin reload. */
    public void refreshAll() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof Holder) p.closeInventory();
        }
    }

    // ============================================================ browser

    public void openBrowser(Player p) { openBrowser(p, null, null); }

    public void openBrowser(Player p, UUID ownerFilter, String search) {
        Holder h = new Holder();
        h.type = Type.BROWSER;
        h.ownerFilter = ownerFilter;
        h.search = search;
        String title = ownerFilter != null ? "&8» &bMy Warps" : (search != null ? "&8» &bWarps: &f" + search : "&8» &b&lPlayer Warps");
        h.inv = Bukkit.createInventory(h, 54, Util.c(title));
        renderBrowser(p, h);
        p.openInventory(h.inv);
        Util.play(p, "open");
    }

    private void renderBrowser(Player p, Holder h) {
        List<Warp> l = new ArrayList<>();
        for (Warp w : plugin.warps().all()) {
            if (h.ownerFilter != null && !w.owner.equals(h.ownerFilter)) continue;
            if (h.filter != null && w.category != h.filter) continue;
            if (h.search != null && !w.name.toLowerCase(Locale.ROOT).contains(h.search.toLowerCase(Locale.ROOT))
                    && !w.ownerName.toLowerCase(Locale.ROOT).contains(h.search.toLowerCase(Locale.ROOT))) continue;
            if (!w.open && !w.owner.equals(p.getUniqueId()) && !p.hasPermission("omnishop.pwarp.admin")) continue;
            l.add(w);
        }
        switch (h.sort) {
            case VISITS: l.sort((a, b) -> Integer.compare(b.visits, a.visits)); break;
            case RATING: l.sort((a, b) -> Double.compare(b.rating(), a.rating())); break;
            case NEWEST: l.sort((a, b) -> Long.compare(b.created, a.created)); break;
            default: l.sort(Comparator.comparing(w -> w.name.toLowerCase(Locale.ROOT)));
        }
        h.list = l;
        int pages = Math.max(1, (int) Math.ceil(l.size() / (double) PER_PAGE));
        h.page = Math.max(0, Math.min(h.page, pages - 1));
        Inventory inv = h.inv;
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = h.page * PER_PAGE + i;
            inv.setItem(i, idx < l.size() ? warpIcon(p, l.get(idx)) : null);
        }
        for (int i = 45; i < 54; i++) inv.setItem(i, Util.pane(Material.BLACK_STAINED_GLASS_PANE));
        if (h.page > 0) inv.setItem(45, Util.icon(Material.ARROW, "&a« Previous page"));
        inv.setItem(46, Util.icon(Material.HOPPER, "&e&lSort: &f" + h.sort.label, "&7Click to change sorting"));
        inv.setItem(47, Util.icon(h.filter == null ? Material.NETHER_STAR : h.filter.icon,
                "&e&lCategory: &f" + (h.filter == null ? "All" : h.filter.display), "&7Click to cycle categories"));
        inv.setItem(49, Util.icon(Material.WRITABLE_BOOK, "&b&lPlayer Warps",
                "&7Total: &f" + plugin.warps().all().size() + " &8| &7Shown: &f" + l.size(),
                "&7Page &f" + (h.page + 1) + "&7/&f" + pages, "",
                "&7Create one: &f/pwarps set <name>",
                "&7Visit by name: &f/pwarps v <name>"));
        inv.setItem(50, Util.icon(Material.BOOK, "&6&lMy Warps", "&7You own &f" + plugin.warps().byOwner(p.getUniqueId()).size()
                + "&7/&f" + plugin.warps().limitFor(p), "&eClick to view"));
        inv.setItem(52, Util.icon(Material.EMERALD, "&a&lShop", "&eClick to open the shop"));
        if (h.page < pages - 1) inv.setItem(53, Util.icon(Material.ARROW, "&aNext page »"));
    }

    private ItemStack warpIcon(Player p, Warp w) {
        List<String> lore = new ArrayList<>();
        lore.add("&7By &f" + w.ownerName + " &8| &7" + w.category.display);
        lore.add(w.description);
        lore.add("");
        lore.add("&7Visits: &f" + w.visits + "  &8| &7Rating: " + Util.stars(w.rating()) + " &8(" + w.ratings.size() + ")");
        lore.add("&7Entry: " + (w.fee > 0 ? "&6" + Util.money(w.fee) : "&aFree") + "  &8| " + (w.open ? "&aPublic" : "&cPrivate"));
        lore.add("&7Created: &f" + fmt.format(new Date(w.created)));
        lore.add("");
        lore.add("&aLeft-click &7to teleport");
        lore.add("&eRight-click &7to rate");
        if (plugin.warps().canEdit(p, w)) lore.add("&bShift-right-click &7to manage");
        return Util.icon(w.icon, "&b&l" + w.name, lore);
    }

    // ============================================================ rate / manage

    public void openRate(Player p, Warp w) {
        Holder h = new Holder();
        h.type = Type.RATE;
        h.warpName = w.name;
        h.inv = Bukkit.createInventory(h, 27, Util.c("&8» &eRate &f" + w.name));
        for (int i = 0; i < 27; i++) h.inv.setItem(i, Util.pane(Material.GRAY_STAINED_GLASS_PANE));
        Integer mine = w.ratings.get(p.getUniqueId());
        for (int s = 1; s <= 5; s++) {
            h.inv.setItem(10 + s, Util.icon(mine != null && mine >= s ? Material.GOLD_BLOCK : Material.GOLD_NUGGET,
                    "&e" + s + " star" + (s > 1 ? "s" : ""), "&7Click to rate"));
        }
        h.inv.setItem(22, Util.icon(Material.OAK_DOOR, "&e« Back"));
        p.openInventory(h.inv);
        Util.play(p, "click");
    }

    public void openManage(Player p, Warp w) {
        Holder h = new Holder();
        h.type = Type.MANAGE;
        h.warpName = w.name;
        h.inv = Bukkit.createInventory(h, 27, Util.c("&8» &bManage &f" + w.name));
        renderManage(h, w);
        p.openInventory(h.inv);
        Util.play(p, "click");
    }

    private void renderManage(Holder h, Warp w) {
        Inventory inv = h.inv;
        for (int i = 0; i < 27; i++) inv.setItem(i, Util.pane(Material.GRAY_STAINED_GLASS_PANE));
        inv.setItem(10, Util.icon(w.icon, "&b&lSet Icon", "&7Hold an item and click", "&7to use it as the icon."));
        inv.setItem(11, Util.icon(Material.ENDER_PEARL, "&d&lMove Warp Here", "&7Sets the warp to where", "&7you are standing now."));
        inv.setItem(12, Util.icon(w.open ? Material.LIME_DYE : Material.GRAY_DYE, w.open ? "&a&lPublic" : "&c&lPrivate",
                "&7Click to toggle visibility."));
        inv.setItem(13, Util.icon(w.category.icon, "&e&lCategory: &f" + w.category.display, "&7Click to cycle."));
        inv.setItem(14, Util.icon(Material.GOLD_INGOT, "&6&lEntry Fee: &f" + Util.money(w.fee),
                "&7Change with &f/pwarps setfee " + w.name + " <amount>", "&7You earn the fee when others visit."));
        inv.setItem(15, Util.icon(Material.NAME_TAG, "&f&lDescription", "&7Change with", "&f/pwarps setdesc " + w.name + " <text>"));
        inv.setItem(16, Util.icon(Material.BARRIER, "&c&lBanned players: &f" + w.banned.size(), "&7/pwarps ban " + w.name + " <player>"));
        inv.setItem(22, h.confirmDelete ? Util.icon(Material.TNT, "&4&lCLICK AGAIN TO DELETE", "&cThis cannot be undone!")
                : Util.icon(Material.REDSTONE_BLOCK, "&c&lDelete Warp", "&7Click to delete (asks confirmation)"));
        inv.setItem(18, Util.icon(Material.OAK_DOOR, "&e« Back"));
    }

    // ============================================================ events

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player)) return;
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(e.getView().getTopInventory())) return;
        Player p = (Player) e.getWhoClicked();
        Holder h = (Holder) e.getInventory().getHolder();
        int slot = e.getSlot();
        switch (h.type) {
            case BROWSER: clickBrowser(p, h, slot, e.getClick()); break;
            case RATE: clickRate(p, h, slot); break;
            case MANAGE: clickManage(p, h, slot); break;
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    private void clickBrowser(Player p, Holder h, int slot, ClickType click) {
        if (slot < PER_PAGE) {
            int idx = h.page * PER_PAGE + slot;
            if (idx >= h.list.size()) return;
            Warp w = h.list.get(idx);
            if (click == ClickType.SHIFT_RIGHT) {
                if (plugin.warps().canEdit(p, w)) openManage(p, w);
            } else if (click == ClickType.RIGHT) {
                openRate(p, w);
            } else if (click == ClickType.LEFT || click == ClickType.SHIFT_LEFT) {
                plugin.warps().visit(p, w);
            }
            return;
        }
        switch (slot) {
            case 45: if (h.page > 0) { h.page--; Util.play(p, "page"); renderBrowser(p, h); } break;
            case 53: h.page++; Util.play(p, "page"); renderBrowser(p, h); break;
            case 46: h.sort = h.sort.next(); h.page = 0; Util.play(p, "click"); renderBrowser(p, h); break;
            case 47:
                if (h.filter == null) h.filter = WarpCategory.values()[0];
                else if (h.filter.ordinal() == WarpCategory.values().length - 1) h.filter = null;
                else h.filter = h.filter.next();
                h.page = 0;
                Util.play(p, "click");
                renderBrowser(p, h);
                break;
            case 50: openBrowser(p, p.getUniqueId(), null); break;
            case 52: plugin.shopGui().openMain(p); break;
            default: break;
        }
    }

    private void clickRate(Player p, Holder h, int slot) {
        Warp w = plugin.warps().get(h.warpName);
        if (w == null) { p.closeInventory(); return; }
        if (slot >= 11 && slot <= 15) {
            plugin.warps().rate(p, w, slot - 10);
            p.closeInventory();
        } else if (slot == 22) {
            openBrowser(p);
        }
    }

    private void clickManage(Player p, Holder h, int slot) {
        Warp w = plugin.warps().get(h.warpName);
        if (w == null) { p.closeInventory(); return; }
        if (!plugin.warps().canEdit(p, w)) { p.closeInventory(); return; }
        switch (slot) {
            case 10: {
                Material hand = p.getInventory().getItemInMainHand().getType();
                if (hand == Material.AIR) { Util.send(p, "pw-updated"); Util.play(p, "error"); p.sendMessage(Util.c("&cHold an item first.")); return; }
                w.icon = hand;
                plugin.warps().save();
                Util.play(p, "success");
                break;
            }
            case 11:
                w.setLocation(p.getLocation());
                plugin.warps().save();
                Util.send(p, "pw-updated");
                Util.play(p, "success");
                break;
            case 12: w.open = !w.open; plugin.warps().save(); Util.play(p, "click"); break;
            case 13: w.category = w.category.next(); plugin.warps().save(); Util.play(p, "click"); break;
            case 22:
                if (!h.confirmDelete) { h.confirmDelete = true; Util.play(p, "click"); }
                else { plugin.warps().delete(p, w); openBrowser(p); return; }
                break;
            case 18: openBrowser(p); return;
            default: return;
        }
        if (slot != 22) h.confirmDelete = false;
        renderManage(h, w);
    }
}
