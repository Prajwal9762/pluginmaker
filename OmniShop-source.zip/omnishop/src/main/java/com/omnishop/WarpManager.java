package com.omnishop;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachmentInfo;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.regex.Pattern;

public class WarpManager {

    private final OmniShop plugin;
    private final File file;
    private final Map<String, Warp> warps = new LinkedHashMap<>(); // lower-case name -> warp
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Set<UUID> teleporting = new HashSet<>();
    private boolean dirty = false;

    public WarpManager(OmniShop plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "warps.yml");
    }

    // ------------------------------------------------------------------ storage

    public void load() {
        warps.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = y.getConfigurationSection("warps");
        if (root == null) return;
        for (String k : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(k);
            if (s == null) continue;
            Warp w = new Warp();
            w.name = s.getString("name", k);
            try { w.owner = UUID.fromString(s.getString("owner", "")); } catch (IllegalArgumentException ex) { continue; }
            w.ownerName = s.getString("owner-name", "?");
            w.world = s.getString("world", "world");
            w.x = s.getDouble("x"); w.y = s.getDouble("y"); w.z = s.getDouble("z");
            w.yaw = (float) s.getDouble("yaw"); w.pitch = (float) s.getDouble("pitch");
            Material ic = Material.matchMaterial(s.getString("icon", "ENDER_PEARL"));
            w.icon = ic == null ? Material.ENDER_PEARL : ic;
            w.description = s.getString("description", w.description);
            WarpCategory c = WarpCategory.parse(s.getString("category", "GENERAL"));
            w.category = c == null ? WarpCategory.GENERAL : c;
            w.open = s.getBoolean("open", true);
            w.fee = s.getDouble("fee", 0);
            w.visits = s.getInt("visits", 0);
            w.created = s.getLong("created", System.currentTimeMillis());
            ConfigurationSection r = s.getConfigurationSection("ratings");
            if (r != null) for (String u : r.getKeys(false)) {
                try { w.ratings.put(UUID.fromString(u), r.getInt(u)); } catch (IllegalArgumentException ignored) { }
            }
            for (String u : s.getStringList("banned")) {
                try { w.banned.add(UUID.fromString(u)); } catch (IllegalArgumentException ignored) { }
            }
            warps.put(w.name.toLowerCase(Locale.ROOT), w);
        }
    }

    public void markDirty() { dirty = true; }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Warp w : warps.values()) {
            String p = "warps." + w.name.toLowerCase(Locale.ROOT);
            y.set(p + ".name", w.name);
            y.set(p + ".owner", w.owner.toString());
            y.set(p + ".owner-name", w.ownerName);
            y.set(p + ".world", w.world);
            y.set(p + ".x", w.x); y.set(p + ".y", w.y); y.set(p + ".z", w.z);
            y.set(p + ".yaw", w.yaw); y.set(p + ".pitch", w.pitch);
            y.set(p + ".icon", w.icon.name());
            y.set(p + ".description", w.description);
            y.set(p + ".category", w.category.name());
            y.set(p + ".open", w.open);
            y.set(p + ".fee", w.fee);
            y.set(p + ".visits", w.visits);
            y.set(p + ".created", w.created);
            for (Map.Entry<UUID, Integer> e : w.ratings.entrySet()) y.set(p + ".ratings." + e.getKey(), e.getValue());
            List<String> b = new ArrayList<>();
            for (UUID u : w.banned) b.add(u.toString());
            y.set(p + ".banned", b);
        }
        try { y.save(file); dirty = false; } catch (IOException ex) { plugin.getLogger().warning("warps.yml: " + ex.getMessage()); }
    }

    // ------------------------------------------------------------------ queries

    public Collection<Warp> all() { return warps.values(); }
    public Warp get(String name) { return name == null ? null : warps.get(name.toLowerCase(Locale.ROOT)); }

    public List<Warp> byOwner(UUID id) {
        List<Warp> l = new ArrayList<>();
        for (Warp w : warps.values()) if (w.owner.equals(id)) l.add(w);
        return l;
    }

    public int limitFor(Player p) {
        int best = plugin.getConfig().getInt("pwarps.default-limit", 3);
        for (PermissionAttachmentInfo i : p.getEffectivePermissions()) {
            String perm = i.getPermission();
            if (i.getValue() && perm.startsWith("omnishop.pwarp.limit.")) {
                try { best = Math.max(best, Integer.parseInt(perm.substring("omnishop.pwarp.limit.".length()))); }
                catch (NumberFormatException ignored) { }
            }
        }
        return best;
    }

    public boolean canEdit(Player p, Warp w) {
        return w.owner.equals(p.getUniqueId()) || p.hasPermission("omnishop.pwarp.admin");
    }

    // ------------------------------------------------------------------ create / delete

    public boolean validName(String n) {
        int min = plugin.getConfig().getInt("pwarps.min-name-length", 3);
        int max = plugin.getConfig().getInt("pwarps.max-name-length", 16);
        return n.length() >= min && n.length() <= max && Pattern.matches("[A-Za-z0-9_]+", n);
    }

    private boolean safe(Location l) {
        Block feet = l.getBlock();
        Block head = feet.getRelative(0, 1, 0);
        Block ground = feet.getRelative(0, -1, 0);
        if (!feet.isPassable() || !head.isPassable()) return false;
        if (feet.isLiquid() || head.isLiquid()) return false;
        Material g = ground.getType();
        if (g == Material.LAVA || g == Material.MAGMA_BLOCK || g == Material.FIRE || g == Material.CACTUS || g == Material.CAMPFIRE) return false;
        if (g == Material.AIR && l.getBlockY() > l.getWorld().getMinHeight() + 3) {
            // allow floating only if there is solid ground within 4 blocks below
            for (int i = 2; i <= 4; i++) if (feet.getRelative(0, -i, 0).getType().isSolid()) return true;
            return false;
        }
        return true;
    }

    public void create(Player p, String name) {
        if (!p.hasPermission("omnishop.pwarp.create")) { Util.send(p, "no-permission"); return; }
        if (!validName(name)) {
            Util.send(p, "pw-badname", "min", String.valueOf(plugin.getConfig().getInt("pwarps.min-name-length", 3)),
                    "max", String.valueOf(plugin.getConfig().getInt("pwarps.max-name-length", 16)));
            Util.play(p, "error");
            return;
        }
        if (get(name) != null) { Util.send(p, "pw-exists"); Util.play(p, "error"); return; }
        List<String> disabled = plugin.getConfig().getStringList("pwarps.disabled-worlds");
        if (disabled.contains(p.getWorld().getName()) && !p.hasPermission("omnishop.pwarp.admin")) { Util.send(p, "pw-world"); Util.play(p, "error"); return; }
        int limit = limitFor(p);
        if (byOwner(p.getUniqueId()).size() >= limit && !p.hasPermission("omnishop.pwarp.admin")) {
            Util.send(p, "pw-limit", "limit", String.valueOf(limit)); Util.play(p, "error"); return;
        }
        if (plugin.getConfig().getBoolean("pwarps.require-safe-location", true) && !safe(p.getLocation())) {
            Util.send(p, "pw-unsafe"); Util.play(p, "error"); return;
        }
        double cost = plugin.getConfig().getDouble("pwarps.create-cost", 0);
        if (cost > 0 && !p.hasPermission("omnishop.pwarp.nocost")) {
            if (!plugin.eco().has(p, cost)) { Util.send(p, "no-money", "cost", Util.money(cost)); Util.play(p, "error"); return; }
            plugin.eco().withdrawPlayer(p, cost);
        }
        Warp w = new Warp();
        w.name = name;
        w.owner = p.getUniqueId();
        w.ownerName = p.getName();
        w.setLocation(p.getLocation());
        Material hand = p.getInventory().getItemInMainHand().getType();
        if (hand != Material.AIR) w.icon = hand;
        warps.put(name.toLowerCase(Locale.ROOT), w);
        save();
        Util.send(p, "pw-created", "name", name);
        Util.play(p, "success");
    }

    public boolean delete(Player p, Warp w) {
        if (!canEdit(p, w)) { Util.send(p, "pw-notowner"); Util.play(p, "error"); return false; }
        warps.remove(w.name.toLowerCase(Locale.ROOT));
        save();
        Util.send(p, "pw-deleted", "name", w.name);
        Util.play(p, "success");
        return true;
    }

    public boolean rename(Warp w, String newName) {
        if (get(newName) != null && !newName.equalsIgnoreCase(w.name)) return false;
        warps.remove(w.name.toLowerCase(Locale.ROOT));
        w.name = newName;
        warps.put(newName.toLowerCase(Locale.ROOT), w);
        save();
        return true;
    }

    // ------------------------------------------------------------------ teleport

    public void visit(Player p, Warp w) {
        if (!p.hasPermission("omnishop.pwarp.use")) { Util.send(p, "no-permission"); return; }
        boolean admin = p.hasPermission("omnishop.pwarp.admin");
        boolean owner = w.owner.equals(p.getUniqueId());
        if (!owner && !admin) {
            if (w.banned.contains(p.getUniqueId())) { Util.send(p, "pw-banned"); Util.play(p, "error"); return; }
            if (!w.open) { Util.send(p, "pw-private"); Util.play(p, "error"); return; }
        }
        Location dest = w.location();
        if (dest == null) { Util.send(p, "pw-notfound", "name", w.name); return; }
        if (teleporting.contains(p.getUniqueId())) return;
        int cd = plugin.getConfig().getInt("pwarps.cooldown-seconds", 10);
        Long last = cooldowns.get(p.getUniqueId());
        if (cd > 0 && last != null && !admin) {
            long left = (last + cd * 1000L - System.currentTimeMillis() + 999) / 1000;
            if (left > 0) { Util.send(p, "pw-cooldown", "seconds", String.valueOf(left)); Util.play(p, "error"); return; }
        }
        double fee = (owner || admin) ? 0 : w.fee;
        if (fee > 0 && !plugin.eco().has(p, fee)) { Util.send(p, "no-money", "cost", Util.money(fee)); Util.play(p, "error"); return; }

        int warm = p.hasPermission("omnishop.pwarp.nowarmup") ? 0 : plugin.getConfig().getInt("pwarps.warmup-seconds", 3);
        p.closeInventory();
        if (warm <= 0) { finish(p, w, dest, fee); return; }

        teleporting.add(p.getUniqueId());
        Util.send(p, "pw-warmup", "seconds", String.valueOf(warm));
        final Location start = p.getLocation();
        new BukkitRunnable() {
            int left = warm;
            @Override
            public void run() {
                if (!p.isOnline()) { teleporting.remove(p.getUniqueId()); cancel(); return; }
                Location now = p.getLocation();
                if (now.getWorld() != start.getWorld() || now.distanceSquared(start) > 0.6) {
                    teleporting.remove(p.getUniqueId());
                    Util.send(p, "pw-cancelled");
                    Util.play(p, "error");
                    cancel();
                    return;
                }
                if (left <= 0) {
                    teleporting.remove(p.getUniqueId());
                    cancel();
                    Location d = w.location();
                    if (d != null) finish(p, w, d, fee);
                    return;
                }
                p.spigot().sendMessage(net.md_5.bungee.api.ChatMessageType.ACTION_BAR,
                        new net.md_5.bungee.api.chat.TextComponent(Util.c("&eTeleporting to &6" + w.name + " &ein &f" + left + "s")));
                Util.play(p, "warmup");
                left--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void finish(Player p, Warp w, Location dest, double fee) {
        if (fee > 0) {
            if (!plugin.eco().has(p, fee)) { Util.send(p, "no-money", "cost", Util.money(fee)); return; }
            plugin.eco().withdrawPlayer(p, fee);
            double tax = plugin.getConfig().getDouble("pwarps.fee-tax-percent", 0);
            OfflinePlayer owner = Bukkit.getOfflinePlayer(w.owner);
            plugin.eco().depositPlayer(owner, Util.round(fee * (1 - tax / 100.0)));
            Util.send(p, "pw-fee", "fee", Util.money(fee));
        }
        p.teleport(dest);
        cooldowns.put(p.getUniqueId(), System.currentTimeMillis());
        Util.play(p, "teleport");
        Util.send(p, "pw-teleported", "name", w.name, "owner", w.ownerName);
        if (!w.owner.equals(p.getUniqueId())) {
            w.visits++;
            dirty = true;
            Player op = Bukkit.getPlayer(w.owner);
            if (op != null) { Util.send(op, "pw-visit-notify", "player", p.getName(), "name", w.name); Util.play(op, "click"); }
        }
    }

    public void rate(Player p, Warp w, int stars) {
        if (w.owner.equals(p.getUniqueId())) { Util.send(p, "pw-cant-rate-own"); Util.play(p, "error"); return; }
        w.ratings.put(p.getUniqueId(), Math.max(1, Math.min(5, stars)));
        dirty = true;
        Util.send(p, "pw-rated", "name", w.name, "stars", String.valueOf(stars));
        Util.play(p, "rate");
    }
}
