package com.votelinks;

import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class VoteLinks extends JavaPlugin implements CommandExecutor, TabCompleter {

    private File dataFile;
    private FileConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadData();
        getCommand("vote").setExecutor(this);
        getCommand("vote").setTabCompleter(this);
        getLogger().info("VoteLinks enabled.");
    }

    private void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.exists()) {
            try {
                getDataFolder().mkdirs();
                dataFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
    }

    private void saveData() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }

    private String msg(String key) {
        return color(getConfig().getString("messages." + key, ""));
    }

    private long cooldownMillis(String siteId) {
        double hours = getConfig().getDouble("sites." + siteId + ".cooldown-hours",
                getConfig().getDouble("cooldown-hours", 24));
        return (long) (hours * 60 * 60 * 1000L);
    }

    private long remaining(UUID uuid, String siteId) {
        long last = data.getLong("players." + uuid + "." + siteId, 0L);
        long left = (last + cooldownMillis(siteId)) - System.currentTimeMillis();
        return Math.max(0, left);
    }

    private String formatTime(long millis) {
        long s = millis / 1000;
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        if (h > 0) return h + "h " + m + "m";
        if (m > 0) return m + "m " + sec + "s";
        return sec + "s";
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("votelinks.admin")) {
                sender.sendMessage(msg("no-permission"));
                return true;
            }
            reloadConfig();
            loadData();
            sender.sendMessage(msg("reloaded"));
            return true;
        }

        if (!(sender instanceof Player)) {
            sender.sendMessage(msg("players-only"));
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("votelinks.use")) {
            player.sendMessage(msg("no-permission"));
            return true;
        }

        if (args.length >= 2 && args[0].equalsIgnoreCase("claim")) {
            claim(player, args[1]);
            return true;
        }

        showLinks(player);
        return true;
    }

    private void showLinks(Player player) {
        ConfigurationSection sites = getConfig().getConfigurationSection("sites");
        player.sendMessage(msg("header"));
        if (sites != null) {
            for (String id : sites.getKeys(false)) {
                String url = sites.getString(id + ".url", "");
                String name = color(sites.getString(id + ".name", id));

                TextComponent line = new TextComponent(TextComponent.fromLegacyText(name));
                line.setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, url));
                line.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                        new ComponentBuilder(msg("link-hover")).create()));

                TextComponent claim = new TextComponent(TextComponent.fromLegacyText(msg("claim-button")));
                claim.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/vote claim " + id));
                claim.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                        new ComponentBuilder(msg("claim-hover")).create()));

                long left = remaining(player.getUniqueId(), id);
                String status = " " + (left <= 0 ? msg("ready")
                        : color(getConfig().getString("messages.waiting", "").replace("%time%", formatTime(left))));
                TextComponent st = new TextComponent(TextComponent.fromLegacyText(status));

                TextComponent full = new TextComponent("");
                full.addExtra(line);
                full.addExtra(claim);
                full.addExtra(st);
                player.spigot().sendMessage(full);
            }
        }
        player.sendMessage(msg("footer"));
    }

    private void claim(Player player, String siteId) {
        ConfigurationSection site = getConfig().getConfigurationSection("sites." + siteId);
        if (site == null) {
            player.sendMessage(msg("unknown-site"));
            return;
        }
        String siteName = color(site.getString("name", siteId));
        long left = remaining(player.getUniqueId(), siteId);
        if (left > 0) {
            player.sendMessage(msg("on-cooldown")
                    .replace("%site%", siteName)
                    .replace("%time%", formatTime(left)));
            return;
        }

        data.set("players." + player.getUniqueId() + "." + siteId, System.currentTimeMillis());
        saveData();

        for (String c : site.getStringList("commands")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c.replace("%player%", player.getName()));
        }
        player.sendMessage(msg("claimed").replace("%site%", siteName));

        String bc = site.getString("broadcast", "");
        if (bc != null && !bc.isEmpty()) {
            Bukkit.broadcastMessage(color(bc.replace("%player%", player.getName())));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.add("claim");
            if (sender.hasPermission("votelinks.admin")) out.add("reload");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("claim")) {
            ConfigurationSection sites = getConfig().getConfigurationSection("sites");
            if (sites != null) out.addAll(sites.getKeys(false));
        }
        String last = args[args.length - 1].toLowerCase();
        out.removeIf(s -> !s.toLowerCase().startsWith(last));
        return out;
    }
}
