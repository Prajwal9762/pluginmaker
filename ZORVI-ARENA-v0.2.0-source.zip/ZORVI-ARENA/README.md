# ZORVI ARENA

**One Hotspot. Ten Players. Endless Competition.**
Offline LAN multiplayer game platform for Android, by ZORVI Studios. Godot **4.3-stable**, GDScript, ENet over UDP. No internet, servers or accounts.

## Status: v0.2.0 - code complete for Milestones 1-3 and part of 4-5. NEVER COMPILED OR RUN.

This code was written without a Godot editor, an Android device or CI. **Nothing has been compiled, run or tested.** Expect syntax errors and bugs on the first build. Do not treat any row below as "working" until it has a PASS in `docs/TESTING.md`.

| Feature | Code written | Verified |
|---|---|---|
| Splash + logo animation, menu, collection, settings | yes | no |
| Host room, UDP discovery, manual IP, join by code, lobby (ready/team/kick/ping) | yes | no |
| Host-authoritative synced 3D movement, touch controls | yes | no |
| Automatic balancing bot (odd humans -> 1 bot, max 10, host ON/OFF) | yes | unit tests written, not run |
| Team balancing incl. bot placement | yes | unit tests written, not run |
| Bot AI (wander, see, aim, shoot, reload; easy/normal/hard) | yes | no |
| Shooter modes: Team Deathmatch, Free-for-All, Sniper Only | yes | no |
| HP, hitscan, respawn, kill feed, scoreboard, timer, results | yes | no |
| Search and Destroy, Gun Game, Domination | **not built** | - |
| Racing, Sports, Survival, Classic, Challenges, Strategy | **not built** | - |
| Profiles, ranks, achievements, tournaments | **not built** (settings + player ID only) | - |
| Sound effects, extra maps, reconnection | **not built** | - |

## Build the APK on GitHub
1. Create a repo and push this folder's contents (keep `.github/` at the root).
2. Open the **Actions** tab > "Android Build". It runs on every push, or run it manually (workflow_dispatch).
3. When it finishes, download the artifact **ZORVI-ARENA-debug-apk** and install `ZORVI-ARENA-debug.apk` (allow "install unknown apps").
4. Release: push a tag such as `v0.2.0` and the APK is attached to a GitHub Release.
5. If a step fails, open its log and send me the error text.

The unit-test step is set to `continue-on-error` so an untested bug in a test cannot block the APK. Remove that line once tests pass.

## Build locally
Install Godot 4.3-stable + export templates, open the folder, run `godot --headless --path . --import`. Desktop test: run twice, host in one, join `127.0.0.1` in the other (WASD, right-mouse look, Space jump, F fire, R reload).

### Release signing
Never commit keystores or passwords. Create a keystore and supply `GODOT_ANDROID_KEYSTORE_RELEASE_PATH`, `_USER`, `_PASSWORD` as GitHub secrets, then export with `--export-release`.

## How to play
- **Host**: Host Game > Create Room. Turn on the phone's hotspot (or join a Wi-Fi). Pick a mode and bot options in the lobby. Friends join at the IP shown. Start when everyone is READY.
- **Join**: discovered rooms appear automatically, otherwise enter host IP + port (default 47778) or the 4-letter code (needs discovery).
- **Bot rule**: with auto-bot ON and an odd number of humans, exactly one bot is added before the match (1 human = you vs bot). Even number = no bot. Never above the room max.
- Only private-network IPs are accepted; the app never falls back to the internet.

## Layout
```
scripts/core        app root, arena (match), game modes, settings (GameConfig)
scripts/networking  Net (room/lobby/handshake), LanDiscovery, NetUtil
scripts/players     PlayerAvatar, Weapons
scripts/bots        BotBalancer (rules), BotBrain (AI)
scripts/ui          UIKit theme, TouchControls, screens/
tests/              headless unit tests      docs/   NETWORKING.md, TESTING.md
```

## Android notes
- Permissions: INTERNET (Android requires it even for LAN sockets), ACCESS_NETWORK_STATE, ACCESS_WIFI_STATE, CHANGE_WIFI_MULTICAST_STATE.
- Renderer: GL Compatibility. ABIs: arm64-v8a, armeabi-v7a. Orientation: sensor landscape.
- Hotspots/routers with client isolation or blocked broadcast: use manual IP.
- The launcher icon is the SVG project icon; replace it with proper PNG/adaptive icons later.
