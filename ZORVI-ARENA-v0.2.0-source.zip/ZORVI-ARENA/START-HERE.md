# Start here (build the APK with GitHub)

1. Make a new GitHub repository (empty).
2. Upload ALL files and folders from this project to it (unzip first, then upload/drag everything).
3. The build file must be at exactly this path in the repo:
       .github/workflows/android-build.yml
   The folder `.github` is HIDDEN on many systems. A visible copy of the same file is in `workflow-copy/build.yml`.
   If `.github` did not upload: in GitHub click Add file > Create new file, type the name
   `.github/workflows/android-build.yml`, and paste the contents of `workflow-copy/build.yml`.
4. Open the Actions tab > "Android Build" > Run workflow. Wait about 10-15 minutes.
5. Open the finished run, download the artifact "ZORVI-ARENA-debug-apk", unzip it, install the .apk on Android.
6. If the run fails (red X), open the failed step and send me the error text. The code has never been run, so a first-build error is likely.

You need at least 2 phones with the app on the same Wi-Fi/hotspot to test multiplayer. One phone alone can play you vs bot.
