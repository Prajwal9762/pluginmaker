# Networking

- **Transport**: Godot `ENetMultiplayerPeer` (UDP). Host = peer 1 = authoritative server and also a player. `create_server(port, max_players - 1)`.
- **Ports**: game UDP 47778 (configurable), discovery UDP 47777.
- **Handshake**: client connects, sends `request_join(name, protocol_version)`. Host answers `join_accepted` or `join_rejected` (version mismatch, room full, match running). Unhandshaked peers are dropped after 5 s. Client join times out after 8 s with a helpful message.
- **Discovery**: host broadcasts a JSON beacon (magic `ZORVI_ARENA_V1`) every 1 s to `255.255.255.255` and the /24 directed broadcast of each private local IPv4 (assumes /24). Clients listen on 47777; rooms expire after 4 s. Discovery may be blocked by some devices - manual IP is always available.
- **Local-only rule**: `Net.join_game` rejects non-private, non-loopback addresses. The UI shows an explicit "LOCAL NETWORK" status.
- **Gameplay sync** (see `scripts/core/arena.gd`): client input 30 Hz (unreliable) -> host simulation -> state 20 Hz (unreliable_ordered). Client-side prediction for own avatar with soft reconciliation; smoothing for remote avatars.
- **Ping**: ENet round-trip statistic; host refreshes every 2 s and shares it in the lobby list.
- **Not yet implemented**: reconnection, snapshot-interpolation buffer, shooting/damage sync, bot authority (Milestone 3).
