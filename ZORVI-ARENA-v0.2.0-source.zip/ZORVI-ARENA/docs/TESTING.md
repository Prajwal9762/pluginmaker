# Testing

Status legend: PASS / FAIL / NOT RUN. **Nothing has been run yet.**

## Automated (headless)
`godot --headless --path . --import` then `godot --headless --path . -s tests/run_tests.gd`
Covers room codes, IPv4 validation, private-range checks, broadcast address, discovery packet encode/decode, the bot rule for 1-10 humans, team balancing with the bot, and mode tables. - **NOT RUN**

## Manual (devices)
| Test | Result |
|---|---|
| App starts, splash plays, menu appears | NOT RUN |
| All menu buttons work | NOT RUN |
| Host creates room; IP/port/code shown | NOT RUN |
| LAN discovery on hotspot (note phone models) | NOT RUN |
| Manual IP join | NOT RUN |
| 2 / 3 / 5 / 10 device connection | NOT RUN |
| Kick, ready, team switch | NOT RUN |
| Match start; movement synced across devices | NOT RUN |
| Auto bot appears only for odd human counts (1,3,5,7,9) | NOT RUN |
| Bot moves, spots, shoots, reloads, respawns on each difficulty | NOT RUN |
| Team Deathmatch / FFA / Sniper: damage, kill feed, scoreboard, timer, results | NOT RUN |
| Fire/reload/jump buttons and joystick on touch screens | NOT RUN |
| Client leaves mid-match; host leaves mid-match | NOT RUN |
| Works with mobile data and Wi-Fi internet disabled | NOT RUN |
| Android versions / screen sizes / low-end FPS | NOT RUN |

Record device model, Android version, network type and result for each run.
