class_name BotBalancer
extends RefCounted
## Pure rules for the automatic balancing bot (unit-tested, no engine state).
##   even humans -> 0 bots, odd humans -> exactly 1 bot,
##   never exceed the room's max players, and 0 when the host disabled bots.

const BOT_ID := -1  # real peer ids are always positive


static func bots_needed(human_count: int, auto_bots: bool, max_players: int) -> int:
	if not auto_bots or human_count <= 0:
		return 0
	if human_count % 2 == 0:
		return 0
	var cap := mini(max_players, 10)
	if human_count + 1 > cap:
		return 0
	return 1


## humans: peer_id -> team (0/1). Returns {"teams": {peer_id: team}, "bot_team": int}.
## Humans are moved from the larger team until sizes differ by at most 1, then the
## bot (if any) joins the smaller team so the teams end up as equal as possible.
static func balance_teams(humans: Dictionary, bot_count: int) -> Dictionary:
	var teams: Dictionary = humans.duplicate()
	var counts := [0, 0]
	for id in teams:
		counts[clampi(int(teams[id]), 0, 1)] += 1
	while absi(counts[0] - counts[1]) > 1:
		var big := 0 if counts[0] > counts[1] else 1
		var mover := -999999
		var found := false
		for id in teams:
			if int(teams[id]) == big and int(id) != 1 and (not found or int(id) > mover):
				mover = int(id)
				found = true
		if not found:
			for id in teams:
				if int(teams[id]) == big:
					mover = int(id)
					found = true
					break
		teams[mover] = 1 - big
		counts[big] -= 1
		counts[1 - big] += 1
	var bot_team := 0 if counts[0] <= counts[1] else 1
	return {"teams": teams, "bot_team": bot_team}
