class_name BotBrain
extends RefCounted
## Host-side AI for one bot. Clients never run this; they only receive the bot's
## position like any other player. Behaviour: wander between random waypoints,
## acquire the nearest visible enemy, turn toward it (limited turn speed), wait a
## reaction delay, strafe/approach/back off, shoot with an aim error, auto reload.
## Not implemented yet: cover, objectives (needs the objective game modes).

const DIFFICULTY := {
	"easy": {"reaction": 0.8, "error": 0.16, "turn": 3.0, "range": 25.0},
	"normal": {"reaction": 0.4, "error": 0.08, "turn": 5.5, "range": 40.0},
	"hard": {"reaction": 0.15, "error": 0.03, "turn": 9.0, "range": 60.0},
}

var yaw := 0.0
var _cfg: Dictionary
var _rng := RandomNumberGenerator.new()
var _target: PlayerAvatar
var _seen := 0.0
var _wp := Vector3.ZERO
var _has_wp := false
var _think := 0.0
var _stuck := 0.0
var _last_pos := Vector3.ZERO
var _strafe := 1.0
var _strafe_t := 0.0
var _inited := false


func _init(difficulty: String) -> void:
	_cfg = DIFFICULTY.get(difficulty, DIFFICULTY["normal"])
	_rng.randomize()


## Returns {move: Vector2 (world XZ), yaw: float, jump: bool, fire: bool, reload: bool}
func think(a: PlayerAvatar, delta: float, arena: Arena) -> Dictionary:
	var out := {"move": Vector2.ZERO, "yaw": yaw, "jump": false, "fire": false, "reload": false}
	if not a.alive:
		return out
	if not _inited:
		_inited = true
		yaw = a.yaw
		_last_pos = a.global_position

	_think += delta
	if _think >= 0.2:
		_think = 0.0
		_pick_target(a, arena)

	var turn: float = _cfg["turn"]
	if _target != null and is_instance_valid(_target) and _target.alive:
		var to := _target.global_position - a.global_position
		var desired := atan2(-to.x, -to.z)
		yaw = lerp_angle(yaw, desired, minf(1.0, turn * delta))
		_seen += delta
		var dist := Vector2(to.x, to.z).length()
		_strafe_t -= delta
		if _strafe_t <= 0.0:
			_strafe = -_strafe if _rng.randf() < 0.5 else _strafe
			_strafe_t = _rng.randf_range(0.8, 2.0)
		var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
		var right := Vector3(cos(yaw), 0.0, -sin(yaw))
		var m := right * _strafe * 0.6
		if dist > 14.0:
			m += fwd
		elif dist < 6.0:
			m -= fwd * 0.6
		out["move"] = Vector2(m.x, m.z)
		var diff := absf(angle_difference(yaw, desired))
		var err: float = _cfg["error"]
		out["yaw"] = yaw + _rng.randf_range(-err, err)
		out["fire"] = _seen >= float(_cfg["reaction"]) and diff < 0.12
	else:
		_seen = 0.0
		if not _has_wp or a.global_position.distance_to(_wp) < 2.0:
			_wp = Vector3(_rng.randf_range(-34.0, 34.0), 0.0, _rng.randf_range(-34.0, 34.0))
			_has_wp = true
		var dir := _wp - a.global_position
		var desired := atan2(-dir.x, -dir.z)
		yaw = lerp_angle(yaw, desired, minf(1.0, turn * delta))
		var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
		out["move"] = Vector2(fwd.x, fwd.z)
		out["yaw"] = yaw
		out["reload"] = a.ammo < int(arena.weapon_mag() * 0.4)

	# Stuck detection: jump and pick a new waypoint if barely moving.
	_stuck += delta
	if _stuck >= 0.6:
		if a.global_position.distance_to(_last_pos) < 0.3 and out["move"] != Vector2.ZERO:
			out["jump"] = true
			_has_wp = false
		_last_pos = a.global_position
		_stuck = 0.0
	return out


func _pick_target(a: PlayerAvatar, arena: Arena) -> void:
	_target = null
	if not arena.is_combat():
		return
	var best := INF
	var rng_limit: float = _cfg["range"]
	for e in arena.enemies_of(a):
		var d := a.global_position.distance_to(e.global_position)
		if d <= rng_limit and d < best and arena.has_line_of_sight(a, e):
			best = d
			_target = e
