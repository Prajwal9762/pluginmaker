extends Node
## Root of the app: owns the active UI screen, the arena (while a match runs),
## and reacts to global network events (match start, host loss, kick).
## The arena node MUST be named "Arena" under this node so that RPC node paths
## (/root/AppRoot/Arena) are identical on every device.

var _ui_layer: CanvasLayer
var _screen: Control
var _arena: Arena
var _toast: Label
var _toast_tween: Tween


func _ready() -> void:
	_ui_layer = CanvasLayer.new()
	_ui_layer.layer = 10
	add_child(_ui_layer)
	_toast = UIKit.label("", 22, UIKit.TEXT)
	_toast.theme = UIKit.theme()
	_toast.add_theme_stylebox_override("normal", UIKit.box(UIKit.CHARCOAL, UIKit.ORANGE, 10, 2, 10))
	_toast.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast.anchor_left = 0.15
	_toast.anchor_right = 0.85
	_toast.anchor_top = 1.0
	_toast.anchor_bottom = 1.0
	_toast.offset_top = -130
	_toast.offset_bottom = -40
	_toast.z_index = 100
	_toast.modulate.a = 0.0
	_toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui_layer.add_child(_toast)

	Net.match_started.connect(_on_match_started)
	Net.returned_to_lobby.connect(_on_returned_to_lobby)
	Net.disconnected.connect(_on_disconnected)
	show_screen("splash")


func show_screen(target: String, args := {}) -> void:
	if _screen:
		_ui_layer.remove_child(_screen)
		_screen.queue_free()
		_screen = null
	var s: ScreenBase
	match target:
		"splash": s = SplashScreen.new()
		"main_menu": s = MainMenuScreen.new()
		"collection": s = CollectionScreen.new()
		"host": s = HostScreen.new()
		"join": s = JoinScreen.new()
		"lobby": s = LobbyScreen.new()
		"settings": s = SettingsScreen.new()
		_:
			push_error("Unknown screen: " + target)
			return
	s.navigate.connect(show_screen)
	_ui_layer.add_child(s)
	_ui_layer.move_child(s, 0)  # keep the toast on top
	_screen = s


func toast(message: String) -> void:
	_toast.text = message
	if _toast_tween:
		_toast_tween.kill()
	_toast.modulate.a = 1.0
	_toast_tween = create_tween()
	_toast_tween.tween_interval(4.0)
	_toast_tween.tween_property(_toast, "modulate:a", 0.0, 0.5)


func _on_match_started(_settings: Dictionary) -> void:
	if _screen:
		_ui_layer.remove_child(_screen)
		_screen.queue_free()
		_screen = null
	_free_arena()
	_arena = Arena.new()
	_arena.name = "Arena"
	_arena.leave_requested.connect(_on_arena_leave)
	add_child(_arena)


func _on_arena_leave() -> void:
	if Net.is_host:
		Net.end_match()
	else:
		Net.leave()
		_free_arena()
		show_screen("main_menu")


func _on_returned_to_lobby() -> void:
	_free_arena()
	show_screen("lobby")


func _on_disconnected(reason: String) -> void:
	_free_arena()
	show_screen("main_menu")
	toast(reason)


func _free_arena() -> void:
	if _arena:
		remove_child(_arena)
		_arena.queue_free()
		_arena = null
