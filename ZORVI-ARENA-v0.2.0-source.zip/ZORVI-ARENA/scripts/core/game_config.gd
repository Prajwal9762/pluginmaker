extends Node
## Autoload "GameConfig": persistent local settings + player identity.
## Stored as JSON in user://settings.json. No cloud, no accounts.

signal changed

const SAVE_PATH := "user://settings.json"
const VERSION := "0.1.0"
const TAGLINE := "One Hotspot. Ten Players. Endless Competition."

var username := ""
var player_id := ""
var graphics_quality := 1      # 0 Low, 1 Medium, 2 High
var max_fps := 60              # 30, 60, 0 = unlimited
var sfx_volume := 0.8
var music_volume := 0.6
var sensitivity := 1.0
var control_scale := 1.0
var language := "en"           # architecture hook for translations
var auto_bots := true          # stored now, used by the Milestone 3 bot system
var bot_difficulty := "normal" # easy / normal / hard (Milestone 3)
var last_ip := ""
var last_port := 47778


func _ready() -> void:
	load_settings()
	apply()


func load_settings() -> void:
	var d: Dictionary = {}
	if FileAccess.file_exists(SAVE_PATH):
		var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
		if f:
			var parsed: Variant = JSON.parse_string(f.get_as_text())
			if parsed is Dictionary:
				d = parsed
	username = str(d.get("username", ""))
	player_id = str(d.get("player_id", ""))
	graphics_quality = clampi(int(d.get("graphics_quality", 1)), 0, 2)
	max_fps = int(d.get("max_fps", 60))
	sfx_volume = clampf(float(d.get("sfx_volume", 0.8)), 0.0, 1.0)
	music_volume = clampf(float(d.get("music_volume", 0.6)), 0.0, 1.0)
	sensitivity = clampf(float(d.get("sensitivity", 1.0)), 0.2, 3.0)
	control_scale = clampf(float(d.get("control_scale", 1.0)), 0.6, 1.6)
	language = str(d.get("language", "en"))
	auto_bots = bool(d.get("auto_bots", true))
	bot_difficulty = str(d.get("bot_difficulty", "normal"))
	last_ip = str(d.get("last_ip", ""))
	last_port = int(d.get("last_port", 47778))
	if username.strip_edges() == "":
		username = "Player%d" % randi_range(1000, 9999)
	if player_id == "":
		player_id = "ZV-%06X" % (randi() & 0xFFFFFF)
		save_settings()


func save_settings() -> void:
	var d := {
		"username": username, "player_id": player_id,
		"graphics_quality": graphics_quality, "max_fps": max_fps,
		"sfx_volume": sfx_volume, "music_volume": music_volume,
		"sensitivity": sensitivity, "control_scale": control_scale,
		"language": language, "auto_bots": auto_bots,
		"bot_difficulty": bot_difficulty, "last_ip": last_ip, "last_port": last_port,
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d, "\t"))
	changed.emit()


func apply() -> void:
	Engine.max_fps = max_fps
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(sfx_volume, 0.0001)))


func reset_all() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
	load_settings()
	apply()
	save_settings()
