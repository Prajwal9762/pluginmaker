class_name GameModes
extends RefCounted
## Data-driven mode definitions shared by lobby, arena and bots.

const ORDER := ["team_deathmatch", "free_for_all", "sniper_only", "free_roam"]

const MODES := {
	"team_deathmatch": {"label": "Team Deathmatch", "combat": true, "teams": true, "weapon": "rifle", "limit": 30, "time": 300},
	"free_for_all": {"label": "Free-for-All", "combat": true, "teams": false, "weapon": "rifle", "limit": 15, "time": 300},
	"sniper_only": {"label": "Sniper Only", "combat": true, "teams": false, "weapon": "sniper", "limit": 10, "time": 300},
	"free_roam": {"label": "Free Roam (movement test)", "combat": false, "teams": false, "weapon": "rifle", "limit": 0, "time": 0},
}


static func get_mode(id: String) -> Dictionary:
	return MODES.get(id, MODES["free_roam"])


static func label(id: String) -> String:
	return str(get_mode(id)["label"])
