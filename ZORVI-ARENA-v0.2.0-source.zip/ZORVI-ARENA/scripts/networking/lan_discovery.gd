extends Node
## Autoload "LanDiscovery": UDP room discovery on the local network.
##
## Host: broadcasts a small JSON packet once per second to 255.255.255.255 AND to
##       the directed /24 broadcast of every private local IPv4 address.
## Client: listens on DISCOVERY_PORT and collects rooms (keyed by sender IP + game port).
##
## Broadcast can be blocked by some phones/routers (AP client isolation, OEM hotspot
## quirks). Discovery is therefore only a convenience: manual IP is always available,
## and nothing here ever touches the internet.

signal rooms_changed
signal listen_failed(message: String)

const DISCOVERY_PORT := 47777
const BROADCAST_INTERVAL := 1.0
const ROOM_TTL := 4.0

var rooms: Dictionary = {}   # "ip:port" -> {name, code, port, n, max, mode, ip, seen}
var is_broadcasting := false
var is_listening := false

var _tx: PacketPeerUDP
var _rx: PacketPeerUDP
var _info_provider: Callable
var _tx_accum := 0.0


func start_broadcast(info_provider: Callable) -> void:
	stop_broadcast()
	_info_provider = info_provider
	_tx = PacketPeerUDP.new()
	_tx.set_broadcast_enabled(true)
	is_broadcasting = true
	_tx_accum = BROADCAST_INTERVAL  # send immediately


func stop_broadcast() -> void:
	is_broadcasting = false
	if _tx:
		_tx.close()
		_tx = null


func start_listening() -> Error:
	stop_listening()
	rooms.clear()
	_rx = PacketPeerUDP.new()
	var err := _rx.bind(DISCOVERY_PORT)
	if err != OK:
		_rx = null
		listen_failed.emit("Could not listen for rooms (error %d). Use manual IP instead." % err)
		return err
	is_listening = true
	rooms_changed.emit()
	return OK


func stop_listening() -> void:
	is_listening = false
	if _rx:
		_rx.close()
		_rx = null


func find_room_by_code(code: String) -> Dictionary:
	var c := code.strip_edges().to_upper()
	for key in rooms:
		if str(rooms[key].get("code", "")) == c:
			return rooms[key]
	return {}


func _process(delta: float) -> void:
	if is_broadcasting and _tx:
		_tx_accum += delta
		if _tx_accum >= BROADCAST_INTERVAL:
			_tx_accum = 0.0
			_send_beacon()
	if is_listening and _rx:
		_poll_listener()


func _send_beacon() -> void:
	if not _info_provider.is_valid():
		return
	var bytes := NetUtil.encode_room_info(_info_provider.call())
	var targets: Array[String] = ["255.255.255.255"]
	for ip in NetUtil.get_local_ipv4_addresses():
		var b := NetUtil.directed_broadcast(ip)
		if b != "" and not targets.has(b):
			targets.append(b)
	for t in targets:
		_tx.set_dest_address(t, DISCOVERY_PORT)
		_tx.put_packet(bytes)


func _poll_listener() -> void:
	var now := Time.get_ticks_msec() / 1000.0
	var dirty := false
	while _rx.get_available_packet_count() > 0:
		var bytes := _rx.get_packet()
		var ip := _rx.get_packet_ip()
		var info := NetUtil.decode_room_info(bytes)
		if info.is_empty() or not NetUtil.is_valid_ipv4(ip):
			continue
		info["ip"] = ip
		info["seen"] = now
		var key := "%s:%d" % [ip, int(info["port"])]
		if not rooms.has(key):
			dirty = true
		rooms[key] = info
	for key in rooms.keys():
		if now - float(rooms[key]["seen"]) > ROOM_TTL:
			rooms.erase(key)
			dirty = true
	if dirty:
		rooms_changed.emit()
