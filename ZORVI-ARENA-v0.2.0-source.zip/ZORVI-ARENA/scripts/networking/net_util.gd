class_name NetUtil
extends RefCounted
## Pure, side-effect-free networking helpers (unit-testable without a running game).

const DISCOVERY_MAGIC := "ZORVI_ARENA_V1"
const CODE_CHARS := "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no 0/O/1/I


static func generate_room_code(rng: RandomNumberGenerator = null) -> String:
	var r := rng if rng != null else RandomNumberGenerator.new()
	if rng == null:
		r.randomize()
	var out := ""
	for i in 4:
		out += CODE_CHARS[r.randi_range(0, CODE_CHARS.length() - 1)]
	return out


static func is_valid_ipv4(s: String) -> bool:
	var parts := s.strip_edges().split(".")
	if parts.size() != 4:
		return false
	for p in parts:
		if p == "" or not p.is_valid_int():
			return false
		var n := p.to_int()
		if n < 0 or n > 255 or p.length() > 3:
			return false
	return true


static func is_loopback(ip: String) -> bool:
	return is_valid_ipv4(ip) and ip.begins_with("127.")


static func is_private_ipv4(ip: String) -> bool:
	if not is_valid_ipv4(ip):
		return false
	var p := ip.split(".")
	var a := p[0].to_int()
	var b := p[1].to_int()
	if a == 10:
		return true
	if a == 172 and b >= 16 and b <= 31:
		return true
	if a == 192 and b == 168:
		return true
	if a == 169 and b == 254:
		return true
	return false


static func get_local_ipv4_addresses() -> Array[String]:
	var out: Array[String] = []
	for addr in IP.get_local_addresses():
		var s := str(addr)
		if is_private_ipv4(s) and not out.has(s):
			out.append(s)
	return out


## Directed broadcast address assuming a /24 network (true for nearly all
## phone hotspots and home routers). Used alongside 255.255.255.255.
static func directed_broadcast(ip: String) -> String:
	if not is_valid_ipv4(ip):
		return ""
	var p := ip.split(".")
	return "%s.%s.%s.255" % [p[0], p[1], p[2]]


static func encode_room_info(info: Dictionary) -> PackedByteArray:
	var d := info.duplicate()
	d["m"] = DISCOVERY_MAGIC
	return JSON.stringify(d).to_utf8_buffer()


## Returns {} if the packet is not a valid ZORVI ARENA discovery packet.
static func decode_room_info(bytes: PackedByteArray) -> Dictionary:
	if bytes.size() == 0 or bytes.size() > 512:
		return {}
	var parsed: Variant = JSON.parse_string(bytes.get_string_from_utf8())
	if not (parsed is Dictionary):
		return {}
	var d: Dictionary = parsed
	if d.get("m", "") != DISCOVERY_MAGIC:
		return {}
	if not d.has("port") or not d.has("name"):
		return {}
	return d


static func sanitize_name(raw: String, fallback := "Player") -> String:
	var s := raw.strip_edges().replace("\n", " ")
	if s.length() > 16:
		s = s.substr(0, 16)
	return fallback if s == "" else s
