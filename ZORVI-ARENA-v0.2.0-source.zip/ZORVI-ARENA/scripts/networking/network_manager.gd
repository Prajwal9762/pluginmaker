extends Node
## Autoload "Net": room lifecycle, lobby state and handshake over ENet (UDP).
##
## Topology: the host phone is peer 1 and the authoritative server. It also plays.
## Max 10 humans => the ENet server accepts at most 9 remote clients.
## The handshake (request_join -> join_accepted/join_rejected) validates protocol
## version, room capacity and match state before a peer is added to `players`.
## Only private/loopback IPv4 addresses are accepted: no internet fallback.

signal players_changed
signal player_left(peer_id: int)
signal connection_succeeded
signal connection_failed(reason: String)
signal disconnected(reason: String)
signal match_started(settings: Dictionary)
signal returned_to_lobby

const PROTOCOL_VERSION := 1
const DEFAULT_PORT := 47778
const MAX_PLAYERS_LIMIT := 10
const JOIN_TIMEOUT_SEC := 8.0
const HANDSHAKE_TIMEOUT_SEC := 5.0
const PING_INTERVAL_SEC := 2.0

var peer: ENetMultiplayerPeer
var is_active := false
var is_host := false
var room_name := ""
var room_code := ""
var port := DEFAULT_PORT
var max_players := MAX_PLAYERS_LIMIT
var host_address := ""
## peer_id -> {name:String, ready:bool, team:int, ping:int}
var players: Dictionary = {}
var settings: Dictionary = {}
var in_match := false

var _joining := false
var _join_elapsed := 0.0
var _pending: Dictionary = {}   # peer_id -> seconds since connect (host, awaiting handshake)
var _ping_elapsed := 0.0


func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)


# ---------------------------------------------------------------- host / join

func host_game(p_room_name: String, p_port: int, p_max_players: int) -> Error:
	leave()
	peer = ENetMultiplayerPeer.new()
	max_players = clampi(p_max_players, 2, MAX_PLAYERS_LIMIT)
	var err := peer.create_server(p_port, max_players - 1)
	if err != OK:
		peer = null
		return err
	multiplayer.multiplayer_peer = peer
	is_active = true
	is_host = true
	port = p_port
	room_name = NetUtil.sanitize_name(p_room_name, "ZORVI Room")
	room_code = NetUtil.generate_room_code()
	host_address = ""
	in_match = false
	settings = {
		"mode": "team_deathmatch", "map": "test_arena",
		"auto_bots": GameConfig.auto_bots, "bot_difficulty": GameConfig.bot_difficulty,
		"bot_name": "ZORVI-Bot", "bot_color": 0,
	}
	players.clear()
	players[1] = _new_player(GameConfig.username, 0)
	players[1]["ready"] = true
	LanDiscovery.start_broadcast(Callable(self, "_discovery_info"))
	players_changed.emit()
	return OK


## Returns "" on success, otherwise a human-readable error.
func join_game(address: String, p_port: int) -> String:
	var addr := address.strip_edges()
	if not NetUtil.is_valid_ipv4(addr):
		return "'%s' is not a valid IPv4 address (example: 192.168.43.1)." % addr
	if not NetUtil.is_private_ipv4(addr) and not NetUtil.is_loopback(addr):
		return "%s is not a local-network address. ZORVI ARENA only plays over local Wi-Fi or a phone hotspot - never the internet." % addr
	if p_port < 1024 or p_port > 65535:
		return "Port must be between 1024 and 65535."
	leave()
	peer = ENetMultiplayerPeer.new()
	var err := peer.create_client(addr, p_port)
	if err != OK:
		peer = null
		return "Could not start the connection (error %d)." % err
	multiplayer.multiplayer_peer = peer
	is_active = true
	is_host = false
	host_address = addr
	port = p_port
	_joining = true
	_join_elapsed = 0.0
	return ""


func leave() -> void:
	LanDiscovery.stop_broadcast()
	is_active = false
	is_host = false
	_joining = false
	in_match = false
	_pending.clear()
	players.clear()
	if peer:
		peer.close()
		peer = null
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()


# ----------------------------------------------------------------- lobby API

func request_ready(r: bool) -> void:
	if is_host:
		_apply_ready(1, r)
	else:
		set_ready.rpc_id(1, r)


func request_team(t: int) -> void:
	if is_host:
		_apply_team(1, t)
	else:
		set_team.rpc_id(1, t)


func update_setting(key: String, value: Variant) -> void:
	if not is_host:
		return
	settings[key] = value
	sync_settings.rpc(settings)
	players_changed.emit()


func kick_player(id: int) -> void:
	if not is_host or id == 1 or not players.has(id):
		return
	kicked.rpc_id(id)
	peer.disconnect_peer(id)  # graceful: queued message is delivered first


func all_clients_ready() -> bool:
	for id in players:
		if id != 1 and not bool(players[id]["ready"]):
			return false
	return true


func start_match() -> bool:
	if not is_host or in_match or not all_clients_ready():
		return false
	_prepare_match_roster()
	begin_match.rpc(settings)
	return true


## Number of automatic bots that would be added if the match started now.
func planned_bot_count() -> int:
	var humans := 0
	for id in players:
		if int(id) > 0:
			humans += 1
	return BotBalancer.bots_needed(humans, bool(settings.get("auto_bots", true)), max_players)


## Runs on the host right before every match: removes stale bots, balances teams
## and adds the single automatic balancing bot when the human count is odd.
## The bot is a host-simulated participant (id -1); it is never a fake connection.
func _prepare_match_roster() -> void:
	_remove_bots()
	var humans := {}
	for id in players:
		humans[id] = int(players[id]["team"])
	var need := planned_bot_count()
	var mode := GameModes.get_mode(str(settings.get("mode", "free_roam")))
	var bal := BotBalancer.balance_teams(humans, need)
	if bool(mode["teams"]):
		var new_teams: Dictionary = bal["teams"]
		for id in new_teams:
			players[id]["team"] = int(new_teams[id])
	if need > 0:
		var bot := _new_player(str(settings.get("bot_name", "ZORVI-Bot")), int(bal["bot_team"]) if bool(mode["teams"]) else 0)
		bot["ready"] = true
		bot["bot"] = true
		players[BotBalancer.BOT_ID] = bot
	_broadcast_players()
	players_changed.emit()


func _remove_bots() -> void:
	for id in players.keys():
		if int(id) < 0:
			players.erase(id)


func end_match() -> void:
	if not is_host or not in_match:
		return
	for id in players:
		if id != 1:
			players[id]["ready"] = false
	return_to_lobby.rpc()
	_broadcast_players()


func get_my_ping_ms() -> int:
	if is_host or peer == null:
		return 0
	var p := peer.get_peer(1)
	if p == null:
		return 0
	return int(p.get_statistic(ENetPacketPeer.PEER_ROUND_TRIP_TIME))


func my_id() -> int:
	return multiplayer.get_unique_id()


## Explicit, honest statement of whether this connection is local.
func connection_label() -> String:
	if not is_active:
		return "OFFLINE"
	if is_host:
		var ips := NetUtil.get_local_ipv4_addresses()
		if ips.is_empty():
			return "NO LOCAL NETWORK FOUND - enable hotspot or join Wi-Fi"
		return "LOCAL NETWORK ONLY (no internet used)"
	if NetUtil.is_loopback(host_address):
		return "THIS DEVICE (loopback test)"
	if NetUtil.is_private_ipv4(host_address):
		return "LOCAL NETWORK (%s) - no internet used" % host_address
	return "NON-LOCAL ADDRESS"


# -------------------------------------------------------------------- process

func _process(delta: float) -> void:
	if _joining:
		_join_elapsed += delta
		if _join_elapsed > JOIN_TIMEOUT_SEC:
			_joining = false
			leave()
			connection_failed.emit("Timed out. Make sure both phones are on the same Wi-Fi/hotspot, the host room is open, and the IP and port are correct. Some routers block device-to-device traffic (client isolation).")
	if is_host and peer:
		for id in _pending.keys():
			_pending[id] += delta
			if _pending[id] > HANDSHAKE_TIMEOUT_SEC:
				_pending.erase(id)
				peer.disconnect_peer(id, true)
		_ping_elapsed += delta
		if _ping_elapsed >= PING_INTERVAL_SEC:
			_ping_elapsed = 0.0
			_refresh_pings()


func _refresh_pings() -> void:
	for id in players:
		if id == 1:
			players[id]["ping"] = 0
			continue
		var p := peer.get_peer(id)
		if p:
			players[id]["ping"] = int(p.get_statistic(ENetPacketPeer.PEER_ROUND_TRIP_TIME))
	_broadcast_players()
	players_changed.emit()


# ------------------------------------------------------------- engine signals

func _on_peer_connected(id: int) -> void:
	if is_host:
		_pending[id] = 0.0


func _on_peer_disconnected(id: int) -> void:
	if not is_host:
		return
	_pending.erase(id)
	if players.has(id):
		players.erase(id)
		player_left.emit(id)
		_broadcast_players()
		players_changed.emit()


func _on_connected_to_server() -> void:
	_joining = false
	request_join.rpc_id(1, GameConfig.username, PROTOCOL_VERSION)


func _on_connection_failed() -> void:
	_joining = false
	leave()
	connection_failed.emit("Could not reach the host. Check Wi-Fi/hotspot, IP and port.")


func _on_server_disconnected() -> void:
	leave()
	disconnected.emit("The host closed the room or the connection was lost.")


# ------------------------------------------------------------------------ RPCs

@rpc("any_peer", "reliable")
func request_join(p_name: String, version: int) -> void:
	if not is_host:
		return
	var id := multiplayer.get_remote_sender_id()
	_pending.erase(id)
	if version != PROTOCOL_VERSION:
		_reject(id, "Game version mismatch. Everyone must install the same ZORVI ARENA build.")
		return
	if in_match:
		_reject(id, "A match is already in progress.")
		return
	if players.size() >= max_players:
		_reject(id, "The room is full.")
		return
	players[id] = _new_player(_unique_name(NetUtil.sanitize_name(p_name)), _smaller_team())
	join_accepted.rpc_id(id, room_name, room_code, settings, max_players)
	_broadcast_players()
	players_changed.emit()


@rpc("authority", "reliable")
func join_accepted(p_room: String, p_code: String, p_settings: Dictionary, p_max: int) -> void:
	room_name = p_room
	room_code = p_code
	settings = p_settings
	max_players = p_max
	connection_succeeded.emit()


@rpc("authority", "reliable")
func join_rejected(reason: String) -> void:
	leave()
	connection_failed.emit(reason)


@rpc("authority", "reliable")
func kicked() -> void:
	leave()
	disconnected.emit("You were removed from the room by the host.")


@rpc("authority", "reliable")
func sync_players(p: Dictionary) -> void:
	players = p
	players_changed.emit()


@rpc("authority", "reliable")
func sync_settings(s: Dictionary) -> void:
	settings = s
	players_changed.emit()


@rpc("any_peer", "reliable")
func set_ready(r: bool) -> void:
	if is_host:
		_apply_ready(multiplayer.get_remote_sender_id(), r)


@rpc("any_peer", "reliable")
func set_team(t: int) -> void:
	if is_host:
		_apply_team(multiplayer.get_remote_sender_id(), t)


@rpc("authority", "call_local", "reliable")
func begin_match(s: Dictionary) -> void:
	settings = s
	in_match = true
	match_started.emit(s)


@rpc("authority", "call_local", "reliable")
func return_to_lobby() -> void:
	in_match = false
	if is_host:
		_remove_bots()
		_broadcast_players()
	returned_to_lobby.emit()


# --------------------------------------------------------------------- helpers

func _reject(id: int, reason: String) -> void:
	join_rejected.rpc_id(id, reason)
	peer.disconnect_peer(id)


func _apply_ready(id: int, r: bool) -> void:
	if in_match or not players.has(id):
		return
	players[id]["ready"] = r
	_broadcast_players()
	players_changed.emit()


func _apply_team(id: int, t: int) -> void:
	if in_match or not players.has(id):
		return
	players[id]["team"] = clampi(t, 0, 1)
	_broadcast_players()
	players_changed.emit()


func _broadcast_players() -> void:
	if is_host and peer:
		sync_players.rpc(players)


func _new_player(p_name: String, team: int) -> Dictionary:
	return {"name": p_name, "ready": false, "team": team, "ping": 0}


func _smaller_team() -> int:
	var counts := [0, 0]
	for id in players:
		counts[int(players[id]["team"])] += 1
	return 0 if counts[0] <= counts[1] else 1


func _unique_name(base: String) -> String:
	var taken: Array[String] = []
	for id in players:
		taken.append(str(players[id]["name"]))
	if not taken.has(base):
		return base
	var i := 2
	while taken.has("%s %d" % [base, i]):
		i += 1
	return "%s %d" % [base, i]


func _discovery_info() -> Dictionary:
	return {
		"name": room_name, "code": room_code, "port": port,
		"n": players.size(), "max": max_players,
		"mode": str(settings.get("mode", "")), "open": not in_match,
	}
