class_name PlayerAvatar
extends CharacterBody3D
## One participant's body (human or bot). The host simulates every avatar
## (authoritative). A client simulates only its own avatar (prediction) and
## smooths all others toward the positions the host sends.

const SPEED := 6.5
const ACCEL := 40.0
const JUMP_VELOCITY := 6.5
const GRAVITY := 20.0
const MAX_HP := 100

var peer_id := 0
var display_name := ""
var team := 0
var is_bot := false
var remote_driven := false      # true on clients for other participants
var target_pos := Vector3.ZERO
var target_yaw := 0.0
var yaw := 0.0

# Combat state: authoritative on host, mirrored to clients for HUD/visibility.
var hp := MAX_HP
var ammo := 0
var alive := true
var cooldown := 0.0
var reload_left := 0.0
var respawn_left := 0.0
var kills := 0
var deaths := 0

var _label: Label3D


func setup(p_id: int, p_name: String, color: Color, spawn: Vector3) -> void:
	peer_id = p_id
	display_name = p_name
	position = spawn
	target_pos = spawn

	var shape := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	shape.shape = cap
	shape.position.y = 0.9
	add_child(shape)

	var body := MeshInstance3D.new()
	var mesh := CapsuleMesh.new()
	mesh.radius = 0.4
	mesh.height = 1.8
	mesh.radial_segments = 12
	mesh.rings = 4
	body.mesh = mesh
	body.position.y = 0.9
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.7
	body.material_override = mat
	add_child(body)

	# Visor: shows which way the participant faces (-Z is forward).
	var visor := MeshInstance3D.new()
	var vm := BoxMesh.new()
	vm.size = Vector3(0.5, 0.18, 0.2)
	visor.mesh = vm
	visor.position = Vector3(0, 1.45, -0.34)
	var vmat := StandardMaterial3D.new()
	vmat.albedo_color = Color("0b0b0d")
	visor.material_override = vmat
	add_child(visor)

	_label = Label3D.new()
	_label.text = p_name + (" [BOT]" if is_bot else "")
	_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_label.pixel_size = 0.006
	_label.font_size = 48
	_label.outline_size = 10
	_label.position.y = 2.25
	add_child(_label)


func set_alive(v: bool) -> void:
	alive = v
	visible = v
	collision_layer = 1 if v else 0


## Shared movement step. `move` is in the frame given by `cam_yaw`
## (bots pass world-space move with cam_yaw 0). If `face_yaw` is a number the body
## turns to it (aiming); otherwise it faces the movement direction.
func step(move: Vector2, cam_yaw: float, jump: bool, delta: float, face_yaw := NAN) -> void:
	var dir := Vector3(move.x, 0.0, move.y).rotated(Vector3.UP, cam_yaw)
	if dir.length() > 1.0:
		dir = dir.normalized()
	var hv := Vector2(velocity.x, velocity.z).move_toward(Vector2(dir.x, dir.z) * SPEED, ACCEL * delta)
	velocity.x = hv.x
	velocity.z = hv.y
	if is_on_floor():
		if jump:
			velocity.y = JUMP_VELOCITY
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()
	if not is_nan(face_yaw):
		yaw = lerp_angle(yaw, face_yaw, minf(1.0, 14.0 * delta))
		rotation.y = yaw
	elif dir.length() > 0.1:
		yaw = lerp_angle(yaw, atan2(-dir.x, -dir.z), minf(1.0, 12.0 * delta))
		rotation.y = yaw


func _process(delta: float) -> void:
	if remote_driven:
		var k := 1.0 - exp(-14.0 * delta)
		global_position = global_position.lerp(target_pos, k)
		yaw = lerp_angle(yaw, target_yaw, k)
		rotation.y = yaw
