class_name Weapons
extends RefCounted
## Hitscan weapon table. Damage is applied only on the host.

const DATA := {
	"rifle": {"name": "ZR-7 Rifle", "damage": 22, "cooldown": 0.11, "mag": 30, "reload": 1.7, "range": 80.0, "spread": 0.015},
	"sniper": {"name": "ZS-9 Sniper", "damage": 100, "cooldown": 1.1, "mag": 5, "reload": 2.4, "range": 150.0, "spread": 0.0},
}


static func get_weapon(id: String) -> Dictionary:
	return DATA.get(id, DATA["rifle"])
