class_name CollectionScreen
extends ScreenBase
## Game collection. Shows the real implementation status of every category:
## only modes that are actually implemented are marked AVAILABLE.

const PLANNED := [
	{"name": "SHOOTER (more modes)", "modes": "Search and Destroy, Gun Game, Domination"},
	{"name": "RACING", "modes": "Circuit, Drag, Elimination, Checkpoint, Free Drive"},
	{"name": "SPORTS", "modes": "Football, Basketball, Penalty Shootout"},
	{"name": "SURVIVAL", "modes": "Last Player Standing, Zombie Survival, Resource Collection, Shrinking Safe Zone"},
	{"name": "CLASSIC", "modes": "8-Ball Pool, Chess, Carrom, Ludo, Checkers"},
	{"name": "CHALLENGES", "modes": "Obstacle Race, Parkour, Reaction Test, Target Practice, Time Trials"},
	{"name": "STRATEGY", "modes": "Territory Control, Tactical Team Battles, Resource Management, Turn-Based Battles"},
]


func _ready() -> void:
	UIKit.add_background(self)
	var root := UIKit.screen_margin(self, 32)
	root.add_child(UIKit.label("GAME COLLECTION", 44, UIKit.ORANGE))

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(scroll)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 10)
	scroll.add_child(list)

	list.add_child(UIKit.panel_row("AVAILABLE - SHOOTER", "Team Deathmatch, Free-for-All, Sniper Only (hitscan combat, bots, respawn, scoreboard). Plus Free Roam movement test. Host a room to play.", UIKit.GOOD))
	for c in PLANNED:
		list.add_child(UIKit.panel_row(str(c["name"]) + "  -  planned, not built yet", str(c["modes"]), UIKit.MUTED))

	var back := UIKit.button("BACK")
	back.pressed.connect(func(): go("main_menu"))
	root.add_child(back)
