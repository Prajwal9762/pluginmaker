class_name HostScreen
extends ScreenBase

var _room: LineEdit
var _port: SpinBox
var _max: SpinBox
var _status: Label


func _ready() -> void:
	UIKit.add_background(self)
	var root := UIKit.screen_margin(self, 40)
	root.add_child(UIKit.label("HOST GAME", 44, UIKit.ORANGE))
	root.add_child(UIKit.label("This phone becomes the server. Friends join over the same Wi-Fi or this phone's hotspot. No internet needed.", 20, UIKit.MUTED))

	var form := VBoxContainer.new()
	form.custom_minimum_size = Vector2(560, 0)
	form.add_theme_constant_override("separation", 10)
	root.add_child(form)

	form.add_child(UIKit.label("Room name", 20, UIKit.GOLD))
	_room = LineEdit.new()
	_room.text = "%s's Room" % GameConfig.username
	_room.max_length = 24
	_room.custom_minimum_size = Vector2(0, 60)
	form.add_child(_room)

	form.add_child(UIKit.label("Port (UDP)", 20, UIKit.GOLD))
	_port = SpinBox.new()
	_port.min_value = 1024
	_port.max_value = 65535
	_port.value = Net.DEFAULT_PORT
	_port.custom_minimum_size = Vector2(0, 60)
	form.add_child(_port)

	form.add_child(UIKit.label("Max players (2-10)", 20, UIKit.GOLD))
	_max = SpinBox.new()
	_max.min_value = 2
	_max.max_value = Net.MAX_PLAYERS_LIMIT
	_max.value = Net.MAX_PLAYERS_LIMIT
	_max.custom_minimum_size = Vector2(0, 60)
	form.add_child(_max)

	var ips := NetUtil.get_local_ipv4_addresses()
	var net_text := ""
	if ips.is_empty():
		net_text = "No local network detected. Join a Wi-Fi network or turn on this phone's hotspot first."
		root.add_child(UIKit.label(net_text, 20, UIKit.BAD))
	else:
		root.add_child(UIKit.label("Local address(es) friends can use: " + ", ".join(ips), 20, UIKit.GOOD))

	_status = UIKit.label("", 20, UIKit.BAD)
	root.add_child(_status)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	root.add_child(row)
	var back := UIKit.button("BACK")
	back.pressed.connect(func(): go("main_menu"))
	row.add_child(back)
	var create := UIKit.button("CREATE ROOM", true)
	create.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	create.pressed.connect(_create)
	row.add_child(create)


func _create() -> void:
	var err := Net.host_game(_room.text, int(_port.value), int(_max.value))
	if err != OK:
		_status.text = "Could not start the server (error %d). The port may be in use - try another port." % err
		return
	go("lobby")
