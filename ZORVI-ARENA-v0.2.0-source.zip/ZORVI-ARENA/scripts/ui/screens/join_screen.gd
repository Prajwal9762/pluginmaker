class_name JoinScreen
extends ScreenBase

var _rooms_box: VBoxContainer
var _ip: LineEdit
var _port: SpinBox
var _code: LineEdit
var _status: Label
var _connect_btn: Button
var _empty: Label


func _ready() -> void:
	UIKit.add_background(self)
	var root := UIKit.screen_margin(self, 32)
	root.add_child(UIKit.label("JOIN GAME", 44, UIKit.ORANGE))

	var cols := HBoxContainer.new()
	cols.add_theme_constant_override("separation", 24)
	cols.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(cols)

	# Left: discovered rooms
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_theme_constant_override("separation", 10)
	cols.add_child(left)
	left.add_child(UIKit.label("Rooms found on this network", 24, UIKit.GOLD))
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	left.add_child(scroll)
	_rooms_box = VBoxContainer.new()
	_rooms_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_rooms_box.add_theme_constant_override("separation", 8)
	scroll.add_child(_rooms_box)
	_empty = UIKit.label("Searching...\nIf nothing appears, your phone/router may block discovery. Use the manual IP on the right.", 20, UIKit.MUTED)
	_empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_rooms_box.add_child(_empty)

	# Right: manual / code
	var right := VBoxContainer.new()
	right.custom_minimum_size = Vector2(420, 0)
	right.add_theme_constant_override("separation", 8)
	cols.add_child(right)
	right.add_child(UIKit.label("Manual connection", 24, UIKit.GOLD))
	_ip = LineEdit.new()
	_ip.placeholder_text = "Host IP, e.g. 192.168.43.1"
	_ip.text = GameConfig.last_ip
	_ip.custom_minimum_size = Vector2(0, 58)
	right.add_child(_ip)
	_port = SpinBox.new()
	_port.min_value = 1024
	_port.max_value = 65535
	_port.value = GameConfig.last_port
	_port.custom_minimum_size = Vector2(0, 58)
	right.add_child(_port)
	_connect_btn = UIKit.button("CONNECT", true)
	_connect_btn.pressed.connect(_connect_manual)
	right.add_child(_connect_btn)
	right.add_child(UIKit.label("Room code (needs discovery)", 20, UIKit.GOLD))
	_code = LineEdit.new()
	_code.placeholder_text = "4-letter code"
	_code.max_length = 4
	_code.custom_minimum_size = Vector2(0, 58)
	right.add_child(_code)
	var by_code := UIKit.button("JOIN BY CODE")
	by_code.pressed.connect(_connect_code)
	right.add_child(by_code)

	_status = UIKit.label("", 20, UIKit.MUTED)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(_status)
	var back := UIKit.button("BACK")
	back.pressed.connect(func(): go("main_menu"))
	root.add_child(back)

	Net.connection_succeeded.connect(_on_connected)
	Net.connection_failed.connect(_on_failed)
	LanDiscovery.rooms_changed.connect(_refresh_rooms)
	LanDiscovery.listen_failed.connect(func(m: String): _set_status(m, UIKit.BAD))
	LanDiscovery.start_listening()


func _exit_tree() -> void:
	LanDiscovery.stop_listening()


func _refresh_rooms() -> void:
	for c in _rooms_box.get_children():
		c.queue_free()
	if LanDiscovery.rooms.is_empty():
		_empty = UIKit.label("Searching...\nIf nothing appears, your phone/router may block discovery. Use the manual IP on the right.", 20, UIKit.MUTED)
		_empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_rooms_box.add_child(_empty)
		return
	for key in LanDiscovery.rooms:
		var r: Dictionary = LanDiscovery.rooms[key]
		var b := UIKit.button("%s   [%s]   %d/%d   %s" % [r["name"], r.get("code", "----"), int(r.get("n", 0)), int(r.get("max", 10)), r["ip"]], false, Vector2(0, 70))
		b.disabled = not bool(r.get("open", true))
		var ip: String = r["ip"]
		var prt: int = int(r["port"])
		b.pressed.connect(func(): _start_join(ip, prt))
		_rooms_box.add_child(b)


func _connect_manual() -> void:
	_start_join(_ip.text, int(_port.value))


func _connect_code() -> void:
	var r := LanDiscovery.find_room_by_code(_code.text)
	if r.is_empty():
		_set_status("No room with that code was discovered. Discovery may be blocked on this network - use the host's IP instead.", UIKit.BAD)
		return
	_start_join(str(r["ip"]), int(r["port"]))


func _start_join(ip: String, prt: int) -> void:
	var err := Net.join_game(ip, prt)
	if err != "":
		_set_status(err, UIKit.BAD)
		return
	GameConfig.last_ip = ip
	GameConfig.last_port = prt
	GameConfig.save_settings()
	_connect_btn.disabled = true
	_set_status("Connecting to %s:%d over the local network..." % [ip, prt], UIKit.GOLD)


func _on_connected() -> void:
	go("lobby")


func _on_failed(reason: String) -> void:
	_connect_btn.disabled = false
	_set_status(reason, UIKit.BAD)


func _set_status(text: String, color: Color) -> void:
	_status.text = text
	_status.add_theme_color_override("font_color", color)
