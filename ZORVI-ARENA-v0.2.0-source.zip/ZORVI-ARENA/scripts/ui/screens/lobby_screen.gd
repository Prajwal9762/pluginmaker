class_name LobbyScreen
extends ScreenBase

const TEAM_NAMES := ["TEAM A", "TEAM B"]
const DIFFICULTIES := ["easy", "normal", "hard"]
const BOT_NAMES := ["ZORVI-Bot", "Ghost", "Viper", "Nova", "Atlas"]
const BOT_LOOKS := ["Steel", "Crimson", "Forest", "Violet", "Ivory"]

var _list: VBoxContainer
var _status: Label
var _summary: Label
var _ready_btn: Button
var _start_btn: Button


func _ready() -> void:
	UIKit.add_background(self)
	var root := UIKit.screen_margin(self, 28)

	var head := HBoxContainer.new()
	root.add_child(head)
	var title := UIKit.label("%s   [%s]" % [Net.room_name, Net.room_code], 38, UIKit.ORANGE)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	head.add_child(UIKit.label("ROLE: " + ("HOST" if Net.is_host else "CLIENT"), 22, UIKit.GOLD))

	var net_color := UIKit.GOOD if Net.connection_label().begins_with("LOCAL") else UIKit.BAD
	root.add_child(UIKit.label(Net.connection_label(), 20, net_color))
	if Net.is_host:
		var addrs := ""
		for ip in NetUtil.get_local_ipv4_addresses():
			addrs += "%s:%d   " % [ip, Net.port]
		if addrs == "":
			addrs = "(no local IP found)"
		root.add_child(UIKit.label("Friends can join at: " + addrs, 22, UIKit.TEXT))

	var cols := HBoxContainer.new()
	cols.add_theme_constant_override("separation", 20)
	cols.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(cols)

	var left := PanelContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cols.add_child(left)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	left.add_child(scroll)
	_list = VBoxContainer.new()
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_theme_constant_override("separation", 8)
	scroll.add_child(_list)

	var right := VBoxContainer.new()
	right.custom_minimum_size = Vector2(400, 0)
	right.add_theme_constant_override("separation", 8)
	cols.add_child(right)

	var sscroll := ScrollContainer.new()
	sscroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sscroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	right.add_child(sscroll)
	var sbox := VBoxContainer.new()
	sbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sbox.add_theme_constant_override("separation", 8)
	sscroll.add_child(sbox)
	sbox.add_child(UIKit.label("Match settings", 24, UIKit.GOLD))
	if Net.is_host:
		_build_host_controls(sbox)
	else:
		_summary = UIKit.label("", 20)
		_summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		sbox.add_child(_summary)

	_status = UIKit.label("", 20, UIKit.MUTED)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	right.add_child(_status)

	if Net.is_host:
		_start_btn = UIKit.button("START MATCH", true, Vector2(0, 70))
		_start_btn.pressed.connect(func(): Net.start_match())
		right.add_child(_start_btn)
	else:
		_ready_btn = UIKit.button("READY", true, Vector2(0, 70))
		_ready_btn.pressed.connect(_toggle_ready)
		right.add_child(_ready_btn)
	var leave := UIKit.button("LEAVE ROOM", false, Vector2(0, 56))
	leave.pressed.connect(_leave)
	right.add_child(leave)

	Net.players_changed.connect(_refresh)
	_refresh()


func _option(parent: Control, caption: String, items: Array, selected: int, on_pick: Callable) -> void:
	parent.add_child(UIKit.label(caption, 18, UIKit.MUTED))
	var ob := OptionButton.new()
	for it in items:
		ob.add_item(str(it))
	ob.selected = clampi(selected, 0, items.size() - 1)
	ob.custom_minimum_size = Vector2(0, 52)
	ob.item_selected.connect(on_pick)
	parent.add_child(ob)


func _build_host_controls(box: VBoxContainer) -> void:
	var mode_labels: Array = []
	for id in GameModes.ORDER:
		mode_labels.append(GameModes.label(id))
	_option(box, "Game mode", mode_labels, GameModes.ORDER.find(str(Net.settings.get("mode"))),
		func(i: int): Net.update_setting("mode", GameModes.ORDER[i]))
	box.add_child(UIKit.label("Map: Test Arena (only map so far)", 18, UIKit.MUTED))

	var cb := CheckButton.new()
	cb.text = "Automatic balancing bot (odd player count)"
	cb.button_pressed = bool(Net.settings.get("auto_bots", true))
	cb.custom_minimum_size = Vector2(0, 52)
	cb.toggled.connect(func(on: bool): Net.update_setting("auto_bots", on))
	box.add_child(cb)
	_option(box, "Bot difficulty", ["Easy", "Normal", "Hard"], DIFFICULTIES.find(str(Net.settings.get("bot_difficulty"))),
		func(i: int): Net.update_setting("bot_difficulty", DIFFICULTIES[i]))
	_option(box, "Bot name", BOT_NAMES, BOT_NAMES.find(str(Net.settings.get("bot_name"))),
		func(i: int): Net.update_setting("bot_name", BOT_NAMES[i]))
	_option(box, "Bot appearance (non-team modes)", BOT_LOOKS, int(Net.settings.get("bot_color", 0)),
		func(i: int): Net.update_setting("bot_color", i))


func _toggle_ready() -> void:
	var me: Dictionary = Net.players.get(Net.my_id(), {})
	Net.request_ready(not bool(me.get("ready", false)))


func _leave() -> void:
	Net.leave()
	go("main_menu")


func _refresh() -> void:
	for c in _list.get_children():
		c.queue_free()
	var ids: Array = Net.players.keys()
	ids.sort_custom(func(a, b): return int(a) == 1 or (int(b) != 1 and int(a) < int(b)))
	var me := Net.my_id()
	for id in ids:
		_list.add_child(_make_row(int(id), Net.players[id], int(id) == me))

	var humans := 0
	for id in Net.players:
		if int(id) > 0:
			humans += 1
	var bots := BotBalancer.bots_needed(humans, bool(Net.settings.get("auto_bots", true)), Net.max_players)
	var bot_text := "Auto bot: +1 bot will join (%d humans is odd)." % humans if bots > 0 else "Auto bot: none (%d humans)." % humans
	if not bool(Net.settings.get("auto_bots", true)):
		bot_text = "Auto bot: OFF."

	if _summary != null:
		_summary.text = "Mode: %s\nMap: Test Arena\nBot: %s, %s\nMax players: %d" % [
			GameModes.label(str(Net.settings.get("mode"))),
			"on" if bool(Net.settings.get("auto_bots", true)) else "off",
			str(Net.settings.get("bot_difficulty", "normal")), Net.max_players]
	if Net.is_host:
		var ok := Net.all_clients_ready()
		_start_btn.disabled = not ok
		_status.text = "%d human(s). %s\n%s" % [humans, "Everyone is ready." if ok else "Waiting for players to press READY.", bot_text]
	else:
		var mine: Dictionary = Net.players.get(me, {})
		_ready_btn.text = "UNREADY" if bool(mine.get("ready", false)) else "READY"
		_status.text = "%d human(s). Waiting for the host to start.\n%s" % [humans, bot_text]


func _make_row(id: int, p: Dictionary, is_me: bool) -> Control:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UIKit.box(UIKit.CHARCOAL, UIKit.ORANGE if is_me else UIKit.BORDER, 10, 2, 8))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	panel.add_child(row)
	var name_text := str(p["name"]) + ("  (you)" if is_me else "")
	var nm := UIKit.label(name_text, 24)
	nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(nm)
	if id == 1:
		row.add_child(UIKit.label("HOST", 18, UIKit.GOLD))
	var team := int(p["team"])
	if is_me:
		var tb := UIKit.button(TEAM_NAMES[team], false, Vector2(130, 52))
		tb.pressed.connect(func(): Net.request_team(1 - team))
		row.add_child(tb)
	else:
		row.add_child(UIKit.label(TEAM_NAMES[team], 20, UIKit.ORANGE if team == 0 else Color("3fa9f5")))
	row.add_child(UIKit.label("%d ms" % int(p["ping"]), 18, UIKit.MUTED))
	row.add_child(UIKit.label("READY" if bool(p["ready"]) else "...", 20, UIKit.GOOD if bool(p["ready"]) else UIKit.MUTED))
	if Net.is_host and id != 1:
		var kick := UIKit.button("KICK", false, Vector2(90, 52))
		kick.pressed.connect(func(): Net.kick_player(id))
		row.add_child(kick)
	return panel
