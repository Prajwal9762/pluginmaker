class_name MainMenuScreen
extends ScreenBase


func _ready() -> void:
	UIKit.add_background(self)
	var root := UIKit.screen_margin(self, 48)

	var title := UIKit.label("ZORVI", 84, UIKit.ORANGE)
	root.add_child(title)
	var sub := UIKit.label("ARENA  -  " + GameConfig.TAGLINE, 22, UIKit.GOLD)
	root.add_child(sub)
	root.add_child(UIKit.spacer(10))

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 14)
	col.custom_minimum_size = Vector2(440, 0)
	root.add_child(col)

	var host := UIKit.button("HOST GAME", true, Vector2(0, 76))
	host.pressed.connect(func(): go("host"))
	col.add_child(host)
	var join := UIKit.button("JOIN GAME", false, Vector2(0, 76))
	join.pressed.connect(func(): go("join"))
	col.add_child(join)
	var games := UIKit.button("GAME COLLECTION")
	games.pressed.connect(func(): go("collection"))
	col.add_child(games)
	var settings := UIKit.button("SETTINGS")
	settings.pressed.connect(func(): go("settings"))
	col.add_child(settings)
	if not OS.has_feature("mobile"):
		var quit := UIKit.button("QUIT")
		quit.pressed.connect(func(): get_tree().quit())
		col.add_child(quit)

	var fill := Control.new()
	fill.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(fill)
	root.add_child(UIKit.label("Playing as %s  (%s)   |   v%s   |   Offline: local Wi-Fi / hotspot only, no internet used" % [GameConfig.username, GameConfig.player_id, GameConfig.VERSION], 18, UIKit.MUTED))
