class_name ScreenBase
extends Control
## Base class for full-screen UI pages. A screen asks AppRoot to switch pages
## by emitting `navigate` (it never changes the scene tree itself).

signal navigate(target: String, args: Dictionary)


func _init() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = UIKit.theme()


func go(target: String, args := {}) -> void:
	navigate.emit(target, args)
