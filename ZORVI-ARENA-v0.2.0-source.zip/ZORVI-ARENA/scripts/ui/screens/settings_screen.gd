class_name SettingsScreen
extends ScreenBase

const QUALITY := ["Low", "Medium", "High"]
const FPS := [30, 60, 0]  # 0 = unlimited

var _name: LineEdit
var _quality: OptionButton
var _fps: OptionButton
var _sfx: HSlider
var _music: HSlider
var _sens: HSlider
var _ctrl: HSlider
var _bots: CheckButton
var _diff: OptionButton
var _confirm: ConfirmationDialog

const DIFFICULTIES := ["easy", "normal", "hard"]


func _ready() -> void:
	UIKit.add_background(self)
	var root := UIKit.screen_margin(self, 32)
	root.add_child(UIKit.label("SETTINGS", 44, UIKit.ORANGE))

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(scroll)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 8)
	scroll.add_child(col)

	col.add_child(UIKit.label("Username", 20, UIKit.GOLD))
	_name = LineEdit.new()
	_name.text = GameConfig.username
	_name.max_length = 16
	_name.custom_minimum_size = Vector2(0, 58)
	col.add_child(_name)
	col.add_child(UIKit.label("Player ID: " + GameConfig.player_id, 18, UIKit.MUTED))

	col.add_child(UIKit.label("Graphics quality", 20, UIKit.GOLD))
	_quality = OptionButton.new()
	for q in QUALITY:
		_quality.add_item(q)
	_quality.selected = GameConfig.graphics_quality
	_quality.custom_minimum_size = Vector2(0, 58)
	col.add_child(_quality)

	col.add_child(UIKit.label("Frame rate limit", 20, UIKit.GOLD))
	_fps = OptionButton.new()
	for f in FPS:
		_fps.add_item("Unlimited" if f == 0 else "%d FPS" % f)
	_fps.selected = maxi(FPS.find(GameConfig.max_fps), 0)
	_fps.custom_minimum_size = Vector2(0, 58)
	col.add_child(_fps)

	_sfx = _slider(col, "Audio volume", GameConfig.sfx_volume, 0.0, 1.0)
	_music = _slider(col, "Music volume", GameConfig.music_volume, 0.0, 1.0)
	_sens = _slider(col, "Camera sensitivity", GameConfig.sensitivity, 0.2, 3.0)
	_ctrl = _slider(col, "Touch control size", GameConfig.control_scale, 0.6, 1.6)

	col.add_child(UIKit.label("Bot settings (used when you host)", 20, UIKit.GOLD))
	_bots = CheckButton.new()
	_bots.text = "Automatic balancing bot"
	_bots.button_pressed = GameConfig.auto_bots
	_bots.custom_minimum_size = Vector2(0, 52)
	col.add_child(_bots)
	_diff = OptionButton.new()
	for d in DIFFICULTIES:
		_diff.add_item(str(d).capitalize())
	_diff.selected = maxi(DIFFICULTIES.find(GameConfig.bot_difficulty), 0)
	_diff.custom_minimum_size = Vector2(0, 52)
	col.add_child(_diff)

	col.add_child(UIKit.spacer(8))
	var reset := UIKit.button("RESET LOCAL DATA")
	reset.pressed.connect(func(): _confirm.popup_centered(Vector2i(560, 220)))
	col.add_child(reset)

	var back := UIKit.button("SAVE AND BACK", true)
	back.pressed.connect(_save_back)
	root.add_child(back)

	_confirm = ConfirmationDialog.new()
	_confirm.dialog_text = "Reset username, settings and all local data on this device?"
	_confirm.theme = UIKit.theme()
	_confirm.confirmed.connect(func():
		GameConfig.reset_all()
		go("main_menu"))
	add_child(_confirm)


func _slider(parent: Control, text: String, value: float, lo: float, hi: float) -> HSlider:
	parent.add_child(UIKit.label(text, 20, UIKit.GOLD))
	var s := HSlider.new()
	s.min_value = lo
	s.max_value = hi
	s.step = 0.05
	s.value = value
	s.custom_minimum_size = Vector2(0, 44)
	parent.add_child(s)
	return s


func _save_back() -> void:
	GameConfig.username = NetUtil.sanitize_name(_name.text, GameConfig.username)
	GameConfig.graphics_quality = _quality.selected
	GameConfig.max_fps = FPS[_fps.selected]
	GameConfig.sfx_volume = _sfx.value
	GameConfig.music_volume = _music.value
	GameConfig.sensitivity = _sens.value
	GameConfig.control_scale = _ctrl.value
	GameConfig.auto_bots = _bots.button_pressed
	GameConfig.bot_difficulty = DIFFICULTIES[_diff.selected]
	GameConfig.save_settings()
	GameConfig.apply()
	go("main_menu")
