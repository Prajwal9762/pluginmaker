class_name SplashScreen
extends ScreenBase
## Animated ZORVI logo. Tap anywhere to skip.

var _done := false
var _tween: Tween


func _ready() -> void:
	UIKit.add_background(self)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 4)
	center.add_child(box)

	var logo := _centered("ZORVI", 128, UIKit.ORANGE)
	var studios := _centered("S T U D I O S", 24, UIKit.GOLD)
	var line := ColorRect.new()
	line.color = UIKit.ORANGE
	line.custom_minimum_size = Vector2(0, 5)
	var arena := _centered("ARENA", 56, UIKit.TEXT)
	var tag := _centered(GameConfig.TAGLINE, 22, UIKit.MUTED)
	for n in [logo, studios, line, arena, tag]:
		n.modulate.a = 0.0
		box.add_child(n)

	_tween = create_tween()
	_tween.tween_property(logo, "modulate:a", 1.0, 0.7)
	_tween.tween_property(studios, "modulate:a", 1.0, 0.4)
	_tween.tween_property(line, "modulate:a", 1.0, 0.1)
	_tween.tween_property(line, "custom_minimum_size:x", 460.0, 0.6).set_trans(Tween.TRANS_CUBIC)
	_tween.tween_property(arena, "modulate:a", 1.0, 0.5)
	_tween.tween_property(tag, "modulate:a", 1.0, 0.5)
	_tween.tween_interval(0.8)
	_tween.tween_callback(_finish)


func _centered(text: String, size: int, color: Color) -> Label:
	var l := UIKit.label(text, size, color)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		_finish()
	elif event is InputEventScreenTouch and event.pressed:
		_finish()


func _finish() -> void:
	if _done:
		return
	_done = true
	if _tween:
		_tween.kill()
	go("main_menu")
