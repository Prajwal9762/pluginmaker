class_name TouchControls
extends Control
## Floating virtual joystick (left half of the screen) + drag-to-look (right half).
## Multi-touch aware via touch indices. Touches that start on any control listed
## in `exclude_controls` (HUD buttons) are ignored so buttons keep working.
## Desktop testing: WASD to move, right-mouse drag to look.

const RADIUS := 110.0

var exclude_controls: Array[Control] = []
var _move_id := -1
var _look_id := -1
var _origin := Vector2.ZERO
var _stick := Vector2.ZERO
var _look_accum := Vector2.ZERO


func _init() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func get_move() -> Vector2:
	var k := Vector2(
		float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A)),
		float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W)))
	if k.length() > 0.0:
		return k.normalized()
	return _stick


func consume_look() -> Vector2:
	var v := _look_accum
	_look_accum = Vector2.ZERO
	return v


func _is_excluded(pos: Vector2) -> bool:
	for c in exclude_controls:
		if is_instance_valid(c) and c.get_global_rect().has_point(pos):
			return true
	return false


func _input(event: InputEvent) -> void:
	var radius := RADIUS * GameConfig.control_scale
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			if _is_excluded(t.position):
				return
			var half := get_viewport_rect().size.x * 0.5
			if t.position.x < half and _move_id == -1:
				_move_id = t.index
				_origin = t.position
				_stick = Vector2.ZERO
				queue_redraw()
			elif t.position.x >= half and _look_id == -1:
				_look_id = t.index
		else:
			if t.index == _move_id:
				_move_id = -1
				_stick = Vector2.ZERO
				queue_redraw()
			elif t.index == _look_id:
				_look_id = -1
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		if d.index == _move_id:
			_stick = ((d.position - _origin) / radius).limit_length(1.0)
			queue_redraw()
		elif d.index == _look_id:
			_look_accum += d.relative
	elif event is InputEventMouseMotion and not OS.has_feature("mobile"):
		var m := event as InputEventMouseMotion
		if m.button_mask & MOUSE_BUTTON_MASK_RIGHT:
			_look_accum += m.relative


func _draw() -> void:
	if _move_id == -1:
		return
	var radius := RADIUS * GameConfig.control_scale
	draw_circle(_origin, radius, Color(1, 1, 1, 0.07))
	draw_arc(_origin, radius, 0.0, TAU, 48, Color(UIKit.ORANGE, 0.6), 3.0)
	draw_circle(_origin + _stick * radius, radius * 0.38, Color(UIKit.ORANGE, 0.85))
