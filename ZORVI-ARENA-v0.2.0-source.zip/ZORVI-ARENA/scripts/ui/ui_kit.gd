class_name UIKit
extends RefCounted
## ZORVI brand theme + small helpers for building UI in code.

const BG := Color("0b0b0d")
const CHARCOAL := Color("17181b")
const PANEL := Color("1f2024")
const BORDER := Color("34353b")
const ORANGE := Color("ff7a1a")
const ORANGE_DARK := Color("c85a0a")
const GOLD := Color("f5b335")
const TEXT := Color("ecebe8")
const MUTED := Color("8d8f96")
const GOOD := Color("4ad28a")
const BAD := Color("ff5560")

static var _theme: Theme


static func box(bg: Color, border := Color.TRANSPARENT, radius := 10, bw := 0, pad := 14) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_corner_radius_all(radius)
	s.set_border_width_all(bw)
	s.content_margin_left = pad + 4
	s.content_margin_right = pad + 4
	s.content_margin_top = pad
	s.content_margin_bottom = pad
	return s


static func theme() -> Theme:
	if _theme:
		return _theme
	var t := Theme.new()
	t.default_font_size = 22
	t.set_color("font_color", "Label", TEXT)
	for type in ["Button", "OptionButton", "CheckButton"]:
		t.set_stylebox("normal", type, box(PANEL, BORDER, 10, 2))
		t.set_stylebox("hover", type, box(CHARCOAL, ORANGE, 10, 2))
		t.set_stylebox("pressed", type, box(ORANGE_DARK, ORANGE, 10, 2))
		t.set_stylebox("disabled", type, box(CHARCOAL, BORDER, 10, 1))
		t.set_stylebox("focus", type, StyleBoxEmpty.new())
		t.set_color("font_color", type, TEXT)
		t.set_color("font_hover_color", type, Color.WHITE)
		t.set_color("font_pressed_color", type, Color.WHITE)
		t.set_color("font_disabled_color", type, MUTED)
	t.set_stylebox("normal", "LineEdit", box(BG, BORDER, 8, 2, 10))
	t.set_stylebox("focus", "LineEdit", box(BG, ORANGE, 8, 2, 10))
	t.set_color("font_color", "LineEdit", TEXT)
	t.set_color("font_placeholder_color", "LineEdit", MUTED)
	t.set_color("caret_color", "LineEdit", ORANGE)
	t.set_stylebox("panel", "PanelContainer", box(PANEL, BORDER, 14, 2, 16))
	t.set_stylebox("panel", "PopupMenu", box(CHARCOAL, ORANGE, 8, 2, 8))
	t.set_stylebox("hover", "PopupMenu", box(ORANGE_DARK, Color.TRANSPARENT, 6, 0, 8))
	t.set_stylebox("panel", "PopupPanel", box(CHARCOAL, ORANGE, 8, 2, 8))
	t.set_stylebox("panel", "AcceptDialog", box(CHARCOAL, ORANGE, 12, 2, 16))
	t.set_stylebox("slider", "HSlider", box(BORDER, Color.TRANSPARENT, 6, 0, 4))
	t.set_stylebox("grabber_area", "HSlider", box(ORANGE, Color.TRANSPARENT, 6, 0, 4))
	t.set_stylebox("grabber_area_highlight", "HSlider", box(GOLD, Color.TRANSPARENT, 6, 0, 4))
	_theme = t
	return t


static func label(text: String, size := 22, color := TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


static func button(text: String, primary := false, min_size := Vector2(0, 64)) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	if primary:
		b.add_theme_stylebox_override("normal", box(ORANGE, GOLD, 10, 2))
		b.add_theme_stylebox_override("hover", box(GOLD, GOLD, 10, 2))
		b.add_theme_stylebox_override("pressed", box(ORANGE_DARK, GOLD, 10, 2))
		b.add_theme_color_override("font_color", Color.BLACK)
		b.add_theme_color_override("font_hover_color", Color.BLACK)
		b.add_theme_color_override("font_pressed_color", Color.WHITE)
	return b


## A card with a coloured title line and a wrapped description line.
static func panel_row(title: String, body: String, title_color := ORANGE) -> PanelContainer:
	var p := PanelContainer.new()
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	p.add_child(v)
	v.add_child(label(title, 24, title_color))
	var b := label(body, 20, TEXT)
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b.custom_minimum_size = Vector2(300, 0)
	v.add_child(b)
	return p


static func spacer(h: float) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	return c


static func add_background(parent: Control) -> void:
	var bg := ColorRect.new()
	bg.color = BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(bg)
	var bar := ColorRect.new()
	bar.color = ORANGE
	bar.anchor_right = 1.0
	bar.offset_bottom = 5.0
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(bar)


## corner: "tl", "tr", "bl", "br"
static func place_corner(c: Control, corner: String, margin: float, size: Vector2) -> void:
	c.custom_minimum_size = size
	var right := corner.ends_with("r")
	var bottom := corner.begins_with("b")
	c.anchor_left = 1.0 if right else 0.0
	c.anchor_right = c.anchor_left
	c.anchor_top = 1.0 if bottom else 0.0
	c.anchor_bottom = c.anchor_top
	c.offset_left = -(margin + size.x) if right else margin
	c.offset_right = -margin if right else margin + size.x
	c.offset_top = -(margin + size.y) if bottom else margin
	c.offset_bottom = -margin if bottom else margin + size.y


static func screen_margin(parent: Control, m := 40) -> VBoxContainer:
	var mc := MarginContainer.new()
	mc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		mc.add_theme_constant_override("margin_" + side, m)
	parent.add_child(mc)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	mc.add_child(v)
	return v
