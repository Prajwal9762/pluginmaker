extends SceneTree
## Headless unit tests for pure networking helpers.
## Run:  godot --headless --path . -s tests/run_tests.gd
## (run `godot --headless --path . --import` once first so class_names resolve)

var failures := 0
var checks := 0


func _init() -> void:
	_test_room_code()
	_test_ipv4()
	_test_private_ranges()
	_test_broadcast()
	_test_packets()
	_test_names()
	_test_bot_rule()
	_test_team_balance()
	_test_modes()
	print("tests: %d checks, %d failed" % [checks, failures])
	quit(1 if failures > 0 else 0)


func check(cond: bool, msg: String) -> void:
	checks += 1
	if not cond:
		failures += 1
		printerr("FAIL: " + msg)


func _test_room_code() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 42
	for i in 200:
		var c := NetUtil.generate_room_code(rng)
		check(c.length() == 4, "room code length")
		for ch in c:
			check(NetUtil.CODE_CHARS.contains(ch), "room code charset: " + c)


func _test_ipv4() -> void:
	check(NetUtil.is_valid_ipv4("192.168.43.1"), "valid ip")
	check(not NetUtil.is_valid_ipv4("192.168.43"), "too few octets")
	check(not NetUtil.is_valid_ipv4("256.1.1.1"), "octet > 255")
	check(not NetUtil.is_valid_ipv4("a.b.c.d"), "letters")
	check(not NetUtil.is_valid_ipv4(""), "empty")
	check(not NetUtil.is_valid_ipv4("1.2.3.4.5"), "too many octets")


func _test_private_ranges() -> void:
	check(NetUtil.is_private_ipv4("192.168.0.5"), "192.168/16")
	check(NetUtil.is_private_ipv4("10.1.2.3"), "10/8")
	check(NetUtil.is_private_ipv4("172.20.10.1"), "172.16/12 (iOS hotspot)")
	check(not NetUtil.is_private_ipv4("172.32.0.1"), "172.32 is public")
	check(not NetUtil.is_private_ipv4("8.8.8.8"), "public ip rejected")
	check(NetUtil.is_loopback("127.0.0.1"), "loopback")
	check(not NetUtil.is_loopback("192.168.1.1"), "not loopback")


func _test_broadcast() -> void:
	check(NetUtil.directed_broadcast("192.168.43.1") == "192.168.43.255", "directed broadcast")
	check(NetUtil.directed_broadcast("nope") == "", "invalid broadcast input")


func _test_packets() -> void:
	var info := {"name": "Room", "code": "AB23", "port": 47778, "n": 3, "max": 10}
	var d := NetUtil.decode_room_info(NetUtil.encode_room_info(info))
	check(d.get("code") == "AB23" and int(d.get("port")) == 47778, "packet roundtrip")
	check(NetUtil.decode_room_info("garbage".to_utf8_buffer()).is_empty(), "garbage rejected")
	check(NetUtil.decode_room_info('{"m":"OTHER","name":"x","port":1}'.to_utf8_buffer()).is_empty(), "wrong magic rejected")
	check(NetUtil.decode_room_info(PackedByteArray()).is_empty(), "empty rejected")
	var big := PackedByteArray()
	big.resize(600)
	check(NetUtil.decode_room_info(big).is_empty(), "oversize rejected")


func _test_names() -> void:
	check(NetUtil.sanitize_name("   ") == "Player", "blank name fallback")
	check(NetUtil.sanitize_name("abcdefghijklmnopqrstuvwxyz").length() == 16, "name truncated")


func _test_bot_rule() -> void:
	# humans -> total players (bots on, max 10): the spec table
	var expect := {1: 2, 2: 2, 3: 4, 4: 4, 5: 6, 6: 6, 7: 8, 8: 8, 9: 10, 10: 10}
	for h in expect:
		var bots := BotBalancer.bots_needed(h, true, 10)
		check(h + bots == expect[h], "humans %d -> total %d" % [h, expect[h]])
		check(bots <= 1, "never more than one bot")
		check(BotBalancer.bots_needed(h, false, 10) == 0, "bots off -> none (%d humans)" % h)
	check(BotBalancer.bots_needed(9, true, 9) == 0, "never exceed room max")
	check(BotBalancer.bots_needed(0, true, 10) == 0, "no humans -> no bot")


func _team_sizes(res: Dictionary, bots: int) -> Array:
	var c := [0, 0]
	for id in res["teams"]:
		c[int(res["teams"][id])] += 1
	if bots > 0:
		c[int(res["bot_team"])] += 1
	return c


func _test_team_balance() -> void:
	var r3 := BotBalancer.balance_teams({1: 0, 11: 0, 12: 1}, 1)
	var s3 := _team_sizes(r3, 1)
	check(s3[0] == 2 and s3[1] == 2, "3 humans + bot -> 2v2")
	check(int(r3["bot_team"]) == 1, "bot joins the smaller team (3 humans)")
	var r5 := BotBalancer.balance_teams({1: 0, 11: 0, 12: 0, 13: 1, 14: 1}, 1)
	var s5 := _team_sizes(r5, 1)
	check(s5[0] == 3 and s5[1] == 3, "5 humans + bot -> 3v3")
	var r4 := BotBalancer.balance_teams({1: 0, 11: 0, 12: 0, 13: 0}, 0)
	var s4 := _team_sizes(r4, 0)
	check(s4[0] == 2 and s4[1] == 2, "4 lopsided humans rebalanced to 2v2")
	var r1 := BotBalancer.balance_teams({1: 0}, 1)
	var s1 := _team_sizes(r1, 1)
	check(s1[0] == 1 and s1[1] == 1, "1 human + bot -> 1v1")
	for n in range(1, 11):
		var humans := {}
		for i in n:
			humans[i + 1] = 0  # everyone starts on team A
		var bots := BotBalancer.bots_needed(n, true, 10)
		var res := BotBalancer.balance_teams(humans, bots)
		var s := _team_sizes(res, bots)
		check(absi(s[0] - s[1]) <= 1, "teams within 1 for %d humans" % n)
		if (n + bots) % 2 == 0:
			check(s[0] == s[1], "equal teams for %d humans" % n)


func _test_modes() -> void:
	for id in GameModes.ORDER:
		var m := GameModes.get_mode(id)
		check(m.has("label") and m.has("combat") and m.has("teams"), "mode fields: " + id)
		check(Weapons.DATA.has(str(m["weapon"])), "mode weapon exists: " + id)
	check(GameModes.get_mode("nonsense")["label"] == GameModes.get_mode("free_roam")["label"], "unknown mode falls back")
