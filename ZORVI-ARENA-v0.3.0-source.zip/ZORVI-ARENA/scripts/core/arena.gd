class_name Arena
extends Node3D
## The match scene. One map ("Test Arena"), modes from GameModes:
## Team Deathmatch, Free-for-All, Sniper Only and Free Roam (movement test).
##
## Networking model (host-authoritative):
##  * Client -> host: input (stick, camera yaw, jump/fire/reload held) at 30 Hz, unreliable.
##  * Host: simulates EVERY avatar (humans from received input, bots from BotBrain),
##    performs hitscan shots, applies damage, handles kills/respawns/score/timer.
##  * Host -> clients: positions, yaws, hp, ammo at 20 Hz (unreliable_ordered) only to
##    peers whose Arena is loaded; scores/time at 2 Hz and kill feed/shot effects/
##    results as events. Bots are host-simulated and appear to clients as ordinary
##    avatars (negative id); clients never control a bot.
##  * Client predicts its own movement and gently reconciles toward the host;
##    other avatars are exponentially smoothed (not a full interpolation buffer).

signal leave_requested

const SEND_INTERVAL := 1.0 / 20.0
const INPUT_INTERVAL := 1.0 / 30.0
const SCORE_INTERVAL := 0.5
const SNAP_DISTANCE := 1.5
const RESPAWN_TIME := 3.0
const TEAM_COLORS := [Color("ff7a1a"), Color("3fa9f5")]
const FFA_COLORS := [Color("ff7a1a"), Color("3fa9f5"), Color("4ad28a"), Color("f5b335"), Color("c76bff"), Color("ff5560"), Color("37d6d6"), Color("e8e8e8"), Color("9aff5a"), Color("ff8fc7")]
const BOT_COLORS := [Color("8d8f96"), Color("b02a30"), Color("2f8f4e"), Color("7a4bd1"), Color("e8e8e8")]

var avatars: Dictionary = {}       # id -> PlayerAvatar (bots have negative ids)
var _mode: Dictionary
var _combat := false
var _teams_mode := false
var _weapon: Dictionary
var _rng := RandomNumberGenerator.new()

# host only
var _inputs: Dictionary = {}       # peer_id -> {move, yaw, jump, fire, reload}
var _ready_peers: Array[int] = []
var _brains: Dictionary = {}       # bot id -> BotBrain
var _team_scores := [0, 0]
var _score_accum := 0.0
var _send_accum := 0.0

# shared (host computes; clients mirror via RPC)
var _scores: Dictionary = {}       # id -> [kills, deaths]
var _time_left := 0.0
var _over := false

# client input
var _cam: Camera3D
var _cam_yaw := 0.0
var _cam_pitch := -0.2
var _touch: TouchControls
var _jump_held := false
var _fire_held := false
var _reload_held := false
var _input_accum := 0.0

# HUD
var _info: Label
var _timer_label: Label
var _score_label: Label
var _feed_label: Label
var _center_msg: Label
var _hp_label: Label
var _hp_bar: ProgressBar
var _hp_fill: StyleBoxFlat
var _ammo_label: Label
var _damage_flash: ColorRect
var _minimap: Minimap
var _last_hp := 100
var _info_accum := 0.0
var _feed: Array = []              # [{text, until}]


func _ready() -> void:
	_mode = GameModes.get_mode(str(Net.settings.get("mode", "free_roam")))
	_combat = bool(_mode["combat"])
	_teams_mode = bool(_mode["teams"])
	_weapon = Weapons.get_weapon(str(_mode["weapon"]))
	_time_left = float(_mode["time"])
	_rng.randomize()
	_build_world()
	_build_hud()
	Net.player_left.connect(_on_player_left)
	if multiplayer.is_server():
		_host_add_player(1)
		for id in Net.players.keys():
			if int(id) != 1 and bool(Net.players[id].get("bot", false)):
				_host_add_player(int(id))
	else:
		report_ready.rpc_id(1)


# ---------------------------------------------------------- queries for bots

func is_combat() -> bool:
	return _combat and not _over


func weapon_mag() -> int:
	return int(_weapon["mag"])


func enemies_of(a: PlayerAvatar) -> Array:
	var out: Array = []
	for id in avatars:
		var e: PlayerAvatar = avatars[id]
		if e != a and e.alive and _can_damage(a, e):
			out.append(e)
	return out


func has_line_of_sight(a: PlayerAvatar, b: PlayerAvatar) -> bool:
	var q := PhysicsRayQueryParameters3D.create(a.global_position + Vector3(0, 1.3, 0), b.global_position + Vector3(0, 1.3, 0))
	q.exclude = [a.get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	return hit.is_empty() or hit["collider"] == b


# ------------------------------------------------------------------- world

func _build_world() -> void:
	var q := GameConfig.graphics_quality
	get_viewport().msaa_3d = Viewport.MSAA_2X if q >= 2 else Viewport.MSAA_DISABLED

	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("3d6fb0")
	sky_mat.sky_horizon_color = Color("b9c9d8")
	sky_mat.ground_horizon_color = Color("b9c9d8")
	sky_mat.ground_bottom_color = Color("6e6a5c")
	var sky := Sky.new()
	sky.sky_material = sky_mat
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = q >= 1
	env.fog_light_color = Color("b9c9d8")
	env.fog_density = 0.004
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, 40, 0)
	sun.light_color = Color(1.0, 0.95, 0.85)
	sun.light_energy = 1.15
	sun.shadow_enabled = q >= 1
	sun.directional_shadow_max_distance = 60.0
	add_child(sun)

	ArenaMap.new().build(self, q)

	_cam = Camera3D.new()
	_cam.far = 260.0
	_cam.fov = 70.0
	add_child(_cam)
	_cam.make_current()


func _build_hud() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 5
	add_child(layer)
	var hud := Control.new()
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.theme = UIKit.theme()
	layer.add_child(hud)

	_touch = TouchControls.new()
	hud.add_child(_touch)

	var s := GameConfig.control_scale
	var dim := UIKit.box(Color(0, 0, 0, 0.5), Color.TRANSPARENT, 8, 0, 6)

	# Red flash when you take damage.
	_damage_flash = ColorRect.new()
	_damage_flash.color = Color(0.85, 0.05, 0.05, 0.0)
	_damage_flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_damage_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(_damage_flash)

	# Small connection line (top-left) + minimap + kill feed underneath.
	_info = UIKit.label("", 15, Color(1, 1, 1, 0.9))
	_info.add_theme_stylebox_override("normal", dim)
	_info.position = Vector2(16, 12)
	hud.add_child(_info)

	_minimap = Minimap.new()
	_minimap.arena = self
	_minimap.position = Vector2(16, 54)
	hud.add_child(_minimap)

	_feed_label = UIKit.label("", 18, UIKit.TEXT)
	_feed_label.position = Vector2(16, 214)
	_feed_label.size = Vector2(460, 120)
	hud.add_child(_feed_label)

	# Timer + team score pill (top-centre).
	_timer_label = UIKit.label("", 26, UIKit.GOLD)
	_timer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_timer_label.add_theme_stylebox_override("normal", dim)
	_timer_label.anchor_left = 0.5
	_timer_label.anchor_right = 0.5
	_timer_label.offset_left = -110
	_timer_label.offset_right = 110
	_timer_label.offset_top = 10
	_timer_label.offset_bottom = 80
	_timer_label.visible = _combat
	hud.add_child(_timer_label)

	# Exit + compact scoreboard (top-right).
	var leave := UIKit.button("END MATCH" if Net.is_host else "LEAVE", false, Vector2.ZERO)
	leave.add_theme_font_size_override("font_size", 18)
	UIKit.place_corner(leave, "tr", 16, Vector2(150, 48))
	leave.pressed.connect(func(): leave_requested.emit())
	hud.add_child(leave)

	_score_label = UIKit.label("", 16, UIKit.TEXT)
	_score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_score_label.add_theme_stylebox_override("normal", dim)
	UIKit.place_corner(_score_label, "tr", 16, Vector2(250, 130))
	_score_label.offset_top += 62
	_score_label.offset_bottom += 62
	_score_label.visible = _combat
	hud.add_child(_score_label)

	# Crosshair (marks where shots travel).
	var cross := Control.new()
	cross.anchor_left = 0.5
	cross.anchor_right = 0.5
	cross.anchor_top = 0.5
	cross.anchor_bottom = 0.5
	cross.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cross.visible = _combat
	hud.add_child(cross)
	for r in [Rect2(-1.5, -20, 3, 12), Rect2(-1.5, 8, 3, 12), Rect2(-20, -1.5, 12, 3), Rect2(8, -1.5, 12, 3), Rect2(-1.5, -1.5, 3, 3)]:
		var tick := ColorRect.new()
		tick.color = Color(1, 1, 1, 0.85)
		tick.position = r.position
		tick.size = r.size
		tick.mouse_filter = Control.MOUSE_FILTER_IGNORE
		cross.add_child(tick)

	# Health bar (bottom-centre).
	var hp_box := VBoxContainer.new()
	hp_box.anchor_left = 0.5
	hp_box.anchor_right = 0.5
	hp_box.anchor_top = 1.0
	hp_box.anchor_bottom = 1.0
	hp_box.offset_left = -170
	hp_box.offset_right = 170
	hp_box.offset_top = -62
	hp_box.offset_bottom = -16
	hp_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hp_box.visible = _combat
	_hp_label = UIKit.label("HP 100", 18, UIKit.TEXT)
	_hp_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hp_box.add_child(_hp_label)
	_hp_bar = ProgressBar.new()
	_hp_bar.max_value = PlayerAvatar.MAX_HP
	_hp_bar.value = PlayerAvatar.MAX_HP
	_hp_bar.show_percentage = false
	_hp_bar.custom_minimum_size = Vector2(0, 18)
	_hp_fill = UIKit.box(UIKit.GOOD, Color.TRANSPARENT, 6, 0, 0)
	_hp_bar.add_theme_stylebox_override("fill", _hp_fill)
	_hp_bar.add_theme_stylebox_override("background", UIKit.box(Color(0, 0, 0, 0.55), Color.TRANSPARENT, 6, 0, 0))
	hp_box.add_child(_hp_bar)
	hud.add_child(hp_box)

	# Action buttons (bottom-right): FIRE big, JUMP left of it, RELOAD above JUMP.
	var fire := UIKit.button("FIRE", true, Vector2.ZERO)
	UIKit.place_corner(fire, "br", 36, Vector2(180, 180) * s)
	fire.button_down.connect(func(): _fire_held = true)
	fire.button_up.connect(func(): _fire_held = false)
	fire.visible = _combat
	hud.add_child(fire)

	var jump := UIKit.button("JUMP", false, Vector2.ZERO)
	UIKit.place_corner(jump, "br", 36, Vector2(120, 120) * s)
	jump.offset_left -= 200 * s
	jump.offset_right -= 200 * s
	jump.button_down.connect(func(): _jump_held = true)
	jump.button_up.connect(func(): _jump_held = false)
	hud.add_child(jump)

	var reload := UIKit.button("RELOAD", false, Vector2.ZERO)
	UIKit.place_corner(reload, "br", 36, Vector2(120, 90) * s)
	reload.offset_left -= 200 * s
	reload.offset_right -= 200 * s
	reload.offset_top -= 140 * s
	reload.offset_bottom -= 140 * s
	reload.button_down.connect(func(): _reload_held = true)
	reload.button_up.connect(func(): _reload_held = false)
	reload.visible = _combat
	hud.add_child(reload)

	# Weapon + ammo (above FIRE).
	_ammo_label = UIKit.label("", 26, UIKit.TEXT)
	_ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_ammo_label.add_theme_stylebox_override("normal", dim)
	UIKit.place_corner(_ammo_label, "br", 36, Vector2(200, 72))
	_ammo_label.offset_top -= 192 * s
	_ammo_label.offset_bottom -= 192 * s
	_ammo_label.visible = _combat
	hud.add_child(_ammo_label)

	_center_msg = UIKit.label("", 30, UIKit.TEXT)
	_center_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_center_msg.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_center_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_center_msg.add_theme_stylebox_override("normal", UIKit.box(Color(0, 0, 0, 0.78), UIKit.ORANGE, 12, 2, 16))
	_center_msg.anchor_left = 0.25
	_center_msg.anchor_right = 0.75
	_center_msg.anchor_top = 0.2
	_center_msg.anchor_bottom = 0.8
	_center_msg.visible = false
	hud.add_child(_center_msg)

	_touch.exclude_controls = [leave, fire, jump, reload]


# ---------------------------------------------------------------- spawning

func _spawn_position(index: int) -> Vector3:
	var n: int = ArenaMap.SPAWNS.size()
	return ArenaMap.SPAWNS[index % n] + Vector3(floorf(float(index) / float(n)) * 1.5, 0.0, 0.0)


func _make_info(id: int) -> Dictionary:
	var p: Dictionary = Net.players.get(id, {"name": "Player", "team": 0})
	var is_bot := bool(p.get("bot", false))
	var ids: Array = Net.players.keys()
	ids.sort()
	var idx := maxi(ids.find(id), 0)
	var team := int(p.get("team", 0))
	var color: Color
	if _teams_mode:
		color = TEAM_COLORS[team]
	elif is_bot:
		color = BOT_COLORS[clampi(int(Net.settings.get("bot_color", 0)), 0, BOT_COLORS.size() - 1)]
	else:
		color = FFA_COLORS[idx % FFA_COLORS.size()]
	return {"id": id, "name": str(p["name"]), "team": team, "bot": is_bot, "color": color, "pos": _spawn_position(idx)}


func _spawn_avatar(info: Dictionary) -> void:
	var id: int = info["id"]
	if avatars.has(id):
		return
	var a := PlayerAvatar.new()
	a.is_bot = bool(info["bot"])
	a.team = int(info["team"])
	a.weapon_id = str(_mode["weapon"])
	a.setup(id, str(info["name"]), info["color"], info["pos"])
	a.ammo = int(_weapon["mag"])
	a.remote_driven = (not multiplayer.is_server()) and id != multiplayer.get_unique_id()
	add_child(a)
	avatars[id] = a


func _host_add_player(id: int) -> void:
	if avatars.has(id) or not Net.players.has(id):
		return
	var is_bot := bool(Net.players[id].get("bot", false))
	var info := _make_info(id)
	_spawn_avatar(info)
	if is_bot:
		_brains[id] = BotBrain.new(str(Net.settings.get("bot_difficulty", "normal")))
	if not is_bot and id != 1:
		var all: Array = []
		for existing in avatars:
			all.append(info if int(existing) == id else _make_info(int(existing)))
		spawn_many.rpc_id(id, all)
	if id != 1:
		for other in _ready_peers:
			if other != 1 and other != id:
				spawn_many.rpc_id(other, [info])
	if not is_bot:
		_ready_peers.append(id)


func _on_player_left(id: int) -> void:
	if not multiplayer.is_server():
		return
	_ready_peers.erase(id)
	_inputs.erase(id)
	_remove_avatar(id)
	for other in _ready_peers:
		if other != 1:
			despawn.rpc_id(other, id)
	if _teams_mode:
		pass  # teams are not re-balanced mid-match (planned)


func _remove_avatar(id: int) -> void:
	if avatars.has(id):
		avatars[id].queue_free()
		avatars.erase(id)
	_brains.erase(id)


# --------------------------------------------------------------------- RPCs

@rpc("any_peer", "reliable")
func report_ready() -> void:
	if multiplayer.is_server():
		_host_add_player(multiplayer.get_remote_sender_id())


@rpc("authority", "reliable")
func spawn_many(infos: Array) -> void:
	for info in infos:
		_spawn_avatar(info)


@rpc("authority", "reliable")
func despawn(id: int) -> void:
	_remove_avatar(id)


@rpc("any_peer", "unreliable_ordered")
func submit_input(move: Vector2, yaw: float, jump: bool, fire: bool, reload: bool) -> void:
	if not multiplayer.is_server():
		return
	if not (is_finite(move.x) and is_finite(move.y) and is_finite(yaw)):
		return
	_inputs[multiplayer.get_remote_sender_id()] = {"move": move.limit_length(1.0), "yaw": yaw, "jump": jump, "fire": fire, "reload": reload}


@rpc("authority", "unreliable_ordered")
func apply_state(ids: PackedInt32Array, positions: PackedVector3Array, yaws: PackedFloat32Array, hps: PackedInt32Array, ammos: PackedInt32Array) -> void:
	var me := multiplayer.get_unique_id()
	for i in ids.size():
		var a: PlayerAvatar = avatars.get(ids[i])
		if a == null:
			continue
		a.hp = hps[i]
		a.ammo = ammos[i]
		var alive_now := hps[i] > 0
		if a.alive != alive_now:
			a.set_alive(alive_now)
			a.global_position = positions[i]
		if ids[i] == me:
			var err := positions[i] - a.global_position
			if err.length() > SNAP_DISTANCE:
				a.global_position = positions[i]
			else:
				a.global_position += err * 0.15
		else:
			a.target_pos = positions[i]
			a.target_yaw = yaws[i]


@rpc("authority", "unreliable_ordered")
func apply_scores(scores: Dictionary, team_scores: Array, time_left: int) -> void:
	_scores = scores
	_team_scores = team_scores
	_time_left = float(time_left)


@rpc("authority", "reliable")
func kill_feed(killer: String, victim: String) -> void:
	_push_feed("%s  >  %s" % [killer, victim])


@rpc("authority", "unreliable")
func fx_shot(from: Vector3, to: Vector3) -> void:
	_spawn_tracer(from, to)
	_flash_near(from)


@rpc("authority", "reliable")
func show_results(title: String, lines: Array) -> void:
	_show_results(title, lines)


# --------------------------------------------------------------------- loop

func _physics_process(delta: float) -> void:
	var move := _touch.get_move()
	var jump := _jump_held or Input.is_key_pressed(KEY_SPACE)
	var fire := _fire_held or Input.is_key_pressed(KEY_F)
	var reload := _reload_held or Input.is_key_pressed(KEY_R)
	var look := _touch.consume_look()
	_cam_yaw -= look.x * 0.005 * GameConfig.sensitivity
	_cam_pitch = clampf(_cam_pitch - look.y * 0.004 * GameConfig.sensitivity, -0.6, 0.15)
	var me := multiplayer.get_unique_id()

	if multiplayer.is_server():
		_host_tick(delta, me, move, jump, fire, reload)
	else:
		var mine: PlayerAvatar = avatars.get(me)
		if mine and mine.alive and not _over:
			mine.step(move, _cam_yaw, jump, delta, _cam_yaw if fire else NAN)
		_input_accum += delta
		if _input_accum >= INPUT_INTERVAL:
			_input_accum = 0.0
			submit_input.rpc_id(1, move, _cam_yaw, jump, fire, reload)


func _host_tick(delta: float, me: int, move: Vector2, jump: bool, fire: bool, reload: bool) -> void:
	if _combat and not _over and _time_left > 0.0:
		_time_left -= delta
		if _time_left <= 0.0:
			_time_left = 0.0
			_end_match()

	for id in avatars:
		var a: PlayerAvatar = avatars[id]
		var m := Vector2.ZERO
		var yaw := 0.0
		var j := false
		var f := false
		var r := false
		var cam_for_move := 0.0
		if id == me:
			m = move
			yaw = _cam_yaw
			cam_for_move = _cam_yaw
			j = jump
			f = fire
			r = reload
		elif a.is_bot:
			if _brains.has(id):
				var d: Dictionary = _brains[id].think(a, delta, self)
				m = d["move"]
				yaw = float(d["yaw"])
				j = bool(d["jump"])
				f = bool(d["fire"])
				r = bool(d["reload"])
		else:
			var inp: Dictionary = _inputs.get(id, {})
			m = inp.get("move", Vector2.ZERO)
			yaw = float(inp.get("yaw", 0.0))
			cam_for_move = yaw
			j = bool(inp.get("jump", false))
			f = bool(inp.get("fire", false))
			r = bool(inp.get("reload", false))
		if _over:
			m = Vector2.ZERO
			f = false
			j = false
		_host_update_avatar(a, m, cam_for_move, yaw, j, f, r, delta)

	_send_accum += delta
	if _send_accum >= SEND_INTERVAL:
		_send_accum = 0.0
		_broadcast_state()
	_score_accum += delta
	if _score_accum >= SCORE_INTERVAL:
		_score_accum = 0.0
		_sync_scores()


func _host_update_avatar(a: PlayerAvatar, move: Vector2, cam_yaw: float, aim_yaw: float, jump: bool, fire: bool, reload: bool, delta: float) -> void:
	if not a.alive:
		a.respawn_left -= delta
		if _combat and not _over and a.respawn_left <= 0.0:
			_respawn(a)
		return
	a.step(move, cam_yaw, jump, delta, aim_yaw if (fire or a.is_bot) else NAN)
	if not _combat or _over:
		return
	a.cooldown = maxf(0.0, a.cooldown - delta)
	var mag := int(_weapon["mag"])
	if a.reload_left > 0.0:
		a.reload_left -= delta
		if a.reload_left <= 0.0:
			a.reload_left = 0.0
			a.ammo = mag
	elif (reload and a.ammo < mag) or a.ammo <= 0:
		a.reload_left = float(_weapon["reload"])
	if fire and a.cooldown <= 0.0 and a.reload_left <= 0.0 and a.ammo > 0:
		_fire(a, aim_yaw)


func _can_damage(attacker: PlayerAvatar, victim: PlayerAvatar) -> bool:
	if attacker == victim:
		return false
	if _teams_mode:
		return attacker.team != victim.team
	return true


func _fire(a: PlayerAvatar, yaw: float) -> void:
	a.ammo -= 1
	a.cooldown = float(_weapon["cooldown"])
	var spread := _rng.randf_range(-float(_weapon["spread"]), float(_weapon["spread"]))
	var dir := Vector3(-sin(yaw + spread), 0.0, -cos(yaw + spread))
	var from := a.global_position + Vector3(0, 1.3, 0)
	var to := from + dir * float(_weapon["range"])
	var q := PhysicsRayQueryParameters3D.create(from, to)
	q.exclude = [a.get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	var end := to
	if not hit.is_empty():
		end = hit["position"]
		var victim := hit["collider"] as PlayerAvatar
		if victim != null and victim.alive and _can_damage(a, victim):
			_damage(victim, a, int(_weapon["damage"]))
	a.flash()
	_spawn_tracer(from, end)
	for pid in _ready_peers:
		if pid != 1:
			fx_shot.rpc_id(pid, from, end)


func _damage(victim: PlayerAvatar, attacker: PlayerAvatar, dmg: int) -> void:
	victim.hp -= dmg
	if victim.hp > 0:
		return
	victim.hp = 0
	victim.set_alive(false)
	victim.deaths += 1
	victim.respawn_left = RESPAWN_TIME
	attacker.kills += 1
	if _teams_mode:
		_team_scores[attacker.team] += 1
	_push_feed("%s  >  %s" % [attacker.display_name, victim.display_name])
	for pid in _ready_peers:
		if pid != 1:
			kill_feed.rpc_id(pid, attacker.display_name, victim.display_name)
	_sync_scores()
	_check_win(attacker)


func _respawn(a: PlayerAvatar) -> void:
	a.global_position = ArenaMap.SPAWNS[_rng.randi_range(0, ArenaMap.SPAWNS.size() - 1)]
	a.velocity = Vector3.ZERO
	a.hp = PlayerAvatar.MAX_HP
	a.ammo = int(_weapon["mag"])
	a.reload_left = 0.0
	a.cooldown = 0.0
	a.set_alive(true)


func _check_win(attacker: PlayerAvatar) -> void:
	var limit := int(_mode["limit"])
	if limit <= 0 or _over:
		return
	if _teams_mode:
		if int(_team_scores[0]) >= limit or int(_team_scores[1]) >= limit:
			_end_match()
	elif attacker.kills >= limit:
		_end_match()


func _end_match() -> void:
	if _over:
		return
	_over = true
	var title := "MATCH OVER"
	var board: Array = []
	for id in avatars:
		var a: PlayerAvatar = avatars[id]
		board.append([a.display_name + (" [BOT]" if a.is_bot else ""), a.kills, a.deaths, a.team])
	board.sort_custom(func(x, y): return int(x[1]) > int(y[1]) or (int(x[1]) == int(y[1]) and int(x[2]) < int(y[2])))
	if _teams_mode:
		if _team_scores[0] > _team_scores[1]:
			title = "TEAM A WINS  %d - %d" % [_team_scores[0], _team_scores[1]]
		elif _team_scores[1] > _team_scores[0]:
			title = "TEAM B WINS  %d - %d" % [_team_scores[1], _team_scores[0]]
		else:
			title = "DRAW  %d - %d" % [_team_scores[0], _team_scores[1]]
	elif board.size() > 0:
		var top: Array = board[0]
		var tied := board.size() > 1 and int(board[1][1]) == int(top[1])
		title = "DRAW" if tied else "%s WINS" % top[0]
	var lines: Array = []
	for row in board:
		lines.append("%s    %d / %d" % [row[0], row[1], row[2]])
	_sync_scores()
	_show_results(title, lines)
	for pid in _ready_peers:
		if pid != 1:
			show_results.rpc_id(pid, title, lines)


func _collect_scores() -> Dictionary:
	var d := {}
	for id in avatars:
		var a: PlayerAvatar = avatars[id]
		d[id] = [a.kills, a.deaths]
	return d


func _sync_scores() -> void:
	_scores = _collect_scores()
	for pid in _ready_peers:
		if pid != 1:
			apply_scores.rpc_id(pid, _scores, _team_scores, int(ceilf(_time_left)))


func _broadcast_state() -> void:
	var ids := PackedInt32Array()
	var pos := PackedVector3Array()
	var yaws := PackedFloat32Array()
	var hps := PackedInt32Array()
	var ammos := PackedInt32Array()
	for id in avatars:
		var a: PlayerAvatar = avatars[id]
		ids.append(int(id))
		pos.append(a.global_position)
		yaws.append(a.yaw)
		hps.append(a.hp)
		ammos.append(a.ammo)
	for pid in _ready_peers:
		if pid != 1:
			apply_state.rpc_id(pid, ids, pos, yaws, hps, ammos)


# ------------------------------------------------------------ presentation

func _spawn_tracer(from: Vector3, to: Vector3) -> void:
	var length := from.distance_to(to)
	if length < 0.1:
		return
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.04, 0.04, length)
	mi.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color("ffb347")
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	mi.global_position = (from + to) * 0.5
	mi.look_at(to)
	get_tree().create_timer(0.06).timeout.connect(mi.queue_free)


func _push_feed(text: String) -> void:
	_feed.append({"text": text, "until": Time.get_ticks_msec() / 1000.0 + 6.0})
	if _feed.size() > 5:
		_feed.pop_front()


func _show_results(title: String, lines: Array) -> void:
	_over = true
	var txt := title + "\n\n"
	for l in lines:
		txt += str(l) + "\n"
	txt += "\n" + ("Press END MATCH to return to the lobby." if multiplayer.is_server() else "Waiting for the host to return to the lobby...")
	_center_msg.text = txt
	_center_msg.visible = true


func _fmt_time(sec: float) -> String:
	var s := maxi(int(ceilf(sec)), 0)
	return "%d:%02d" % [s / 60, s % 60]


func local_avatar() -> PlayerAvatar:
	return avatars.get(multiplayer.get_unique_id())


func cam_yaw() -> float:
	return _cam_yaw


func is_ally(a: PlayerAvatar, b: PlayerAvatar) -> bool:
	return _teams_mode and a.team == b.team


func _flash_near(pos: Vector3) -> void:
	var best := 4.0
	var who: PlayerAvatar = null
	for id in avatars:
		var a: PlayerAvatar = avatars[id]
		var d := Vector2(a.global_position.x - pos.x, a.global_position.z - pos.z).length()
		if d < best:
			best = d
			who = a
	if who != null:
		who.flash()


func _process(delta: float) -> void:
	var mine := local_avatar()
	if mine:
		# Camera sits behind/above the shoulder and looks along the aim line,
		# so the crosshair marks where hitscan shots travel. A ray from the head
		# pulls the camera in front of walls so it never sits inside geometry.
		var fwd := Vector3(-sin(_cam_yaw), 0.0, -cos(_cam_yaw))
		var right := Vector3(cos(_cam_yaw), 0.0, -sin(_cam_yaw))
		var head := mine.global_position + Vector3(0, 1.4, 0)
		var desired := head - fwd * 5.0 + right * 0.9 + Vector3.UP * (1.2 - _cam_pitch * 3.0)
		var q := PhysicsRayQueryParameters3D.create(head, desired)
		q.collision_mask = 1
		var hit := get_world_3d().direct_space_state.intersect_ray(q)
		if not hit.is_empty():
			desired = hit["position"] + (head - desired).normalized() * 0.25
		_cam.global_position = desired
		_cam.look_at(head + fwd * 25.0)
		# Damage flash.
		if mine.hp < _last_hp and mine.alive:
			_damage_flash.color.a = 0.35
			create_tween().tween_property(_damage_flash, "color:a", 0.0, 0.35)
		_last_hp = mine.hp

	_info_accum += delta
	if _info_accum < 0.25:
		return
	_info_accum = 0.0
	var label := Net.connection_label()
	var net_short := "LOCAL NET" if (label.begins_with("LOCAL") or label.begins_with("THIS")) else "CHECK NETWORK"
	_info.text = "%s   %d ms   %d FPS" % [net_short, Net.get_my_ping_ms(), Engine.get_frames_per_second()]

	if _combat and mine:
		_hp_bar.value = mine.hp
		_hp_label.text = "HP %d" % mine.hp if mine.alive else "RESPAWNING..."
		_hp_fill.bg_color = UIKit.GOOD if mine.hp > 50 else (UIKit.GOLD if mine.hp > 25 else UIKit.BAD)
		var reloading := "\nRELOADING" if (mine.ammo <= 0 and mine.alive) else "\n%d / %d" % [mine.ammo, int(_weapon["mag"])]
		_ammo_label.text = str(_weapon["name"]) + reloading
	if _combat:
		var t := _fmt_time(_time_left) if float(_mode["time"]) > 0.0 else ""
		if _teams_mode:
			t += "\nA %d  -  %d B" % [_team_scores[0], _team_scores[1]]
		_timer_label.text = t
		var rows: Array = []
		for id in _scores:
			var a: PlayerAvatar = avatars.get(id)
			if a != null:
				rows.append([a.display_name, int(_scores[id][0]), int(_scores[id][1])])
		rows.sort_custom(func(x, y): return int(x[1]) > int(y[1]))
		var txt := "TOP  K / D\n"
		for i in mini(rows.size(), 5):
			txt += "%s  %d / %d\n" % [rows[i][0], rows[i][1], rows[i][2]]
		_score_label.text = txt

	var now := Time.get_ticks_msec() / 1000.0
	_feed = _feed.filter(func(e): return float(e["until"]) > now)
	var ft := ""
	for e in _feed:
		ft += str(e["text"]) + "\n"
	_feed_label.text = ft
