class_name ArenaMap
extends RefCounted
## "Depot Yard": a 160 x 160 m outdoor map built entirely in code (no imported art).
## Layout: central raised plaza with ramps, 6 enterable buildings (two doors each),
## container yards, crate clusters, jersey barriers, 2 climbable watchtowers, trees.
## Everything is deterministic so every device builds the identical collision world.
## Textures are procedural noise (tri-planar) so there are no image files to ship.

const HALF := 80.0
const SPAWNS := [
	Vector3(-70, 0.3, -70), Vector3(70, 0.3, -70), Vector3(-70, 0.3, 70), Vector3(70, 0.3, 70),
	Vector3(0, 0.3, -72), Vector3(0, 0.3, 72), Vector3(-72, 0.3, 0), Vector3(72, 0.3, 0),
	Vector3(-36, 0.3, -72), Vector3(36, 0.3, -72), Vector3(-36, 0.3, 72), Vector3(36, 0.3, 72),
]

# name -> [colour, texture scale (1/metres), noise frequency, roughness]
const MAT_DEFS := {
	"ground": [Color("8a7f68"), 0.12, 0.02, 1.0],
	"asphalt": [Color("3b3d42"), 0.2, 0.05, 0.95],
	"concrete": [Color("a5a6a8"), 0.25, 0.03, 0.95],
	"concrete_dark": [Color("66686d"), 0.25, 0.03, 0.95],
	"brick": [Color("9a5a44"), 0.5, 0.08, 0.95],
	"metal": [Color("56606a"), 0.4, 0.06, 0.6],
	"wood": [Color("8a6038"), 0.6, 0.1, 0.9],
	"roof": [Color("3a3d44"), 0.3, 0.04, 0.9],
	"c_red": [Color("a8322d"), 0.5, 0.07, 0.7],
	"c_blue": [Color("2f5d9e"), 0.5, 0.07, 0.7],
	"c_green": [Color("3b7a4a"), 0.5, 0.07, 0.7],
	"c_yellow": [Color("c79a2a"), 0.5, 0.07, 0.7],
	"c_orange": [Color("d0661e"), 0.5, 0.07, 0.7],
	"trunk": [Color("5a3d24"), 0.8, 0.1, 1.0],
	"leaf": [Color("3c6e3a"), 0.4, 0.08, 1.0],
	"barrel": [Color("b13a2e"), 0.8, 0.06, 0.6],
}

var _root: Node3D
var _mats := {}
var _noise := {}
var _quality := 1


func build(root: Node3D, quality: int) -> void:
	_root = root
	_quality = quality
	_ground_and_walls()
	_plaza()
	_building(Vector3(-38, 0, -30), 16, 12, 5.5, "ns", "brick")
	_building(Vector3(40, 0, -34), 14, 14, 5.5, "ew", "concrete")
	_building(Vector3(-42, 0, 34), 14, 12, 5.5, "ew", "brick")
	_building(Vector3(36, 0, 38), 18, 12, 5.5, "ns", "concrete")
	_building(Vector3(0, 0, -52), 20, 10, 5.5, "ns", "brick")
	_building(Vector3(0, 0, 52), 20, 10, 5.5, "ns", "concrete")
	_containers()
	_crates()
	_barriers()
	_tower(Vector3(60, 0, 22), -1.0)
	_tower(Vector3(-60, 0, -22), 1.0)
	if quality >= 1:
		_barrels()
		_trees()


# ----------------------------------------------------------------- materials

func _get_noise(freq: float) -> NoiseTexture2D:
	var key := str(freq)
	if _noise.has(key):
		return _noise[key]
	var n := FastNoiseLite.new()
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.frequency = freq
	var g := Gradient.new()
	g.set_color(0, Color(0.72, 0.72, 0.72))
	g.set_color(1, Color.WHITE)
	var t := NoiseTexture2D.new()
	t.noise = n
	t.width = 256
	t.height = 256
	t.seamless = true
	t.color_ramp = g
	_noise[key] = t
	return t


func _get_mat(name: String) -> StandardMaterial3D:
	if _mats.has(name):
		return _mats[name]
	var d: Array = MAT_DEFS[name]
	var m := StandardMaterial3D.new()
	m.albedo_color = d[0]
	m.albedo_texture = _get_noise(float(d[2]))
	m.uv1_triplanar = true
	var s := float(d[1])
	m.uv1_scale = Vector3(s, s, s)
	m.roughness = float(d[3])
	_mats[name] = m
	return m


# ------------------------------------------------------------------ helpers

func _box(pos: Vector3, size: Vector3, mat: String, rot := Vector3.ZERO, collide := true) -> Node3D:
	var node: Node3D
	if collide:
		var body := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = size
		cs.shape = bs
		body.add_child(cs)
		node = body
	else:
		node = Node3D.new()
	node.position = pos
	node.rotation_degrees = rot
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _get_mat(mat)
	node.add_child(mi)
	_root.add_child(node)
	return node


func _cyl(pos: Vector3, radius: float, height: float, mat: String, collide := true) -> Node3D:
	var node: Node3D
	if collide:
		var body := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var shp := CylinderShape3D.new()
		shp.radius = radius
		shp.height = height
		cs.shape = shp
		body.add_child(cs)
		node = body
	else:
		node = Node3D.new()
	node.position = pos
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = 10
	mi.mesh = cm
	mi.material_override = _get_mat(mat)
	node.add_child(mi)
	_root.add_child(node)
	return node


# ------------------------------------------------------------------- terrain

func _ground_and_walls() -> void:
	_box(Vector3(0, -0.5, 0), Vector3(172, 1, 172), "ground")
	# Roads (visual only).
	_box(Vector3(0, 0.02, 0), Vector3(12, 0.04, 160), "asphalt", Vector3.ZERO, false)
	_box(Vector3(0, 0.025, 0), Vector3(160, 0.04, 12), "asphalt", Vector3.ZERO, false)
	# Perimeter.
	_box(Vector3(0, 4, -81), Vector3(166, 8, 2), "concrete_dark")
	_box(Vector3(0, 4, 81), Vector3(166, 8, 2), "concrete_dark")
	_box(Vector3(-81, 4, 0), Vector3(2, 8, 166), "concrete_dark")
	_box(Vector3(81, 4, 0), Vector3(2, 8, 166), "concrete_dark")


func _plaza() -> void:
	_box(Vector3(0, 0.6, 0), Vector3(16, 1.2, 16), "concrete")
	# Ramps (rise 1.2 m over 8 m).
	_box(Vector3(0, 0.45, 12), Vector3(6, 0.3, 8.1), "concrete", Vector3(-8.5, 0, 0))
	_box(Vector3(0, 0.45, -12), Vector3(6, 0.3, 8.1), "concrete", Vector3(8.5, 0, 0))
	_box(Vector3(12, 0.45, 0), Vector3(8.1, 0.3, 6), "concrete", Vector3(0, 0, -8.5))
	_box(Vector3(-12, 0.45, 0), Vector3(8.1, 0.3, 6), "concrete", Vector3(0, 0, 8.5))
	_cyl(Vector3(0, 1.8, 0), 2.2, 1.2, "concrete_dark")
	for sx in [-5.5, 5.5]:
		for sz in [-5.5, 5.5]:
			_box(Vector3(sx, 2.0, sz), Vector3(1.6, 1.6, 1.6), "wood", Vector3(0, 20.0 * sx, 0))


# ----------------------------------------------------------------- buildings

## doors: "ns" = doorways in the north/south walls, "ew" = east/west walls.
func _building(c: Vector3, w: float, d: float, h: float, doors: String, wall_mat: String) -> void:
	var t := 0.5
	var ns := doors == "ns"
	for side in [-1.0, 1.0]:
		var z: float = c.z + side * (d * 0.5 - t * 0.5)
		if ns:
			_wall_door_x(c.x, z, w, h, t, wall_mat)
		else:
			_box(Vector3(c.x, h * 0.5, z), Vector3(w, h, t), wall_mat)
	var inner := d - 2.0 * t
	for side in [-1.0, 1.0]:
		var x: float = c.x + side * (w * 0.5 - t * 0.5)
		if ns:
			_box(Vector3(x, h * 0.5, c.z), Vector3(t, h, inner), wall_mat)
		else:
			_wall_door_z(x, c.z, inner, h, t, wall_mat)
	_box(Vector3(c.x, h + 0.2, c.z), Vector3(w + 0.4, 0.4, d + 0.4), "roof")
	# Interior cover.
	_box(Vector3(c.x - w * 0.28, 0.8, c.z - d * 0.2), Vector3(1.6, 1.6, 1.6), "wood", Vector3(0, 15, 0))
	_box(Vector3(c.x + w * 0.28, 0.8, c.z + d * 0.2), Vector3(1.6, 1.6, 1.6), "wood", Vector3(0, -20, 0))
	if ns:
		_box(Vector3(c.x + w * 0.2, 0.6, c.z), Vector3(w * 0.3, 1.2, 0.3), "concrete_dark")
	else:
		_box(Vector3(c.x, 0.6, c.z + d * 0.2), Vector3(0.3, 1.2, d * 0.3), "concrete_dark")


func _wall_door_x(cx: float, z: float, length: float, h: float, t: float, mat: String) -> void:
	var dw := 3.4
	var dh := 3.0
	var seg := (length - dw) * 0.5
	for s in [-1.0, 1.0]:
		_box(Vector3(cx + s * (dw * 0.5 + seg * 0.5), h * 0.5, z), Vector3(seg, h, t), mat)
	_box(Vector3(cx, dh + (h - dh) * 0.5, z), Vector3(dw, h - dh, t), mat)


func _wall_door_z(x: float, cz: float, length: float, h: float, t: float, mat: String) -> void:
	var dw := 3.4
	var dh := 3.0
	var seg := (length - dw) * 0.5
	for s in [-1.0, 1.0]:
		_box(Vector3(x, h * 0.5, cz + s * (dw * 0.5 + seg * 0.5)), Vector3(t, h, seg), mat)
	_box(Vector3(x, dh + (h - dh) * 0.5, cz), Vector3(t, h - dh, dw), mat)


# ----------------------------------------------------------- yards and props

func _container(x: float, z: float, rot_y: float, mat: String, top_mat := "") -> void:
	_box(Vector3(x, 1.3, z), Vector3(12, 2.6, 2.4), mat, Vector3(0, rot_y, 0))
	if top_mat != "":
		_box(Vector3(x, 3.9, z), Vector3(12, 2.6, 2.4), top_mat, Vector3(0, rot_y, 0))


func _containers() -> void:
	# South yard.
	_container(-20, 26, 0, "c_red")
	_container(-5, 26, 0, "c_blue", "c_yellow")
	_container(10, 26, 0, "c_green")
	_container(-12, 36, 90, "c_orange")
	_container(4, 36, 90, "c_red")
	# North yard.
	_container(-10, -26, 0, "c_green")
	_container(5, -26, 0, "c_red", "c_blue")
	_container(20, -26, 0, "c_blue")
	_container(-4, -37, 90, "c_yellow")
	_container(12, -37, 90, "c_orange")
	# East and west flanks.
	_container(60, -10, 90, "c_blue")
	_container(60, 6, 90, "c_red")
	_container(52, -20, 0, "c_green")
	_container(-60, -6, 90, "c_green")
	_container(-60, 12, 90, "c_red")
	_container(-52, 22, 0, "c_blue")


func _crate_stack(base: Vector3, count: int, rot_y: float) -> void:
	var r := Vector3(0, rot_y, 0)
	_box(base + Vector3(0, 0.8, 0), Vector3(1.6, 1.6, 1.6), "wood", r)
	if count >= 2:
		_box(base + Vector3(1.8, 0.8, 0).rotated(Vector3.UP, deg_to_rad(rot_y)), Vector3(1.6, 1.6, 1.6), "wood", r)
	if count >= 3:
		_box(base + Vector3(0.9, 2.4, 0).rotated(Vector3.UP, deg_to_rad(rot_y)), Vector3(1.6, 1.6, 1.6), "wood", r)


func _crates() -> void:
	var list := [
		[Vector3(-26, 0, 8), 2, 10.0], [Vector3(26, 0, -8), 3, -15.0], [Vector3(-14, 0, -14), 2, 0.0],
		[Vector3(16, 0, 14), 3, 20.0], [Vector3(-30, 0, -6), 1, 0.0], [Vector3(30, 0, 8), 2, 30.0],
		[Vector3(-48, 0, 14), 3, 0.0], [Vector3(46, 0, -14), 2, 10.0], [Vector3(0, 0, -20), 2, 0.0],
		[Vector3(-8, 0, 18), 2, 0.0], [Vector3(10, 0, -18), 1, 0.0], [Vector3(-52, 0, 48), 2, 0.0],
		[Vector3(52, 0, -52), 3, 0.0], [Vector3(-56, 0, -48), 2, 0.0], [Vector3(54, 0, 52), 2, 25.0],
	]
	for e in list:
		_crate_stack(e[0], int(e[1]), float(e[2]))


func _barriers() -> void:
	var list := [
		[Vector3(-22, 0.5, 0), 90.0], [Vector3(22, 0.5, 0), 90.0], [Vector3(-34, 0.5, -8), 90.0],
		[Vector3(34, 0.5, 6), 90.0], [Vector3(20, 0.5, 30), 0.0], [Vector3(-24, 0.5, -18), 45.0],
		[Vector3(-20, 0.5, 46), 0.0], [Vector3(24, 0.5, -48), 0.0], [Vector3(46, 0.5, 20), 90.0],
		[Vector3(-46, 0.5, -10), 90.0],
	]
	for e in list:
		_box(e[0], Vector3(3, 1, 0.7), "concrete", Vector3(0, float(e[1]), 0))


func _barrels() -> void:
	var list := [
		Vector3(-47, 0.55, -37), Vector3(-46, 0.55, -36.2), Vector3(48, 0.55, -42), Vector3(31, 0.55, 45),
		Vector3(30, 0.55, 44), Vector3(-34, 0.55, 42), Vector3(12, 0.55, 58), Vector3(-12, 0.55, -58),
		Vector3(-11, 0.55, -58.8), Vector3(26, 0.55, -16),
	]
	for p in list:
		_cyl(p, 0.4, 1.1, "barrel")


func _trees() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 424242  # fixed seed: identical trees on every device
	var placed := 0
	var tries := 0
	while placed < 18 and tries < 400:
		tries += 1
		var ang := rng.randf() * TAU
		var rad := rng.randf_range(60.0, 68.0)
		var p := Vector3(cos(ang) * rad, 0, sin(ang) * rad)
		if absf(p.x) > 74.0 or absf(p.z) > 74.0:
			continue
		var near_spawn := false
		for s in SPAWNS:
			if Vector2(p.x - s.x, p.z - s.z).length() < 9.0:
				near_spawn = true
		if near_spawn or (absf(p.x) < 8.0) or (absf(p.z) < 8.0):
			continue
		_cyl(p + Vector3(0, 2.0, 0), 0.35, 4.0, "trunk")
		_cyl(p + Vector3(0, 5.2, 0), 2.0, 3.2, "leaf", false)
		placed += 1


func _tower(c: Vector3, dir: float) -> void:
	var top := 5.0
	_box(Vector3(c.x, top, c.z), Vector3(6, 0.4, 6), "wood")
	for sx in [-2.6, 2.6]:
		for sz in [-2.6, 2.6]:
			_box(Vector3(c.x + sx, top * 0.5, c.z + sz), Vector3(0.5, top, 0.5), "wood")
	# Railings on three sides; the ramp side stays open.
	_box(Vector3(c.x, top + 0.7, c.z - 2.9), Vector3(6, 1.0, 0.2), "wood")
	_box(Vector3(c.x, top + 0.7, c.z + 2.9), Vector3(6, 1.0, 0.2), "wood")
	_box(Vector3(c.x - dir * 2.9, top + 0.7, c.z), Vector3(0.2, 1.0, 6), "wood")
	# Ramp: 14 m run, 5 m rise (about 21 degrees).
	_box(Vector3(c.x + dir * 10.0, 2.5, c.z), Vector3(14.9, 0.4, 3.2), "wood", Vector3(0, 0, -dir * 20.9))
