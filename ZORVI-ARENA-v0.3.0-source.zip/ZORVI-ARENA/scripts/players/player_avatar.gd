class_name PlayerAvatar
extends CharacterBody3D
## One participant's body (human or bot). The host simulates every avatar
## (authoritative). A client simulates only its own avatar (prediction) and
## smooths all others toward the positions the host sends.
## Physics layers: 1 = world, 2 = players. Players collide with both.

const SPEED := 6.5
const ACCEL := 40.0
const JUMP_VELOCITY := 6.5
const GRAVITY := 20.0
const MAX_HP := 100

var peer_id := 0
var display_name := ""
var team := 0
var is_bot := false
var weapon_id := "rifle"
var remote_driven := false      # true on clients for other participants
var target_pos := Vector3.ZERO
var target_yaw := 0.0
var yaw := 0.0

# Combat state: authoritative on host, mirrored to clients for HUD/visibility.
var hp := MAX_HP
var ammo := 0
var alive := true
var cooldown := 0.0
var reload_left := 0.0
var respawn_left := 0.0
var kills := 0
var deaths := 0

var _label: Label3D
var _model: PlayerModel
var _prev_pos := Vector3.ZERO


func setup(p_id: int, p_name: String, color: Color, spawn: Vector3) -> void:
	peer_id = p_id
	display_name = p_name
	position = spawn
	target_pos = spawn
	_prev_pos = spawn
	collision_layer = 2
	collision_mask = 3

	var shape := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	shape.shape = cap
	shape.position.y = 0.9
	add_child(shape)

	_model = PlayerModel.new()
	add_child(_model)
	_model.build(color, weapon_id == "sniper")

	_label = Label3D.new()
	_label.text = p_name + (" [BOT]" if is_bot else "")
	_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_label.pixel_size = 0.005
	_label.font_size = 48
	_label.outline_size = 12
	_label.no_depth_test = false
	_label.position.y = 2.15
	add_child(_label)


func set_alive(v: bool) -> void:
	alive = v
	visible = v
	collision_layer = 2 if v else 0


func flash() -> void:
	if _model:
		_model.flash()


## Shared movement step. `move` is in the frame given by `cam_yaw`
## (bots pass world-space move with cam_yaw 0). If `face_yaw` is a number the body
## turns to it (aiming); otherwise it faces the movement direction.
func step(move: Vector2, cam_yaw: float, jump: bool, delta: float, face_yaw := NAN) -> void:
	var dir := Vector3(move.x, 0.0, move.y).rotated(Vector3.UP, cam_yaw)
	if dir.length() > 1.0:
		dir = dir.normalized()
	var hv := Vector2(velocity.x, velocity.z).move_toward(Vector2(dir.x, dir.z) * SPEED, ACCEL * delta)
	velocity.x = hv.x
	velocity.z = hv.y
	if is_on_floor():
		if jump:
			velocity.y = JUMP_VELOCITY
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()
	if not is_nan(face_yaw):
		yaw = lerp_angle(yaw, face_yaw, minf(1.0, 14.0 * delta))
		rotation.y = yaw
	elif dir.length() > 0.1:
		yaw = lerp_angle(yaw, atan2(-dir.x, -dir.z), minf(1.0, 12.0 * delta))
		rotation.y = yaw


func _process(delta: float) -> void:
	var speed := 0.0
	var grounded := true
	if remote_driven:
		var k := 1.0 - exp(-14.0 * delta)
		global_position = global_position.lerp(target_pos, k)
		yaw = lerp_angle(yaw, target_yaw, k)
		rotation.y = yaw
		speed = Vector2(global_position.x - _prev_pos.x, global_position.z - _prev_pos.z).length() / maxf(delta, 0.0001)
		grounded = global_position.y < 0.7 or absf(global_position.y - _prev_pos.y) < 0.02
		_prev_pos = global_position
	else:
		speed = Vector2(velocity.x, velocity.z).length()
		grounded = is_on_floor()
	if _model and visible:
		_model.animate(speed, delta, grounded)
