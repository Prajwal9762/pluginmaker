class_name PlayerModel
extends Node3D
## Low-poly humanoid built from primitives (no external assets): legs, torso with a
## team-coloured vest, arms holding a rifle/sniper, helmet + visor, blob shadow,
## procedural walk cycle and a muzzle flash. Faces -Z.

static var _cache := {}

var _phase := 0.0
var _swing := 0.0
var _legs: Array[Node3D] = []
var _arm_l: Node3D
var _arm_r: Node3D
var _torso: Node3D
var _flash: MeshInstance3D
var _flash_t := 0.0


static func _mat(color: Color, rough := 0.85, unshaded := false, alpha := 1.0) -> StandardMaterial3D:
	var key := "%s_%s_%s_%s" % [color.to_html(), rough, unshaded, alpha]
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(color.r, color.g, color.b, alpha)
	m.roughness = rough
	if unshaded:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_cache[key] = m
	return m


func _part(parent: Node3D, mesh: Mesh, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	parent.add_child(mi)
	return mi


func _box(size: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = size
	return b


func _sphere(r: float, squash := 1.0) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0 * squash
	s.radial_segments = 12
	s.rings = 6
	return s


func build(team_color: Color, sniper := false) -> void:
	var skin := _mat(Color("c68e6a"), 0.8)
	var cloth := _mat(Color("2b2d33"), 0.9)
	var vest := _mat(team_color, 0.7)
	var dark := _mat(Color("15161a"), 0.5)
	var visor_m := _mat(Color("2a4a66"), 0.2)

	# Blob shadow keeps players grounded even with real shadows off (Low quality).
	var shadow := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.55
	cm.bottom_radius = 0.55
	cm.height = 0.02
	cm.radial_segments = 14
	shadow.mesh = cm
	shadow.position = Vector3(0, 0.03, 0)
	shadow.material_override = _mat(Color.BLACK, 1.0, true, 0.35)
	shadow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(shadow)

	# Legs (pivot at hip).
	for sx in [-0.12, 0.12]:
		var leg := Node3D.new()
		leg.position = Vector3(sx, 0.9, 0)
		add_child(leg)
		_part(leg, _box(Vector3(0.17, 0.78, 0.2)), Vector3(0, -0.4, 0), cloth)
		_part(leg, _box(Vector3(0.19, 0.12, 0.3)), Vector3(0, -0.84, -0.04), dark)
		_legs.append(leg)

	# Torso.
	_torso = Node3D.new()
	_torso.position = Vector3(0, 0.95, 0)
	add_child(_torso)
	_part(_torso, _box(Vector3(0.46, 0.58, 0.26)), Vector3(0, 0.28, 0), cloth)
	_part(_torso, _box(Vector3(0.5, 0.4, 0.3)), Vector3(0, 0.34, 0), vest)
	_part(_torso, _box(Vector3(0.16, 0.1, 0.06)), Vector3(0, 0.2, -0.17), dark)  # chest pouch

	# Head, helmet, visor.
	_part(_torso, _sphere(0.115), Vector3(0, 0.74, 0), skin)
	_part(_torso, _sphere(0.145, 0.8), Vector3(0, 0.79, 0.01), dark)
	_part(_torso, _box(Vector3(0.2, 0.06, 0.06)), Vector3(0, 0.76, -0.12), visor_m)

	# Arms (rotation.x > 0 swings the arm forward toward -Z).
	_arm_l = _make_arm(cloth, skin, Vector3(-0.31, 0.5, 0), 1.25, -0.5)
	_arm_r = _make_arm(cloth, skin, Vector3(0.31, 0.5, 0), 1.3, 0.35)

	# Weapon held in front of the chest.
	var length := 1.0 if sniper else 0.65
	var gun := Node3D.new()
	gun.position = Vector3(0.02, 0.36, -0.35 - length * 0.2)
	_torso.add_child(gun)
	_part(gun, _box(Vector3(0.07, 0.1, length)), Vector3.ZERO, dark)
	_part(gun, _box(Vector3(0.06, 0.12, 0.2)), Vector3(0, -0.01, length * 0.5 + 0.08), dark)
	_part(gun, _box(Vector3(0.05, 0.15, 0.08)), Vector3(0, -0.11, 0.05), dark)
	if sniper:
		_part(gun, _box(Vector3(0.05, 0.06, 0.26)), Vector3(0, 0.085, -0.05), visor_m)
	_flash = _part(gun, _sphere(0.1), Vector3(0, 0, -length * 0.5 - 0.08), _mat(Color("ffb347"), 1.0, true))
	_flash.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_flash.visible = false


func _make_arm(cloth: Material, skin: Material, shoulder: Vector3, bend: float, yaw: float) -> Node3D:
	var arm := Node3D.new()
	arm.position = shoulder
	arm.rotation = Vector3(bend, yaw, 0)
	_torso.add_child(arm)
	_part(arm, _box(Vector3(0.12, 0.5, 0.12)), Vector3(0, -0.24, 0), cloth)
	_part(arm, _sphere(0.065), Vector3(0, -0.52, 0), skin)
	return arm


func flash() -> void:
	_flash_t = 0.06
	if _flash:
		_flash.visible = true


## speed in m/s; call every frame.
func animate(speed: float, delta: float, grounded: bool) -> void:
	var k := clampf(speed / 6.5, 0.0, 1.2)
	if k > 0.05:
		_phase += delta * (5.0 + 6.0 * k)
	var target := sin(_phase) * 0.85 * k if grounded else 0.5
	_swing = lerpf(_swing, target, minf(1.0, 14.0 * delta))
	if _legs.size() == 2:
		_legs[0].rotation.x = _swing
		_legs[1].rotation.x = -_swing if grounded else _swing
	if _torso:
		_torso.position.y = 0.95 + absf(sin(_phase)) * 0.035 * k
	if _arm_l:
		_arm_l.rotation.x = 1.25 + sin(_phase * 2.0) * 0.04 * k
	if _flash_t > 0.0:
		_flash_t -= delta
		if _flash_t <= 0.0 and _flash:
			_flash.visible = false
