class_name Minimap
extends Control
## Round radar: you in the centre, "up" = the way you aim. Green = ally, red = enemy.

const RANGE_M := 45.0

var arena: Arena


func _init() -> void:
	custom_minimum_size = Vector2(150, 150)
	size = Vector2(150, 150)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _process(_delta: float) -> void:
	queue_redraw()


func _draw() -> void:
	var c := size * 0.5
	var r := minf(size.x, size.y) * 0.5
	draw_circle(c, r, Color(0, 0, 0, 0.5))
	draw_arc(c, r, 0.0, TAU, 48, Color(UIKit.ORANGE, 0.7), 2.0)
	draw_arc(c, r * 0.5, 0.0, TAU, 32, Color(1, 1, 1, 0.12), 1.0)
	if arena == null:
		return
	var me := arena.local_avatar()
	if me == null:
		return
	var yaw := arena.cam_yaw()
	var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
	var right := Vector3(cos(yaw), 0.0, -sin(yaw))
	for id in arena.avatars:
		var a: PlayerAvatar = arena.avatars[id]
		if a == me or not a.alive:
			continue
		var rel := a.global_position - me.global_position
		var p := Vector2(rel.dot(right), -rel.dot(fwd)) / RANGE_M * r
		if p.length() > r - 5.0:
			p = p.normalized() * (r - 5.0)
		var col := UIKit.GOOD if arena.is_ally(me, a) else Color("ff5560")
		draw_circle(c + p, 4.0, col)
	draw_colored_polygon(PackedVector2Array([c + Vector2(0, -8), c + Vector2(6, 6), c + Vector2(-6, 6)]), UIKit.GOLD)
